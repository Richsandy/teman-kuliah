// Server AI Teman Kuliah (Cloudflare Worker, satu file).
// Tugasnya: menyimpan API key milik pembuat aplikasi, membagi jatah harian per pengguna,
// dan memilih AI yang sedang kosong (Cerebras, Groq, Gemini). Pengguna aplikasi tidak perlu API key.
//
// Pengaturan di Cloudflare (Settings > Variables and Secrets):
//   Secret: CEREBRAS_KEY, GROQ_KEY, GEMINI_KEY   (isi minimal satu; Groq dibutuhkan untuk transkrip video)
//   Secret opsional: TG_TOKEN, TG_CHAT   (notifikasi Telegram), ADMIN_KEY (melihat statistik)
//   Variabel opsional: JATAH_MATERI, JATAH_CHAT, JATAH_LAIN, JATAH_VIDEO, KALI_IP
// Binding: D1 database dengan nama variabel DB.

const VERSI = "1.1";
const JATAH = { materi: 8, chat: 40, lain: 10, video: 6 };
const KALI_IP = 4; // satu alamat internet boleh memakai sampai 4x jatah satu orang (misalnya satu kos/wifi)

const AI = {
  // Beberapa model per layanan: tiap model punya jatah gratis sendiri, jadi kalau satu penuh dicoba yang lain
  cerebras: { key: "CEREBRAS_KEY", url: "https://api.cerebras.ai/v1/chat/completions", models: ["gpt-oss-120b"], maks: 400000 },
  groq:     { key: "GROQ_KEY", url: "https://api.groq.com/openai/v1/chat/completions", models: ["openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b"], maks: 24000 },
  gemini:   { key: "GEMINI_KEY", url: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", models: ["gemini-2.5-flash", "gemini-flash-latest", "gemini-2.5-flash-lite", "gemini-flash-lite-latest"], maks: 4000000 }
};
const URUTAN = {
  chat:   ["groq", "cerebras", "gemini"],
  materi: ["cerebras", "gemini", "groq"],
  lain:   ["cerebras", "gemini", "groq"]
};

const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "*", "Access-Control-Allow-Methods": "GET, POST, OPTIONS" };
const json = (obj, status = 200, extra = {}) => new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json", ...CORS, ...extra } });
const gagal = (status, code, message, extra) => json({ error: { code, message } }, status, extra);
const hariIni = () => new Date(Date.now() + 7 * 3600 * 1000).toISOString().slice(0, 10); // tanggal WIB
const detikKeTengahMalam = () => { const wib = Date.now() + 7 * 3600 * 1000; return Math.ceil((86400000 - (wib % 86400000)) / 1000); };

async function sha(s){
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("").slice(0, 32);
}

let siap = false;
async function siapkanDB(env){
  if (siap) return;
  await env.DB.batch([
    env.DB.prepare("CREATE TABLE IF NOT EXISTS pakai (hari TEXT, siapa TEXT, jenis TEXT, n INTEGER, PRIMARY KEY (hari, siapa, jenis))"),
    env.DB.prepare("CREATE TABLE IF NOT EXISTS catatan (k TEXT PRIMARY KEY, t INTEGER)")
  ]);
  siap = true;
}

function jatahDari(env){
  const n = (v, d) => { const x = parseInt(v, 10); return Number.isFinite(x) && x >= 0 ? x : d; };
  return { materi: n(env.JATAH_MATERI, JATAH.materi), chat: n(env.JATAH_CHAT, JATAH.chat), lain: n(env.JATAH_LAIN, JATAH.lain), video: n(env.JATAH_VIDEO, JATAH.video) };
}

async function siapaDia(req){
  const uid = String(req.headers.get("X-TK-User") || "");
  const dev = String(req.headers.get("X-TK-Device") || "");
  const ip = req.headers.get("CF-Connecting-IP") || "0";
  const orang = /^[a-f0-9]{16,64}$/.test(uid) ? "u:" + uid.slice(0, 32) : /^[a-zA-Z0-9-]{16,64}$/.test(dev) ? "d:" + dev : null;
  return { orang, ip: "ip:" + await sha("tk-ip:" + ip) };
}

async function hitung(env, hari, siapa, jenis){
  const r = await env.DB.prepare("SELECT n FROM pakai WHERE hari = ? AND siapa = ? AND jenis = ?").bind(hari, siapa, jenis).first();
  return r ? r.n : 0;
}
async function tambah(env, hari, siapa, jenis){
  await env.DB.prepare("INSERT INTO pakai (hari, siapa, jenis, n) VALUES (?, ?, ?, 1) ON CONFLICT (hari, siapa, jenis) DO UPDATE SET n = n + 1").bind(hari, siapa, jenis).run();
}

// Notifikasi Telegram ke pembuat aplikasi, paling sering sekali per jeda untuk tiap jenis pesan
async function kabari(env, ctx, jenis, pesan, jedaDetik = 3600){
  if (!env.TG_TOKEN || !env.TG_CHAT) return;
  const job = (async () => {
    const now = Math.floor(Date.now() / 1000);
    const r = await env.DB.prepare("SELECT t FROM catatan WHERE k = ?").bind("tg:" + jenis).first();
    if (r && now - r.t < jedaDetik) return;
    await env.DB.prepare("INSERT INTO catatan (k, t) VALUES (?, ?) ON CONFLICT (k) DO UPDATE SET t = excluded.t").bind("tg:" + jenis, now).run();
    await fetch(`https://api.telegram.org/bot${env.TG_TOKEN}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: env.TG_CHAT, text: "Teman Kuliah AI: " + pesan }) });
  })().catch(() => {});
  ctx.waitUntil(job);
}

// Cek jatah orang ini dan alamat internetnya. Mengembalikan Response kalau habis, atau null kalau masih ada.
async function cekJatah(env, ctx, who, jenis){
  const J = jatahDari(env), hari = hariIni(), batas = J[jenis];
  const kali = parseInt(env.KALI_IP, 10) || KALI_IP;
  const [a, b] = await Promise.all([who.orang ? hitung(env, hari, who.orang, jenis) : 0, hitung(env, hari, who.ip, jenis)]);
  const nama = { materi: "meringkas materi", chat: "Tanya AI", lain: "latihan soal dan rangkuman", video: "transkrip video" }[jenis];
  if ((who.orang && a >= batas) || b >= batas * kali){
    kabari(env, ctx, "jatah", `hari ini sudah ada pengguna yang menghabiskan jatah ${nama} (${batas}/hari). Kalau ini sering terjadi, jatah bisa dinaikkan di Variables, atau saatnya membuka paket Pro.`, 86400);
    return gagal(429, "tk_quota", `Jatah ${nama} hari ini sudah habis (${batas} per hari). Besok jam 00.00 WIB terisi lagi.`, { "Retry-After": String(detikKeTengahMalam()) });
  }
  return null;
}

async function catatPakai(env, ctx, who, jenis){
  const hari = hariIni();
  ctx.waitUntil(Promise.all([who.orang && tambah(env, hari, who.orang, jenis), tambah(env, hari, who.ip, jenis)].filter(Boolean)).catch(() => {}));
  if (Math.random() < 0.01) ctx.waitUntil(env.DB.prepare("DELETE FROM pakai WHERE hari < ?").bind(new Date(Date.now() - 3 * 86400000).toISOString().slice(0, 10)).run().catch(() => {}));
}

// Meneruskan permintaan chat ke AI yang sedang kosong. Isi permintaan tidak diurai (hemat CPU),
// cukup nama modelnya diganti. Aplikasi selalu menulis "model":"auto" di awal isi permintaan.
async function teruskanChat(req, env, ctx, who){
  const tugas = ["chat", "materi", "lain"].includes(req.headers.get("X-TK-Task")) ? req.headers.get("X-TK-Task") : "lain";
  const habis = await cekJatah(env, ctx, who, tugas); if (habis) return habis;
  const isi = await req.text();
  if (!isi.includes('"model":"auto"')) return gagal(400, "tk_bad", "Permintaan tidak dikenali. Perbarui aplikasi Teman Kuliah.");
  // Ada gambar slide: Gemini dulu karena bisa melihat gambar; model open source di Cerebras/Groq hanya membaca teks
  const urut = isi.includes('"image_url"') ? ["gemini", ...URUTAN[tugas].filter(p => p !== "gemini")] : URUTAN[tugas];
  const daftar = urut.filter(p => env[AI[p].key] && isi.length <= AI[p].maks);
  if (!daftar.length) return gagal(503, "tk_nokey", "Server AI belum diatur oleh pembuat aplikasi.");
  const catatan = [];
  for (const p of daftar){
    const A = AI[p], models = [...new Set([env[p.toUpperCase() + "_MODEL"], ...A.models].filter(Boolean))];
    let pindahLayanan = false;
    for (const m of models){
      let r;
      try {
        r = await fetch(A.url, { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + env[A.key] }, body: isi.replace('"model":"auto"', '"model":"' + m + '"') });
      } catch (e) { catatan.push(`${m}: koneksi gagal`); continue; }
      if (r.ok){
        catatPakai(env, ctx, who, tugas);
        return new Response(r.body, { status: 200, headers: { "Content-Type": r.headers.get("Content-Type") || "text/event-stream", "Cache-Control": "no-cache", "X-TK-AI": p + "/" + m, ...CORS } });
      }
      const teks = await r.text().catch(() => "");
      let pesan = teks; try { const j = JSON.parse(teks); const e = Array.isArray(j) ? j[0] && j[0].error : j.error; pesan = (e && (e.message || e.status)) || teks; } catch (x) {}
      catatan.push(`${m}: ${r.status} ${String(pesan).replace(/\s+/g, " ").slice(0, 140)}`);
      if (r.status === 401 || r.status === 403 || r.status === 402){
        kabari(env, ctx, "key-" + p, `API key ${p} ditolak (${r.status}: ${String(pesan).slice(0, 120)}). Mungkin key-nya salah, dihapus, atau kreditnya habis. Cek di Variables and Secrets. Pengguna sementara dilayani AI lain.`);
        break; // key bermasalah: model lain di layanan ini juga akan ditolak
      }
      // 400 karena format (gambar/JSON tidak didukung): pindah ke layanan berikutnya (Gemini bisa melihat gambar);
      // kalau tidak ada lagi, kembalikan ke aplikasi supaya dicoba ulang tanpa gambar/JSON
      if (r.status === 400 && /image|vision|multimodal|content type|response_format|json/i.test(teks)){
        if (p === daftar[daftar.length - 1]) return new Response(teks, { status: 400, headers: { "Content-Type": "application/json", ...CORS } });
        pindahLayanan = true; break;
      }
      // 404 (model tidak ada), 413 (terlalu panjang), 429 (jatah per menit/hari), 5xx (penuh): coba model berikutnya
    }
    if (pindahLayanan) continue;
  }
  kabari(env, ctx, "penuh", "semua AI sedang penuh atau menolak. " + catatan.join(" | ").slice(0, 600));
  return json({ error: { code: "tk_busy", message: "Semua AI gratis sedang penuh. Materimu masuk antrean dan dicoba lagi otomatis.", detail: catatan } }, 503, { "Retry-After": "600" });
}

// Transkrip video dengan Whisper (Groq). Isi formulir diteruskan apa adanya.
async function teruskanWhisper(req, env, ctx, who){
  if (!env.GROQ_KEY) return gagal(503, "tk_nokey", "Transkrip video belum diatur oleh pembuat aplikasi.");
  const habis = await cekJatah(env, ctx, who, "video"); if (habis) return habis;
  const r = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", { method: "POST", headers: { Authorization: "Bearer " + env.GROQ_KEY, "Content-Type": req.headers.get("Content-Type") || "" }, body: req.body });
  if (r.ok){ catatPakai(env, ctx, who, "video"); return new Response(r.body, { status: 200, headers: { "Content-Type": r.headers.get("Content-Type") || "text/plain", ...CORS } }); }
  const teks = await r.text().catch(() => "");
  if (r.status === 401 || r.status === 403) kabari(env, ctx, "key-groq", "API key Groq ditolak saat transkrip video. Cek di Variables and Secrets.");
  if (r.status === 429 || r.status >= 500) return gagal(503, "tk_busy", "Transkrip video sedang penuh. Dicoba lagi nanti.", { "Retry-After": "600" });
  return new Response(teks, { status: r.status, headers: { "Content-Type": "application/json", ...CORS } });
}

async function sisaJatah(env, who){
  const J = jatahDari(env), hari = hariIni(), out = {};
  for (const j of Object.keys(J)) out[j] = Math.max(0, J[j] - (who.orang ? await hitung(env, hari, who.orang, j) : 0));
  return json({ ok: true, hari, jatah: J, sisa: out, reset: detikKeTengahMalam(), ai: Object.keys(AI).filter(p => env[AI[p].key]) });
}

async function statistik(env, url){
  if (!env.ADMIN_KEY || url.searchParams.get("key") !== env.ADMIN_KEY) return gagal(403, "tk_forbidden", "Kunci admin salah.");
  const hari = url.searchParams.get("hari") || hariIni();
  const r = await env.DB.prepare("SELECT jenis, COUNT(DISTINCT siapa) AS orang, SUM(n) AS total FROM pakai WHERE hari = ? AND siapa NOT LIKE 'ip:%' GROUP BY jenis").bind(hari).all();
  const o = await env.DB.prepare("SELECT COUNT(DISTINCT siapa) AS orang FROM pakai WHERE hari = ? AND siapa NOT LIKE 'ip:%'").bind(hari).first();
  return json({ hari, pengguna: o ? o.orang : 0, per_jenis: r.results, jatah: jatahDari(env) });
}

export default {
  async fetch(req, env, ctx){
    const url = new URL(req.url);
    if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
    if (url.pathname === "/" || url.pathname === "/v1") return json({ ok: true, nama: "Teman Kuliah AI", versi: VERSI, ai: Object.keys(AI).filter(p => env[AI[p].key]), db: !!env.DB });
    if (!env.DB) return gagal(500, "tk_nodb", "Database belum dihubungkan (binding DB).");
    await siapkanDB(env);
    if (url.pathname === "/v1/stats") return statistik(env, url);
    if (req.headers.get("X-TK-App") !== "teman-kuliah") return gagal(403, "tk_app", "Server ini khusus aplikasi Teman Kuliah.");
    const who = await siapaDia(req);
    try {
      if (url.pathname === "/v1/quota" && req.method === "GET") return await sisaJatah(env, who);
      if (url.pathname === "/v1/chat/completions" && req.method === "POST") return await teruskanChat(req, env, ctx, who);
      if (url.pathname === "/v1/audio/transcriptions" && req.method === "POST") return await teruskanWhisper(req, env, ctx, who);
    } catch (e) {
      return gagal(500, "tk_error", "Server AI error: " + String(e && e.message || e).slice(0, 200));
    }
    return gagal(404, "tk_404", "Alamat tidak ditemukan.");
  }
};
