// Server AI Teman Kuliah (Cloudflare Worker, satu file).
// Tugasnya: menyimpan API key milik pembuat aplikasi, membagi jatah harian per pengguna,
// dan memilih AI yang sedang kosong (Cerebras, Groq, Gemini). Pengguna aplikasi tidak perlu API key.
//
// Pengaturan di Cloudflare (Settings > Variables and Secrets):
//   Secret: CEREBRAS_KEY, GROQ_KEY, GEMINI_KEY   (isi minimal satu; Groq dibutuhkan untuk transkrip video)
//   Secret opsional: TG_TOKEN, TG_CHAT   (notifikasi Telegram), ADMIN_KEY (melihat statistik)
//   Variabel opsional: JATAH_MATERI, JATAH_CHAT, JATAH_LAIN, JATAH_VIDEO, KALI_IP
// Binding: D1 database dengan nama variabel DB.
// Sejak 1.2: pusat pantau di https://alamat-worker/dash (butuh secret ADMIN_KEY). Mencatat unduhan GitHub,
// kunjungan website, dan perangkat yang memakai aplikasi, semuanya anonim. Opsional: Cron Trigger harian
// (Settings > Triggers) supaya angka unduhan tetap dicatat walau hari itu tidak ada pengunjung.

const VERSI = "1.3";
const REPO = "Richsandy/teman-kuliah";
const JATAH = { materi: 8, chat: 40, lain: 10, video: 6 };
const KALI_IP = 4; // satu alamat internet boleh memakai sampai 4x jatah satu orang (misalnya satu kos/wifi)

const AI = {
  // Beberapa model per layanan: tiap model punya jatah gratis sendiri, jadi kalau satu penuh dicoba yang lain
  cerebras: { key: "CEREBRAS_KEY", url: "https://api.cerebras.ai/v1/chat/completions", models: ["gpt-oss-120b"], maks: 400000 },
  groq:     { key: "GROQ_KEY", url: "https://api.groq.com/openai/v1/chat/completions", models: ["openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b"], maks: 24000 },
  gemini:   { key: "GEMINI_KEY", url: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", models: ["gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite"], maks: 4000000 }
};
const URUTAN = {
  chat:   ["groq", "cerebras", "gemini"],
  materi: ["cerebras", "gemini", "groq"],
  lain:   ["cerebras", "gemini", "groq"]
};

const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "*", "Access-Control-Allow-Methods": "GET, POST, OPTIONS" };
const json = (obj, status = 200, extra = {}) => new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json", ...CORS, ...extra } });
const gagal = (status, code, message, extra) => json({ error: { code, message } }, status, extra);
const hariIni = () => new Date(Date.now() + 7 * 3600 * 1000).toISOString().slice(0, 10); // tanggal WIB
const detikKeTengahMalam = () => { const wib = Date.now() + 7 * 3600 * 1000; return Math.ceil((86400000 - (wib % 86400000)) / 1000); };

async function sha(s){
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("").slice(0, 32);
}

let siap = false;
async function siapkanDB(env){
  if (siap) return;
  await env.DB.batch([
    env.DB.prepare("CREATE TABLE IF NOT EXISTS pakai (hari TEXT, siapa TEXT, jenis TEXT, n INTEGER, PRIMARY KEY (hari, siapa, jenis))"),
    env.DB.prepare("CREATE TABLE IF NOT EXISTS catatan (k TEXT PRIMARY KEY, t INTEGER)"),
    // Statistik (1.2). Semua anonim: perangkat dan pengunjung disimpan sebagai sidik acak, bukan nama.
    env.DB.prepare("CREATE TABLE IF NOT EXISTS perangkat (dev TEXT PRIMARY KEY, pertama TEXT, terakhir TEXT, ver TEXT, plat TEXT, edlink INTEGER)"),
    env.DB.prepare("CREATE TABLE IF NOT EXISTS aktif (hari TEXT, dev TEXT, ver TEXT, plat TEXT, PRIMARY KEY (hari, dev))"),
    env.DB.prepare("CREATE TABLE IF NOT EXISTS web (hari TEXT, jenis TEXT, kunci TEXT, n INTEGER, PRIMARY KEY (hari, jenis, kunci))"),
    env.DB.prepare("CREATE TABLE IF NOT EXISTS unduh (hari TEXT, tag TEXT, aset TEXT, n INTEGER, PRIMARY KEY (hari, tag, aset))"),
    env.DB.prepare("CREATE TABLE IF NOT EXISTS simpan (k TEXT PRIMARY KEY, t INTEGER, v TEXT)"),
    // Pengumuman (1.3): dikirim dari papan pantau, diambil aplikasi saat ping
    env.DB.prepare("CREATE TABLE IF NOT EXISTS pesan (id INTEGER PRIMARY KEY AUTOINCREMENT, dibuat INTEGER, judul TEXT, isi TEXT, link TEXT, jenis TEXT, plat TEXT, verdi TEXT, sampai INTEGER, aktif INTEGER)"),
    env.DB.prepare("CREATE TABLE IF NOT EXISTS pesan_terima (pesan_id INTEGER, dev TEXT, t INTEGER, PRIMARY KEY (pesan_id, dev))")
  ]);
  siap = true;
}

function jatahDari(env){
  const n = (v, d) => { const x = parseInt(v, 10); return Number.isFinite(x) && x >= 0 ? x : d; };
  return { materi: n(env.JATAH_MATERI, JATAH.materi), chat: n(env.JATAH_CHAT, JATAH.chat), lain: n(env.JATAH_LAIN, JATAH.lain), video: n(env.JATAH_VIDEO, JATAH.video) };
}

async function siapaDia(req){
  const uid = String(req.headers.get("X-TK-User") || "");
  const dev = String(req.headers.get("X-TK-Device") || "");
  const ip = req.headers.get("CF-Connecting-IP") || "0";
  const orang = /^[a-f0-9]{16,64}$/.test(uid) ? "u:" + uid.slice(0, 32) : /^[a-zA-Z0-9-]{16,64}$/.test(dev) ? "d:" + dev : null;
  return { orang, ip: "ip:" + await sha("tk-ip:" + ip) };
}

async function hitung(env, hari, siapa, jenis){
  const r = await env.DB.prepare("SELECT n FROM pakai WHERE hari = ? AND siapa = ? AND jenis = ?").bind(hari, siapa, jenis).first();
  return r ? r.n : 0;
}
async function tambah(env, hari, siapa, jenis){
  await env.DB.prepare("INSERT INTO pakai (hari, siapa, jenis, n) VALUES (?, ?, ?, 1) ON CONFLICT (hari, siapa, jenis) DO UPDATE SET n = n + 1").bind(hari, siapa, jenis).run();
}

// Notifikasi Telegram ke pembuat aplikasi, paling sering sekali per jeda untuk tiap jenis pesan
async function kabari(env, ctx, jenis, pesan, jedaDetik = 3600){
  if (!env.TG_TOKEN || !env.TG_CHAT) return;
  const job = (async () => {
    const now = Math.floor(Date.now() / 1000);
    const r = await env.DB.prepare("SELECT t FROM catatan WHERE k = ?").bind("tg:" + jenis).first();
    if (r && now - r.t < jedaDetik) return;
    await env.DB.prepare("INSERT INTO catatan (k, t) VALUES (?, ?) ON CONFLICT (k) DO UPDATE SET t = excluded.t").bind("tg:" + jenis, now).run();
    await fetch(`https://api.telegram.org/bot${env.TG_TOKEN}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: env.TG_CHAT, text: "Teman Kuliah AI: " + pesan }) });
  })().catch(() => {});
  ctx.waitUntil(job);
}

// Cek jatah orang ini dan alamat internetnya. Mengembalikan Response kalau habis, atau null kalau masih ada.
async function cekJatah(env, ctx, who, jenis){
  const J = jatahDari(env), hari = hariIni(), batas = J[jenis];
  const kali = parseInt(env.KALI_IP, 10) || KALI_IP;
  const [a, b] = await Promise.all([who.orang ? hitung(env, hari, who.orang, jenis) : 0, hitung(env, hari, who.ip, jenis)]);
  const nama = { materi: "meringkas materi", chat: "Tanya AI", lain: "latihan soal dan rangkuman", video: "transkrip video" }[jenis];
  if ((who.orang && a >= batas) || b >= batas * kali){
    kabari(env, ctx, "jatah", `hari ini sudah ada pengguna yang menghabiskan jatah ${nama} (${batas}/hari). Kalau ini sering terjadi, jatah bisa dinaikkan di Variables, atau saatnya membuka paket Pro.`, 86400);
    return gagal(429, "tk_quota", `Jatah ${nama} hari ini sudah habis (${batas} per hari). Besok jam 00.00 WIB terisi lagi.`, { "Retry-After": String(detikKeTengahMalam()) });
  }
  return null;
}

async function catatPakai(env, ctx, who, jenis){
  const hari = hariIni();
  ctx.waitUntil(Promise.all([who.orang && tambah(env, hari, who.orang, jenis), tambah(env, hari, who.ip, jenis)].filter(Boolean)).catch(() => {}));
  if (Math.random() < 0.01) ctx.waitUntil(env.DB.prepare("DELETE FROM pakai WHERE (siapa LIKE 'ip:%' AND hari < ?) OR hari < ?").bind(new Date(Date.now() - 3 * 86400000).toISOString().slice(0, 10), new Date(Date.now() - 400 * 86400000).toISOString().slice(0, 10)).run().catch(() => {}));
}

// Meneruskan permintaan chat ke AI yang sedang kosong. Isi permintaan tidak diurai (hemat CPU),
// cukup nama modelnya diganti. Aplikasi selalu menulis "model":"auto" di awal isi permintaan.
async function teruskanChat(req, env, ctx, who){
  const tugas = ["chat", "materi", "lain"].includes(req.headers.get("X-TK-Task")) ? req.headers.get("X-TK-Task") : "lain";
  const habis = await cekJatah(env, ctx, who, tugas); if (habis) return habis;
  const isi = await req.text();
  if (!isi.includes('"model":"auto"')) return gagal(400, "tk_bad", "Permintaan tidak dikenali. Perbarui aplikasi Teman Kuliah.");
  // Ada gambar slide: Gemini dulu karena bisa melihat gambar; model open source di Cerebras/Groq hanya membaca teks
  const urut = isi.includes('"image_url"') ? ["gemini", ...URUTAN[tugas].filter(p => p !== "gemini")] : URUTAN[tugas];
  const daftar = urut.filter(p => env[AI[p].key] && isi.length <= AI[p].maks);
  if (!daftar.length) return gagal(503, "tk_nokey", "Server AI belum diatur oleh pembuat aplikasi.");
  const catatan = [];
  for (const p of daftar){
    const A = AI[p], models = [...new Set([env[p.toUpperCase() + "_MODEL"], ...A.models].filter(Boolean))];
    let pindahLayanan = false;
    for (const m of models){
      let r;
      try {
        r = await fetch(A.url, { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + env[A.key] }, body: isi.replace('"model":"auto"', '"model":"' + m + '"') });
      } catch (e) { catatan.push(`${m}: koneksi gagal`); continue; }
      if (r.ok){
        catatPakai(env, ctx, who, tugas);
        return new Response(r.body, { status: 200, headers: { "Content-Type": r.headers.get("Content-Type") || "text/event-stream", "Cache-Control": "no-cache", "X-TK-AI": p + "/" + m, ...CORS } });
      }
      const teks = await r.text().catch(() => "");
      let pesan = teks; try { const j = JSON.parse(teks); const e = Array.isArray(j) ? j[0] && j[0].error : j.error; pesan = (e && (e.message || e.status)) || teks; } catch (x) {}
      catatan.push(`${m}: ${r.status} ${String(pesan).replace(/\s+/g, " ").slice(0, 140)}`);
      if (r.status === 401 || r.status === 403 || r.status === 402){
        kabari(env, ctx, "key-" + p, `API key ${p} ditolak (${r.status}: ${String(pesan).slice(0, 120)}). Mungkin key-nya salah, dihapus, atau kreditnya habis. Cek di Variables and Secrets. Pengguna sementara dilayani AI lain.`);
        break; // key bermasalah: model lain di layanan ini juga akan ditolak
      }
      // 400 karena format (gambar/JSON tidak didukung): pindah ke layanan berikutnya (Gemini bisa melihat gambar);
      // kalau tidak ada lagi, kembalikan ke aplikasi supaya dicoba ulang tanpa gambar/JSON
      if (r.status === 400 && /image|vision|multimodal|content type|response_format|json/i.test(teks)){
        if (p === daftar[daftar.length - 1]) return new Response(teks, { status: 400, headers: { "Content-Type": "application/json", ...CORS } });
        pindahLayanan = true; break;
      }
      // 404 (model tidak ada), 413 (terlalu panjang), 429 (jatah per menit/hari), 5xx (penuh): coba model berikutnya
    }
    if (pindahLayanan) continue;
  }
  kabari(env, ctx, "penuh", "semua AI sedang penuh atau menolak. " + catatan.join(" | ").slice(0, 600));
  return json({ error: { code: "tk_busy", message: "Semua AI gratis sedang penuh. Materimu masuk antrean dan dicoba lagi otomatis.", detail: catatan } }, 503, { "Retry-After": "600" });
}

// Transkrip video dengan Whisper (Groq). Isi formulir diteruskan apa adanya.
async function teruskanWhisper(req, env, ctx, who){
  if (!env.GROQ_KEY) return gagal(503, "tk_nokey", "Transkrip video belum diatur oleh pembuat aplikasi.");
  const habis = await cekJatah(env, ctx, who, "video"); if (habis) return habis;
  const r = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", { method: "POST", headers: { Authorization: "Bearer " + env.GROQ_KEY, "Content-Type": req.headers.get("Content-Type") || "" }, body: req.body });
  if (r.ok){ catatPakai(env, ctx, who, "video"); return new Response(r.body, { status: 200, headers: { "Content-Type": r.headers.get("Content-Type") || "text/plain", ...CORS } }); }
  const teks = await r.text().catch(() => "");
  if (r.status === 401 || r.status === 403) kabari(env, ctx, "key-groq", "API key Groq ditolak saat transkrip video. Cek di Variables and Secrets.");
  if (r.status === 429 || r.status >= 500) return gagal(503, "tk_busy", "Transkrip video sedang penuh. Dicoba lagi nanti.", { "Retry-After": "600" });
  return new Response(teks, { status: r.status, headers: { "Content-Type": "application/json", ...CORS } });
}

async function sisaJatah(env, who){
  const J = jatahDari(env), hari = hariIni(), out = {};
  for (const j of Object.keys(J)) out[j] = Math.max(0, J[j] - (who.orang ? await hitung(env, hari, who.orang, j) : 0));
  return json({ ok: true, hari, jatah: J, sisa: out, reset: detikKeTengahMalam(), ai: Object.keys(AI).filter(p => env[AI[p].key]) });
}

async function statistik(env, url){
  if (!env.ADMIN_KEY || url.searchParams.get("key") !== env.ADMIN_KEY) return gagal(403, "tk_forbidden", "Kunci admin salah.");
  const hari = url.searchParams.get("hari") || hariIni();
  const r = await env.DB.prepare("SELECT jenis, COUNT(DISTINCT siapa) AS orang, SUM(n) AS total FROM pakai WHERE hari = ? AND siapa NOT LIKE 'ip:%' GROUP BY jenis").bind(hari).all();
  const o = await env.DB.prepare("SELECT COUNT(DISTINCT siapa) AS orang FROM pakai WHERE hari = ? AND siapa NOT LIKE 'ip:%'").bind(hari).first();
  return json({ hari, pengguna: o ? o.orang : 0, per_jenis: r.results, jatah: jatahDari(env) });
}

// ===================== Pusat pantau (1.2) =====================
// Semua angka di bawah anonim. Perangkat = sidik dari ID acak aplikasi, pengunjung website = sidik harian
// dari alamat internet + browser yang berganti tiap hari, jadi tidak bisa dilacak ke orang tertentu.

const hariLalu = n => new Date(Date.now() + 7 * 3600 * 1000 - n * 86400000).toISOString().slice(0, 10);
const potong = (s, n) => String(s == null ? "" : s).replace(/[\u0000-\u001f]/g, "").trim().slice(0, n);

function tebakPlat(ua){
  if (/Android/i.test(ua)) return "android";
  if (/iPhone|iPad|iOS/i.test(ua)) return "ios";
  if (/Macintosh|Mac OS/i.test(ua)) return "mac";
  if (/Windows|Electron|^node|undici/i.test(ua)) return "windows";
  return "?";
}

// Perangkat yang memakai aplikasi: dicatat sekali per hari per perangkat
const sudahAktif = new Map();
function catatAktif(env, ctx, req){
  const dev = String(req.headers.get("X-TK-Device") || "");
  if (!/^[a-zA-Z0-9-]{16,64}$/.test(dev)) return;
  const h = hariIni(), kunci = h + "|" + dev;
  if (sudahAktif.has(kunci)) return;
  if (sudahAktif.size > 5000) sudahAktif.clear();
  sudahAktif.set(kunci, 1);
  const v = String(req.headers.get("X-TK-Version") || "");
  const ver = /^\d{1,3}\.\d{1,3}\.\d{1,4}$/.test(v) ? v : "lama";
  const p = String(req.headers.get("X-TK-Platform") || "").toLowerCase();
  const plat = ["windows", "android", "mac", "linux", "ios"].includes(p) ? p : tebakPlat(req.headers.get("User-Agent") || "");
  const edl = /^[a-f0-9]{16,64}$/.test(req.headers.get("X-TK-User") || "") ? 1 : 0;
  ctx.waitUntil((async () => {
    const id = await sha("tk-dev:" + dev);
    await env.DB.batch([
      env.DB.prepare("INSERT INTO aktif (hari, dev, ver, plat) VALUES (?, ?, ?, ?) ON CONFLICT (hari, dev) DO UPDATE SET ver = CASE WHEN excluded.ver <> 'lama' THEN excluded.ver ELSE aktif.ver END, plat = CASE WHEN excluded.plat <> '?' THEN excluded.plat ELSE aktif.plat END").bind(h, id, ver, plat),
      env.DB.prepare("INSERT INTO perangkat (dev, pertama, terakhir, ver, plat, edlink) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT (dev) DO UPDATE SET terakhir = excluded.terakhir, ver = CASE WHEN excluded.ver <> 'lama' THEN excluded.ver ELSE perangkat.ver END, plat = CASE WHEN excluded.plat <> '?' THEN excluded.plat ELSE perangkat.plat END, edlink = MAX(perangkat.edlink, excluded.edlink)").bind(id, h, h, ver, plat, edl)
    ]);
  })().catch(() => { sudahAktif.delete(kunci); }));
}

// Angka unduhan dari GitHub. Disimpan maksimal tiap 15 menit, sekaligus jadi catatan harian.
let ghCek = 0;
async function ambilGithub(env, paksa){
  const now = Math.floor(Date.now() / 1000);
  const c = await env.DB.prepare("SELECT t, v FROM simpan WHERE k = 'gh'").first();
  if (c && !paksa && now - c.t < 900) return JSON.parse(c.v);
  try {
    const head = { "User-Agent": "teman-kuliah-ai", Accept: "application/vnd.github+json" };
    if (env.GITHUB_TOKEN) head.Authorization = "Bearer " + env.GITHUB_TOKEN;
    const r = await fetch(`${env.GH_API || "https://api.github.com"}/repos/${REPO}/releases?per_page=100`, { headers: head });
    if (!r.ok) throw new Error("GitHub menjawab " + r.status);
    const j = await r.json();
    const rilis = (Array.isArray(j) ? j : []).filter(x => !x.draft).map(x => ({
      tag: potong(x.tag_name, 40), tanggal: String(x.published_at || x.created_at || "").slice(0, 10), waktu: String(x.published_at || x.created_at || "").slice(0, 20), pre: !!x.prerelease,
      aset: (x.assets || []).map(a => ({ nama: potong(a.name, 120), n: Number(a.download_count) || 0, ukuran: Number(a.size) || 0 }))
    }));
    const v = { at: now, rilis };
    const h = hariIni();
    const st = [env.DB.prepare("INSERT INTO simpan (k, t, v) VALUES ('gh', ?, ?) ON CONFLICT (k) DO UPDATE SET t = excluded.t, v = excluded.v").bind(now, JSON.stringify(v))];
    for (const x of rilis) for (const a of x.aset) if (!/\.blockmap$/i.test(a.nama)) st.push(env.DB.prepare("INSERT INTO unduh (hari, tag, aset, n) VALUES (?, ?, ?, ?) ON CONFLICT (hari, tag, aset) DO UPDATE SET n = excluded.n").bind(h, x.tag, a.nama, a.n));
    await env.DB.batch(st);
    return v;
  } catch (e) {
    if (c){ const v = JSON.parse(c.v); v.galat = String(e && e.message || e); return v; }
    return { at: 0, rilis: [], galat: String(e && e.message || e) };
  }
}
function cekGithubNanti(env, ctx){
  if (Date.now() - ghCek < 900000) return;
  ghCek = Date.now();
  ctx.waitUntil(ambilGithub(env).catch(() => {}));
}

// Kunjungan website (dikirim skrip kecil di temankuliah.netlify.app)
const KLIK = ["windows", "android", "panduan", "trakteer", "github"];
const BAGIAN = ["fitur", "mulai", "unduh", "dukung", "faq", "keluhan"];
function alatDari(ua){
  if (/Android/i.test(ua)) return "HP Android";
  if (/iPhone|iPad|iPod/i.test(ua)) return "iPhone/iPad";
  if (/Windows/i.test(ua)) return "Laptop Windows";
  if (/Macintosh|Mac OS/i.test(ua)) return "Mac";
  if (/CrOS/i.test(ua)) return "Chromebook";
  if (/Linux/i.test(ua)) return "Linux";
  return "Lainnya";
}
function domainDari(ref){
  try {
    const u = new URL(ref), host = u.hostname.replace(/^www\./, "").replace(/^(m|l|lm)\./, "");
    if (/temankuliah/.test(host)) return null;
    if (/(^|\.)google\./.test(host)) return "Google";
    if (/facebook\.com|fb\.com/.test(host)) return "Facebook";
    if (/instagram\.com/.test(host)) return "Instagram";
    if (/t\.co$|twitter\.com|x\.com/.test(host)) return "X (Twitter)";
    if (/whatsapp/.test(host)) return "WhatsApp";
    if (/tiktok/.test(host)) return "TikTok";
    if (/youtube|youtu\.be/.test(host)) return "YouTube";
    if (/github/.test(host)) return "GitHub";
    if (/bing\./.test(host)) return "Bing";
    return potong(host, 60);
  } catch (e) { return null; }
}
async function catatWeb(req, env, ctx){
  const ok = new Response(null, { status: 204, headers: CORS });
  if (req.method !== "POST") return ok;
  const ua = req.headers.get("User-Agent") || "";
  if (!ua || /bot|crawl|spider|slurp|preview|headless|lighthouse|pagespeed|monitor/i.test(ua)) return ok;
  const origin = req.headers.get("Origin") || "";
  if (origin && !/temankuliah|netlify\.app|localhost|127\.0\.0\.1/.test(origin)) return ok;
  let b = {}; try { b = JSON.parse((await req.text()).slice(0, 3000)) || {}; } catch (e) { return ok; }
  const h = hariIni(), ip = req.headers.get("CF-Connecting-IP") || "0";
  const baris = [];
  if (b.t === "view"){
    const cf = req.cf || {};
    baris.push(["view", potong(b.p, 80) || "/"]);
    baris.push(["ref", domainDari(String(b.r || "")) || "Langsung / ketik alamat"]);
    if (b.s) baris.push(["sumber", potong(b.s, 40).toLowerCase()]);
    baris.push(["alat", alatDari(ua)]);
    if (cf.country) baris.push(["negara", potong(cf.country, 4)]);
    if (cf.city) baris.push(["kota", potong(cf.city, 60) + (cf.region ? ", " + potong(cf.region, 40) : "")]);
  } else if (b.t === "klik" && KLIK.includes(b.k)) baris.push(["klik", b.k]);
  else if (b.t === "lihat" && BAGIAN.includes(b.k)) baris.push(["bagian", b.k]);
  else if (b.t === "keluhan") baris.push(["keluhan", potong(b.k, 40) || "Lainnya"]);
  if (!baris.length) return ok;
  ctx.waitUntil((async () => {
    const vis = await sha("tk-web:" + h + ":" + ip + ":" + ua);
    const r = await env.DB.prepare("SELECT n FROM web WHERE hari = ? AND jenis = 'unik' AND kunci = ?").bind(h, vis).first();
    if (r && r.n > 300) return; // satu pengunjung paling banyak 300 catatan per hari (penahan spam)
    const ins = (j, k) => env.DB.prepare("INSERT INTO web (hari, jenis, kunci, n) VALUES (?, ?, ?, 1) ON CONFLICT (hari, jenis, kunci) DO UPDATE SET n = n + 1").bind(h, j, k);
    // Pengunjung unik hanya dihitung dari kunjungan halaman; klik tanpa kunjungan diabaikan (penahan spam)
    if (b.t === "view") await env.DB.batch([ins("unik", vis), ...baris.map(([j, k]) => ins(j, k))]);
    else if (r) await env.DB.batch([env.DB.prepare("UPDATE web SET n = n + 1 WHERE hari = ? AND jenis = 'unik' AND kunci = ?").bind(h, vis), ...baris.map(([j, k]) => ins(j, k))]);
  })().catch(() => {}));
  cekGithubNanti(env, ctx);
  return ok;
}

function adminOk(env, req, url){
  const k = req.headers.get("X-TK-Admin") || url.searchParams.get("key") || "";
  return !!env.ADMIN_KEY && k.length > 0 && k === env.ADMIN_KEY;
}

// Semua angka untuk halaman pantau dalam satu jawaban
async function dataPantau(req, env, url){
  if (!env.ADMIN_KEY) return gagal(403, "tk_noadmin", "Secret ADMIN_KEY belum dibuat di Cloudflare.");
  if (!adminOk(env, req, url)) return gagal(403, "tk_forbidden", "Kata sandi salah.");
  const rentang = Math.min(800, Math.max(1, parseInt(url.searchParams.get("rentang"), 10) || 30));
  const dari = hariLalu(rentang - 1), d1 = hariIni(), d7 = hariLalu(6), d30 = hariLalu(29);
  const q = (sql, ...a) => env.DB.prepare(sql).bind(...a);
  const gh = await ambilGithub(env, url.searchParams.get("segar") === "1"); // dulu, supaya catatan hari ini ikut terbaca
  const [webHari, webTop, klikHari, aktifHari, baruHari, devTotal, akt, verRows, platRows, aiHari, aiOrang, unduhRows, unduhAwal, webAwal, devAwal] = await Promise.all([
    q("SELECT hari, SUM(CASE WHEN jenis = 'view' THEN n ELSE 0 END) AS lihat, SUM(CASE WHEN jenis = 'unik' THEN 1 ELSE 0 END) AS unik FROM web WHERE hari >= ? AND jenis IN ('view', 'unik') GROUP BY hari ORDER BY hari", dari).all(),
    q("SELECT jenis, kunci, SUM(n) AS n FROM web WHERE hari >= ? AND jenis <> 'unik' GROUP BY jenis, kunci ORDER BY n DESC", dari).all(),
    q("SELECT hari, kunci, SUM(n) AS n FROM web WHERE hari >= ? AND jenis = 'klik' GROUP BY hari, kunci", dari).all(),
    q("SELECT hari, COUNT(*) AS n FROM aktif WHERE hari >= ? GROUP BY hari ORDER BY hari", dari).all(),
    q("SELECT pertama AS hari, COUNT(*) AS n FROM perangkat WHERE pertama >= ? GROUP BY pertama ORDER BY pertama", dari).all(),
    q("SELECT COUNT(*) AS n, SUM(edlink) AS e FROM perangkat").first(),
    q("SELECT COUNT(DISTINCT CASE WHEN hari >= ? THEN dev END) AS a1, COUNT(DISTINCT CASE WHEN hari >= ? THEN dev END) AS a7, COUNT(DISTINCT dev) AS a30 FROM aktif WHERE hari >= ?", d1, d7, d30).first(),
    q("SELECT ver, COUNT(*) AS n FROM perangkat WHERE terakhir >= ? GROUP BY ver ORDER BY n DESC", d30).all(),
    q("SELECT plat, COUNT(*) AS n FROM perangkat WHERE terakhir >= ? GROUP BY plat ORDER BY n DESC", d30).all(),
    q("SELECT hari, jenis, COUNT(DISTINCT siapa) AS orang, SUM(n) AS total FROM pakai WHERE hari >= ? AND siapa NOT LIKE 'ip:%' GROUP BY hari, jenis ORDER BY hari", dari).all(),
    q("SELECT hari, COUNT(DISTINCT siapa) AS orang FROM pakai WHERE hari >= ? AND siapa NOT LIKE 'ip:%' GROUP BY hari ORDER BY hari", dari).all(),
    q("SELECT hari, aset, SUM(n) AS n FROM unduh WHERE hari >= ? GROUP BY hari, aset ORDER BY hari", hariLalu(rentang)).all(),
    env.DB.prepare("SELECT MIN(hari) AS h FROM unduh").first(),
    env.DB.prepare("SELECT MIN(hari) AS h FROM web").first(),
    env.DB.prepare("SELECT MIN(pertama) AS h FROM perangkat").first()
  ]);
  return json({
    ok: true, versi: VERSI, dibuat: new Date().toISOString(), hariIni: d1, rentang, dari,
    github: gh,
    unduhHarian: unduhRows.results,
    web: { harian: webHari.results, top: webTop.results, klikHarian: klikHari.results },
    aplikasi: { harian: aktifHari.results, baru: baruHari.results, total: devTotal ? devTotal.n : 0, edlink: devTotal ? (devTotal.e || 0) : 0, aktif: akt || {}, versi: verRows.results, platform: platRows.results },
    ai: { harian: aiHari.results, orang: aiOrang.results, jatah: jatahDari(env) },
    mulai: { unduh: unduhAwal && unduhAwal.h, web: webAwal && webAwal.h, aplikasi: devAwal && devAwal.h }
  }, 200, { "Cache-Control": "no-store" });
}

// ===================== Pengumuman ke aplikasi (1.3) =====================
const angkaVersi = v => String(v || "0").split(".").map(Number).reduce((a, x) => a * 1000 + (x || 0), 0);
const cocokVersi = (ver, verdi) => !verdi || ver === "lama" || angkaVersi(ver) < angkaVersi(verdi); // verdi = "hanya yang di bawah versi ini"

// Dipanggil aplikasi (1.0.19 ke atas) saat dibuka dan tiap 30 menit
async function ping(req, env, ctx){
  let b = {}; if (req.method === "POST"){ try { b = JSON.parse((await req.text()).slice(0, 500)) || {}; } catch (e) {} }
  const since = Math.max(0, parseInt(b.since, 10) || 0), now = Math.floor(Date.now() / 1000);
  const v = String(req.headers.get("X-TK-Version") || ""), ver = /^\d{1,3}\.\d{1,3}\.\d{1,4}$/.test(v) ? v : "lama";
  const p0 = String(req.headers.get("X-TK-Platform") || "").toLowerCase(), plat = ["windows", "android", "mac", "linux", "ios"].includes(p0) ? p0 : tebakPlat(req.headers.get("User-Agent") || "");
  // Pemasangan baru (since 0) hanya dapat pengumuman 7 hari terakhir yang masih berlaku
  const r = await env.DB.prepare("SELECT id, dibuat, judul, isi, link, jenis, plat, verdi FROM pesan WHERE aktif = 1 AND id > ? AND (sampai IS NULL OR sampai > ?) AND dibuat > ? ORDER BY id LIMIT 20").bind(since, now, since ? 0 : now - 7 * 86400).all();
  const kirim = (r.results || []).filter(m => (m.plat === "semua" || m.plat === plat) && cocokVersi(ver, m.verdi)).slice(0, 10);
  const dev = String(req.headers.get("X-TK-Device") || "");
  if (kirim.length && /^[a-zA-Z0-9-]{16,64}$/.test(dev)){
    ctx.waitUntil((async () => {
      const id = await sha("tk-dev:" + dev);
      await env.DB.batch(kirim.map(m => env.DB.prepare("INSERT OR IGNORE INTO pesan_terima (pesan_id, dev, t) VALUES (?, ?, ?)").bind(m.id, id, now)));
    })().catch(() => {}));
  }
  return json({ ok: true, versi: VERSI, pesan: kirim.map(m => ({ id: m.id, dibuat: m.dibuat, judul: m.judul, isi: m.isi, link: m.link || "", jenis: m.jenis })) });
}

async function pesanAdmin(req, env, url){
  if (!env.ADMIN_KEY) return gagal(403, "tk_noadmin", "Secret ADMIN_KEY belum dibuat di Cloudflare.");
  if (!adminOk(env, req, url)) return gagal(403, "tk_forbidden", "Kata sandi salah.");
  const now = Math.floor(Date.now() / 1000);
  if (req.method === "POST"){
    let b = {}; try { b = JSON.parse((await req.text()).slice(0, 8000)) || {}; } catch (e) { return gagal(400, "tk_bad", "Isi permintaan tidak terbaca."); }
    if (url.pathname.endsWith("/tarik")){
      const id = parseInt(b.id, 10); if (!id) return gagal(400, "tk_bad", "ID pengumuman kosong.");
      await env.DB.prepare("UPDATE pesan SET aktif = 0 WHERE id = ?").bind(id).run();
      return json({ ok: true });
    }
    const judul = potong(b.judul, 80), isi = String(b.isi == null ? "" : b.isi).replace(/[\u0000-\u0008\u000b-\u001f]/g, "").trim().slice(0, 600);
    const link = /^https:\/\/[^\s]{3,}$/.test(String(b.link || "").trim()) ? String(b.link).trim().slice(0, 500) : "";
    if (!judul) return gagal(400, "tk_bad", "Judul pengumuman wajib diisi.");
    if (b.link && !link) return gagal(400, "tk_bad", "Link harus diawali https://");
    const jenis = ["info", "penting", "update"].includes(b.jenis) ? b.jenis : "info";
    const plat = ["semua", "windows", "android"].includes(b.plat) ? b.plat : "semua";
    const verdi = /^\d{1,3}\.\d{1,3}\.\d{1,4}$/.test(String(b.verdi || "")) ? String(b.verdi) : "";
    const hari = Math.min(60, Math.max(1, parseInt(b.hari, 10) || 14));
    const r = await env.DB.prepare("INSERT INTO pesan (dibuat, judul, isi, link, jenis, plat, verdi, sampai, aktif) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)").bind(now, judul, isi, link, jenis, plat, verdi, now + hari * 86400).run();
    return json({ ok: true, id: r.meta && r.meta.last_row_id });
  }
  const d30 = hariLalu(29);
  const [list, perangkat] = await Promise.all([
    env.DB.prepare("SELECT p.*, (SELECT COUNT(*) FROM pesan_terima t WHERE t.pesan_id = p.id) AS terkirim FROM pesan p ORDER BY p.id DESC LIMIT 50").all(),
    env.DB.prepare("SELECT plat, ver, COUNT(*) AS n FROM perangkat WHERE terakhir >= ? GROUP BY plat, ver").bind(d30).all()
  ]);
  return json({ ok: true, now, pesan: list.results || [], perangkat: perangkat.results || [] }, 200, { "Cache-Control": "no-store" });
}

function bersihkanStatistik(env, ctx){
  if (Math.random() >= 0.005) return;
  const b = hariLalu(400);
  ctx.waitUntil(env.DB.batch([
    env.DB.prepare("DELETE FROM aktif WHERE hari < ?").bind(b),
    env.DB.prepare("DELETE FROM web WHERE jenis = 'unik' AND hari < ?").bind(b)
  ]).catch(() => {}));
}

const HALAMAN_PANTAU = "<!doctype html>\n<html lang=\"id\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">\n<meta name=\"robots\" content=\"noindex, nofollow\">\n<title>Pantau Teman Kuliah</title>\n<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap\">\n<link rel=\"icon\" href=\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%2315171C'/%3E%3Cpath d='M6 10c3-1.2 6.5-1 10 1v12c-3.5-2-7-2.2-10-1z' fill='%23fff'/%3E%3Cpath d='M26 10c-3-1.2-6.5-1-10 1v12c3.5-2 7-2.2 10-1z' fill='%23FFD60A'/%3E%3C/svg%3E\">\n<style>\n/* Papan pantau: tinta + stabilo seperti aplikasinya. Ringkasan di atas, lalu Unduhan, Website, Aplikasi, AI. */\n:root{\n  --bg:#F5F5F2; --panel:#FFFFFF; --ink:#15171C; --muted:#5E626B; --faint:#8A8E96; --line:#E3E3DE; --grid:#ECECE7;\n  --stabilo:#FFD60A; --stabilo-ink:#15171C; --mark:rgba(255,214,10,.45);\n  --win:#2F64D6; --apk:#1F9D63; --c3:#C2410C; --c4:#7C3AED; --c5:#0E7490;\n  --good:#1F8A55; --warn:#B45309; --bad:#C4302B;\n  --shadow:0 1px 2px rgba(21,23,28,.06); --lead-bg:#15171C; --lead-fg:#FFFFFF;\n  --font:\"Inter\",ui-sans-serif,system-ui,-apple-system,\"Segoe UI\",Roboto,Arial,sans-serif;\n}\n@media (prefers-color-scheme: dark){ :root:not([data-theme=\"light\"]){\n  --bg:#0F1013; --panel:#17191E; --ink:#ECEDEF; --muted:#A3A7AF; --faint:#7A7E87; --line:#2A2D34; --grid:#22252B;\n  --stabilo:#FFD60A; --stabilo-ink:#15171C; --mark:rgba(255,214,10,.28);\n  --win:#6C9BFF; --apk:#43C887; --c3:#FB8A4C; --c4:#B28CFF; --c5:#3CC4DA;\n  --good:#43C887; --warn:#F2B03D; --bad:#FF6B63; --shadow:none; --lead-bg:#2A2510; --lead-fg:#FFF6CC; color-scheme:dark } }\n:root[data-theme=\"dark\"]{\n  --bg:#0F1013; --panel:#17191E; --ink:#ECEDEF; --muted:#A3A7AF; --faint:#7A7E87; --line:#2A2D34; --grid:#22252B;\n  --stabilo:#FFD60A; --stabilo-ink:#15171C; --mark:rgba(255,214,10,.28);\n  --win:#6C9BFF; --apk:#43C887; --c3:#FB8A4C; --c4:#B28CFF; --c5:#3CC4DA;\n  --good:#43C887; --warn:#F2B03D; --bad:#FF6B63; --shadow:none; --lead-bg:#2A2510; --lead-fg:#FFF6CC; color-scheme:dark }\n[hidden]{display:none!important}*{box-sizing:border-box}\nhtml,body{margin:0}\nbody{background:var(--bg);color:var(--ink);font:15px/1.5 var(--font);font-feature-settings:\"cv11\",\"ss01\";-webkit-font-smoothing:antialiased}\nbutton,input{font:inherit;color:inherit}\na{color:inherit}\n.wrap{max-width:1180px;margin:0 auto;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}\n.num,.tab,td.r,.kpi b{font-variant-numeric:tabular-nums}\n\n/* bar atas */\n.top{position:sticky;top:0;z-index:5;background:color-mix(in srgb,var(--bg) 88%,transparent);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-bottom:1px solid var(--line)}\n.top .wrap{display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding-block:12px}\n.brand{display:flex;align-items:center;gap:10px;margin-right:auto;min-width:0}\n.brand svg{flex:none}\n.brand h1{font-size:17px;line-height:1.2;margin:0;font-weight:750;letter-spacing:-.01em}\n.brand small{display:block;color:var(--muted);font-size:12.5px;font-weight:500}\n.seg{display:inline-flex;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:3px;gap:2px}\n.seg button{border:0;background:none;padding:5px 11px;border-radius:7px;font-size:13.5px;font-weight:600;color:var(--muted);cursor:pointer}\n.seg button[aria-pressed=\"true\"]{background:var(--ink);color:var(--bg)}\n.btn{border:1px solid var(--line);background:var(--panel);border-radius:10px;padding:6px 12px;font-size:13.5px;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:6px}\n.btn:hover{border-color:var(--faint)}\n.btn.primary{background:var(--ink);color:var(--bg);border-color:var(--ink)}\n.btn.st{background:var(--stabilo);color:var(--stabilo-ink);border-color:var(--stabilo)}\n:focus-visible{outline:2px solid var(--stabilo);outline-offset:2px}\n.upd{font-size:12.5px;color:var(--muted)}\n\nmain{padding-block:22px 48px;display:grid;gap:28px}\n.note{font-size:13px;color:var(--muted)}\n.warnbar{border:1px solid color-mix(in srgb,var(--warn) 45%,var(--line));background:color-mix(in srgb,var(--warn) 9%,var(--panel));border-radius:12px;padding:10px 14px;font-size:13.5px}\n\n/* angka utama */\n.kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}\n.kpi{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:14px 16px 13px;box-shadow:var(--shadow);min-width:0}\n.kpi > span{display:block;font-size:12.5px;font-weight:600;color:var(--muted);letter-spacing:.01em}\n.kpi b{display:block;font-size:30px;line-height:1.15;font-weight:800;letter-spacing:-.02em;margin:4px 0 2px}\n.kpi b .hl{background:linear-gradient(transparent 58%,var(--mark) 58%)}\n.kpi em{font-style:normal;font-size:12.5px;color:var(--muted)}\n.kpi.lead{background:var(--lead-bg);color:var(--lead-fg);border-color:var(--lead-bg)}\n.kpi.lead > span,.kpi.lead em{color:color-mix(in srgb,var(--lead-fg) 70%,transparent)}\n.kpi.lead b .hl{background:none;color:var(--stabilo)}\n\n/* bagian */\nsection.part{display:grid;gap:12px}\n.ph{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}\n.ph h2{font-size:19px;margin:0;font-weight:750;letter-spacing:-.01em}\n.ph h2 .u{background:linear-gradient(transparent 62%,var(--mark) 62%)}\n.ph p{margin:0;color:var(--muted);font-size:13.5px}\n.grid2{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:12px}\n.grid3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}\n.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:14px 16px;box-shadow:var(--shadow);min-width:0}\n.card h3{margin:0 0 2px;font-size:14.5px;font-weight:700}\n.card .sub{margin:0 0 10px;font-size:12.5px;color:var(--muted)}\n.legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12.5px;color:var(--muted);margin:0 0 6px}\n.legend i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}\n.chart{position:relative;width:100%}\n.chart svg{display:block;width:100%;overflow:visible}\n.chart text{fill:var(--faint);font-size:11px;font-family:var(--font)}\n.empty{display:grid;place-items:center;text-align:center;min-height:150px;color:var(--muted);font-size:13.5px;border:1px dashed var(--line);border-radius:10px;padding:16px}\n.tip{position:absolute;pointer-events:none;background:var(--ink);color:var(--bg);font-size:12.5px;line-height:1.4;padding:7px 9px;border-radius:8px;white-space:nowrap;transform:translate(-50%,calc(-100% - 10px));z-index:3;box-shadow:0 4px 14px rgba(0,0,0,.18)}\n.tip b{font-weight:700}\n.tip .dot{display:inline-block;width:8px;height:8px;border-radius:2px;margin-right:5px}\n\n/* daftar batang */\n.bars{display:grid;gap:7px}\n.bar{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:2px 10px;font-size:13.5px}\n.bar .lab{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.bar .val{color:var(--muted);font-variant-numeric:tabular-nums;font-size:13px}\n.bar .trk{grid-column:1/-1;height:6px;border-radius:4px;background:var(--grid);overflow:hidden}\n.bar .trk i{display:block;height:100%;border-radius:4px;background:var(--ink)}\n.bar.hl .trk i{background:var(--stabilo)}\n\n/* corong */\n.funnel{display:grid;gap:9px}\n.fstep{display:grid;grid-template-columns:minmax(0,150px) minmax(0,1fr) auto;align-items:center;gap:10px;font-size:13.5px}\n.fstep .trk{height:22px;background:var(--grid);border-radius:6px;overflow:hidden}\n.fstep .trk i{display:block;height:100%;background:var(--ink);border-radius:6px}\n.fstep:last-child .trk i{background:var(--stabilo)}\n.fstep .v{font-variant-numeric:tabular-nums;color:var(--muted);font-size:13px;min-width:86px;text-align:right}\n\n/* tabel */\n.tw{overflow-x:auto;margin:0 -4px}\ntable{border-collapse:collapse;width:100%;font-size:13.5px;min-width:420px}\nth,td{padding:8px 6px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}\nth{font-size:12px;color:var(--muted);font-weight:600}\ntd.r,th.r{text-align:right}\ntr:last-child td{border-bottom:0}\n.pill{display:inline-block;font-size:11.5px;font-weight:700;padding:1px 7px;border-radius:99px;background:var(--stabilo);color:var(--stabilo-ink);margin-left:6px;vertical-align:1px}\n.mini{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:12px}\n.mini div{border:1px solid var(--line);border-radius:10px;padding:8px 10px}\n.mini span{display:block;font-size:12px;color:var(--muted)}\n.mini b{font-size:20px;font-weight:750;font-variant-numeric:tabular-nums}\n\n/* masuk */\n.login{max-width:420px;margin:12vh auto 0;background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:22px;box-shadow:var(--shadow)}\n.login h2{margin:0 0 4px;font-size:20px}\n.login p{margin:0 0 14px;color:var(--muted);font-size:14px}\n.login label{display:block;font-size:13px;font-weight:600;margin-bottom:6px}\n.login input[type=password]{width:100%;padding:10px 12px;border:1px solid var(--line);border-radius:10px;background:var(--bg)}\n.login .row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:12px;flex-wrap:wrap}\n.login .chk{display:flex;align-items:center;gap:7px;font-size:13.5px;font-weight:500;margin:0}\n.err{color:var(--bad);font-size:13.5px;margin-top:10px}\n.links{display:flex;flex-wrap:wrap;gap:8px}\n.links a{text-decoration:none}\nfooter{padding-block:0 32px}\n.skel{animation:pulse 1.4s ease-in-out infinite}\n@keyframes pulse{50%{opacity:.45}}\n@media (prefers-reduced-motion: reduce){.skel{animation:none}}\n\n\n/* pengumuman */\n.compose{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);gap:12px}\n.form{display:grid;gap:12px}\n.form label.l{display:block;font-size:12.5px;font-weight:600;color:var(--muted);margin-bottom:5px}\n.form input[type=text],.form input[type=url],.form textarea,.form select{width:100%;padding:9px 11px;border:1px solid var(--line);border-radius:10px;background:var(--bg);font:inherit;color:var(--ink)}\n.form textarea{min-height:92px;resize:vertical;line-height:1.45}\n.form .row2{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:12px}\n.form .cnt{font-size:11.5px;color:var(--faint);text-align:right;margin-top:3px}\n.seg.small button{padding:5px 10px;font-size:13px}\n.chkrow{display:flex;align-items:flex-start;gap:8px;font-size:13.5px}\n.chkrow input{margin-top:3px}\n.aud{font-size:13px;color:var(--muted);background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:9px 11px}\n.aud b{color:var(--ink)}\n.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}\n.confirm{border:1.5px solid var(--stabilo);border-radius:12px;padding:10px 12px;display:grid;gap:8px;font-size:13.5px}\n.ok-msg{font-size:13.5px;color:var(--good)}\n.prev-wrap{display:grid;gap:10px;align-content:start}\n.prev-l{font-size:12px;font-weight:600;color:var(--muted)}\n.toast-prev{background:#202226;color:#F3F4F6;border-radius:10px;padding:12px 14px;display:grid;grid-template-columns:28px minmax(0,1fr);gap:10px;box-shadow:0 6px 20px rgba(0,0,0,.18)}\n.toast-prev .ti{font-size:12px;color:#A9ADB5}\n.toast-prev b{display:block;font-size:14px;margin:2px 0;overflow-wrap:anywhere}\n.toast-prev p{margin:0;font-size:13px;color:#D5D7DB;overflow-wrap:anywhere;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}\n.card-prev{border:1px solid var(--line);border-left:4px solid var(--ink);border-radius:12px;padding:12px 14px;display:grid;gap:6px;background:var(--panel)}\n.card-prev[data-j=\"penting\"]{border-left-color:#F08A00;background:color-mix(in srgb,#F08A00 8%,var(--panel))}\n.card-prev[data-j=\"update\"]{border-left-color:var(--stabilo)}\n.card-prev .tg{font-size:10.5px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;padding:2px 8px;border-radius:99px;background:color-mix(in srgb,var(--ink) 10%,transparent);justify-self:start}\n.card-prev[data-j=\"update\"] .tg{background:var(--stabilo);color:var(--stabilo-ink)}\n.card-prev b{font-size:15px;overflow-wrap:anywhere}\n.card-prev p{margin:0;font-size:13.5px;white-space:pre-line;overflow-wrap:anywhere}\n.card-prev .bt{display:flex;gap:6px;justify-content:flex-end}\n.card-prev .bt span{font-size:12px;font-weight:600;border:1px solid var(--line);border-radius:8px;padding:3px 9px}\n.card-prev .bt span.d{background:var(--ink);color:var(--bg);border-color:var(--ink)}\n.st{font-size:11.5px;font-weight:700;padding:2px 8px;border-radius:99px;white-space:nowrap}\n.st.on{background:color-mix(in srgb,var(--good) 16%,transparent);color:var(--good)}\n.st.off{background:var(--grid);color:var(--muted)}\n.btn.sm{padding:4px 9px;font-size:12.5px}\ntd.wrap{white-space:normal;min-width:180px}\ntd.wrap small{display:block;color:var(--muted);font-size:12px}\n@media (max-width:900px){ .kpis{grid-template-columns:repeat(2,minmax(0,1fr))} .grid2,.grid3,.compose{grid-template-columns:minmax(0,1fr)} }\n@media (max-width:460px){ .form .row2{grid-template-columns:minmax(0,1fr)} .mini span{font-size:11px} .mini b{font-size:17px} .kpi b{font-size:25px} .fstep{grid-template-columns:minmax(0,100px) minmax(0,1fr) auto} .brand small{display:none} .seg button{padding:5px 8px} }\n</style>\n</head>\n<body>\n<header class=\"top\">\n  <div class=\"wrap\">\n    <div class=\"brand\">\n      <svg width=\"34\" height=\"34\" viewBox=\"0 0 32 32\" aria-hidden=\"true\"><rect width=\"32\" height=\"32\" rx=\"8\" fill=\"#15171C\"/><path d=\"M6 10c3-1.2 6.5-1 10 1v12c-3.5-2-7-2.2-10-1z\" fill=\"#fff\"/><path d=\"M26 10c-3-1.2-6.5-1-10 1v12c3.5-2 7-2.2 10-1z\" fill=\"#FFD60A\"/></svg>\n      <div><h1>Pantau Teman Kuliah</h1><small id=\"upd-line\">Unduhan, website, aplikasi, dan AI di satu tempat</small></div>\n    </div>\n    <div class=\"seg\" role=\"group\" aria-label=\"Rentang waktu\" id=\"seg\" hidden>\n      <button type=\"button\" data-r=\"7\" aria-pressed=\"false\">7 hari</button>\n      <button type=\"button\" data-r=\"30\" aria-pressed=\"true\">30 hari</button>\n      <button type=\"button\" data-r=\"90\" aria-pressed=\"false\">90 hari</button>\n      <button type=\"button\" data-r=\"365\" aria-pressed=\"false\">1 tahun</button>\n    </div>\n    <button type=\"button\" class=\"btn\" id=\"reload\" hidden>Muat ulang</button>\n  </div>\n</header>\n\n<div class=\"wrap\">\n  <form class=\"login\" id=\"login\" hidden>\n    <h2>Masuk ke papan pantau</h2>\n    <p>Isi kata sandi yang kamu simpan sebagai secret <b>ADMIN_KEY</b> di Cloudflare.</p>\n    <label for=\"key\">Kata sandi admin</label>\n    <input type=\"password\" id=\"key\" autocomplete=\"current-password\" required>\n    <div class=\"row\">\n      <label class=\"chk\"><input type=\"checkbox\" id=\"ingat\" checked> Ingat di perangkat ini</label>\n      <button class=\"btn primary\" type=\"submit\">Masuk</button>\n    </div>\n    <div class=\"err\" id=\"login-err\" role=\"alert\" hidden></div>\n  </form>\n\n  <main id=\"app\" hidden>\n    <div class=\"warnbar\" id=\"warn\" hidden></div>\n\n    <div class=\"kpis\" id=\"kpis\">\n      <div class=\"kpi lead\"><span>Total unduhan</span><b class=\"skel\">…</b><em>sejak rilis pertama</em></div>\n      <div class=\"kpi\"><span>Pengunjung website</span><b class=\"skel\">…</b><em>&nbsp;</em></div>\n      <div class=\"kpi\"><span>Perangkat aktif</span><b class=\"skel\">…</b><em>&nbsp;</em></div>\n      <div class=\"kpi\"><span>Pemakaian AI server</span><b class=\"skel\">…</b><em>&nbsp;</em></div>\n    </div>\n\n\n    <section class=\"part\" id=\"pengumuman\" aria-labelledby=\"h-pesan\">\n      <div class=\"ph\"><h2 id=\"h-pesan\"><span class=\"u\">Kirim pengumuman</span></h2><p>Muncul sebagai notifikasi dan kartu di Beranda aplikasi pengguna.</p></div>\n      <div class=\"compose\">\n        <form class=\"card form\" id=\"f-pesan\" autocomplete=\"off\">\n          <div><span class=\"l\" style=\"display:block;font-size:12.5px;font-weight:600;color:var(--muted);margin-bottom:5px\">Jenis</span>\n            <div class=\"seg small\" role=\"group\" aria-label=\"Jenis pengumuman\" id=\"p-jenis\"><button type=\"button\" data-j=\"info\" aria-pressed=\"true\">Info</button><button type=\"button\" data-j=\"update\" aria-pressed=\"false\">Update</button><button type=\"button\" data-j=\"penting\" aria-pressed=\"false\">Penting</button></div></div>\n          <div><label class=\"l\" for=\"p-judul\">Judul notifikasi</label><input type=\"text\" id=\"p-judul\" maxlength=\"80\" required placeholder=\"Contoh: Versi 1.0.19 sudah tersedia\"><div class=\"cnt\" id=\"c-judul\">0/80</div></div>\n          <div><label class=\"l\" for=\"p-isi\">Isi pesan</label><textarea id=\"p-isi\" maxlength=\"600\" placeholder=\"Tulis pesan untuk pengguna. Boleh beberapa baris.\"></textarea><div class=\"cnt\" id=\"c-isi\">0/600</div></div>\n          <div><label class=\"l\" for=\"p-link\">Link tombol \"Buka\" (opsional)</label><input type=\"url\" id=\"p-link\" placeholder=\"https://temankuliah.netlify.app\"></div>\n          <div class=\"row2\">\n            <div><label class=\"l\" for=\"p-plat\">Kirim ke</label><select id=\"p-plat\"><option value=\"semua\">Semua perangkat</option><option value=\"windows\">Laptop Windows saja</option><option value=\"android\">HP Android saja</option></select></div>\n            <div><label class=\"l\" for=\"p-hari\">Berlaku selama</label><select id=\"p-hari\"><option value=\"3\">3 hari</option><option value=\"7\">7 hari</option><option value=\"14\" selected>14 hari</option><option value=\"30\">30 hari</option></select></div>\n          </div>\n          <label class=\"chkrow\"><input type=\"checkbox\" id=\"p-lama\"> <span id=\"p-lama-l\">Hanya perangkat yang belum memakai versi terbaru</span></label>\n          <div class=\"aud\" id=\"p-aud\">Menghitung perkiraan penerima…</div>\n          <div class=\"actions\" id=\"p-act\"><button class=\"btn st\" type=\"submit\" id=\"p-kirim\">Kirim pengumuman</button><span class=\"note\">Pengguna yang aplikasinya tertutup menerimanya saat membuka aplikasi.</span></div>\n          <div class=\"confirm\" id=\"p-confirm\" hidden><span id=\"p-confirm-t\"></span><div class=\"actions\"><button class=\"btn primary\" type=\"button\" id=\"p-ya\">Ya, kirim sekarang</button><button class=\"btn\" type=\"button\" id=\"p-batal\">Batal</button></div></div>\n          <div class=\"ok-msg\" id=\"p-ok\" role=\"status\" hidden></div>\n          <div class=\"err\" id=\"p-err\" role=\"alert\" hidden></div>\n        </form>\n        <div class=\"prev-wrap\">\n          <div class=\"card prev-wrap\">\n            <span class=\"prev-l\">Notifikasi di laptop atau HP</span>\n            <div class=\"toast-prev\" aria-hidden=\"true\"><svg width=\"28\" height=\"28\" viewBox=\"0 0 32 32\"><rect width=\"32\" height=\"32\" rx=\"7\" fill=\"#15171C\"/><path d=\"M6 10c3-1.2 6.5-1 10 1v12c-3.5-2-7-2.2-10-1z\" fill=\"#fff\"/><path d=\"M26 10c-3-1.2-6.5-1-10 1v12c3.5-2 7-2.2 10-1z\" fill=\"#FFD60A\"/></svg><div><span class=\"ti\">Teman Kuliah</span><b id=\"pv-t1\">Judul notifikasi</b><p id=\"pv-i1\">Isi pesan tampil di sini.</p></div></div>\n            <span class=\"prev-l\">Kartu di Beranda aplikasi</span>\n            <div class=\"card-prev\" id=\"pv-card\" data-j=\"info\" aria-hidden=\"true\"><span class=\"tg\" id=\"pv-tag\">Info</span><b id=\"pv-t2\">Judul notifikasi</b><p id=\"pv-i2\">Isi pesan tampil di sini.</p><div class=\"bt\"><span class=\"d\" id=\"pv-buka\" hidden>Buka</span><span>Tutup</span></div></div>\n          </div>\n        </div>\n      </div>\n      <div class=\"card\" id=\"c-pesanlist\">\n        <h3>Pengumuman terkirim</h3>\n        <p class=\"sub\">\"Diterima\" = jumlah perangkat yang sudah mengambil pengumuman itu.</p>\n        <div class=\"tw\"><table id=\"tb-pesan\"><thead><tr><th>Tanggal</th><th>Pengumuman</th><th>Sasaran</th><th class=\"r\">Diterima</th><th>Status</th><th></th></tr></thead><tbody></tbody></table></div>\n      </div>\n    </section>\n    <section class=\"part\" id=\"unduhan\" aria-labelledby=\"h-unduh\">\n      <div class=\"ph\"><h2 id=\"h-unduh\"><span class=\"u\">Unduhan</span></h2><p>Dari GitHub, sejak versi pertama.</p></div>\n      <div class=\"grid2\">\n        <div class=\"card\" id=\"c-perversi\">\n          <h3>Unduhan per versi</h3>\n          <p class=\"sub\">Installer Windows dan APK Android, termasuk update otomatis.</p>\n          <div class=\"legend\"><span><i style=\"background:var(--win)\"></i>Windows</span><span><i style=\"background:var(--apk)\"></i>Android</span></div>\n          <div class=\"chart\" id=\"ch-versi\"></div>\n        </div>\n        <div class=\"card\" id=\"c-unduhharian\">\n          <h3>Unduhan per hari</h3>\n          <p class=\"sub\" id=\"sub-unduhharian\">Selisih angka GitHub dari hari ke hari.</p>\n          <div class=\"legend\"><span><i style=\"background:var(--win)\"></i>Windows</span><span><i style=\"background:var(--apk)\"></i>Android</span></div>\n          <div class=\"chart\" id=\"ch-unduhharian\"></div>\n        </div>\n      </div>\n      <div class=\"card\" id=\"c-tabelversi\">\n        <h3>Rincian per versi</h3>\n        <p class=\"sub\">Unduhan versi lama terus bertambah kalau ada yang memasang dari link lama.</p>\n        <div class=\"tw\"><table id=\"tb-versi\"><thead><tr><th>Versi</th><th>Rilis</th><th class=\"r\">Windows</th><th class=\"r\">Android</th><th class=\"r\">Total</th></tr></thead><tbody></tbody></table></div>\n      </div>\n    </section>\n\n    <section class=\"part\" id=\"website\" aria-labelledby=\"h-web\">\n      <div class=\"ph\"><h2 id=\"h-web\"><span class=\"u\">Website</span></h2><p id=\"p-web\">temankuliah.netlify.app</p></div>\n      <div class=\"grid2\">\n        <div class=\"card\" id=\"c-kunjungan\">\n          <h3>Pengunjung per hari</h3>\n          <p class=\"sub\">Pengunjung unik dihitung per hari, tanpa cookie.</p>\n          <div class=\"legend\"><span><i style=\"background:var(--ink)\"></i>Pengunjung</span><span><i style=\"background:var(--stabilo)\"></i>Halaman dibuka</span></div>\n          <div class=\"chart\" id=\"ch-web\"></div>\n        </div>\n        <div class=\"card\" id=\"c-corong\">\n          <h3>Dari datang sampai unduh</h3>\n          <p class=\"sub\">Berapa banyak pengunjung yang sampai ke tiap langkah.</p>\n          <div class=\"funnel\" id=\"funnel\"></div>\n        </div>\n      </div>\n      <div class=\"grid3\">\n        <div class=\"card\" id=\"c-klik\"><h3>Tombol yang diklik</h3><p class=\"sub\">Dalam rentang terpilih.</p><div class=\"bars\" id=\"b-klik\"></div></div>\n        <div class=\"card\" id=\"c-ref\"><h3>Datang dari mana</h3><p class=\"sub\">Situs sebelum membuka website.</p><div class=\"bars\" id=\"b-ref\"></div></div>\n        <div class=\"card\" id=\"c-alat\"><h3>Dibuka pakai apa</h3><p class=\"sub\">Jenis perangkat pengunjung.</p><div class=\"bars\" id=\"b-alat\"></div></div>\n        <div class=\"card\" id=\"c-kota\"><h3>Kota</h3><p class=\"sub\">Perkiraan dari jaringan internet.</p><div class=\"bars\" id=\"b-kota\"></div></div>\n        <div class=\"card\" id=\"c-sumber\"><h3>Link kampanye</h3><p class=\"sub\">Dari link berakhiran ?ref=nama, misalnya ?ref=ig.</p><div class=\"bars\" id=\"b-sumber\"></div></div>\n        <div class=\"card\" id=\"c-keluhan\"><h3>Keluhan terkirim</h3><p class=\"sub\">Per kategori. Isinya ada di Google Sheets.</p><div class=\"bars\" id=\"b-keluhan\"></div></div>\n      </div>\n    </section>\n\n    <section class=\"part\" id=\"aplikasi\" aria-labelledby=\"h-app\">\n      <div class=\"ph\"><h2 id=\"h-app\"><span class=\"u\">Aplikasi</span></h2><p>Perangkat yang benar-benar memakai Teman Kuliah, anonim.</p></div>\n      <div class=\"grid2\">\n        <div class=\"card\" id=\"c-aktif\">\n          <h3>Perangkat aktif per hari</h3>\n          <p class=\"sub\" id=\"sub-aktif\"></p>\n          <div class=\"mini\" id=\"mini-app\"></div>\n          <div class=\"legend\"><span><i style=\"background:var(--ink)\"></i>Aktif</span><span><i style=\"background:var(--stabilo)\"></i>Baru pertama kali</span></div>\n          <div class=\"chart\" id=\"ch-aktif\"></div>\n        </div>\n        <div class=\"card\" id=\"c-versiapp\">\n          <h3>Versi yang dipakai</h3>\n          <p class=\"sub\">Perangkat aktif 30 hari terakhir.</p>\n          <div class=\"bars\" id=\"b-ver\"></div>\n          <h3 style=\"margin-top:16px\">Platform</h3>\n          <p class=\"sub\">Laptop atau HP.</p>\n          <div class=\"bars\" id=\"b-plat\"></div>\n        </div>\n      </div>\n    </section>\n\n    <section class=\"part\" id=\"ai\" aria-labelledby=\"h-ai\">\n      <div class=\"ph\"><h2 id=\"h-ai\"><span class=\"u\">AI server</span></h2><p>Permintaan yang dikerjakan server Cloudflare-mu (Groq), bukan Gemini milik pengguna.</p></div>\n      <div class=\"grid2\">\n        <div class=\"card\" id=\"c-aiharian\">\n          <h3>Permintaan per hari</h3>\n          <p class=\"sub\">Per jenis tugas.</p>\n          <div class=\"legend\" id=\"lg-ai\"></div>\n          <div class=\"chart\" id=\"ch-ai\"></div>\n        </div>\n        <div class=\"card\" id=\"c-aitotal\">\n          <h3>Total dalam rentang</h3>\n          <p class=\"sub\" id=\"sub-aitotal\"></p>\n          <div class=\"bars\" id=\"b-ai\"></div>\n          <h3 style=\"margin-top:16px\">Jatah per orang per hari</h3>\n          <p class=\"sub\">Diubah lewat Variables di Cloudflare.</p>\n          <div class=\"bars\" id=\"b-jatah\"></div>\n        </div>\n      </div>\n    </section>\n\n    <footer>\n      <div class=\"links\">\n        <a class=\"btn\" href=\"https://github.com/Richsandy/teman-kuliah/releases\" target=\"_blank\" rel=\"noopener\">Rilis GitHub</a>\n        <a class=\"btn\" href=\"https://temankuliah.netlify.app/\" target=\"_blank\" rel=\"noopener\">Website</a>\n        <a class=\"btn\" href=\"https://app.netlify.com/\" target=\"_blank\" rel=\"noopener\">Netlify</a>\n        <a class=\"btn\" href=\"https://dash.cloudflare.com/\" target=\"_blank\" rel=\"noopener\">Cloudflare</a>\n        <a class=\"btn\" href=\"https://trakteer.id/\" target=\"_blank\" rel=\"noopener\">Trakteer</a>\n        <button class=\"btn\" type=\"button\" id=\"keluar\">Keluar</button>\n      </div>\n      <p class=\"note\" style=\"margin-top:12px\">Angka unduhan GitHub ikut menghitung update otomatis dan unduhanmu sendiri, jadi lebih besar dari jumlah orang. Jumlah orang paling tepat dilihat di bagian Aplikasi.</p>\n    </footer>\n  </main>\n</div>\n\n<script>\n(function(){\n  \"use strict\";\n  var $ = function(s){ return document.querySelector(s); };\n  var KEY = \"tk-admin\", RKEY = \"tk-pantau-rentang\";\n  var store = { get: function(k){ try { return localStorage.getItem(k) || sessionStorage.getItem(k); } catch(e){ return null; } },\n    set: function(k, v, tetap){ try { (tetap ? localStorage : sessionStorage).setItem(k, v); } catch(e){} },\n    del: function(k){ try { localStorage.removeItem(k); sessionStorage.removeItem(k); } catch(e){} } };\n  var rentang = parseInt(store.get(RKEY), 10) || 30, D = null, loading = false;\n\n  var fmt = function(n){ return (Number(n) || 0).toLocaleString(\"id-ID\"); };\n  var BLN = [\"Jan\",\"Feb\",\"Mar\",\"Apr\",\"Mei\",\"Jun\",\"Jul\",\"Agu\",\"Sep\",\"Okt\",\"Nov\",\"Des\"];\n  var tgl = function(s, thn){ if (!s) return \"-\"; var p = String(s).split(\"-\"); return Number(p[2]) + \" \" + BLN[Number(p[1]) - 1] + (thn ? \" \" + p[0] : \"\"); };\n  function addDays(s, n){ var p = s.split(\"-\").map(Number); var d = new Date(Date.UTC(p[0], p[1] - 1, p[2] + n)); return d.toISOString().slice(0, 10); }\n  function daysRange(dari, sampai){ var out = [], d = dari, i = 0; while (d <= sampai && i < 900){ out.push(d); d = addDays(d, 1); i++; } return out; }\n  function el(tag, cls, txt){ var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }\n  var NS = \"http://www.w3.org/2000/svg\";\n  function sv(tag, attrs){ var e = document.createElementNS(NS, tag); for (var k in attrs) e.setAttribute(k, attrs[k]); return e; }\n  function css(v){ return getComputedStyle(document.documentElement).getPropertyValue(v).trim(); }\n  function niceMax(m){ if (m <= 4) return 4; if (m <= 8) return 8; var p = Math.pow(10, Math.floor(Math.log10(m))), f = m / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p; }\n\n  // ---------- grafik ----------\n  // Grafik kolom (bisa bertumpuk) atau garis. series: [{name, color, values, type:\"bar\"|\"line\"}]\n  function chart(box, labels, series, opt){\n    opt = opt || {};\n    box.textContent = \"\";\n    var total = 0; series.forEach(function(s){ s.values.forEach(function(v){ total += v || 0; }); });\n    if (!labels.length || (!total && !opt.showZero)){ box.appendChild(el(\"div\", \"empty\", opt.empty || \"Belum ada data di rentang ini.\")); return; }\n    var W = Math.max(280, box.clientWidth || 600), H = opt.h || 210, padL = 34, padR = 8, padT = 10, padB = 24;\n    var iw = W - padL - padR, ih = H - padT - padB, n = labels.length;\n    var bars = series.filter(function(s){ return s.type !== \"line\"; }), lines = series.filter(function(s){ return s.type === \"line\"; });\n    var max = 0;\n    for (var i = 0; i < n; i++){ var st = 0; bars.forEach(function(s){ st += s.values[i] || 0; }); max = Math.max(max, st); lines.forEach(function(s){ max = Math.max(max, s.values[i] || 0); }); }\n    max = niceMax(max || 1);\n    var y = function(v){ return padT + ih - (v / max) * ih; };\n    var bw = iw / n, x = function(i){ return padL + bw * i + bw / 2; };\n    var svg = sv(\"svg\", { viewBox: \"0 0 \" + W + \" \" + H, height: H, role: \"img\", \"aria-label\": opt.label || \"grafik\" });\n    var steps = (max / 4) % 1 ? 5 : 4;\n    for (var g = 0; g <= steps; g++){\n      var v = max * g / steps, yy = y(v);\n      svg.appendChild(sv(\"line\", { x1: padL, x2: W - padR, y1: yy, y2: yy, stroke: css(\"--grid\"), \"stroke-width\": 1 }));\n      var t = sv(\"text\", { x: padL - 6, y: yy + 3.5, \"text-anchor\": \"end\" }); t.textContent = v >= 1000 ? (v / 1000).toLocaleString(\"id-ID\") + \"rb\" : fmt(Math.round(v * 10) / 10); svg.appendChild(t);\n    }\n    var every = Math.ceil(n / Math.max(2, Math.floor(iw / (opt.labW || 52))));\n    labels.forEach(function(l, i){\n      if (i % every && i !== n - 1) return;\n      if (i !== n - 1 && n - 1 - i < every && i % every === 0 && n > every) { /* hindari label bertumpuk di ujung */ if (n - 1 - i < every * .7) return; }\n      var t = sv(\"text\", { x: x(i), y: H - 6, \"text-anchor\": \"middle\" }); t.textContent = opt.fmtLab ? opt.fmtLab(l) : l; svg.appendChild(t);\n    });\n    var gap = Math.min(10, bw * .28), w = Math.max(1.5, bw - gap);\n    for (var i2 = 0; i2 < n; i2++){\n      var base = 0;\n      bars.forEach(function(s){ var v = s.values[i2] || 0; if (!v) return; var y0 = y(base), y1 = y(base + v); svg.appendChild(sv(\"rect\", { x: x(i2) - w / 2, y: y1, width: w, height: Math.max(.5, y0 - y1), rx: Math.min(3, w / 3), fill: s.color })); base += v; });\n    }\n    lines.forEach(function(s){\n      var d = s.values.map(function(v, i){ return (i ? \"L\" : \"M\") + x(i).toFixed(1) + \" \" + y(v || 0).toFixed(1); }).join(\" \");\n      if (s.area){ svg.appendChild(sv(\"path\", { d: d + \" L\" + x(n - 1).toFixed(1) + \" \" + y(0) + \" L\" + x(0).toFixed(1) + \" \" + y(0) + \" Z\", fill: s.color, opacity: .12 })); }\n      svg.appendChild(sv(\"path\", { d: d, fill: \"none\", stroke: s.color, \"stroke-width\": s.w || 2.2, \"stroke-linejoin\": \"round\", \"stroke-linecap\": \"round\" }));\n      var li = n - 1; svg.appendChild(sv(\"circle\", { cx: x(li), cy: y(s.values[li] || 0), r: 3.6, fill: s.color, stroke: css(\"--panel\"), \"stroke-width\": 1.5 }));\n    });\n    var hover = sv(\"rect\", { x: 0, y: padT, width: 0, height: ih, fill: css(\"--ink\"), opacity: 0 }); svg.insertBefore(hover, svg.firstChild);\n    var tip = el(\"div\", \"tip\"); tip.hidden = true;\n    function show(ev){\n      var r = svg.getBoundingClientRect(), px = (ev.clientX - r.left) * (W / r.width), i = Math.floor((px - padL) / bw);\n      if (i < 0 || i >= n){ hide(); return; }\n      hover.setAttribute(\"x\", padL + bw * i); hover.setAttribute(\"width\", bw); hover.setAttribute(\"opacity\", .05);\n      tip.textContent = \"\"; var h = el(\"b\", null, opt.fmtTip ? opt.fmtTip(labels[i]) : labels[i]); tip.appendChild(h);\n      series.forEach(function(s){ var row = el(\"div\"); var d = el(\"span\", \"dot\"); d.style.background = s.color; row.appendChild(d); row.appendChild(document.createTextNode(s.name + \": \" + fmt(s.values[i]))); tip.appendChild(row); });\n      tip.hidden = false;\n      var left = x(i) / W * r.width; left = Math.max(70, Math.min(r.width - 70, left)); tip.style.left = left + \"px\"; tip.style.top = (padT / H * r.height + 6) + \"px\";\n    }\n    function hide(){ tip.hidden = true; hover.setAttribute(\"opacity\", 0); }\n    svg.addEventListener(\"pointermove\", show); svg.addEventListener(\"pointerleave\", hide);\n    box.appendChild(svg); box.appendChild(tip);\n  }\n\n  function barList(box, rows, opt){\n    opt = opt || {}; box.textContent = \"\";\n    rows = rows.filter(function(r){ return r.n > 0; });\n    if (!rows.length){ box.appendChild(el(\"div\", \"empty\", opt.empty || \"Belum ada data.\")); box.firstChild.style.minHeight = \"90px\"; return; }\n    var max = Math.max.apply(null, rows.map(function(r){ return r.n; })), sum = rows.reduce(function(a, r){ return a + r.n; }, 0);\n    rows.slice(0, opt.limit || 8).forEach(function(r, i){\n      var b = el(\"div\", \"bar\" + (opt.hlFirst && i === 0 ? \" hl\" : \"\"));\n      b.appendChild(el(\"span\", \"lab\", r.label));\n      b.appendChild(el(\"span\", \"val\", fmt(r.n) + (opt.pct === false ? \"\" : \" · \" + Math.round(r.n / sum * 100) + \"%\")));\n      var trk = el(\"span\", \"trk\"), fill = el(\"i\"); fill.style.width = Math.max(2, r.n / max * 100) + \"%\"; if (r.color) fill.style.background = r.color; trk.appendChild(fill); b.appendChild(trk);\n      box.appendChild(b);\n    });\n  }\n\n  // ---------- olah data ----------\n  function jenisAset(nama){ return /\\.exe$/i.test(nama) ? \"win\" : /\\.apk$/i.test(nama) ? \"apk\" : /latest.*\\.yml$/i.test(nama) ? \"yml\" : null; }\n  function olahRilis(gh){\n    var rows = (gh.rilis || []).map(function(r){ var o = { tag: r.tag, tanggal: r.tanggal, waktu: r.waktu || r.tanggal, pre: r.pre, win: 0, apk: 0, yml: 0 }; r.aset.forEach(function(a){ var j = jenisAset(a.nama); if (j) o[j] += a.n; }); o.total = o.win + o.apk; return o; });\n    rows.sort(function(a, b){ return a.waktu < b.waktu ? -1 : a.waktu > b.waktu ? 1 : 0; });\n    return rows;\n  }\n  function topOf(jenis, map){ return (D.web.top || []).filter(function(r){ return r.jenis === jenis; }).map(function(r){ return { label: map ? map(r.kunci) : r.kunci, n: r.n }; }); }\n  var NEGARA = { ID: \"Indonesia\", MY: \"Malaysia\", SG: \"Singapura\", US: \"Amerika Serikat\", JP: \"Jepang\", AU: \"Australia\", NL: \"Belanda\", DE: \"Jerman\", GB: \"Inggris\", TW: \"Taiwan\", KR: \"Korea Selatan\", SA: \"Arab Saudi\", HK: \"Hong Kong\" };\n  var KLIK = { windows: \"Unduh Windows\", android: \"Unduh Android\", panduan: \"Panduan PDF\", trakteer: \"Traktir di Trakteer\", github: \"Semua versi (GitHub)\" };\n  var JENIS_AI = { chat: [\"Tanya AI\", \"--ink\"], materi: [\"Ringkas materi\", \"--win\"], lain: [\"Latihan dan lainnya\", \"--apk\"], video: [\"Transkrip video\", \"--c3\"] };\n  var PLAT = { windows: \"Laptop Windows\", android: \"HP Android\", mac: \"Mac\", ios: \"iPhone\", linux: \"Linux\", \"?\": \"Belum diketahui\" };\n\n  function render(){\n    if (!D) return;\n    var days = daysRange(D.dari, D.hariIni), rel = olahRilis(D.github);\n    var totWin = rel.reduce(function(a, r){ return a + r.win; }, 0), totApk = rel.reduce(function(a, r){ return a + r.apk; }, 0);\n    var warn = [];\n    if (D.github.galat) warn.push(\"Angka GitHub belum bisa diperbarui (\" + D.github.galat + \"). Yang tampil adalah angka terakhir yang tersimpan.\");\n    var wb = $(\"#warn\"); wb.hidden = !warn.length; wb.textContent = warn.join(\" \");\n    var ghAt = D.github.at ? new Date(D.github.at * 1000) : null;\n    $(\"#upd-line\").textContent = \"Diperbarui \" + new Date(D.dibuat).toLocaleTimeString(\"id-ID\", { hour: \"2-digit\", minute: \"2-digit\" }) + (ghAt ? \" · GitHub \" + ghAt.toLocaleTimeString(\"id-ID\", { hour: \"2-digit\", minute: \"2-digit\" }) : \"\") + \" · server \" + D.versi;\n\n    // web per hari\n    var wmap = {}; (D.web.harian || []).forEach(function(r){ wmap[r.hari] = r; });\n    var unik = days.map(function(d){ return wmap[d] ? wmap[d].unik : 0; }), lihat = days.map(function(d){ return wmap[d] ? wmap[d].lihat : 0; });\n    var sumUnik = unik.reduce(function(a, b){ return a + b; }, 0), sumLihat = lihat.reduce(function(a, b){ return a + b; }, 0);\n    // ai\n    var aiTot = { chat: 0, materi: 0, lain: 0, video: 0 }, aiByDay = {};\n    (D.ai.harian || []).forEach(function(r){ aiTot[r.jenis] = (aiTot[r.jenis] || 0) + r.total; (aiByDay[r.hari] = aiByDay[r.hari] || {})[r.jenis] = r.total; });\n    var aiAll = Object.keys(aiTot).reduce(function(a, k){ return a + aiTot[k]; }, 0);\n    var orangMap = {}; (D.ai.orang || []).forEach(function(r){ orangMap[r.hari] = r.orang; });\n    var orangToday = orangMap[D.hariIni] || 0, orangMax = Math.max.apply(null, [0].concat((D.ai.orang || []).map(function(r){ return r.orang; })));\n    var A = D.aplikasi.aktif || {};\n\n    // KPI\n    var k = document.querySelectorAll(\".kpi\");\n    function kpi(i, val, em){ var b = k[i].querySelector(\"b\"); b.className = \"\"; b.textContent = \"\"; var s = el(\"span\", \"hl\", val); b.appendChild(s); k[i].querySelector(\"em\").textContent = em; }\n    kpi(0, fmt(totWin + totApk), \"Windows \" + fmt(totWin) + \" · Android \" + fmt(totApk));\n    kpi(1, fmt(sumUnik), \"dalam \" + rentangTeks() + \" · \" + fmt(sumLihat) + \" kali dibuka\");\n    kpi(2, fmt(A.a30 || 0), \"30 hari · hari ini \" + fmt(A.a1 || 0) + \" · 7 hari \" + fmt(A.a7 || 0));\n    kpi(3, fmt(aiAll), \"permintaan dalam \" + rentangTeks() + \" · paling ramai \" + fmt(orangMax) + \" orang/hari\");\n\n    // unduhan per versi\n    var relShow = rel.slice(-Math.max(6, Math.min(rel.length, 24)));\n    chart($(\"#ch-versi\"), relShow.map(function(r){ return r.tag; }), [\n      { name: \"Windows\", color: css(\"--win\"), values: relShow.map(function(r){ return r.win; }) },\n      { name: \"Android\", color: css(\"--apk\"), values: relShow.map(function(r){ return r.apk; }) }\n    ], { label: \"Unduhan per versi\", labW: 50, fmtLab: function(t){ return String(t).replace(/^v/, \"\"); }, fmtTip: function(t){ var r = rel.filter(function(x){ return x.tag === t; })[0]; return t + (r ? \" · rilis \" + tgl(r.tanggal, true) : \"\"); }, empty: \"Belum ada rilis yang terbaca dari GitHub.\" });\n\n    // unduhan per hari dari catatan harian\n    var cum = {}; (D.unduhHarian || []).forEach(function(r){ var j = jenisAset(r.aset); if (!j) return; var c = cum[r.hari] || (cum[r.hari] = { win: 0, apk: 0, yml: 0 }); c[j] += r.n; });\n    var snapDays = Object.keys(cum).sort(), dWin = {}, dApk = {}, dYml = {};\n    for (var i = 1; i < snapDays.length; i++){ var a = cum[snapDays[i - 1]], b = cum[snapDays[i]]; dWin[snapDays[i]] = Math.max(0, b.win - a.win); dApk[snapDays[i]] = Math.max(0, b.apk - a.apk); dYml[snapDays[i]] = Math.max(0, b.yml - a.yml); }\n    var mulaiU = D.mulai.unduh;\n    $(\"#sub-unduhharian\").textContent = mulaiU ? \"Dicatat sejak \" + tgl(mulaiU, true) + \". Hari tanpa catatan digabung ke hari berikutnya.\" : \"Mulai dicatat setelah server versi baru dipasang.\";\n    chart($(\"#ch-unduhharian\"), days, [\n      { name: \"Windows\", color: css(\"--win\"), values: days.map(function(d){ return dWin[d] || 0; }) },\n      { name: \"Android\", color: css(\"--apk\"), values: days.map(function(d){ return dApk[d] || 0; }) }\n    ], { label: \"Unduhan per hari\", fmtLab: function(d){ return tgl(d); }, fmtTip: function(d){ return tgl(d, true); }, empty: snapDays.length < 2 ? \"Grafik ini mulai terisi besok. Server perlu catatan dua hari untuk menghitung selisihnya.\" : \"Tidak ada unduhan baru di rentang ini.\" });\n\n    // tabel per versi\n    var tb = $(\"#tb-versi tbody\"); tb.textContent = \"\";\n    rel.slice().reverse().forEach(function(r, i){\n      var tr = document.createElement(\"tr\");\n      var td0 = el(\"td\"); td0.appendChild(document.createTextNode(r.tag)); if (i === 0) td0.appendChild(el(\"span\", \"pill\", \"terbaru\"));\n      tr.appendChild(td0); tr.appendChild(el(\"td\", null, tgl(r.tanggal, true)));\n      [r.win, r.apk, r.total].forEach(function(v){ tr.appendChild(el(\"td\", \"r\", fmt(v))); });\n      tb.appendChild(tr);\n    });\n    if (rel.length){ var tf = document.createElement(\"tr\"); tf.style.fontWeight = \"700\"; tf.appendChild(el(\"td\", null, \"Semua versi\")); tf.appendChild(el(\"td\", null, \"\")); [totWin, totApk, totWin + totApk].forEach(function(v){ tf.appendChild(el(\"td\", \"r\", fmt(v))); }); tb.appendChild(tf); }\n\n    // website\n    $(\"#p-web\").textContent = \"temankuliah.netlify.app\" + (D.mulai.web ? \" · dicatat sejak \" + tgl(D.mulai.web, true) : \" · belum ada catatan\");\n    chart($(\"#ch-web\"), days, [\n      { name: \"Halaman dibuka\", color: css(\"--stabilo\"), values: lihat },\n      { name: \"Pengunjung\", color: css(\"--ink\"), values: unik, type: \"line\", area: true }\n    ], { label: \"Pengunjung website per hari\", fmtLab: function(d){ return tgl(d); }, fmtTip: function(d){ return tgl(d, true); }, empty: D.mulai.web ? \"Belum ada pengunjung di rentang ini.\" : \"Belum ada catatan. Pasang skrip pencatat di website, lalu deploy ulang ke Netlify.\" });\n    var bag = {}; topOf(\"bagian\").forEach(function(r){ bag[r.label] = r.n; });\n    var kl = {}; topOf(\"klik\").forEach(function(r){ kl[r.label] = r.n; });\n    var steps = [[\"Membuka website\", sumLihat], [\"Melihat fitur\", bag.fitur || 0], [\"Sampai bagian Unduh\", bag.unduh || 0], [\"Klik unduh\", (kl.windows || 0) + (kl.android || 0)]];\n    var fb = $(\"#funnel\"); fb.textContent = \"\";\n    var top0 = Math.max(1, steps[0][1]);\n    steps.forEach(function(s){ var row = el(\"div\", \"fstep\"); row.appendChild(el(\"span\", null, s[0])); var trk = el(\"span\", \"trk\"), f = el(\"i\"); f.style.width = Math.max(1.5, s[1] / top0 * 100) + \"%\"; trk.appendChild(f); row.appendChild(trk); row.appendChild(el(\"span\", \"v\", fmt(s[1]) + (steps[0][1] ? \" · \" + Math.round(s[1] / top0 * 100) + \"%\" : \"\"))); fb.appendChild(row); });\n    barList($(\"#b-klik\"), Object.keys(KLIK).map(function(k){ return { label: KLIK[k], n: kl[k] || 0, color: k === \"windows\" ? css(\"--win\") : k === \"android\" ? css(\"--apk\") : null }; }).sort(function(a, b){ return b.n - a.n; }), { empty: \"Belum ada klik tercatat.\" });\n    barList($(\"#b-ref\"), topOf(\"ref\"), { hlFirst: true });\n    barList($(\"#b-alat\"), topOf(\"alat\"));\n    var kota = topOf(\"kota\"); if (!kota.length) kota = topOf(\"negara\", function(c){ return NEGARA[c] || c; });\n    barList($(\"#b-kota\"), kota);\n    barList($(\"#b-sumber\"), topOf(\"sumber\"), { empty: \"Belum ada. Bagikan link seperti temankuliah.netlify.app/?ref=ig supaya terlihat di sini.\" });\n    barList($(\"#b-keluhan\"), topOf(\"keluhan\"), { empty: \"Belum ada keluhan terkirim di rentang ini.\" });\n\n    // aplikasi\n    var amap = {}, bmap = {}; (D.aplikasi.harian || []).forEach(function(r){ amap[r.hari] = r.n; }); (D.aplikasi.baru || []).forEach(function(r){ bmap[r.hari] = r.n; });\n    $(\"#sub-aktif\").textContent = D.mulai.aplikasi ? \"Dicatat sejak \" + tgl(D.mulai.aplikasi, true) + \". Sampai versi 1.0.18, perangkat baru terhitung saat memakai Tanya AI atau melihat sisa jatah AI.\" : \"Belum ada perangkat tercatat. Angka masuk saat aplikasi menghubungi server.\";\n    var mini = $(\"#mini-app\"); mini.textContent = \"\";\n    [[\"Pernah tercatat\", D.aplikasi.total], [\"Baru di rentang ini\", days.reduce(function(a, d){ return a + (bmap[d] || 0); }, 0)], [\"Sudah login Edlink\", D.aplikasi.edlink]].forEach(function(m){ var d = el(\"div\"); d.appendChild(el(\"span\", null, m[0])); d.appendChild(el(\"b\", null, fmt(m[1]))); mini.appendChild(d); });\n    chart($(\"#ch-aktif\"), days, [\n      { name: \"Baru pertama kali\", color: css(\"--stabilo\"), values: days.map(function(d){ return bmap[d] || 0; }) },\n      { name: \"Aktif\", color: css(\"--ink\"), values: days.map(function(d){ return amap[d] || 0; }), type: \"line\" }\n    ], { label: \"Perangkat aktif per hari\", fmtLab: function(d){ return tgl(d); }, fmtTip: function(d){ return tgl(d, true); }, empty: \"Belum ada perangkat yang tercatat di rentang ini.\" });\n    barList($(\"#b-ver\"), (D.aplikasi.versi || []).map(function(r){ return { label: r.ver === \"lama\" ? \"1.0.18 atau lebih lama\" : \"Versi \" + r.ver, n: r.n }; }), { hlFirst: true, empty: \"Belum ada data versi.\" });\n    barList($(\"#b-plat\"), (D.aplikasi.platform || []).map(function(r){ return { label: PLAT[r.plat] || r.plat, n: r.n, color: r.plat === \"windows\" ? css(\"--win\") : r.plat === \"android\" ? css(\"--apk\") : null }; }), { empty: \"Belum ada data platform.\" });\n\n    // ai\n    var lg = $(\"#lg-ai\"); lg.textContent = \"\";\n    var aiSeries = Object.keys(JENIS_AI).map(function(j){ var sp = el(\"span\"), ic = el(\"i\"); ic.style.background = css(JENIS_AI[j][1]); sp.appendChild(ic); sp.appendChild(document.createTextNode(JENIS_AI[j][0])); lg.appendChild(sp); return { name: JENIS_AI[j][0], color: css(JENIS_AI[j][1]), values: days.map(function(d){ return (aiByDay[d] || {})[j] || 0; }) }; });\n    chart($(\"#ch-ai\"), days, aiSeries, { label: \"Permintaan AI server per hari\", fmtLab: function(d){ return tgl(d); }, fmtTip: function(d){ return tgl(d, true) + \" · \" + fmt(orangMap[d] || 0) + \" orang\"; }, empty: \"Belum ada permintaan ke AI server di rentang ini. Riwayat lengkap mulai disimpan sejak server 1.2.\" });\n    $(\"#sub-aitotal\").textContent = fmt(aiAll) + \" permintaan · hari ini \" + fmt(orangToday) + \" orang memakai\";\n    barList($(\"#b-ai\"), Object.keys(JENIS_AI).map(function(j){ return { label: JENIS_AI[j][0], n: aiTot[j] || 0, color: css(JENIS_AI[j][1]) }; }).sort(function(a, b){ return b.n - a.n; }), { empty: \"Belum ada pemakaian.\" });\n    var J = D.ai.jatah || {};\n    barList($(\"#b-jatah\"), Object.keys(JENIS_AI).map(function(j){ return { label: JENIS_AI[j][0], n: J[j] || 0 }; }), { pct: false });\n  }\n\n  // ---------- pengumuman ----------\n  var P = null, pJenis = \"info\", pMenunggu = false;\n  var JENIS = { info: \"Info\", update: \"Update\", penting: \"Penting\" }, SASARAN = { semua: \"Semua perangkat\", windows: \"Laptop Windows\", android: \"HP Android\" };\n  function versiTerbaru(){ var rel = D ? olahRilis(D.github).filter(function(r){ return !r.pre; }) : []; return rel.length ? String(rel[rel.length - 1].tag).replace(/^v/, \"\") : \"\"; }\n  function vnum(v){ return String(v || \"0\").split(\".\").map(Number).reduce(function(a, x){ return a * 1000 + (x || 0); }, 0); }\n  function pratinjau(){\n    var j = $(\"#p-judul\").value.trim(), i = $(\"#p-isi\").value.trim(), l = $(\"#p-link\").value.trim();\n    $(\"#c-judul\").textContent = $(\"#p-judul\").value.length + \"/80\"; $(\"#c-isi\").textContent = $(\"#p-isi\").value.length + \"/600\";\n    $(\"#pv-t1\").textContent = j || \"Judul notifikasi\"; $(\"#pv-t2\").textContent = j || \"Judul notifikasi\";\n    $(\"#pv-i1\").textContent = i || \"Isi pesan tampil di sini.\"; $(\"#pv-i2\").textContent = i || \"Isi pesan tampil di sini.\";\n    $(\"#pv-card\").setAttribute(\"data-j\", pJenis); $(\"#pv-tag\").textContent = JENIS[pJenis]; $(\"#pv-buka\").hidden = !l;\n    var vt = versiTerbaru(); $(\"#p-lama-l\").textContent = vt ? \"Hanya perangkat yang belum memakai versi \" + vt + \" (pengingat update)\" : \"Hanya perangkat yang belum memakai versi terbaru\";\n    hitungPenerima(); batalKonfirmasi();\n  }\n  function hitungPenerima(){\n    var a = $(\"#p-aud\"); if (!P){ a.textContent = \"Menghitung perkiraan penerima…\"; return; }\n    var plat = $(\"#p-plat\").value, lama = $(\"#p-lama\").checked, vt = versiTerbaru(), bisa = 0, belum = 0;\n    (P.perangkat || []).forEach(function(r){\n      if (plat !== \"semua\" && r.plat !== plat) return;\n      var siap = r.ver !== \"lama\" && vnum(r.ver) >= vnum(\"1.0.19\");\n      if (lama && vt && r.ver !== \"lama\" && vnum(r.ver) >= vnum(vt)) return;\n      if (siap) bisa += r.n; else belum += r.n;\n    });\n    a.textContent = \"\";\n    a.appendChild(document.createTextNode(\"Perkiraan penerima: \")); a.appendChild(el(\"b\", null, fmt(bisa) + \" perangkat\")); a.appendChild(document.createTextNode(\" (aktif 30 hari, versi 1.0.19 ke atas).\"));\n    if (belum) a.appendChild(document.createTextNode(\" \" + fmt(belum) + \" perangkat lain masih versi 1.0.18 atau lebih lama, jadi baru menerima pengumuman setelah update.\"));\n    return bisa;\n  }\n  function batalKonfirmasi(){ $(\"#p-confirm\").hidden = true; $(\"#p-act\").hidden = false; }\n  function muatPesan(){\n    var key = store.get(KEY); if (!key) return;\n    fetch(\"/v1/dash/pesan\", { headers: { \"X-TK-Admin\": key }, cache: \"no-store\" }).then(function(r){ return r.json(); }).then(function(j){ if (!j || !j.ok) return; P = j; renderPesan(); hitungPenerima(); }).catch(function(){});\n  }\n  function renderPesan(){\n    var tb = $(\"#tb-pesan tbody\"); tb.textContent = \"\";\n    if (!P || !P.pesan.length){ var tr = document.createElement(\"tr\"), td = el(\"td\", null, \"Belum ada pengumuman yang dikirim.\"); td.colSpan = 6; td.style.color = \"var(--muted)\"; tr.appendChild(td); tb.appendChild(tr); return; }\n    P.pesan.forEach(function(m){\n      var tr = document.createElement(\"tr\"), d = new Date(m.dibuat * 1000);\n      tr.appendChild(el(\"td\", null, d.getDate() + \" \" + BLN[d.getMonth()] + \" \" + String(d.getHours()).padStart(2, \"0\") + \".\" + String(d.getMinutes()).padStart(2, \"0\")));\n      var tdj = el(\"td\", \"wrap\"); var bj = el(\"b\", null, m.judul); tdj.appendChild(bj); if (m.isi) tdj.appendChild(el(\"small\", null, m.isi.length > 90 ? m.isi.slice(0, 90) + \"…\" : m.isi)); tr.appendChild(tdj);\n      tr.appendChild(el(\"td\", null, JENIS[m.jenis] + \" · \" + SASARAN[m.plat] + (m.verdi ? \" · di bawah \" + m.verdi : \"\")));\n      tr.appendChild(el(\"td\", \"r\", fmt(m.terkirim)));\n      var aktif = m.aktif && m.sampai > P.now, tds = el(\"td\"); tds.appendChild(el(\"span\", \"st \" + (aktif ? \"on\" : \"off\"), aktif ? \"Aktif sampai \" + tgl(new Date(m.sampai * 1000).toISOString().slice(0, 10)) : (m.aktif ? \"Kedaluwarsa\" : \"Ditarik\"))); tr.appendChild(tds);\n      var tda = el(\"td\"); if (aktif){ var b = el(\"button\", \"btn sm\", \"Tarik\"); b.type = \"button\"; b.title = \"Berhenti mengirim ke perangkat yang belum menerima\"; b.addEventListener(\"click\", function(){ tarik(m.id, b); }); tda.appendChild(b); } tr.appendChild(tda);\n      tb.appendChild(tr);\n    });\n  }\n  function tarik(id, b){\n    if (b.dataset.yakin !== \"1\"){ b.dataset.yakin = \"1\"; b.textContent = \"Yakin tarik?\"; setTimeout(function(){ if (b.isConnected){ b.dataset.yakin = \"\"; b.textContent = \"Tarik\"; } }, 4000); return; }\n    b.disabled = true;\n    fetch(\"/v1/dash/pesan/tarik\", { method: \"POST\", headers: { \"X-TK-Admin\": store.get(KEY), \"Content-Type\": \"application/json\" }, body: JSON.stringify({ id: id }) }).then(function(r){ return r.json(); }).then(function(){ muatPesan(); }).catch(function(){ b.disabled = false; });\n  }\n  Array.prototype.forEach.call(document.querySelectorAll(\"#p-jenis button\"), function(b){ b.addEventListener(\"click\", function(){ pJenis = b.dataset.j; Array.prototype.forEach.call(document.querySelectorAll(\"#p-jenis button\"), function(x){ x.setAttribute(\"aria-pressed\", String(x === b)); }); pratinjau(); }); });\n  [\"#p-judul\", \"#p-isi\", \"#p-link\"].forEach(function(s){ $(s).addEventListener(\"input\", pratinjau); });\n  [\"#p-plat\", \"#p-hari\", \"#p-lama\"].forEach(function(s){ $(s).addEventListener(\"change\", pratinjau); });\n  $(\"#f-pesan\").addEventListener(\"submit\", function(e){\n    e.preventDefault(); $(\"#p-err\").hidden = true; $(\"#p-ok\").hidden = true;\n    var j = $(\"#p-judul\").value.trim(), l = $(\"#p-link\").value.trim();\n    if (!j){ $(\"#p-err\").hidden = false; $(\"#p-err\").textContent = \"Judul wajib diisi.\"; $(\"#p-judul\").focus(); return; }\n    if (l && !/^https:\\/\\/\\S{3,}$/.test(l)){ $(\"#p-err\").hidden = false; $(\"#p-err\").textContent = \"Link harus diawali https://\"; $(\"#p-link\").focus(); return; }\n    var n = hitungPenerima() || 0;\n    $(\"#p-confirm-t\").textContent = \"Kirim \\\"\" + j + \"\\\" ke \" + SASARAN[$(\"#p-plat\").value].toLowerCase() + ($(\"#p-lama\").checked && versiTerbaru() ? \" yang belum versi \" + versiTerbaru() : \"\") + \"? Perkiraan \" + fmt(n) + \" perangkat langsung menerima, sisanya saat membuka aplikasi. Pengumuman yang sudah diterima tidak bisa ditarik dari perangkat.\";\n    $(\"#p-act\").hidden = true; $(\"#p-confirm\").hidden = false; $(\"#p-ya\").focus();\n  });\n  $(\"#p-batal\").addEventListener(\"click\", batalKonfirmasi);\n  $(\"#p-ya\").addEventListener(\"click\", function(){\n    if (pMenunggu) return; pMenunggu = true; $(\"#p-ya\").disabled = true; $(\"#p-ya\").textContent = \"Mengirim…\";\n    var body = { judul: $(\"#p-judul\").value.trim(), isi: $(\"#p-isi\").value.trim(), link: $(\"#p-link\").value.trim(), jenis: pJenis, plat: $(\"#p-plat\").value, hari: Number($(\"#p-hari\").value), verdi: $(\"#p-lama\").checked ? versiTerbaru() : \"\" };\n    fetch(\"/v1/dash/pesan\", { method: \"POST\", headers: { \"X-TK-Admin\": store.get(KEY), \"Content-Type\": \"application/json\" }, body: JSON.stringify(body) })\n      .then(function(r){ return r.json(); })\n      .then(function(j){\n        if (!j || !j.ok) throw new Error(j && j.error ? j.error.message : \"Gagal mengirim.\");\n        $(\"#f-pesan\").reset(); pJenis = \"info\"; Array.prototype.forEach.call(document.querySelectorAll(\"#p-jenis button\"), function(x){ x.setAttribute(\"aria-pressed\", String(x.dataset.j === \"info\")); });\n        pratinjau(); $(\"#p-ok\").hidden = false; $(\"#p-ok\").textContent = \"Terkirim. Aplikasi yang terbuka menerimanya dalam 30 menit, sisanya saat dibuka.\"; muatPesan();\n      })\n      .catch(function(err){ batalKonfirmasi(); $(\"#p-err\").hidden = false; $(\"#p-err\").textContent = (err && err.message) || \"Gagal mengirim.\"; })\n      .then(function(){ pMenunggu = false; $(\"#p-ya\").disabled = false; $(\"#p-ya\").textContent = \"Ya, kirim sekarang\"; });\n  });\n  function rentangTeks(){ return rentang >= 365 ? \"1 tahun\" : rentang + \" hari\"; }\n\n  // ---------- muat ----------\n  function muat(segar){\n    var key = store.get(KEY); if (!key){ tampilLogin(); return; }\n    if (loading) return; loading = true; $(\"#reload\").textContent = \"Memuat…\";\n    fetch(\"/v1/dash/data?rentang=\" + rentang + (segar ? \"&segar=1\" : \"\"), { headers: { \"X-TK-Admin\": key }, cache: \"no-store\" })\n      .then(function(r){ return r.json().then(function(j){ return { s: r.status, j: j }; }); })\n      .then(function(x){\n        if (x.s === 403){ store.del(KEY); tampilLogin(x.j && x.j.error ? x.j.error.message : \"Kata sandi salah.\"); return; }\n        if (!x.j || !x.j.ok) throw new Error(x.j && x.j.error ? x.j.error.message : \"Server menjawab \" + x.s);\n        D = x.j; $(\"#login\").hidden = true; $(\"#app\").hidden = false; $(\"#seg\").hidden = false; $(\"#reload\").hidden = false; render(); pratinjau(); muatPesan();\n      })\n      .catch(function(e){ var wb = $(\"#warn\"); if (!$(\"#app\").hidden){ wb.hidden = false; wb.textContent = \"Gagal memuat: \" + (e && e.message || e) + \". Cek internet lalu tekan Muat ulang.\"; } else tampilLogin(\"Gagal menghubungi server: \" + (e && e.message || e)); })\n      .then(function(){ loading = false; $(\"#reload\").textContent = \"Muat ulang\"; });\n  }\n  function tampilLogin(msg){\n    $(\"#app\").hidden = true; $(\"#seg\").hidden = true; $(\"#reload\").hidden = true; $(\"#login\").hidden = false;\n    var e = $(\"#login-err\"); e.hidden = !msg; e.textContent = msg || \"\"; $(\"#key\").focus();\n  }\n  $(\"#login\").addEventListener(\"submit\", function(e){ e.preventDefault(); var v = $(\"#key\").value.trim(); if (!v) return; store.del(KEY); store.set(KEY, v, $(\"#ingat\").checked); muat(true); });\n  $(\"#keluar\").addEventListener(\"click\", function(){ store.del(KEY); D = null; $(\"#key\").value = \"\"; tampilLogin(); });\n  $(\"#reload\").addEventListener(\"click\", function(){ muat(true); });\n  Array.prototype.forEach.call(document.querySelectorAll(\"#seg button\"), function(b){\n    b.setAttribute(\"aria-pressed\", String(Number(b.dataset.r) === rentang));\n    b.addEventListener(\"click\", function(){ rentang = Number(b.dataset.r); store.set(RKEY, String(rentang), true); Array.prototype.forEach.call(document.querySelectorAll(\"#seg button\"), function(x){ x.setAttribute(\"aria-pressed\", String(x === b)); }); muat(false); });\n  });\n  var rt; window.addEventListener(\"resize\", function(){ clearTimeout(rt); rt = setTimeout(render, 150); });\n  if (window.matchMedia) matchMedia(\"(prefers-color-scheme: dark)\").addEventListener(\"change\", render);\n  setInterval(function(){ if (!document.hidden && D) muat(false); }, 5 * 60 * 1000);\n  muat(false);\n})();\n</script>\n</body>\n</html>\n";

export default {
  async fetch(req, env, ctx){
    const url = new URL(req.url);
    if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
    if (url.pathname === "/" || url.pathname === "/v1") return json({ ok: true, nama: "Teman Kuliah AI", versi: VERSI, ai: Object.keys(AI).filter(p => env[AI[p].key]), db: !!env.DB });
    if (url.pathname === "/dash" || url.pathname === "/dash/") return new Response(HALAMAN_PANTAU, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache", "X-Robots-Tag": "noindex", "Referrer-Policy": "no-referrer", "X-Frame-Options": "DENY" } });
    if (!env.DB) return gagal(500, "tk_nodb", "Database belum dihubungkan (binding DB).");
    await siapkanDB(env);
    if (url.pathname === "/v1/stats") return statistik(env, url);
    try {
      if (url.pathname === "/v1/web") return await catatWeb(req, env, ctx);
      if (url.pathname === "/v1/dash/data") return await dataPantau(req, env, url);
      if (url.pathname === "/v1/dash/pesan" || url.pathname === "/v1/dash/pesan/tarik") return await pesanAdmin(req, env, url);
    } catch (e) {
      return gagal(500, "tk_error", "Server error: " + String(e && e.message || e).slice(0, 200));
    }
    if (req.headers.get("X-TK-App") !== "teman-kuliah") return gagal(403, "tk_app", "Server ini khusus aplikasi Teman Kuliah.");
    const who = await siapaDia(req);
    catatAktif(env, ctx, req); cekGithubNanti(env, ctx); bersihkanStatistik(env, ctx);
    try {
      if (url.pathname === "/v1/ping") return await ping(req, env, ctx);
      if (url.pathname === "/v1/quota" && req.method === "GET") return await sisaJatah(env, who);
      if (url.pathname === "/v1/chat/completions" && req.method === "POST") return await teruskanChat(req, env, ctx, who);
      if (url.pathname === "/v1/audio/transcriptions" && req.method === "POST") return await teruskanWhisper(req, env, ctx, who);
    } catch (e) {
      return gagal(500, "tk_error", "Server AI error: " + String(e && e.message || e).slice(0, 200));
    }
    return gagal(404, "tk_404", "Alamat tidak ditemukan.");
  },
  // Opsional: Cron Trigger harian di Cloudflare supaya angka unduhan GitHub tercatat setiap hari
  async scheduled(event, env, ctx){
    if (!env.DB) return;
    await siapkanDB(env);
    ctx.waitUntil(ambilGithub(env, true).catch(() => {}));
  }
};
