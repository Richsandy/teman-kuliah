# Teman Kuliah

Aplikasi Windows untuk mahasiswa kuliah online di kampus yang memakai LMS **Edlink** (misalnya kuliah.unsia.ac.id atau edlink.id). Isinya jadwal, ceklis absensi, to-do, dan materi yang ditulis ulang supaya mudah dipahami.

Dibuat oleh **Nicky Richsandy Pramana**. Aplikasi independen, bukan produk resmi Edlink maupun kampus.

## Untuk teman-teman (pengguna)

### Pasang
1. Unduh `TemanKuliah-Setup-x.x.x.exe` dari halaman Releases (atau dari link yang dibagikan).
2. Jalankan. Kalau muncul **"Windows protected your PC"**, klik **More info** lalu **Run anyway**. Ini muncul karena aplikasinya belum punya sertifikat berbayar, bukan karena berbahaya.
3. Ikuti langkah instalasi. Ikon **Teman Kuliah** akan muncul di desktop.

### Pindahan dari Ruang Kuliah
Teman Kuliah adalah nama baru Ruang Kuliah. Installer baru mengganti aplikasi lama, dan data (materi, ceklis, to-do, login LMS) dipindahkan otomatis.

### Pertama kali dibuka
1. **Masuk ke LMS.** Ketik alamat web LMS yang biasa kamu buka (misalnya `kuliah.unsia.ac.id`), klik *Masuk ke LMS*, lalu login seperti biasa. Login dengan Google dibuka di jendela kecil; kalau Google menolak, masuk memakai email dan password LMS. Aplikasi tidak melihat atau menyimpan password. Setelah login, jadwal dan mata kuliahmu langsung muncul.
2. **Sambungkan AI (AI otomatis, gratis).** Tempel API key gratis, minimal satu:
   - **Cerebras** (cloud.cerebras.ai): menyusun materi, latihan soal, rangkuman. Disarankan.
   - **Groq** (console.groq.com/keys): Tanya AI tercepat dan transkrip video dengan Whisper. Disarankan.
   - **Gemini** (aistudio.google.com/apikey): opsional, menonton video YouTube dan membaca slide bergambar.
   Aplikasi memilih AI per tugas dan langsung pindah kalau ada yang penuh. Bisa juga pilih satu AI saja (termasuk ChatGPT, Claude, atau Ollama) di Pengaturan.
3. **Sesuaikan hari kuliah** kalau jadwal aslimu berbeda dari hari di KRS.

### Aturan ringkasan materi (berlaku untuk semua AI, dikunci)
1. Tidak terlalu ringkas.
2. Tetap detail, tapi bahasanya lebih mudah dipahami daripada PDF/slide dosen.
3. Tidak boleh ada bagian materi yang hilang.
4. Formatnya enak dibaca: judul per bagian, paragraf pendek, poin, tabel, dan contoh.

### Yang terjadi otomatis
- Setiap 30 menit (dan setiap aplikasi dibuka): jadwal, post dosen, kuis, vicon, dan status komentar absensi tersinkron dari LMS. Muncul notifikasi kalau dosen posting.
- Setiap dosen mengunggah PPT, PDF, DOCX, atau link YouTube, muncul tombol **Ringkas file dosen**. Sekali klik, file diunduh dan disusun jadi materi: ringkasan, istilah, kuis, dan draft komentar absensi. Kuota AI hanya terpakai saat tombol diklik. (Mau serba otomatis? Aktifkan *Ringkas file dosen secara otomatis* di Pengaturan.)
- Kalau *Jalan di latar belakang* aktif, aplikasi menyala bersama Windows dan tetap sinkron dari ikon di pojok kanan bawah taskbar.

### Pengingat
Notifikasi Windows untuk materi baru dari dosen, tenggat tugas/kuis (sehari sebelum dan alarm 3 jam sebelum), vicon (30 menit sebelum), dan jam kuliah (15 menit sebelum). Bisa dimatikan per jenis di **Pengaturan**. Pengingat hanya jalan selama aplikasi menyala (aktifkan *Jalan di latar belakang*).

### Panduan
Panduan PDF ikut terpasang. Klik **Panduan** di kanan atas, atau buka **Pengaturan > Panduan** untuk membuka file PDF-nya.

### Menambah materi sendiri
Seret file atau folder materi (PDF, PPTX, DOCX, gambar), link YouTube, atau teks ringkasan video ke jendela aplikasi. Mata kuliah dan pertemuan ditebak dari nama folder (misalnya `Semester 1\Komunikasi Massa\2`) dan bisa diubah sebelum diproses. File `.ppt`/`.doc` lama perlu disimpan ulang sebagai `.pptx`/`.docx` atau PDF.

### Privasi
Semua data (materi, ceklis, to-do, API key) hanya tersimpan di laptop masing-masing, di `%APPDATA%\Teman Kuliah`. Aplikasi hanya terhubung ke LMS kampus dan AI yang dipilih.

---

## Untuk pengelola (Nicky)

### Menerbitkan versi baru lewat GitHub (auto-update)
Repository: https://github.com/Richsandy/teman-kuliah (Public).
1. Naikkan `"version"` di `package.json` (misal `1.0.12`).
2. Zip seluruh isi folder ini (kecuali `node_modules` dan `dist`) dengan nama `teman-kuliah-source.zip`.
3. Di repository, klik *Add file > Upload files*, upload zip itu (menimpa yang lama), lalu *Commit changes*.
4. GitHub Actions (`.github/workflows/rilis.yml` di repository) otomatis membangun installer di server Windows GitHub dan menerbitkannya sebagai rilis `v1.0.12`. Aplikasi teman-teman mengunduh update sendiri dan menampilkan tombol *Mulai ulang untuk update*.

### Build manual di laptop Windows
```
npm install
npm run build:win
```
Hasilnya ada di folder `dist`.

### Catatan teknis
- Sinkron LMS berjalan di dalam halaman LMS Edlink kampus memakai sesi login pengguna sendiri (jalur yang sama dengan web LMS). Edlink tidak menyediakan API publik, jadi kalau Edlink mengubah sistemnya, bagian `src/lms.js` mungkin perlu diperbarui.
- Kode: `src/main.js` (proses utama, tray, auto-update), `src/lms.js` (login & sinkron), `src/process.js` (olah data LMS), `src/ingest.js` + `src/extract.js` (baca file materi), `src/ai.js` (Gemini/ChatGPT/Claude/Ollama), `src/renderer/` (tampilan).
