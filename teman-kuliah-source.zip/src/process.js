// Mengolah data mentah LMS menjadi matkul, jadwal, tugas, status komentar, dan to-do.
const { periodeLabel } = require("./store");
const HARI = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const BULAN = { januari:1, februari:2, maret:3, april:4, mei:5, juni:6, juli:7, agustus:8, september:9, oktober:10, november:11, desember:12 };

// File yang bukan materi pertemuan: tidak perlu diringkas
const NON_MATERI = /\b(rps|rencana pembelajaran semester|kontrak (?:kuliah|perkuliahan|belajar)|silabus|syllabus|satuan acara perkuliahan|sertifikat|daftar hadir|kalender akademik|panduan penilaian|rubrik penilaian)\b/i;
const parseDT = s => { if (!s) return null; const m = String(s).match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/); return m ? new Date(+m[1], +m[2]-1, +m[3], +m[4], +m[5]) : null; };
const ymd = d => d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
const hm = d => String(d.getHours()).padStart(2,"0") + ":" + String(d.getMinutes()).padStart(2,"0");
const mode = arr => { const c = {}; arr.forEach(x => { if (x) c[x] = (c[x]||0) + 1; }); return Object.keys(c).sort((a,b) => c[b]-c[a])[0] || ""; };
const shortName = n => n.replace(/^(Pengantar|Dasar-Dasar|Dasar-dasar|Dasar Dasar)\s+/i, "").replace(/\bAi\b/g, "AI");
let LMS = "";
const postLink = (cid, p) => `${LMS}/panel/classes/${cid}/sections/${p.sec}/${p.id}/`;

function viconDate(text){
  const t = String(text || "").toLowerCase();
  const m = t.match(/(\d{1,2})\s+(januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember)\s+(\d{4})/);
  if (!m) return null;
  const tm = t.slice(m.index).match(/(?:pukul|pk\.?|jam)\s*(\d{1,2})[.:](\d{2})/);
  return { date: `${m[3]}-${String(BULAN[m[2]]).padStart(2,"0")}-${String(m[1]).padStart(2,"0")}`, time: tm ? `${tm[1].padStart(2,"0")}.${tm[2]} WIB` : "" };
}

// Post dosen yang menyebut "materi tambahan pertemuan 3" (atau sesi/minggu ke-3) padahal diunggah di sesi lain:
// lampirannya dimasukkan ke pertemuan yang disebut. Rentang ("pertemuan 1-7", "1 sampai 7") diabaikan.
const MEET_RE = /(?:pertemuan|sesi|minggu|pekan)\s*(?:ke\s*[-.]?\s*)?(\d{1,2})(?!\s*(?:-|–|s\.?\s?d|sampai|hingga|dan\b|&|,|\d))/gi;
function targetMeet(p, meets){
  const t = String(p.title || "") + " " + String(p.text || "");
  if (!/tambahan|susulan|pengganti|revisi|perbaikan|update|pembaruan|lanjutan|melengkapi|untuk|materi/i.test(t)) return null;
  const found = new Set(); let m; MEET_RE.lastIndex = 0;
  while ((m = MEET_RE.exec(t))){ const n = Number(m[1]); if (n >= 1 && n <= (meets || 16)) found.add(n); }
  if (found.size !== 1) return null;
  const n = [...found][0];
  return n !== p.meet ? n : null;
}
const KELOMPOK_RE = /\b(berkelompok|kelompok|tugas tim|kerja tim|group project|team project|pembagian tim)\b/i;

// raw: hasil lms.sync(); store: instance Store. Mengembalikan daftar notifikasi baru.
function applySync(store, raw){
  const d = store.data;
  const abaikan = new Set(d.lampiranAbaikan || []);
  const paksa = new Set(d.lampiranPaksa || []); // file yang pengguna minta tetap diringkas walau terdeteksi RPS/kontrak
  LMS = raw.base || "";
  const periode = mode(raw.courses.map(c => c.periode)) || "unknown";
  if (periode !== "unknown") raw = { ...raw, courses: raw.courses.filter(c => !c.periode || String(c.periode) === String(periode)) };
  d.current = periode;
  const sem = store.sem(periode);
  sem.label = periodeLabel(periode);
  const firsts = raw.courses.map(c => parseDT((c.sections.find(s => s.meet === 1) || {}).start)).filter(Boolean).sort((a,b) => a-b);
  if (firsts[0]){ const m = new Date(firsts[0]); m.setDate(m.getDate() - ((m.getDay() + 6) % 7)); sem.mulai = ymd(m); }

  const seen = new Set(d.lms.seen || []);
  const firstSync = !d.lms.seen;
  const notes = [];
  const today = ymd(new Date());

  raw.courses.forEach((c, i) => {
    const s1 = c.sections.find(s => s.meet === 1) || c.sections[0] || {};
    const st = parseDT(s1.start), en = parseDT(s1.end);
    const lecturer = c.posts.filter(p => !p.fromMe);
    const prev = sem.courses[c.id] || {};
    const course = {
      id: c.id, nama: c.name.replace(/\bAi\b/g, "AI"), singkat: shortName(c.name), kelas: c.kelas,
      dosen: mode(lecturer.map(p => p.author)) || prev.dosen || "",
      hariKRS: st ? HARI[st.getDay()] : (prev.hariKRS || ""), jam: st && en ? `${hm(st)}-${hm(en)}` : (prev.jam || ""),
      warna: prev.warna || "c" + ((i % 7) + 1), meets: c.meets || 16,
      lms: `${LMS}/panel/classes/${c.id}/sections/${s1.id || ""}/`,
      sesi: {}, tugas: {}, absen: {}, vicon: [], lampiran: {}, ujian: {},
      unggahan: {}, // semua yang diunggah dosen per pertemuan, termasuk yang tidak diringkas, lengkap dengan alasannya
      // Kehadiran per pertemuan dari SES: st = presensi resmi (H/I/S/A, null = belum di-ACC dosen), ses = aktivitas yang langsung tercatat
      hadir: c.sesOk ? (c.hadir || {}) : (prev.hadir || {}), sesUpd: c.sesOk ? c.sesUpd : (prev.sesUpd || null), rekap: c.sesOk ? c.rekap : (prev.rekap || null),
      kelompok: { tim: null, semua: [], adaTim: false, tugas: {}, info: [] }
    };
    // Kelompok: tim yang memuat kamu, atau daftar semua tim kalau tim milikmu belum bisa dikenali
    const tims = c.timsOk ? (c.tims || []) : ((prev.kelompok && prev.kelompok.tims) || []);
    const myTim = tims.find(t => t.me) || null;
    course.kelompok.tims = tims; course.kelompok.adaTim = tims.length > 0; course.kelompok.tim = myTim; course.kelompok.semua = myTim ? [] : tims.slice(0, 40);
    if (!firstSync && myTim && (!prev.kelompok || !prev.kelompok.tim || prev.kelompok.tim.id !== myTim.id)){
      const lain = myTim.anggota.filter(a => !a.me).map(a => a.nama);
      notes.push({ title: course.singkat, kind: "kelompok", body: `Kamu masuk ${myTim.nama}` + (lain.length ? ` bersama ${lain.slice(0, 5).join(", ")}${lain.length > 5 ? ", dan lainnya" : ""}.` : ".") });
    }
    // Perubahan kehadiran: kabari kalau dosen sudah mengonfirmasi, apalagi kalau tercatat tidak hadir
    if (!firstSync && c.sesOk) Object.entries(course.hadir).forEach(([mt, h]) => {
      const before = prev.hadir && prev.hadir[mt] && prev.hadir[mt].st;
      if (h.st && h.st !== before){
        if (h.st === "A") notes.push({ title: course.singkat, kind: "hadir", body: `Pertemuan ${mt} tercatat tidak hadir (alfa). Cek ke dosen kalau ini keliru.` });
        else if (h.st === "H" && !before) notes.push({ title: course.singkat, kind: "hadir", body: `Kehadiran pertemuan ${mt} sudah dikonfirmasi dosen.` });
      }
    });
    c.sections.forEach(s => { course.sesi[s.meet] = { id: s.id, start: s.start }; });
    // Jadwal ujian: dari post ujian/kuis berjudul UTS/UAS di LMS, kalau tidak ada pakai jadwal pertemuan 8 (UTS) dan 16 (UAS)
    const exJenis = p => { const t = String(p.title || "") + " " + String((p.quiz && p.quiz.title) || ""); if (/\b(uts|ujian tengah|mid ?term|midterm)\b/i.test(t)) return "uts"; if (/\b(uas|ujian akhir|final ?exam|final test)\b/i.test(t)) return "uas"; if (p.exam) return (p.meet || 0) <= 8 ? "uts" : "uas"; return null; };
    lecturer.forEach(p => { const j = exJenis(p); if (!j || course.ujian[j]) return; const d = parseDT((p.quiz && (p.quiz.start || p.quiz.end)) || (course.sesi[p.meet] || {}).start); course.ujian[j] = { tanggal: d ? ymd(d) : "", jam: d ? hm(d) : "", judul: p.title || (j === "uts" ? "UTS" : "UAS"), link: postLink(c.id, p), sumber: "lms" }; });
    for (const [j, mt] of [["uts", 8], ["uas", 16]]){ if (course.ujian[j]) continue; const d = parseDT((course.sesi[mt] || {}).start); if (d) course.ujian[j] = { tanggal: ymd(d), jam: hm(d), judul: j === "uts" ? "Ujian Tengah Semester" : "Ujian Akhir Semester", sumber: "jadwal" }; }
    lecturer.forEach(p => {
      const meet = p.meet || null;
      const link = postLink(c.id, p);
      // Tugas: hanya yang benar-benar tugas di LMS (kuis, ujian, atau jenis post tugas)
      if (p.quiz || p.exam || !["M", "V", "I"].includes(p.type)){
        const end = parseDT(p.quiz && p.quiz.end);
        // Selesai kalau LMS menandai sudah dikumpulkan, atau (untuk tugas biasa) kamu sudah mengirim jawaban di kolom komentar
        const viaLMS = !!p.done || !!(p.quiz && /submit|finish|done|complet|grad/i.test(p.quiz.status || ""));
        const viaKomentar = !p.quiz && p.commented === true;
        const selesai = viaLMS || viaKomentar;
        const kel = !!p.team || (!p.quiz && !p.exam && KELOMPOK_RE.test(String(p.title || "") + " " + String(p.text || "")));
        if (kel) (course.kelompok.tugas[meet || 0] ||= []).push({ id: String(p.id), judul: p.title, tenggat: end ? ymd(end) : "", link, selesai });
        (course.tugas[meet || 0] ||= []).push({
          id: String(p.id), judul: p.title, jenis: p.quiz ? "Kuis" : p.exam ? "Ujian" : kel ? "Tugas kelompok" : "Tugas", kelompok: kel,
          tenggat: end ? ymd(end) : "", jam: end ? hm(end).replace(":", ".") : "",
          status: viaLMS ? "Sudah dikerjakan" : viaKomentar ? "Sudah dikirim lewat komentar" : p.quiz ? "Belum dikerjakan" : "Cek di LMS",
          selesai, link, desc: p.desc || "", files: (p.files || []).map(f => ({ name: f.name, ext: f.ext, link: f.link, size: f.size }))
        });
      }
      if (["M", "V", "I"].includes(p.type) && !p.quiz && !p.exam && KELOMPOK_RE.test(String(p.title || "") + " " + String(p.text || ""))) course.kelompok.info.push({ meet, judul: p.title, link, text: String(p.text || "").slice(0, 280) });
      if (meet && ((p.files && p.files.length) || (p.youtube && p.youtube.length) || (p.videos && p.videos.length) || (p.lain && p.lain.length))){
        const tm = targetMeet(p, course.meets), lm = tm || meet; // "materi tambahan pertemuan 3" masuk ke pertemuan 3
        const L = (course.lampiran[lm] ||= []), U = (course.unggahan[lm] ||= []), skipPost = NON_MATERI.test(p.title || "");
        const ok = id => !Object.values(course.lampiran).some(arr => arr.some(x => x.id === id));
        const post = { postId: String(p.id), post: p.title || "", postLink: link, tgl: p.created || null, ...(tm ? { pindah: meet } : {}) };
        // status: materi = bisa diringkas; rps = RPS/kontrak; abaikan = isinya terdeteksi RPS saat dibaca; format = format tidak terbaca; lain = bukan file materi
        const add = (id, item, status, alasan) => {
          if (U.some(x => x.id === id)) return;
          U.push({ id, ...item, ...post, status, alasan: alasan || "" });
          if (status === "materi" && ok(id)) L.push({ id, ...item, ...post });
        };
        (p.files || []).forEach(f => {
          const id = "f" + f.id, item = { name: f.name, size: f.size, link: f.link, kind: f.ext || "file" };
          if (!["pdf", "pptx", "docx"].includes(f.ext)) return add(id, item, "format", /^(ppt|doc)$/.test(f.ext) ? `Format lama .${f.ext} tidak bisa dibaca. Buka di PowerPoint/Word, simpan sebagai .${f.ext}x atau PDF, lalu seret ke aplikasi.` : `File .${f.ext || "?"} tidak bisa diringkas.`);
          if ((skipPost || NON_MATERI.test(f.name || "")) && !paksa.has(id)) return add(id, item, "rps", "Namanya menunjukkan RPS, kontrak kuliah, atau dokumen administrasi, jadi tidak diringkas.");
          if (abaikan.has(id) && !paksa.has(id)) return add(id, item, "abaikan", "Isinya terdeteksi RPS atau kontrak kuliah saat dibaca, jadi dilewati.");
          add(id, item, "materi");
        });
        (p.youtube || []).forEach(y => { const id = "y" + y; add(id, { name: (p.ytNames && p.ytNames[y]) || ("Video: " + p.title), youtube: "https://www.youtube.com/watch?v=" + y, kind: "youtube" }, abaikan.has(id) && !paksa.has(id) ? "abaikan" : "materi", abaikan.has(id) && !paksa.has(id) ? "Pernah dilewati bersama file lain di pertemuan ini." : ""); });
        (p.videos || []).forEach(v => { const id = "v" + v.id; add(id, { name: v.name, size: v.size, link: v.link, video: true, ext: v.ext, kind: "video" }, abaikan.has(id) && !paksa.has(id) ? "abaikan" : "materi", abaikan.has(id) && !paksa.has(id) ? "Pernah dilewati bersama file lain di pertemuan ini." : ""); });
        (p.lain || []).forEach(x => add("l" + x.id, { name: x.name, link: x.link, kind: x.type || x.ext || "lampiran" }, "lain", x.type === "link" ? "Tautan, buka langsung dari LMS." : x.type === "image" ? "Gambar, tidak ikut diringkas otomatis." : "Lampiran ini tidak ikut diringkas otomatis."));
        if (!L.length) delete course.lampiran[lm];
        if (!U.length) delete course.unggahan[lm];
        if (tm && !firstSync && !seen.has(String(p.id))) notes.push({ title: course.singkat, kind: "materi", body: `Materi tambahan untuk pertemuan ${tm}: ${p.title}. Buka pertemuan ${tm} untuk meringkas ulang.` });
      }
      if (p.type === "V"){ const vd = viconDate(p.text); course.vicon.push({ id: String(p.id), judul: p.title, meet, link, text: p.text, ...(vd || {}) }); }
      if (meet && p.commented !== null){
        const a = (course.absen[meet] ||= { total: 0, done: 0, belum: [], sudah: [] });
        a.total++;
        if (p.commented === "?") a.unknown = (a.unknown || 0) + 1; // status gagal terbaca: jangan dianggap sudah
        else if (p.commented){ a.done++; a.sudah.push(String(p.id)); } else a.belum.push({ id: String(p.id), judul: p.title, link });
      }
      if (!seen.has(String(p.id))){ seen.add(String(p.id)); if (!firstSync && !(targetMeet(p, course.meets) && meet && ((p.files && p.files.length) || (p.youtube && p.youtube.length) || (p.videos && p.videos.length)))) { const isMateri = !p.quiz && ((p.files && p.files.length) || (p.youtube && p.youtube.length)); const kel = !!p.team || KELOMPOK_RE.test(String(p.title || "") + " " + String(p.text || "")); notes.push({ title: course.singkat, kind: isMateri ? "materi" : kel ? "kelompok" : "post", body: (p.quiz ? "Kuis baru: " : kel ? "Info tugas kelompok: " : p.type === "V" ? "Info vicon: " : isMateri ? "Materi baru dari dosen: " : "Post baru: ") + p.title }); } }
    });
    // Ceklis otomatis dari LMS
    Object.entries(course.absen).forEach(([meet, a]) => {
      const k = `${periode}_${c.id}_p${meet}`, pr = d.progress[k] || {};
      const all = a.total > 0 && a.done === a.total;
      if (all && !pr.komentar) d.progress[k] = { ...pr, komentar: true, komentarBy: "lms" };
      else if (!all && pr.komentar && pr.komentarBy === "lms") d.progress[k] = { ...pr, komentar: false, komentarBy: null };
    });
    Object.entries(course.tugas).forEach(([meet, ts]) => {
      const k = `${periode}_${c.id}_p${meet}`, pr = d.progress[k] || {};
      const all = ts.length && ts.every(t => t.selesai);
      if (all && !pr.tugas) d.progress[k] = { ...pr, tugas: true, tugasBy: "lms" };
    });
    // To-do otomatis: tugas & vicon dari LMS
    const dismissed = new Set(d.lms.dismissed || []);
    Object.values(course.tugas).flat().forEach(t => {
      const id = "lms-" + t.id; if (dismissed.has(id)) return;
      const old = d.todos[id];
      d.todos[id] = { ...(old || { createdAt: new Date().toISOString(), done: false }), text: /^(tugas|kuis|quiz|ujian)\b/i.test(t.judul || "") ? t.judul : `${t.jenis}: ${t.judul}`, jenis: t.jenis, course: c.id, due: t.tenggat, time: t.jam, source: "lms", link: t.link, note: t.status, desc: t.desc, files: t.files, done: old ? (old.manual ? old.done : (old.done || t.selesai)) : t.selesai };
    });
    // To-do komentar absensi (hanya kalau absensinya lewat komentar): post dosen pertemuan minggu ini dan minggu lalu yang belum kamu komentari
    const modeKom = absensiMode(d) === "komentar";
    const minggu = sem.mulai ? Math.floor((Date.now() - new Date(sem.mulai + "T00:00:00")) / 864e5 / 7) + 1 : 0;
    Object.entries(course.absen).forEach(([mt, a]) => {
      (a.sudah || []).forEach(pid => { const t = d.todos["abs-" + pid]; if (t && !t.done) t.done = true; });
      if (!modeKom || !minggu || Number(mt) > minggu || Number(mt) < minggu - 1) return;
      a.belum.forEach(b => {
        const id = "abs-" + b.id; if (dismissed.has(id)) return;
        const old = d.todos[id];
        d.todos[id] = { ...(old || { createdAt: new Date().toISOString(), done: false }), text: `Komentar absensi: ${b.judul}`, course: c.id, due: "", time: "", source: "absen", link: b.link, note: `Pertemuan ${mt}. Buka post di LMS lalu tulis komentar supaya dihitung hadir.` };
      });
    });
    course.vicon.forEach(v => {
      const id = "lms-" + v.id; if (dismissed.has(id) || !v.date) return;
      const old = d.todos[id];
      d.todos[id] = { ...(old || { createdAt: new Date().toISOString(), done: v.date < today }), text: `Vicon: ${v.judul}`, course: c.id, due: v.date, time: v.time, source: "lms", link: v.link, note: v.text.slice(0, 160) };
    });
    sem.courses[c.id] = course;
  });
  d.lms.seen = [...seen].slice(-3000);
  d.lms.me = raw.me; d.lms.connected = true; d.lms.needsLogin = false; d.lms.lastSync = new Date().toISOString(); d.lms.lastError = null;
  if (!d.settings.nama) d.settings.nama = raw.me.name || "";
  if (raw.me.nim) d.lms.me = { ...(d.lms.me || {}), nim: raw.me.nim };
  // Cara absensi: tidak semua kampus memakai komentar. UNSIA ditebak "komentar"; kampus lain dipilih sendiri di langkah 3 atau Pengaturan.
  if (!d.settings.absensiMode && (d.settings.absensiKomentar === null || d.settings.absensiKomentar === undefined) && (/siber asia|unsia/i.test(raw.me.kampus || "") || /unsia\.ac\.id/i.test(LMS))){ d.settings.absensiMode = "komentar"; d.settings.absensiKomentar = true; }
  if (absensiMode(d) !== "komentar") Object.keys(d.todos).forEach(id => { if (d.todos[id].source === "absen") delete d.todos[id]; });
  if (raw.me.kampus) d.settings.kampus = { ...(d.settings.kampus || {}), nama: d.settings.kampus && d.settings.kampus.nama || raw.me.kampus };
  store.save();
  return notes;
}

// "komentar" | "keaktifan" | "tidak" | null (belum dipilih). Pengguna versi lama hanya punya absensiKomentar.
function absensiMode(d){
  const s = d.settings || {};
  if (s.absensiMode) return s.absensiMode;
  return s.absensiKomentar === true ? "komentar" : s.absensiKomentar === false ? "tidak" : null;
}

module.exports = { NON_MATERI, applySync, viconDate, targetMeet, absensiMode };
