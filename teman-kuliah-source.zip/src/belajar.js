// Kartu hafalan pintar (pengulangan berjarak, sistem kotak Leitner).
// Kartu dibuat otomatis dari istilah dan soal kuis setiap materi, plus soal yang salah di latihan/simulasi.
// Kotak 0 sampai 6: makin sering diingat, makin jarang muncul (0, 1, 3, 7, 14, 30, 60 hari).
const JEDA = [0, 1, 3, 7, 14, 30, 60];
const ymd = d => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
const hariIni = () => ymd(new Date());
const tambahHari = (s, n) => { const [y, m, d] = String(s).split("-").map(Number); return ymd(new Date(y, m - 1, d + n)); };
const slug = s => { let h = 5381; for (const c of String(s || "").toLowerCase().replace(/\s+/g, " ").trim()) h = ((h * 33) ^ c.charCodeAt(0)) >>> 0; return h.toString(36); };

function wadah(data){
  const H = data.hafalan || (data.hafalan = {});
  H.kartu ||= {}; H.hari ||= {}; if (H.batasBaru == null) H.batasBaru = 20;
  return H;
}

// Samakan kartu dengan materi yang ada sekarang. Kartu yang sudah pernah dipelajari tidak diubah jadwalnya.
function syncKartu(data){
  const H = wadah(data), sem = data.current && data.semesters && data.semesters[data.current];
  if (!sem) return false;
  let ubah = false;
  const ada = new Set();
  for (const [key, m] of Object.entries(sem.materi || {})){
    const [cid, n] = key.split(/_(?=\d+$)/);
    const dasar = { p: data.current, key, cid, n: Number(n) };
    for (const [a, b] of m.istilah || []){
      if (!a || !b) continue;
      const id = `${data.current}|${key}|i|${slug(a)}`; if (ada.has(id)) continue; ada.add(id); // istilah dobel: cukup satu kartu
      const k = H.kartu[id];
      if (!k){ H.kartu[id] = { ...dasar, t: "istilah", d: String(a).slice(0, 300), b: String(b).slice(0, 700), box: 0, due: null, rep: 0, lupa: 0 }; ubah = true; }
      else if (k.b !== String(b).slice(0, 700)){ k.b = String(b).slice(0, 700); ubah = true; }
    }
    for (const q of m.kuis || []){
      if (!q || !q.q || !Array.isArray(q.o)) continue;
      const id = `${data.current}|${key}|q|${slug(q.q)}`; if (ada.has(id)) continue; ada.add(id);
      if (!H.kartu[id]){ H.kartu[id] = { ...dasar, t: "kuis", d: String(q.q).slice(0, 500), o: q.o.slice(0, 4).map(x => String(x).slice(0, 200)), a: q.a, b: String(q.o[q.a] || ""), e: String(q.e || "").slice(0, 600), box: 0, due: null, rep: 0, lupa: 0 }; ubah = true; }
    }
  }
  // Materi dihapus atau diringkas ulang: kartu lamanya ikut dibuang (kartu dari soal salah tetap disimpan)
  for (const [id, k] of Object.entries(H.kartu)) if (k.p === data.current && k.t !== "salah" && !ada.has(id)){ delete H.kartu[id]; ubah = true; }
  // Catatan harian lebih dari 60 hari dibuang
  const batas = tambahHari(hariIni(), -60);
  for (const d of Object.keys(H.hari)) if (d < batas){ delete H.hari[d]; ubah = true; }
  return ubah;
}

// Kartu yang perlu diulang pada tanggal t: yang jatuh tempo + kartu baru sesuai batas harian
function antrean(data, t, opts){
  const H = wadah(data), tgl = t || hariIni(), o = opts || {};
  const semua = Object.entries(H.kartu).filter(([, k]) => k.p === data.current && (!o.cid || k.cid === o.cid));
  const tempo = semua.filter(([, k]) => k.due && k.due <= tgl).sort((a, b) => a[1].due.localeCompare(b[1].due) || a[1].box - b[1].box);
  const sudahBaru = tgl === hariIni() ? ((H.hari[tgl] || {}).baru || 0) : 0;
  const sisaBaru = Math.max(0, (Number(H.batasBaru) || 0) - sudahBaru);
  const baru = semua.filter(([, k]) => !k.due).sort((a, b) => a[1].n - b[1].n || String(a[1].cid).localeCompare(String(b[1].cid)) || (a[1].t === "istilah" ? -1 : 1)).slice(0, sisaBaru);
  return { tempo: tempo.map(([id]) => id), baru: baru.map(([id]) => id) };
}
function jumlahHariIni(data, t){ const a = antrean(data, t); return a.tempo.length + a.baru.length; }

// r: 0 = Lupa, 1 = Ragu, 2 = Ingat
function nilai(data, id, r){
  const H = wadah(data), k = H.kartu[id]; if (!k) throw new Error("Kartu tidak ditemukan.");
  const t = hariIni(), baru = !k.due, h = H.hari[t] || (H.hari[t] = { ulang: 0, baru: 0, ingat: 0 });
  h.ulang++; if (baru) h.baru++; if (r === 2) h.ingat++;
  if (r === 0){ k.box = 0; k.lupa = (k.lupa || 0) + 1; k.due = t; }
  else if (r === 1){ k.box = Math.max(1, k.box || 0); k.due = tambahHari(t, Math.max(1, Math.round(JEDA[k.box] / 2))); }
  else { k.box = baru ? 2 : Math.min(JEDA.length - 1, (k.box || 0) + 1); k.due = tambahHari(t, JEDA[k.box]); } // kartu baru yang langsung diingat: sudah paham, muncul lagi 3 hari
  k.rep = (k.rep || 0) + 1; k.last = t;
  return { box: k.box, due: k.due };
}

// Soal yang salah di latihan/simulasi dijadikan kartu
function dariLatihan(data, L){
  const H = wadah(data); let n = 0;
  if (!L || !L.hasil) return 0;
  const key = (p) => `${L.cid}_${p || ""}`;
  L.soal.pg.forEach((q, i) => {
    if (L.hasil.pg[i] && L.hasil.pg[i].benar) return;
    const id = `${L.periode}|salah|${slug(q.q)}`; if (H.kartu[id]) return;
    H.kartu[id] = { p: L.periode, key: key(q.p), cid: L.cid, n: Number(q.p) || 0, t: "salah", d: String(q.q).slice(0, 500), o: q.o.slice(0, 4), a: q.a, b: String(q.o[q.a] || ""), e: String(q.e || "").slice(0, 600), topik: q.topik || "", box: 0, due: hariIni(), rep: 0, lupa: 0 }; n++;
  });
  L.soal.essay.forEach((q, i) => {
    const h = L.hasil.essay[i]; if (!h || h.skor >= 70) return;
    const id = `${L.periode}|salah|${slug(q.q)}`; if (H.kartu[id]) return;
    H.kartu[id] = { p: L.periode, key: key(q.p), cid: L.cid, n: Number(q.p) || 0, t: "salah", d: String(q.q).slice(0, 500), b: (q.kunci || []).join("\n").slice(0, 900), topik: q.topik || "", box: 0, due: hariIni(), rep: 0, lupa: 0 }; n++;
  });
  return n;
}

// Statistik singkat untuk tampilan
function ringkasan(data){
  const H = wadah(data), semua = Object.values(H.kartu).filter(k => k.p === data.current);
  const t = hariIni(), a = antrean(data, t);
  let streak = 0; for (let d = t, i = 0; i < 400; i++, d = tambahHari(d, -1)){ if ((H.hari[d] || {}).ulang) streak++; else if (i > 0 || d !== t) break; }
  return { total: semua.length, baru: semua.filter(k => !k.due).length, hafal: semua.filter(k => k.box >= 4).length, tempo: a.tempo.length, baruHariIni: a.baru.length, streak, hariIni: H.hari[t] || { ulang: 0, baru: 0, ingat: 0 } };
}

module.exports = { JEDA, syncKartu, antrean, jumlahHariIni, nilai, dariLatihan, ringkasan, hariIni, tambahHari };
