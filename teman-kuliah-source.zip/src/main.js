const { app, BrowserWindow, ipcMain, shell, Notification, dialog, Tray, Menu, nativeImage, nativeTheme } = require("electron");
const fs = require("fs");
const path = require("path");
const { Store } = require("./store");
const lms = require("./lms");
const { applySync, absensiMode } = require("./process");
const ingest = require("./ingest");
const ai = require("./ai");
const belajar = require("./belajar");
const visual = require("./visual");

let lastWarn = [];
let win, store, tray = null, quitting = false, syncing = false, autoBusy = false, syncTimer = null;
const startHidden = process.argv.includes("--hidden");

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
function showWin(){ if (!win || win.isDestroyed()) createWindow(); if (win.isMinimized()) win.restore(); win.show(); win.focus(); try { updSaatMuncul(); } catch (e) {} }
app.on("second-instance", showWin);
app.setAppUserModelId("id.ruangkuliah.app");

// Kartu hafalan disamakan dengan materi setiap kali tampilan diperbarui (murah: hanya membandingkan daftar)
const pubState = () => { try { if (belajar.syncKartu(store.data)) store.save(); } catch (e) {} const d = store.publicState(); d.serverOn = ai.serverOn(store.data.settings.ai); d.appVersion = require("../package.json").version; return d; };
function push(){ identity(); if (win && !win.isDestroyed()) win.webContents.send("state", pubState()); }
// Identitas untuk jatah server AI: kode acak perangkat + hash akun Edlink (nama dan NIM tidak dikirim)
function identity(){
  if (!store) return;
  const a = store.data.settings.ai;
  if (!a.device){ a.device = require("crypto").randomUUID(); store.save(); }
  const me = store.data.lms.me;
  const uid = me && me.id ? require("crypto").createHash("sha256").update("tk:" + (store.data.lms.base || "") + ":" + me.id).digest("hex").slice(0, 32) : "";
  ai.setIdentity({ uid, device: a.device });
}
function status(msg){ if (win && !win.isDestroyed()) win.webContents.send("status", msg); }

function createWindow(){
  win = new BrowserWindow({
    width: 1320, height: 880, minWidth: 380, minHeight: 600, title: "Teman Kuliah", backgroundColor: nativeTheme.shouldUseDarkColors ? "#000000" : "#F3F4F6", autoHideMenuBar: true, show: false, icon: path.join(__dirname, "renderer", "icon.png"),
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.loadFile(path.join(__dirname, "renderer", "index.html"));
  win.once("ready-to-show", () => { if (!startHidden) win.show(); });
  win.on("session-end", () => { quitting = true; if (store) store.flush(); });
  win.on("closed", () => { try { require("./visr").close(true); } catch (e) {} });
  win.on("close", e => { if (!quitting && store && store.data.settings.background){ e.preventDefault(); win.hide(); } });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https:\/\//.test(url)) shell.openExternal(url); return { action: "deny" }; });
  win.webContents.on("will-navigate", (e, url) => { if (!url.startsWith("file://")){ e.preventDefault(); if (/^https:\/\//.test(url)) shell.openExternal(url); } });
}

// Judul asli video YouTube dari dosen (oEmbed YouTube, tanpa API key), disimpan supaya tidak diambil ulang.
// Dipakai untuk memindah video berjudul "Pertemuan 2 ..." yang di-post di pertemuan lain ke pertemuan 2.
async function lengkapiJudulVideo(raw){
  const cache = store.data.ytJudul || (store.data.ytJudul = {});
  const posts = [];
  for (const c of (raw && raw.courses) || []) for (const p of c.posts || []) if (!p.fromMe && (p.youtube || []).length) posts.push(p);
  const baru = [...new Set(posts.flatMap(p => p.youtube))].filter(y => !(y in cache)).slice(0, 40);
  let i = 0;
  const kerja = async () => {
    while (i < baru.length){
      const y = baru[i++];
      try {
        const r = await fetch("https://www.youtube.com/oembed?format=json&url=" + encodeURIComponent("https://www.youtube.com/watch?v=" + y), { signal: AbortSignal.timeout(8000) });
        if (r.ok){ const j = await r.json(); cache[y] = String(j.title || "").slice(0, 300); }
        else if (r.status === 401 || r.status === 403 || r.status === 404) cache[y] = ""; // video privat atau dihapus
      } catch (e) {} // jaringan: dicoba lagi di sinkron berikutnya
    }
  };
  await Promise.all([kerja(), kerja(), kerja(), kerja()]);
  posts.forEach(p => { p.ytTitles = {}; p.youtube.forEach(y => { if (cache[y]) p.ytTitles[y] = cache[y]; }); });
}

async function doSync(silent){
  if (syncing) return { ok: false, error: "Sinkron sedang berjalan." };
  syncing = true; status({ sync: "running" });
  try {
    const raw = await lms.sync(store.data.settings.kampus.url);
    await lengkapiJudulVideo(raw).catch(() => {});
    const notes = applySync(store, raw);
    const peng = store.data.settings.pengingat || {};
    const shown = notes.filter(n => n.kind !== "materi" || peng.materi !== false);
    if (Notification.isSupported() && shown.length){
      if (shown.length <= 3) shown.forEach(n => notify(n.title, n.body));
      else notify("Teman Kuliah", `${shown.length} post baru dari dosen. Buka aplikasi untuk melihatnya.`);
    }
    push();
    if (store.data.settings.autoMateri) setTimeout(() => autoMateri().catch(() => {}), 500);
    setTimeout(() => prepareExams(false).catch(() => {}), 4000);
    return { ok: true, baru: notes.length };
  } catch (e) {
    store.data.lms.lastError = e.message; if (e.code === "login") store.data.lms.needsLogin = true;
    store.save(); push();
    return { ok: false, error: e.message, login: e.code === "login" };
  } finally { syncing = false; status({ sync: "idle" }); }
}

function scheduleSync(){
  clearInterval(syncTimer);
  syncTimer = setInterval(() => { if (store.data.lms.connected && store.data.settings.autoSync) doSync(true); }, 30 * 60 * 1000);
}

function notify(title, body, urgent){
  if (!Notification.isSupported()) return;
  const n = new Notification({ title, body, silent: false, timeoutType: urgent ? "never" : "default", urgency: urgent ? "critical" : "normal" });
  n.on("click", showWin); n.show();
}

/* ---------- pengingat: tenggat tugas, vicon, dan jam kuliah ---------- */
const HARI = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const hm = s => { const m = String(s || "").match(/(\d{1,2})[.:](\d{2})/); return m ? [+m[1], +m[2]] : null; };
const at = (ymdStr, t) => { const [y, mo, d] = String(ymdStr).slice(0, 10).split("-").map(Number); if (!y) return null; return new Date(y, mo - 1, d, t ? t[0] : 23, t ? t[1] : 59); };
function checkReminders(){
  if (!store) return;
  const peng = store.data.settings.pengingat || {}, now = Date.now(), done = store.data.reminded || (store.data.reminded = {});
  const fire = (key, title, body, urgent) => { if (done[key]) return; done[key] = now; notify(title, body, urgent); changed = true; };
  let changed = false;
  const sem = store.sem(), courses = sem ? sem.courses : {};
  const nm = id => (courses[id] && courses[id].singkat) || "Teman Kuliah";
  for (const [id, t] of Object.entries(store.data.todos || {})){
    if (t.done || !t.due) continue;
    const isVicon = /^Vicon:/i.test(t.text || "");
    const when = at(t.due, hm(t.time));
    if (!when) continue;
    const left = when - now;
    if (left <= 0) continue;
    if (isVicon){
      if (peng.kelas !== false && hm(t.time) && left <= 30 * 60000) fire(id + "_30m", nm(t.course) + ": vicon 30 menit lagi", `${t.text.replace(/^Vicon:\s*/i, "")}, jam ${t.time}.`, true);
      continue;
    }
    if (peng.tenggat === false) continue;
    if (left <= 3 * 3600000){ done[id + "_24h"] = done[id + "_24h"] || now; fire(id + "_3h", "Tenggat " + Math.max(1, Math.round(left / 3600000)) + " jam lagi", `${nm(t.course)}: ${t.text}. Tutup ${t.time ? "jam " + t.time : "hari ini"}.`, true); }
    else if (left <= 24 * 3600000) fire(id + "_24h", "Tenggat besok", `${nm(t.course)}: ${t.text}. Tutup ${t.time ? "jam " + t.time : "besok"}.`, false);
  }
  if (peng.kelas !== false && sem){
    const g = Number(store.data.settings.geserHari) || 0, d = new Date(), day = HARI[d.getDay()];
    const todayStr = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
    for (const c of Object.values(courses)){
      const i = HARI.indexOf(c.hariKRS); if (i < 0 || HARI[(i + g) % 7] !== day) continue;
      const t = hm(String(c.jam || "").split(/[-–]/)[0]); if (!t) continue;
      const left = at(todayStr, t) - now;
      if (left > 0 && left <= 15 * 60000) fire(`kelas_${c.id}_${todayStr}`, c.singkat + " mulai 15 menit lagi", `${c.nama}${c.dosen ? ", " + c.dosen : ""}.${absensiMode(store.data) === "komentar" ? " Jangan lupa komentar absensi." : ""}`, false);
    }
  }
  // Pengingat komentar absensi: jam 19.00 di hari kuliah, kalau post dosen pertemuan minggu ini masih ada yang belum dikomentari
  if (peng.komentar !== false && sem && sem.mulai && absensiMode(store.data) === "komentar" && new Date().getHours() >= 19){
    const g = Number(store.data.settings.geserHari) || 0, d = new Date(), day = HARI[d.getDay()];
    const todayStr = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
    const week = Math.floor((d - new Date(sem.mulai + "T00:00:00")) / 864e5 / 7) + 1;
    for (const c of Object.values(courses)){
      const i = HARI.indexOf(c.hariKRS); if (i < 0 || HARI[(i + g) % 7] !== day) continue;
      const a = c.absen && c.absen[week]; if (!a || !a.belum || !a.belum.length) continue;
      fire(`komentar_${c.id}_${todayStr}`, c.singkat + ": komentar absensi belum lengkap", `${a.belum.length} post dosen pertemuan ${week} belum kamu komentari: ${a.belum.slice(0, 2).map(b => b.judul).join(", ")}${a.belum.length > 2 ? ", dan lainnya" : ""}.`, false);
    }
  }
  // Kartu hafalan: jam 19.30, kalau ada kartu yang perlu diulang hari ini
  if (peng.hafalan !== false && new Date().getHours() * 60 + new Date().getMinutes() >= 19 * 60 + 30){
    const n = belajar.jumlahHariIni(store.data);
    if (n > 0) fire(`hafalan_${belajar.hariIni()}`, "Waktunya kartu hafalan", `${n} kartu menunggu hari ini, sekitar ${Math.max(2, Math.round(n * 0.25))} menit. Sedikit tiap hari bikin materi nempel sampai ujian.`, false);
  }
  // buang catatan lama
  for (const [k, v] of Object.entries(done)) if (now - v > 21 * 864e5){ delete done[k]; changed = true; }
  if (changed) store.save();
}

/* ---------- materi otomatis dari lampiran dosen ---------- */
const aiReady = () => { const a = store.data.settings.ai, p = a.provider; if (p === "server") return ["cerebras", "groq", "gemini"].some(x => a.keys[x]); if (p === "auto") return ["cerebras", "groq", "gemini"].some(x => a.keys[x]); return !!(a.model && a.model[p]) && (p === "ollama" || !!a.keys[p]); };
// target = { cid, meet } untuk tombol "Ringkas file dosen"; tanpa target = mode otomatis (kalau diaktifkan)
async function autoMateri(target){
  const ranges = target && target.ranges; // persiapan ujian: beberapa pertemuan sekaligus
  const force = !!(target && target.force); // "Ringkas ulang": semua file dosen + sumber lama disusun dari awal
  if (ranges) target = null;
  if (autoBusy) throw new Error("Masih menyusun materi lain, tunggu sebentar.");
  if (!aiReady()){ if (target) throw new Error("Pilih dan sambungkan AI dulu di Pengaturan."); return; }
  if (!target && !ranges && !store.data.settings.autoMateri) return;
  const sem = store.sem(); if (!sem){ if (target) throw new Error("Data LMS belum ada. Klik Sinkron dulu."); return; }
  if (!target && !ranges && !sem.mulai) return;
  const week = sem.mulai ? Math.floor((Date.now() - new Date(sem.mulai + "T00:00:00")) / 864e5 / 7) + 1 : 99;
  const jobs = [];
  const lampOf = c => { const L = { ...(c.lampiran || {}) }; if (force && c.id === target.cid && !L[target.meet] && sem.materi[`${c.id}_${target.meet}`]) L[target.meet] = []; return L; };
  for (const c of Object.values(sem.courses)) for (const [meet, files] of Object.entries(lampOf(c))){
    if (target && (c.id !== target.cid || Number(meet) !== Number(target.meet))) continue;
    if (ranges){ const r = ranges.find(x => x.cid === c.id); if (!r || Number(meet) < r.from || Number(meet) > r.to) continue; }
    else if (!target && Number(meet) > week + 1) continue;
    const key = `${c.id}_${meet}`, m = sem.materi[key];
    const done = new Set((m && m.lampiranIds) || []);
    const baru = force ? files : files.filter(f => !done.has(f.id));
    if (!baru.length && !(force && m)) continue;
    if (!target && !ranges && m && !m.auto) continue; // mode otomatis tidak menyentuh materi buatan sendiri
    jobs.push({ c, meet: Number(meet), files, key });
  }
  if (!jobs.length){ if (target) throw new Error(force ? "Belum ada materi atau file dosen untuk pertemuan ini." : "Tidak ada file baru dari dosen untuk pertemuan ini."); return 0; }
  autoBusy = true; status({ auto: `Menyusun ${jobs.length} materi baru dari LMS` });
  const dir = path.join(app.getPath("userData"), "lampiran");
  let ok = 0;
  try {
    for (const j of jobs.slice(0, ranges ? 16 : 8)){
      try {
        const items = [], used = [], skipped = [];
        for (const f of j.files){
          if (f.youtube){ items.push({ type: "youtube", url: f.youtube, name: f.name }); used.push(f.id); continue; }
          const geminiOn = store.data.settings.ai.provider === "gemini" || !!(store.data.settings.ai.keys || {}).gemini; // video ditonton Gemini (juga kalau AI pilihan Claude/ChatGPT: Gemini menulis catatan videonya). Komentar asli: Gemini milik pengguna
          if (f.video && !geminiOn){
            if (store.data.settings.ai.keys.groq || (store.data.settings.ai.provider === "server" && ai.serverOn(store.data.settings.ai))){ items.push({ type: "video", url: f.link, name: f.name }); used.push(f.id); continue; } // Whisper membaca langsung dari link
            skipped.push(f.name + " (video butuh AI Teman Kuliah, Gemini, atau API key Groq untuk transkrip Whisper)"); continue;
          }
          if (f.size > (f.video ? 300 : 40) * 1024 * 1024){ skipped.push(f.name + (f.video ? " (video lebih dari 300 MB)" : " (lebih dari 40 MB)")); continue; }
          const ext = path.extname(f.name).slice(0, 8);
          const safe = (String(f.id).replace(/\W/g, "") + "_" + path.basename(f.name, path.extname(f.name)).replace(/[\\/:*?"<>|\x00-\x1f]+/g, "_").replace(/[. ]+$/, "").slice(0, 80) + ext);
          const fp = path.join(dir, j.c.id, String(j.meet), safe);
          if (!fs.existsSync(fp)){
            status({ auto: `Mengunduh ${f.name}` });
            const buf = await download(f.link, f.video ? 900000 : 120000); if (!buf){ skipped.push(f.name + " (gagal diunduh)"); continue; }
            fs.mkdirSync(path.dirname(fp), { recursive: true });
            fs.writeFileSync(fp + ".part", buf); fs.renameSync(fp + ".part", fp);
          }
          items.push({ type: f.video ? "video" : "file", path: fp, url: f.video ? f.link : undefined, name: f.name, paksa: (store.data.lampiranPaksa || []).includes(f.id) }); used.push(f.id);
        }
        const prevM = sem.materi[j.key];
        if (!items.length && !(force && prevM && (prevM.sources || []).length)){ if (target) throw new Error("File dosen tidak bisa diunduh atau terlalu besar."); continue; }
        status({ auto: `Menyusun materi ${j.c.singkat} pertemuan ${j.meet}` });
        const lbl = `${j.c.singkat} P${j.meet}`;
        if (force && prevM) status({ auto: `Meringkas ulang ${j.c.singkat} pertemuan ${j.meet}` });
        const keepKom = prevM && prevM.komentarAlt;
        const r = await ingest.run(store, { courseId: j.c.id, meet: j.meet, items }, { merge: true }, msg => status({ auto: `${lbl}: ${msg}` }));
        if (keepKom && sem.materi[j.key]) delete sem.materi[j.key].komentarAlt; // variasi komentar lama tidak cocok lagi dengan ringkasan baru
        store.data.lms.autoError = r.warnings && r.warnings.length ? `${lbl}: ${r.warnings.join(" ")}` : null; if (target && r.warnings) lastWarn = r.warnings;
        const m = sem.materi[j.key]; if (!m) continue;
        m.auto = !target; m.lampiranIds = [...new Set([...(m.lampiranIds || []), ...used])];
        if (skipped.length){ const note = "Tidak ikut diringkas: " + skipped.join(", "); store.data.lms.autoError = `${lbl}: ${note}`; if (target) lastWarn = [...(lastWarn || []), note]; }
        store.data.antrean = (store.data.antrean || []).filter(x => !(x.cid === j.c.id && Number(x.meet) === Number(j.meet)));
        store.save(); push(); ok++;
        if (!target && !ranges) notify("Materi baru tersusun", `${j.c.singkat}, pertemuan ${j.meet}: ${m.judul}`);
      } catch (e) {
        if (e.code === "nonmateri"){ // RPS/kontrak: hanya file yang isinya RPS yang ditandai, file lain di pertemuan ini tetap tampil
          const bad = new Set(e.nonMateri || []), ids = j.files.filter(f => bad.has(f.name)).map(f => f.id);
          store.data.lampiranAbaikan = [...new Set([...(store.data.lampiranAbaikan || []), ...ids])];
          if (sem.courses[j.c.id] && sem.courses[j.c.id].lampiran && sem.courses[j.c.id].lampiran[j.meet]) sem.courses[j.c.id].lampiran[j.meet] = sem.courses[j.c.id].lampiran[j.meet].filter(f => !ids.includes(f.id));
          store.save(); push(); if (target) throw e; continue;
        }
        if (e.busy){
          antre(j.c.id, j.meet, force);
          if (e.quota){ const wib = Date.now() + 7 * 3600000; store.data.jedaJatah = Date.now() + (86400000 - (wib % 86400000)) + 5 * 60000; } // jatah server habis: antrean ditunda sampai lewat tengah malam WIB
          if (target){ const x = new Error(e.quota ? "Jatah ringkas materi hari ini sudah habis. Materi ini masuk antrean dan diringkas otomatis besok setelah jam 00.00 WIB." : "AI sedang penuh. Materi ini masuk antrean dan akan diringkas otomatis begitu servernya lega (dicoba tiap 10 menit)."); x.queued = true; throw x; }
          break;
        }
        if (target) throw e; store.data.lms.autoError = `${j.c.singkat} P${j.meet}: ${e.message}`; store.save(); push(); if (/key|kuota|saldo|ditolak/i.test(e.message)) break;
      }
    }
  } finally { autoBusy = false; status({ auto: null }); }
  return ok;
}

// Antrean: materi yang gagal karena server AI penuh dicoba lagi otomatis
function antre(cid, meet, force){
  const q = store.data.antrean || (store.data.antrean = []);
  const ada = q.find(x => x.cid === cid && Number(x.meet) === Number(meet));
  if (ada){ if (force) ada.force = true; }
  else q.push({ cid, meet: Number(meet), at: new Date().toISOString(), coba: 0, next: Date.now() + 5 * 60000, force: !!force });
  store.save(); push();
}
async function runAntrean(){
  const q = store && store.data.antrean; if (!q || !q.length || autoBusy || learnBusy || !aiReady()) return;
  const a = store.data.settings.ai, ownKey = ["cerebras", "groq", "gemini"].some(x => a.keys[x]);
  if (store.data.jedaJatah && Date.now() < store.data.jedaJatah && a.provider === "server" && !ownKey) return;
  // Coba lagi bertahap: 5, 10, 20, lalu tiap 40 menit, supaya tidak terus menabrak server yang sedang penuh
  const job = q.find(x => !x.next || Date.now() >= x.next); if (!job) return;
  try { await autoMateri({ cid: job.cid, meet: job.meet, force: !!job.force }); q.splice(q.indexOf(job), 1); const c = (store.sem() || { courses: {} }).courses[job.cid]; notify("Materi dari antrean selesai", `${c ? c.singkat : "Materi"}, pertemuan ${job.meet} sudah diringkas.`); }
  catch (e) { if (e.queued){ job.coba = (job.coba || 0) + 1; job.next = Date.now() + Math.min(40, 5 * Math.pow(2, job.coba - 1)) * 60000; q.push(q.splice(q.indexOf(job), 1)[0]); } else q.splice(q.indexOf(job), 1); }
  store.save(); push();
}

// Unduh file lampiran dosen dengan batas waktu supaya tidak menggantung.
async function download(url, ms = 120000){
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms);
  try { const r = await fetch(url, { signal: ac.signal }); if (!r.ok) return null; return Buffer.from(await r.arrayBuffer()); }
  catch (e) { return null; } finally { clearTimeout(t); }
}

function setupTray(){
  if (tray) return;
  tray = new Tray(nativeImage.createFromPath(path.join(__dirname, "renderer", "icon.png")).resize({ width: 16, height: 16 }));
  tray.setToolTip("Teman Kuliah");
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: "Buka Teman Kuliah", click: showWin },
    { label: "Sinkron sekarang", click: () => doSync(false) },
    { type: "separator" },
    { label: "Keluar", click: () => { quitting = true; app.quit(); } }
  ]));
  tray.on("click", showWin);
}
function applyTheme(){ const t = (store && store.data.settings.theme) || "auto"; nativeTheme.themeSource = t === "auto" ? "system" : t; }
function applyBackground(){
  const on = !!store.data.settings.background;
  if (app.isPackaged) app.setLoginItemSettings({ openAtLogin: on, args: ["--hidden"] });
  if (on) setupTray(); else if (tray){ tray.destroy(); tray = null; }
}

// Pindahan dari nama lama "Ruang Kuliah": bawa data, sesi login LMS, dan file lampiran ke folder baru.
function migrateOld(){
  try {
    const neu = app.getPath("userData"), old = path.join(app.getPath("appData"), "Ruang Kuliah"), f = "ruang-kuliah-data.json";
    if (fs.existsSync(path.join(neu, f)) || !fs.existsSync(path.join(old, f))) return;
    fs.mkdirSync(neu, { recursive: true });
    fs.copyFileSync(path.join(old, f), path.join(neu, f));
    for (const d of ["Partitions", "lampiran"]) { try { if (fs.existsSync(path.join(old, d))) fs.cpSync(path.join(old, d), path.join(neu, d), { recursive: true }); } catch (e) {} }
  } catch (e) { /* abaikan: mulai baru */ }
}

app.whenReady().then(() => {
  if (!gotLock) return;
  migrateOld();
  store = new Store(app.getPath("userData"));
  identity();
  applyTheme();
  createWindow();
  applyBackground();
  scheduleSync();
  setInterval(checkReminders, 60000); setTimeout(checkReminders, 8000);
  setInterval(() => runAntrean().catch(() => {}), 5 * 60000); setTimeout(() => runAntrean().catch(() => {}), 90000);
  win.webContents.once("did-finish-load", () => { if (store.data.lms.connected && store.data.settings.autoSync) setTimeout(() => doSync(true), 1200); });
  setupUpdater();
});
app.on("before-quit", () => { quitting = true; if (store) store.flush(); });
app.on("window-all-closed", () => { if (!store || !store.data.settings.background){ if (store) store.flush(); app.quit(); } });

/* ---------- IPC ---------- */
const h = (name, fn) => ipcMain.handle(name, async (e, ...a) => { try { return await fn(...a); } catch (err) { return { ok: false, error: err.message }; } });

h("state:get", () => pubState());
h("ai:quota", () => ai.serverQuota(store.data.settings.ai));
h("settings:save", patch => {
  const s = store.data.settings;
  if (patch.ai){
    const a = patch.ai;
    if (a.provider) s.ai.provider = a.provider;
    if (a.serverUrl !== undefined){ const u = String(a.serverUrl || "").trim().replace(/\/+$/, ""); if (u && !/^https:\/\/[^\s/]+/i.test(u) && !/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/i.test(u)) throw new Error("Alamat server harus diawali https://"); s.ai.serverUrl = u; }
    if (a.ollamaUrl) s.ai.ollamaUrl = a.ollamaUrl.trim();
    if (a.key && a.key.trim() && !a.key.startsWith("••••")) s.ai.keys[a.keyFor || s.ai.provider] = a.key.trim();
    if (a.model !== undefined) s.ai.model[a.modelFor || s.ai.provider] = a.model;
  }
  ["nama", "geserHari", "autoSync", "autoMateri", "background", "welcomed", "absensiKomentar", "setupDone"].forEach(k => { if (k in patch) s[k] = patch[k]; });
  // 1.0.17: gambar di ringkasan, suara "Dengarkan", kapasitas rencana belajar, versi yang sudah dilihat (halaman "Yang baru")
  if ("gambarRingkasan" in patch) s.gambarRingkasan = !!patch.gambarRingkasan;
  if ("lastSeenVersion" in patch) s.lastSeenVersion = String(patch.lastSeenVersion || "").slice(0, 20);
  if (patch.suara) s.suara = { ...(s.suara || {}), ...(["auto", "online", "perangkat"].includes(patch.suara.mesin) ? { mesin: patch.suara.mesin } : {}), ...(typeof patch.suara.voice === "string" ? { voice: patch.suara.voice.slice(0, 200) } : {}), ...(Number(patch.suara.rate) > 0 ? { rate: Math.max(0.5, Math.min(2, Number(patch.suara.rate))) } : {}) };
  if (patch.kapasitas) s.kapasitas = { kerja: Math.max(15, Math.min(600, Number(patch.kapasitas.kerja) || (s.kapasitas || {}).kerja || 90)), libur: Math.max(15, Math.min(720, Number(patch.kapasitas.libur) || (s.kapasitas || {}).libur || 150)) };
  if ("absensiMode" in patch){
    const md = ["komentar", "keaktifan", "tidak"].includes(patch.absensiMode) ? patch.absensiMode : null;
    s.absensiMode = md; s.absensiKomentar = md === null ? null : md === "komentar";
    if (md !== "komentar") Object.keys(store.data.todos).forEach(id => { if (store.data.todos[id].source === "absen") delete store.data.todos[id]; });
  }
  if (patch.pengingat) s.pengingat = Object.assign({}, s.pengingat, patch.pengingat);
  if (patch.theme){ s.theme = patch.theme; applyTheme(); }
  if ("ujianOtomatis" in patch) s.ujianOtomatis = !!patch.ujianOtomatis;
  if (patch.kampus){ s.kampus = { nama: String(patch.kampus.nama || "").slice(0, 80), url: patch.kampus.url ? lms.normBase(patch.kampus.url) : "" }; }
  if ("background" in patch) applyBackground();
  if (patch.autoMateri) setTimeout(() => autoMateri().catch(() => {}), 300);
  store.save(); push(); return { ok: true };
});
h("ai:test", async forP => {
  const cfg = store.data.settings.ai, p = forP || cfg.provider;
  const r = await ai.test({ ...cfg, provider: p });
  cfg.model[p] = r.pick; cfg.models[p] = { list: r.models, auto: r.auto };
  store.save(); push(); if (!forP) setTimeout(() => autoMateri().catch(() => {}), 500); return { ok: true, ...r };
});
let loggingIn = false;
h("lms:login", async () => {
  if (loggingIn) throw new Error("Jendela login LMS sudah terbuka.");
  loggingIn = true;
  try { return await loginFlow(); } finally { loggingIn = false; }
});
async function loginFlow(){
  while (syncing) await new Promise(r => setTimeout(r, 300));
  if (!store.data.settings.kampus || !store.data.settings.kampus.url) store.data.settings.kampus = { nama: "", url: "https://edlink.id" };
  const base = lms.normBase(store.data.settings.kampus.url);
  const me = await lms.login(win, base);
  const old = store.data.lms.me;
  if ((old && old.id && String(old.id) !== String(me.id)) || (store.data.lms.base && store.data.lms.base !== base)){
    // Akun LMS berbeda: mulai bersih supaya data teman lain tidak tercampur
    Object.assign(store.data, { semesters: {}, current: null, progress: {}, todos: {} });
    store.data.lms.seen = null; store.data.lms.dismissed = [];
  }
  store.data.lms.connected = true; store.data.lms.needsLogin = false; store.data.lms.lastError = null; store.data.lms.me = me; store.data.lms.base = base; store.save(); push();
  return doSync(false);
}
h("lms:sync", () => doSync(false));
h("sem:set", periode => { if (store.data.semesters[periode]){ store.data.current = periode; store.save(); push(); } return { ok: true }; });
// File dosen yang dilewati karena dikira RPS: pengguna bisa memintanya tetap diringkas
h("lampiran:paksa", id => {
  const k = String(id || ""); if (!k) throw new Error("File tidak dikenal.");
  store.data.lampiranAbaikan = (store.data.lampiranAbaikan || []).filter(x => x !== k);
  store.data.lampiranPaksa = [...new Set([...(store.data.lampiranPaksa || []), k])];
  store.save(); setTimeout(() => doSync(true), 200); return { ok: true };
});
h("auto:one", async (cid, meet) => { lastWarn = []; const n = await autoMateri({ cid, meet }); return { ok: true, n, warnings: lastWarn }; });
h("materi:ulang", async (cid, meet) => { lastWarn = []; const n = await autoMateri({ cid, meet, force: true }); return { ok: true, n, warnings: lastWarn }; });
// Komentar absensi: buat beberapa pilihan baru dari ringkasan materi, lalu pengguna memilih satu
h("komentar:alt", async key => {
  const sem = store.sem(), m = sem && sem.materi[key]; if (!m) throw new Error("Materi tidak ditemukan.");
  if (!aiReady() && !ai.serverOn(store.data.settings.ai)) throw new Error("Sambungkan AI dulu di Pengaturan.");
  const [cid, n] = key.split(/_(?=\d+$)/), c = sem.courses[cid] || {};
  const prevAlt = (m.komentarAlt || []).concat(m.komentar ? [m.komentar] : []);
  const list = await ai.komentarVariasi(store.data.settings.ai, { course: c.nama || "", dosen: c.dosen || "", meet: n }, materiText(m, n), prevAlt);
  m.komentarAlt = list; store.save(); push(); return { ok: true, list };
});
h("komentar:pick", (key, text) => { const sem = store.sem(), m = sem && sem.materi[key]; if (!m) throw new Error("Materi tidak ditemukan."); const t = String(text || "").trim().slice(0, 1200); if (!t) throw new Error("Komentar kosong."); m.komentar = t; store.save(); push(); return { ok: true }; });
h("lms:logout", async () => { await lms.logout(); store.data.lms.connected = false; store.data.lms.needsLogin = false; store.save(); push(); return { ok: true }; });
h("progress:set", (key, field, val) => {
  const pr = store.data.progress[key] || {};
  store.data.progress[key] = { ...pr, [field]: val, [field + "By"]: "manual" };
  store.save(); push(); return { ok: true };
});
h("todo:put", (id, data) => { const old = store.data.todos[id]; if ((id.startsWith("lms-") || id.startsWith("abs-")) && old && !!old.done !== !!data.done) data.manual = true; store.data.todos[id] = data; store.save(); push(); return { ok: true }; });
h("todo:del", id => {
  delete store.data.todos[id];
  if (id.startsWith("lms-") || id.startsWith("abs-")) store.data.lms.dismissed = [...new Set([...(store.data.lms.dismissed || []), id])];
  store.save(); push(); return { ok: true };
});
h("ingest:plan", (items, fallbackMeet) => {
  const sem = store.sem();
  const courses = sem ? Object.values(sem.courses) : [];
  return { ok: true, ...ingest.plan(items, courses, fallbackMeet) };
});
h("ingest:run", async (group, opts) => {
  const r = await ingest.run(store, group, opts || {}, msg => status({ ingest: msg }));
  push(); return { ok: true, ...r };
});
h("materi:delete", key => { const sem = store.sem(); if (sem) delete sem.materi[key]; visual.hapus(path.dirname(store.file), store.data.current, key); store.save(); push(); return { ok: true }; });
// Dengarkan ringkasan dengan suara Google bahasa Indonesia (perangkat sering hanya punya suara bahasa Inggris).
// Satu kalimat (maks 200 huruf) per permintaan; hasilnya disimpan sebentar supaya tidak diambil ulang.
const suaraCache = new Map();
h("suara:online", async teks => {
  const t = String(teks || "").replace(/\s+/g, " ").trim().slice(0, 200);
  if (!t) throw new Error("Teks kosong.");
  if (suaraCache.has(t)) return { ok: true, src: suaraCache.get(t) };
  const url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=id&ttsspeed=1&q=" + encodeURIComponent(t);
  let r;
  try { r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36", "Accept": "audio/mpeg,*/*" }, signal: AbortSignal.timeout(15000) }); }
  catch (e) { throw new Error("tidak ada internet"); }
  if (!r.ok) throw new Error("server suara menolak (" + r.status + ")");
  const buf = Buffer.from(await r.arrayBuffer());
  if (buf.length < 200) throw new Error("suara kosong");
  const src = "data:audio/mpeg;base64," + buf.toString("base64");
  suaraCache.set(t, src); if (suaraCache.size > 300) suaraCache.delete(suaraCache.keys().next().value);
  return { ok: true, src };
});
// Gambar ringkasan disimpan terpisah dan diminta tampilan saat materi dibuka
h("gambar:get", key => ({ ok: true, img: visual.baca(path.dirname(store.file), store.data.current, String(key || "")) }));
// Bagikan ringkasan sebagai PDF atau gambar PNG (desktop)
h("bagikan:file", (key, jenis) => require("./bagikan").simpan(store, win, String(key || ""), jenis === "png" ? "png" : "pdf"));

/* ---------- kartu hafalan ---------- */
h("hafalan:nilai", (id, r) => { const x = belajar.nilai(store.data, String(id), Math.max(0, Math.min(2, Number(r) || 0))); store.save(); push(); return { ok: true, ...x }; });
h("hafalan:set", patch => { const H = store.data.hafalan || (store.data.hafalan = {}); if (patch && Number(patch.batasBaru) >= 0) H.batasBaru = Math.min(100, Math.round(Number(patch.batasBaru))); store.save(); push(); return { ok: true }; });
h("hafalan:dariLatihan", id => { const L = (store.data.latihan || {})[id]; if (!L) throw new Error("Latihan tidak ditemukan."); const n = belajar.dariLatihan(store.data, L); if (n){ L.kartuDibuat = true; } store.save(); push(); return { ok: true, n }; });
h("hafalan:reset", id => { const k = ((store.data.hafalan || {}).kartu || {})[id]; if (k){ k.box = 0; k.due = belajar.hariIni(); store.save(); push(); } return { ok: true }; });

/* ---------- rencana belajar: centang tugas harian ---------- */
h("rencana:cek", (tgl, itemId, done) => {
  const R = store.data.rencana || (store.data.rencana = {});
  const d = String(tgl || "").slice(0, 10), set = new Set((R[d] || {}).done || []);
  if (done) set.add(String(itemId)); else set.delete(String(itemId));
  R[d] = { done: [...set] };
  const batas = belajar.tambahHari(belajar.hariIni(), -21); for (const k of Object.keys(R)) if (k < batas) delete R[k];
  store.save(); push(); return { ok: true };
});
h("ask", async (question, key) => {
  const sem = store.sem(), m = sem && sem.materi[key];
  if (!m) throw new Error("Materi tidak ditemukan.");
  const ctx = [m.judul, m.ringkas, ...(m.bagian || []).map(b => `${b.h}: ${b.p || ""} ${(b.list || []).join(" ")} ${b.note || ""}`)].join("\n");
  return { ok: true, text: await ai.ask(store.data.settings.ai, question, ctx) };
});
h("open", url => { if (/^https:\/\//.test(url)) shell.openExternal(url); return { ok: true }; });
h("pickFiles", async folder => {
  const r = await dialog.showOpenDialog(win, folder ? { title: "Pilih folder materi", properties: ["openDirectory", "multiSelections"] }
    : { title: "Pilih file materi", properties: ["openFile", "multiSelections"], filters: [{ name: "Materi", extensions: ["pdf", "pptx", "docx", "txt", "md", "png", "jpg", "jpeg"] }] });
  return { ok: true, paths: r.canceled ? [] : r.filePaths };
});

/* ---------- belajar: chat AI, persiapan ujian, latihan soal, saran ---------- */
const UJI = { uts: [1, 7], uas: [9, 15] };
const dayDiff = ymdStr => { const [y, m, d] = String(ymdStr).split("-").map(Number); if (!y) return null; const t = new Date(); t.setHours(0, 0, 0, 0); return Math.round((new Date(y, m - 1, d) - t) / 864e5); };
function materiText(m, n){
  if (!m) return "";
  const out = [`## Pertemuan ${n || ""}: ${m.judul}`, m.ringkas];
  for (const b of m.bagian || []){ out.push("### " + b.h); if (b.p) out.push(b.p); (b.list || []).forEach(x => out.push("- " + x)); if (b.table) b.table.forEach(r => out.push("| " + r.join(" | ") + " |")); if (b.contoh) out.push("Contoh: " + b.contoh); if (b.note) out.push(b.note); }
  if ((m.istilah || []).length) out.push("Istilah: " + m.istilah.map(([a, b]) => `${a} = ${b}`).join("; "));
  return out.filter(Boolean).join("\n");
}
function courseText(sem, cid, from = 1, to = 16){
  const parts = [];
  for (let n = from; n <= to; n++){ const m = sem.materi[`${cid}_${n}`]; if (m) parts.push(materiText(m, n)); }
  return parts.join("\n\n");
}
// Konteks chat: "m:<cid>_<n>" satu materi, "c:<cid>" satu mata kuliah, "umum" semua
function chatContext(key){
  const sem = store.sem(); if (!sem) return "";
  if (key.startsWith("m:")){ const k = key.slice(2), [cid, n] = k.split(/_(?=\d+$)/), c = sem.courses[cid]; return (c ? `Mata kuliah: ${c.nama}. Dosen: ${c.dosen}.\n` : "") + materiText(sem.materi[k], n); }
  if (key.startsWith("c:")){ const cid = key.slice(2), c = sem.courses[cid]; return (c ? `Mata kuliah: ${c.nama}. Dosen: ${c.dosen}.\n\n` : "") + courseText(sem, cid); }
  return Object.values(sem.courses).map(c => `# ${c.nama}\n` + Object.entries(sem.materi).filter(([k]) => k.startsWith(c.id + "_")).map(([k, m]) => `- Pertemuan ${k.split("_").pop()}: ${m.judul}. ${m.ringkas}`).join("\n")).join("\n\n");
}
h("chat:send", (key, text) => ipcChatSend(key, text));
async function ipcChatSend(key, text){
  const q = String(text || "").trim(); if (!q) throw new Error("Tulis pertanyaannya dulu.");
  if (!aiReady()) throw new Error("Sambungkan AI dulu di Pengaturan.");
  const chats = store.data.chats || (store.data.chats = {});
  const list = chats[key] || (chats[key] = []);
  const history = list.slice();
  list.push({ role: "user", text: q, at: new Date().toISOString() }); store.save(); push();
  let answer;
  try { answer = await ai.chat(store.data.settings.ai, chatContext(key), history, q, d => { if (win && !win.isDestroyed()) win.webContents.send("chat:delta", { key, delta: d }); }); }
  catch (e) { list.push({ role: "ai", text: "", error: e.message, at: new Date().toISOString() }); store.save(); push(); throw e; }
  list.push({ role: "ai", text: answer, at: new Date().toISOString() }); if (list.length > 200) list.splice(0, list.length - 200);
  store.save(); push(); return { ok: true, text: answer };
}
h("chat:retry", async key => {
  const list = (store.data.chats || {})[key] || [];
  if (list.length && list[list.length - 1].role === "ai" && list[list.length - 1].error) list.pop();
  const last = list.length && list[list.length - 1].role === "user" ? list.pop() : null;
  if (!last) throw new Error("Tidak ada pertanyaan untuk diulang.");
  store.save(); return await ipcChatSend(key, last.text);
});
h("chat:clear", key => { if (store.data.chats) delete store.data.chats[key]; store.save(); push(); return { ok: true }; });

/* ---------- Pandu Tugas ---------- */
const panduBusy = new Set();
h("pandu:start", async (id, tambahan) => {
  const t = (store.data.todos || {})[id]; if (!t) throw new Error("Tugas tidak ditemukan. Coba sinkron dulu.");
  if (!aiReady()) throw new Error("Sambungkan Gemini dulu di Pengaturan.");
  if (panduBusy.has(id)) throw new Error("Tugas ini sedang dibaca AI, tunggu sebentar.");
  panduBusy.add(id);
  try {
    const sem = store.sem(), c = sem && sem.courses[t.course];
    // Lampiran dosen (PDF/PPT/DOCX) ikut dibaca supaya bimbingan sesuai panduan tugasnya
    let lampText = ""; const lampiran = [];
    for (const f of (t.files || []).slice(0, 3)){
      if (!f.link || (f.size && f.size > 40 * 1024 * 1024)) continue;
      const buf = await download(f.link, 120000); if (!buf) continue;
      const tmp = path.join(app.getPath("temp"), "tk-pandu-" + Date.now() + "-" + String(f.name || "lampiran").replace(/[^\w.-]+/g, "_"));
      try { fs.writeFileSync(tmp, buf); const r = await require("./extract").extract(tmp); if (r && r.text && r.text.trim()){ lampText += `\n\n=== Lampiran: ${f.name} ===\n${r.text.slice(0, 30000)}`; lampiran.push(f.name); } }
      catch (e) {} finally { try { fs.unlinkSync(tmp); } catch (e) {} }
    }
    const instruksi = [t.desc || "", String(tambahan || "").trim() ? "Tambahan dari mahasiswa:\n" + String(tambahan).trim() : "", lampText].filter(Boolean).join("\n\n").trim();
    if (!instruksi && !String(t.text || "").trim()) throw new Error("Instruksi tugas belum ada. Tempel instruksinya dulu.");
    const info = { judul: String(t.text || "").replace(/^(Tugas|Ujian|Kuis):\s*/, ""), matkul: c ? c.nama : "", tenggat: t.due ? t.due + (t.time ? ", " + t.time : "") : "", instruksi };
    const plan = await ai.panduRencana(store.data.settings.ai, info);
    const P = store.data.pandu || (store.data.pandu = {});
    P[id] = { judul: info.judul, matkul: info.matkul, tenggat: info.tenggat, instruksi: instruksi.slice(0, 60000), lampiran,
      intinya: plan.intinya, diminta: plan.diminta, hasil: plan.hasil, tidakPerlu: plan.tidakPerlu, langkah: plan.langkah, aktif: 0,
      chat: [{ role: "ai", text: plan.pembuka, step: 0, at: new Date().toISOString() }], dibuat: new Date().toISOString() };
    store.save(); push(); return { ok: true };
  } finally { panduBusy.delete(id); }
});
h("pandu:send", async (id, text, mulai) => {
  const p = (store.data.pandu || {})[id]; if (!p) throw new Error("Panduan tugas ini belum dibuat.");
  const q = String(text || "").trim(); if (!q && !mulai) throw new Error("Tulis jawaban atau pertanyaanmu dulu.");
  const history = p.chat.filter(m => !m.error);
  if (!mulai){ p.chat.push({ role: "user", text: q, step: p.aktif, at: new Date().toISOString() }); store.save(); push(); }
  let answer;
  try { answer = await ai.panduChat(store.data.settings.ai, p, history, q, !!mulai, d => { if (win && !win.isDestroyed()) win.webContents.send("pandu:delta", { id, delta: d }); }); }
  catch (e) { p.chat.push({ role: "ai", text: "", error: e.message, step: p.aktif, retry: mulai ? "" : q, at: new Date().toISOString() }); store.save(); push(); throw e; }
  p.chat.push({ role: "ai", text: answer, step: p.aktif, at: new Date().toISOString() }); if (p.chat.length > 300) p.chat.splice(0, p.chat.length - 300);
  store.save(); push(); return { ok: true };
});
h("pandu:step", (id, idx) => {
  const p = (store.data.pandu || {})[id]; if (!p) throw new Error("Panduan tugas ini belum dibuat.");
  const L = p.langkah, i = Number(idx); if (!L[i]) throw new Error("Langkah tidak ditemukan.");
  L[i].done = !L[i].done;
  const before = p.aktif, next = L.findIndex(x => !x.done);
  p.aktif = next < 0 ? L.length : next;
  store.save(); push(); return { ok: true, pindah: p.aktif !== before, selesai: next < 0 };
});
h("pandu:retry", async id => {
  const p = (store.data.pandu || {})[id]; if (!p) throw new Error("Panduan tugas ini belum dibuat.");
  const last = p.chat[p.chat.length - 1]; if (!last || !last.error) return { ok: true };
  p.chat.pop(); const q = last.retry;
  if (q){ const u = p.chat[p.chat.length - 1]; if (u && u.role === "user" && u.text === q) p.chat.pop(); }
  store.save();
  return { ok: true, q };
});
h("pandu:del", id => { if (store.data.pandu) delete store.data.pandu[id]; store.save(); push(); return { ok: true }; });

let learnBusy = false;
async function learnJob(label, fn){
  if (learnBusy) throw new Error("Masih ada proses AI lain yang berjalan, tunggu sebentar.");
  if (!aiReady()) throw new Error("Sambungkan AI dulu di Pengaturan.");
  learnBusy = true; const t0 = Date.now();
  const tick = x => { const d = Math.round((Date.now() - t0) / 1000), tt = Math.floor(d / 60) + ":" + String(d % 60).padStart(2, "0"); status({ auto: `${label}: ${x && x.phase === "write" ? "AI sedang menulis, " + x.chars.toLocaleString("id-ID") + " karakter" : x && x.phase === "switch" ? "server sibuk, mencoba model " + x.model : x && x.phase === "retry" ? "server penuh, dicoba lagi dalam " + Math.max(0, Math.round((x.until - Date.now()) / 1000)) + " detik" : "AI sedang membaca materi"} (${tt})` }); };
  tick(); let last = null; const iv = setInterval(() => tick(last), 1000);
  try { return await fn(x => { last = x; }); } finally { clearInterval(iv); learnBusy = false; status({ auto: null }); }
}
h("latihan:make", async o => {
  const sem = store.sem(), c = sem && sem.courses[o.cid]; if (!c) throw new Error("Pilih mata kuliah dulu.");
  const from = Number(o.from) || 1, to = Number(o.to) || 16, text = courseText(sem, c.id, from, to);
  if (!text.trim()) throw new Error("Belum ada materi yang diringkas untuk pertemuan " + from + " sampai " + to + ". Ringkas file dosen dulu.");
  const cakupan = from === to ? `pertemuan ${from}` : `pertemuan ${from} sampai ${to}`;
  const sim = o.sim ? { durasi: Math.max(10, Math.min(240, Number(o.sim.durasi) || 60)), jenis: String(o.sim.jenis || "").slice(0, 20), lemah: (Array.isArray(o.sim.lemah) ? o.sim.lemah : []).map(x => String(x).slice(0, 60)).slice(0, 6), mulai: null } : null;
  const nPG = Math.max(1, Math.min(80, Number(o.pg) || 20)), nES = Math.max(0, Math.min(12, Number(o.essay) || 0));
  const soal = await learnJob(`${sim ? "Simulasi" : "Latihan"} ${c.singkat}`, async pr => {
    const s = await ai.makeLatihan(store.data.settings.ai, { course: c.nama, cakupan }, text, { pg: nPG, essay: nES, sim }, pr);
    // Simulasi ujian harus lengkap jumlah soalnya: kalau AI memberi kurang, minta tambahannya (paling banyak 2 kali)
    for (let i = 0; sim && i < 2 && (s.pg.length < nPG || s.essay.length < nES); i++){
      const kurangPG = Math.max(0, nPG - s.pg.length), kurangES = Math.max(0, nES - s.essay.length);
      try {
        const t = await ai.makeLatihan(store.data.settings.ai, { course: c.nama, cakupan }, text, { pg: kurangPG || 1, essay: kurangES, sim, hindari: [...s.pg, ...s.essay].map(x => x.q) }, pr);
        const ada = new Set([...s.pg, ...s.essay].map(x => x.q.toLowerCase().trim()));
        s.pg.push(...t.pg.filter(x => !ada.has(x.q.toLowerCase().trim())).slice(0, kurangPG));
        s.essay.push(...t.essay.filter(x => !ada.has(x.q.toLowerCase().trim())).slice(0, kurangES));
      } catch (e) { break; }
    }
    s.pg = s.pg.slice(0, nPG); s.essay = s.essay.slice(0, nES);
    return s;
  });
  const id = "L" + Date.now().toString(36);
  (store.data.latihan || (store.data.latihan = {}))[id] = { id, periode: store.data.current, cid: c.id, from, to, label: o.label || cakupan, dibuat: new Date().toISOString(), soal, jawaban: { pg: {}, essay: {}, ragu: [] }, hasil: null, ...(sim ? { sim } : {}) };
  store.save(); push(); return { ok: true, id };
});
// Simulasi ujian: waktu mulai dicatat saat tombol Mulai diklik (timer tetap jalan walau halaman ditinggal)
h("latihan:mulai", id => { const L = (store.data.latihan || {})[id]; if (!L || !L.sim) throw new Error("Simulasi tidak ditemukan."); if (!L.sim.mulai){ L.sim.mulai = new Date().toISOString(); store.save(); push(); } return { ok: true, mulai: L.sim.mulai }; });
// Peta konsep per mata kuliah (disimpan; dibuat ulang kalau materinya berubah)
h("peta:make", async cid => {
  const sem = store.sem(), c = sem && sem.courses[cid]; if (!c) throw new Error("Mata kuliah tidak ditemukan.");
  const keys = Object.keys(sem.materi).filter(k => k.startsWith(cid + "_")).sort((a, b) => +a.split("_").pop() - +b.split("_").pop());
  if (!keys.length) throw new Error("Belum ada materi yang diringkas di mata kuliah ini.");
  const text = keys.map(k => materiText(sem.materi[k], k.split("_").pop())).join("\n\n");
  const data = await learnJob(`Peta konsep ${c.singkat}`, pr => ai.petaKonsep(store.data.settings.ai, { course: c.nama }, text, pr));
  (store.data.peta || (store.data.peta = {}))[`${store.data.current}_${cid}`] = { data, dibuat: new Date().toISOString(), sig: keys.map(k => k + ":" + (sem.materi[k].dibuat || "")).join("|") };
  store.save(); push(); return { ok: true };
});
h("latihan:save", (id, jawaban) => { const L = (store.data.latihan || {})[id]; if (L && !L.hasil){ L.jawaban = jawaban; store.save(); } return { ok: true }; });
h("latihan:del", id => { if (store.data.latihan) delete store.data.latihan[id]; store.save(); push(); return { ok: true }; });
h("latihan:submit", async (id, jawaban) => {
  const L = (store.data.latihan || {})[id]; if (!L) throw new Error("Latihan tidak ditemukan.");
  L.jawaban = jawaban;
  const pg = L.soal.pg.map((q, i) => ({ benar: jawaban.pg[i] === q.a, pilih: jawaban.pg[i] ?? null }));
  let essay = [];
  if (L.soal.essay.length){
    const items = L.soal.essay.map((q, i) => ({ q: q.q, kunci: q.kunci, jawaban: String(jawaban.essay[i] || "").trim() }));
    if (items.some(x => x.jawaban)) essay = await learnJob("Menilai essay", pr => ai.gradeEssay(store.data.settings.ai, items, pr));
    else essay = items.map(() => ({ skor: 0, umpan: "Belum dijawab.", kurang: "" }));
  }
  const pgScore = pg.length ? pg.filter(x => x.benar).length / pg.length * 100 : null;
  const esScore = essay.length ? essay.reduce((a, x) => a + x.skor, 0) / essay.length : null;
  const total = pgScore == null ? esScore : esScore == null ? pgScore : pgScore * 0.7 + esScore * 0.3;
  L.hasil = { pg, essay, pgScore, esScore, total: Math.round(total || 0), selesai: new Date().toISOString(), ...(L.sim && L.sim.mulai ? { waktu: Math.max(0, Math.round((Date.now() - new Date(L.sim.mulai)) / 1000)) } : {}) };
  store.save(); push(); return { ok: true };
});

// Ringkas otomatis materi yang belum ada untuk ujian yang tinggal <= 14 hari
async function prepareExams(manual, cid, jenis){
  const sem = store.sem(); if (!sem || !aiReady()) { if (manual) throw new Error(!sem ? "Data LMS belum ada." : "Sambungkan AI dulu di Pengaturan."); return 0; }
  if (!manual && store.data.settings.ujianOtomatis === false) return 0;
  if (autoBusy) return 0;
  const ranges = [];
  for (const c of Object.values(sem.courses)){
    if (cid && c.id !== cid) continue;
    for (const j of jenis ? [jenis] : ["uts", "uas"]){
      const u = (c.ujian || {})[j]; const dd = u && dayDiff(u.tanggal);
      if (manual || (dd != null && dd >= 0 && dd <= 14)) ranges.push({ cid: c.id, from: UJI[j][0], to: UJI[j][1] });
    }
  }
  if (!ranges.length) return 0;
  const n = await autoMateri({ ranges });
  if (n && !manual) notify("Persiapan ujian", `${n} materi untuk ujian yang sudah dekat diringkas otomatis.`);
  return n || 0;
}
h("ujian:prepare", async (cid, jenis) => ({ ok: true, n: await prepareExams(true, cid, jenis) }));
h("ujian:rangkuman", async (cid, jenis) => {
  const sem = store.sem(), c = sem && sem.courses[cid]; if (!c) throw new Error("Mata kuliah tidak ditemukan.");
  const [from, to] = UJI[jenis], text = courseText(sem, cid, from, to);
  if (!text.trim()) throw new Error("Belum ada materi pertemuan " + from + " sampai " + to + " yang diringkas.");
  const teks = await learnJob(`Rangkuman ${jenis.toUpperCase()} ${c.singkat}`, pr => ai.rangkumanUjian(store.data.settings.ai, { course: c.nama, jenis: jenis === "uts" ? "UTS" : "UAS", cakupan: from + " sampai " + to }, text, pr));
  (store.data.ujian || (store.data.ujian = {}))[`${store.data.current}_${cid}_${jenis}`] = { teks, dibuat: new Date().toISOString(), materi: Object.keys(sem.materi).filter(k => { const [a, n] = k.split(/_(?=\d+$)/); return a === cid && +n >= from && +n <= to; }).length };
  store.save(); push(); return { ok: true };
});
h("saran:make", async statsText => {
  const teks = await learnJob("Saran belajar", pr => ai.saranBelajar(store.data.settings.ai, String(statsText || ""), pr));
  (store.data.saran || (store.data.saran = {}))[store.data.current] = { teks, dibuat: new Date().toISOString() };
  store.save(); push(); return { ok: true };
});

/* ---------- panduan (PDF ikut dalam aplikasi) ---------- */
const guidePath = () => app.isPackaged ? path.join(process.resourcesPath, "Panduan Teman Kuliah.pdf") : path.join(__dirname, "..", "docs", "Panduan Teman Kuliah.pdf");
let guideWin = null;
h("guide:open", () => {
  const f = guidePath(); if (!fs.existsSync(f)) throw new Error("File panduan tidak ditemukan.");
  if (guideWin && !guideWin.isDestroyed()){ guideWin.show(); guideWin.focus(); return { ok: true }; }
  guideWin = new BrowserWindow({ width: 980, height: 900, title: "Panduan Teman Kuliah", autoHideMenuBar: true, backgroundColor: "#525659", icon: path.join(__dirname, "renderer", "icon.png"),
    webPreferences: { plugins: true, contextIsolation: true, nodeIntegration: false, sandbox: true } });
  guideWin.webContents.setWindowOpenHandler(({ url }) => { if (/^https:\/\//.test(url)) shell.openExternal(url); return { action: "deny" }; });
  guideWin.loadURL(require("url").pathToFileURL(f).href);
  return { ok: true };
});
h("guide:file", async () => {
  const f = guidePath(); if (!fs.existsSync(f)) throw new Error("File panduan tidak ditemukan.");
  const err = await shell.openPath(f); if (err) throw new Error(err); return { ok: true };
});

/* ---------- auto-update (GitHub Releases) ---------- */
// Status update terlihat di Pengaturan (versi, sedang mengecek, mengunduh %, siap, gagal + alasan), dengan tombol Cek update.
// state: idle | checking | downloading | downloaded | latest | error | off
const upd = { state: "idle", version: app.getVersion ? app.getVersion() : require("../package.json").version };
let updater = null, updLast = 0, updGerak = 0;
const updStatus = o => { Object.assign(upd, o); updGerak = Date.now(); status({ upd: { ...upd } }); };
const updAlasan = e => {
  const m = String((e && (e.message || e)) || "");
  if (/ERR_INTERNET_DISCONNECTED|ENOTFOUND|EAI_AGAIN|ERR_NAME_NOT_RESOLVED|ECONNRESET|ETIMEDOUT|ERR_NETWORK|ERR_CONNECTION/i.test(m)) return "Tidak ada koneksi internet, atau GitHub tidak bisa dihubungi.";
  if (/rate limit|403/i.test(m)) return "GitHub sedang membatasi pengecekan. Coba lagi beberapa menit lagi.";
  if (/latest\.yml|404|Cannot find/i.test(m)) return "File update di GitHub belum siap. Coba lagi beberapa menit lagi.";
  if (/sha512|checksum/i.test(m)) return "File update rusak saat diunduh. Coba lagi.";
  return m.split("\n")[0].slice(0, 160) || "Tidak diketahui.";
};
function checkUpdate(){
  if (!updater) return;
  if (upd.state === "downloaded") return;
  // Sedang mengecek/mengunduh: jangan dobel, kecuali macet (tidak ada kabar 1 menit saat mengecek, 5 menit saat mengunduh)
  if (upd.state === "checking" && Date.now() - updGerak < 60 * 1000) return;
  if (upd.state === "downloading" && Date.now() - updGerak < 5 * 60 * 1000) return;
  updLast = Date.now();
  updStatus({ state: "checking", msg: "" });
  updater.checkForUpdates().catch(e => updStatus({ state: "error", msg: updAlasan(e) }));
}
function setupUpdater(){
  try {
    const pub = (require("../package.json").build.publish || [])[0] || {};
    if (!app.isPackaged || !pub.owner || /GANTI/.test(pub.owner)){ updStatus({ state: "off", msg: "Update otomatis tidak aktif di versi ini." }); return; }
    const { autoUpdater } = require("electron-updater");
    updater = autoUpdater;
    autoUpdater.autoDownload = true;
    autoUpdater.on("checking-for-update", () => updStatus({ state: "checking", msg: "" }));
    autoUpdater.on("update-available", info => updStatus({ state: "downloading", baru: info.version, persen: 0 }));
    autoUpdater.on("update-not-available", () => updStatus({ state: "latest", waktu: new Date().toISOString() }));
    autoUpdater.on("download-progress", p => { const n = Math.floor((p && p.percent) || 0); if (n !== upd.persen) updStatus({ state: "downloading", persen: n }); });
    autoUpdater.on("update-downloaded", info => { updStatus({ state: "downloaded", baru: info.version }); status({ update: info.version }); });
    autoUpdater.on("error", e => { if (upd.state !== "downloaded") updStatus({ state: "error", msg: updAlasan(e) }); });
    checkUpdate();
    setInterval(checkUpdate, 6 * 60 * 60 * 1000);
    app.on("browser-window-focus", () => updSaatMuncul());
    ipcMain.handle("update:install", () => autoUpdater.quitAndInstall());
  } catch (e) { updStatus({ state: "error", msg: updAlasan(e) }); }
}
// Tombol "Cek update" di Pengaturan, dan status awal saat tampilan dibuka
h("update:check", () => { if (updater) checkUpdate(); return { ...upd }; });
h("update:state", () => ({ ...upd }));
// Aplikasi sering hanya disembunyikan ke tray: cek lagi saat jendela dimunculkan (paling sering tiap 30 menit)
function updSaatMuncul(){ if (updater && Date.now() - updLast > 30 * 60 * 1000) checkUpdate(); }
