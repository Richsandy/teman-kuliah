// Gambar di ringkasan materi: diambil dari slide (PPTX), PDF, dokumen Word, foto materi, dan cuplikan video,
// lalu ditaruh di bagian ringkasan yang paling cocok. Gambar disimpan terpisah dari data utama
// (file gambar-<periode>_<matkul>_<pertemuan>.json) supaya data utama tetap ringan.
// Langkah ini tidak pernah menggagalkan ringkasan: kalau ada yang gagal, ringkasan tetap tersimpan tanpa gambar.
const fs = require("fs");
const path = require("path");
const JSZip = require("jszip");
const ai = require("./ai");
let R = null;
const vr = () => R || (R = require("./visr"));

const STOP = new Set("yang dan dari untuk dengan pada adalah dalam ini itu atau oleh akan tidak juga sebagai karena para lebih dapat bisa ada antara setiap secara bahwa sudah telah masih serta yaitu yakni agar maka the and for with are this that from into have has was were their which been slide halaman bagian materi".split(" "));
const tok = s => new Set(String(s || "").toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, " ").split(" ").filter(w => w.length >= 3 && !STOP.has(w) && !/^\d+$/.test(w)));
const decode = s => s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
const mmss = t => { t = Math.max(0, Math.round(t)); const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60; return (h ? h + ":" + String(m).padStart(2, "0") : String(m).padStart(2, "0")) + ":" + String(s).padStart(2, "0"); };
// "03:12", "1:02:30", "3.12", "menit 3" -> detik
function detik(v){
  if (v == null || v === "") return null;
  if (typeof v === "number") return v >= 0 ? v : null;
  const s = String(v).trim(), m = s.match(/(\d{1,2})[:.](\d{2})(?:[:.](\d{2}))?/);
  if (m) return m[3] != null ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) : (+m[1]) * 60 + (+m[2]);
  const n = s.match(/^(\d{1,3})$/); return n ? (+n[1]) * 60 : null;
}
const MIME = { ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp" };

// Ukuran gambar dari kepala file (PNG, JPEG, GIF, WEBP), tanpa membuka gambarnya
function imgSize(b){
  try {
    if (b[0] === 0x89 && b[1] === 0x50) return [b.readUInt32BE(16), b.readUInt32BE(20)];
    if (b[0] === 0x47 && b[1] === 0x49) return [b.readUInt16LE(6), b.readUInt16LE(8)];
    if (b[0] === 0xff && b[1] === 0xd8){
      let i = 2;
      while (i < b.length - 9){
        if (b[i] !== 0xff){ i++; continue; }
        const mk = b[i + 1], len = b.readUInt16BE(i + 2);
        if (mk >= 0xc0 && mk <= 0xcf && mk !== 0xc4 && mk !== 0xc8 && mk !== 0xcc) return [b.readUInt16BE(i + 7), b.readUInt16BE(i + 5)];
        i += 2 + len;
      }
    }
    if (b.toString("ascii", 0, 4) === "RIFF" && b.toString("ascii", 8, 12) === "WEBP") return [0, 0]; // dicek setelah dibuka
  } catch (e) {}
  return null;
}
const layak = (buf, minSide = 140) => {
  if (buf.length < 9 * 1024 || buf.length > 8 * 1024 * 1024) return false;
  const sz = imgSize(buf); if (!sz) return false;
  const [w, h] = sz; if (!w && !h) return true;
  return Math.min(w, h) >= minSide && Math.max(w, h) / Math.max(1, Math.min(w, h)) <= 5;
};
const paraTeks = xml => xml.split(/<\/a:p>/).map(p => decode((p.match(/<a:t>([\s\S]*?)<\/a:t>/g) || []).map(t => t.replace(/<\/?a:t>/g, "")).join(""))).map(s => s.trim()).filter(Boolean);
const resolve = (base, target) => path.posix.normalize(path.posix.join(path.posix.dirname(base), target)).replace(/^\/+/, "");
async function relsOf(zip, partName){
  const rp = path.posix.join(path.posix.dirname(partName), "_rels", path.posix.basename(partName) + ".rels");
  const f = zip.file(rp); if (!f) return {};
  const x = await f.async("string"), out = {};
  for (const m of x.matchAll(/<Relationship\b[^>]*?Id="([^"]+)"[^>]*?Target="([^"]+)"[^>]*?>/g)) out[m[1]] = resolve(partName, m[2]);
  for (const m of x.matchAll(/<Relationship\b[^>]*?Target="([^"]+)"[^>]*?Id="([^"]+)"[^>]*?>/g)) if (!out[m[2]]) out[m[2]] = resolve(partName, m[1]);
  return out;
}

// PPTX: gambar per slide, dengan teks slide sebagai konteks. Logo/latar yang berulang di banyak slide dibuang.
async function pptxCands(file, name){
  const zip = await JSZip.loadAsync(fs.readFileSync(file));
  const pres = zip.file("ppt/presentation.xml") ? await zip.file("ppt/presentation.xml").async("string") : "";
  const sz = pres.match(/<p:sldSz[^>]*?cx="(\d+)"[^>]*?cy="(\d+)"/);
  const SW = sz ? +sz[1] : 12192000, SH = sz ? +sz[2] : 6858000;
  const slides = Object.keys(zip.files).filter(n => /^ppt\/slides\/slide\d+\.xml$/.test(n)).sort((a, b) => +a.match(/(\d+)\.xml$/)[1] - +b.match(/(\d+)\.xml$/)[1]);
  const pics = [], pakai = {};
  for (const [i, n] of slides.entries()){
    const xml = await zip.file(n).async("string"), rels = await relsOf(zip, n);
    const teks = paraTeks(xml).join(" · ").slice(0, 600);
    const seen = new Set();
    for (const pm of xml.matchAll(/<p:pic>([\s\S]*?)<\/p:pic>/g)){
      const blk = pm[1], emb = (blk.match(/r:embed="([^"]+)"/) || [])[1], target = emb && rels[emb]; if (!target) continue;
      const ext = (blk.match(/<a:ext\s+cx="(\d+)"\s+cy="(\d+)"/) || []);
      const cover = ext[1] ? (+ext[1] * +ext[2]) / (SW * SH) : 0.2;
      const descr = decode((blk.match(/\bdescr="([^"]*)"/) || [])[1] || "");
      if (!seen.has(target)){ pakai[target] = (pakai[target] || 0) + 1; seen.add(target); }
      pics.push({ slide: i + 1, target, cover, descr, teks });
    }
  }
  const out = [], sudah = new Set();
  for (const p of pics){
    if (out.length >= 14) break;
    if (sudah.has(p.target) || pakai[p.target] >= 3) continue; // logo/latar template
    if (p.cover < 0.035 || p.cover > 0.93) continue;            // ikon kecil atau gambar latar satu slide penuh
    const ext = path.extname(p.target).toLowerCase(); if (!MIME[ext]) continue; // EMF/WMF/SVG/TIFF dilewati
    const f = zip.file(p.target); if (!f) continue;
    const buf = await f.async("nodebuffer"); if (!layak(buf)) continue;
    sudah.add(p.target);
    out.push({ buf, mime: MIME[ext], ctx: [p.teks, p.descr].filter(Boolean).join(" · "), dari: `${name}, slide ${p.slide}`, skor: p.cover });
  }
  return out;
}

// DOCX: gambar di dokumen dengan paragraf di sekitarnya sebagai konteks
async function docxCands(file, name){
  const zip = await JSZip.loadAsync(fs.readFileSync(file));
  const part = "word/document.xml"; if (!zip.file(part)) return [];
  const xml = await zip.file(part).async("string"), rels = await relsOf(zip, part);
  const paras = xml.split(/<\/w:p>/).map(p => ({ teks: decode((p.match(/<w:t[^>]*>([\s\S]*?)<\/w:t>/g) || []).map(t => t.replace(/<[^>]+>/g, "")).join("")).trim(), emb: [...p.matchAll(/r:embed="([^"]+)"/g)].map(m => m[1]) }));
  const out = [], sudah = new Set();
  for (let i = 0; i < paras.length && out.length < 10; i++){
    for (const e of paras[i].emb){
      const target = rels[e]; if (!target || sudah.has(target)) continue;
      const ext = path.extname(target).toLowerCase(); if (!MIME[ext]) continue;
      const f = zip.file(target); if (!f) continue;
      const buf = await f.async("nodebuffer"); if (!layak(buf, 160)) continue;
      sudah.add(target);
      const ctx = [paras[i - 2], paras[i - 1], paras[i], paras[i + 1]].filter(Boolean).map(x => x.teks).filter(Boolean).join(" ").slice(0, 600);
      out.push({ buf, mime: MIME[ext], ctx, dari: name, skor: 0.3 });
    }
  }
  return out;
}

// AI yang bisa melihat gambar untuk memilih dan menaruh gambar (hemat: Gemini Flash-Lite, gambar versi kecil, satu kali panggil)
function visionCfg(cfg){
  const k = cfg.keys || {};
  if (k.gemini) return { ...cfg, provider: "gemini", model: { ...(cfg.model || {}), gemini: "gemini-flash-lite-latest" }, quick: true, task: "lain" };
  if (cfg.provider === "openai" && k.openai && (cfg.model || {}).openai) return { ...cfg, task: "lain" };
  if (cfg.provider === "anthropic" && k.anthropic && (cfg.model || {}).anthropic) return { ...cfg, task: "lain" };
  return null;
}
const ringkasBagian = b => [b.p, ...(b.list || [])].join(" ").replace(/\*\*/g, "").replace(/\s+/g, " ").slice(0, 150);
async function pilihDenganAI(vcfg, m, cands){
  const prompt = `Kamu menata gambar untuk ringkasan materi kuliah. Di bawah ada daftar BAGIAN ringkasan, lalu beberapa GAMBAR dari materi dosen (slide, PDF, dokumen, foto, atau cuplikan video).
Pilih gambar yang benar-benar membantu memahami isi: diagram, bagan, grafik, skema, alur, tabel bergambar, rumus, ilustrasi konsep, contoh tampilan atau benda yang sedang dibahas, atau tulisan di papan/slide yang menjelaskan sesuatu secara visual.
JANGAN pilih: logo, foto dosen/pembicara/wajah orang, dekorasi, latar, ikon, halaman judul/penutup/terima kasih, slide yang isinya hanya tulisan biasa (tulisannya sudah ada di ringkasan), gambar buram atau terpotong, dan gambar yang hampir sama dengan gambar lain yang sudah dipilih.
Taruh setiap gambar di bagian yang paling cocok isinya. Paling banyak 2 gambar per bagian dan 10 gambar total. Boleh tidak memilih sama sekali kalau tidak ada yang membantu.
Untuk setiap gambar yang dipilih tulis "ket": keterangan 1 kalimat (paling banyak 18 kata, bahasa Indonesia, tanpa em dash) tentang apa yang ditunjukkan gambar itu.
Balas HANYA JSON: {"gambar":[{"id":"g1","bagian":0,"ket":"..."}]}  ("bagian" = nomor bagian di daftar)

BAGIAN:
${m.bagian.map((b, i) => `${i}. ${b.h}: ${ringkasBagian(b)}`).join("\n")}`;
  const parts = [{ kind: "text", text: prompt }];
  for (const c of cands){
    parts.push({ kind: "text", text: `GAMBAR ${c.id} (dari ${c.dari}${c.hint != null ? `, diambil untuk bagian ${c.hint}` : ""}${c.ctx ? `; teks di sekitarnya: "${String(c.ctx).slice(0, 200)}"` : ""})` });
    parts.push({ kind: "image", mime: "image/jpeg", base64: String(c.mini || c.src).replace(/^data:[^,]+,/, "") });
  }
  const r = await ai.generate(vcfg, parts, true);
  const j = ai.repairJSON ? (safeJSON(r.text) || ai.repairJSON(r.text)) : safeJSON(r.text);
  if (!j || !Array.isArray(j.gambar)) throw new Error("jawaban AI tidak terbaca");
  const ids = new Map(cands.map(c => [c.id, c])), per = {}, out = [];
  for (const g of j.gambar){
    const c = ids.get(String(g && g.id || "").trim()), bi = Math.round(Number(g && g.bagian));
    if (!c || !(bi >= 0 && bi < m.bagian.length) || out.some(x => x.c === c)) continue;
    if ((per[bi] || 0) >= 2 || out.length >= 10) continue;
    per[bi] = (per[bi] || 0) + 1;
    out.push({ c, bi, ket: String(g.ket || "").replace(/\s*[—–]\s*/g, ", ").replace(/\s+/g, " ").trim().slice(0, 200) });
  }
  return out;
}
function safeJSON(t){ try { const s = String(t).trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim(); return JSON.parse(s.slice(s.indexOf("{"), s.lastIndexOf("}") + 1)); } catch (e) { return null; } }

// Tanpa AI penglihat: cocokkan teks di sekitar gambar dengan isi tiap bagian (lebih hati-hati: 1 gambar per bagian)
function pilihTanpaAI(m, cands){
  const bt = m.bagian.map(b => tok(b.h + " " + b.h + " " + b.p + " " + (b.list || []).join(" ") + " " + (b.note || "")));
  const calon = [];
  for (const c of cands){
    if (c.hint != null){ if (c.ctxVideo) calon.push({ c, bi: c.hint, skor: 1 }); continue; }
    const ct = tok(c.ctx); if (ct.size < 4) continue;
    let best = -1, bs = 0;
    bt.forEach((b, i) => { if (!b.size) return; let n = 0; for (const w of ct) if (b.has(w)) n++; const s = n >= 3 ? n / Math.sqrt(ct.size * b.size) : 0; if (s > bs){ bs = s; best = i; } });
    if (best >= 0 && bs >= 0.12) calon.push({ c, bi: best, skor: bs });
  }
  calon.sort((a, b) => b.skor - a.skor);
  const per = new Set(), out = [];
  for (const x of calon){ if (per.has(x.bi) || out.length >= 8) continue; per.add(x.bi); out.push({ ...x, ket: "" }); }
  return out;
}

const fileOf = (dir, periode, key) => path.join(dir, `gambar-${String(periode || "x").replace(/\W/g, "")}_${String(key).replace(/[^\w-]/g, "")}.json`);
function hapus(dir, periode, key){ try { fs.unlinkSync(fileOf(dir, periode, key)); } catch (e) {} }
function baca(dir, periode, key){ try { return JSON.parse(fs.readFileSync(fileOf(dir, periode, key), "utf8")).img || {}; } catch (e) { return {}; } }

// o: { dir, periode, key, items, m, cfg, progress }. Mengubah m.bagian[i].gambar / .video dan menulis file gambar.
async function collect(o){
  const { items, m, cfg } = o, batal = () => !!(o.batal && o.batal());
  const progress = x => { if (!batal() && o.progress) o.progress(x); };
  const notes = [], vidLinks = [];
  // Ringkasan tidak diubah sampai semuanya selesai: kalau dibatalkan (terlalu lama), hasil setengah jadi dibuang
  const cands = [], hashes = [];
  const beda = (a, b) => {
    const [pa, ca] = String(a).split("|"), [pb, cb] = String(b).split("|");
    let n = 0; for (let i = 0; i < pa.length; i++) if (pa[i] !== pb[i]) n++;
    if (ca && cb){ const x = ca.split(",").map(Number), y = cb.split(",").map(Number); if (Math.hypot(x[0] - y[0], x[1] - y[1], x[2] - y[2]) > 18) n += 100; }
    return n;
  };
  const add = (r, extra) => {
    if (!r || !r.src || r.sd < 7) return false;
    if (r.hash && hashes.some(h => beda(h, r.hash) <= 8)) return false;
    if (r.hash) hashes.push(r.hash);
    cands.push({ id: "g" + (cands.length + 1), src: r.src, mini: r.mini, w: r.w, h: r.h, hash: r.hash, ...extra });
    return true;
  };
  const vcfg = visionCfg(cfg);

  for (const it of items || []){
    if (batal()) break;
    if (it.type !== "file" || !it.path || !fs.existsSync(it.path)) continue;
    const ext = path.extname(it.path).toLowerCase(), name = it.name || path.basename(it.path);
    try {
      if (ext === ".pdf"){
        progress(`Mencari gambar di ${name}`);
        const r = await vr().pdf(it.path, { maxOut: 12, maxPages: 90 });
        r.forEach(x => add(x, { ctx: x.teks, dari: `${name}, halaman ${x.page}`, skor: x.cover }));
      } else if (ext === ".pptx" || ext === ".docx"){
        progress(`Mencari gambar di ${name}`);
        for (const c of await (ext === ".pptx" ? pptxCands : docxCands)(it.path, name)){
          try { add(await vr().image(c.buf, c.mime), { ctx: c.ctx, dari: c.dari, skor: c.skor }); } catch (e) {}
        }
      } else if (MIME[ext]){
        const buf = fs.readFileSync(it.path); if (buf.length > 15 * 1024 * 1024) continue;
        add(await vr().image(buf, MIME[ext]), { ctx: path.basename(name, ext), dari: name, skor: 0.5 });
      }
    } catch (e) { notes.push(`${name}: ${e.message}`); }
  }

  // Video: cuplikan di menit tempat tiap bagian dibahas (menurut AI yang meringkas). YouTube: tautan ke menit itu.
  const vids = (items || []).filter(i => i.type === "video" || i.type === "youtube");
  const videoKe = b => { const v = Math.round(Number(b.videoKe)); return vids.length === 1 ? 0 : (v >= 1 && v <= vids.length ? v - 1 : -1); };
  for (const [vi, v] of vids.entries()){
    if (batal()) break;
    const minta = m.bagian.map((b, bi) => ({ bi, t: detik(b.menit) })).filter(x => x.t != null && videoKe(m.bagian[x.bi]) === vi);
    if (v.type === "youtube"){
      const id = (String(v.url).match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|live\/|embed\/)|youtu\.be\/)([\w-]{11})/) || [])[1];
      if (id) minta.forEach(x => vidLinks.push({ bi: x.bi, v: { yt: id, t: Math.round(x.t), judul: v.name || "" } }));
      continue;
    }
    if (!v.path || !fs.existsSync(v.path)) continue;
    const name = v.name || path.basename(v.path);
    if (!minta.length && !vcfg) continue; // tanpa penanda waktu dan tanpa AI penglihat: tidak bisa tahu cuplikan mana yang berguna
    progress(`Mengambil cuplikan ${name}`);
    try {
      const r = await vr().frames(v.path, minta.length ? { times: minta.map(x => x.t + 2) } : { sample: 10 });
      const keep = r.frames || [];
      keep.forEach((f, k) => {
        if (f.dup != null || !f.src) return;
        const x = minta[k];
        add(f, { dari: `${name}, menit ${mmss(f.t - (x ? 2 : 0))}`, hint: x ? x.bi : null, ctx: x ? m.bagian[x.bi].h : "", ctxVideo: !!x, skor: 0.4 });
      });
    } catch (e) { notes.push(`${name}: ${e.message}`); }
  }

  let pilih = [];
  if (cands.length){
    // Kalau terlalu banyak, utamakan cuplikan video yang diminta per bagian lalu gambar yang paling besar di halamannya
    let list = cands.slice().sort((a, b) => (b.hint != null) - (a.hint != null) || (b.skor || 0) - (a.skor || 0)).slice(0, 24);
    list = cands.filter(c => list.includes(c)); // urutan asli (sesuai urutan materi)
    if (vcfg){
      progress("Memilih gambar yang cocok untuk tiap bagian");
      try { pilih = await pilihDenganAI(vcfg, m, list); }
      catch (e) { notes.push("Pemilihan gambar dengan AI gagal (" + e.message + "), dipakai pencocokan teks."); pilih = pilihTanpaAI(m, list); }
    } else pilih = pilihTanpaAI(m, list);
  }

  // Gambar yang sama dari dua sumber (misalnya slide yang juga muncul di video) cukup tampil sekali
  // (dicek antarsumber yang berbeda saja: pola mirip DAN warna rata-rata hampir sama)
  const kembar = (a, b) => { const [pa, ca] = String(a).split("|"), [pb, cb] = String(b).split("|"); if (!ca || !cb) return false; let n = 0; for (let i = 0; i < pa.length; i++) if (pa[i] !== pb[i]) n++; const x = ca.split(",").map(Number), y = cb.split(",").map(Number); return n <= 16 && Math.hypot(x[0] - y[0], x[1] - y[1], x[2] - y[2]) <= 9; };
  const sumber = c => String(c.dari || "").split(",")[0];
  const dipakai = [];
  pilih = pilih.filter(x => { if (x.c.hash && dipakai.some(d => sumber(d) !== sumber(x.c) && kembar(d.hash, x.c.hash))) return false; dipakai.push(x.c); return true; });
  if (batal()) return { n: 0, batal: true, notes };
  m.bagian.forEach(b => { delete b.gambar; delete b.video; });
  vidLinks.forEach(x => { m.bagian[x.bi].video = x.v; });
  const img = {};
  pilih.sort((a, b) => a.bi - b.bi || cands.indexOf(a.c) - cands.indexOf(b.c)).forEach(x => {
    img[x.c.id] = x.c.src;
    (m.bagian[x.bi].gambar ||= []).push({ id: x.c.id, ket: x.ket, dari: x.c.dari, w: x.c.w, h: x.c.h });
  });
  const n = Object.keys(img).length;
  if (n){ fs.writeFileSync(fileOf(o.dir, o.periode, o.key), JSON.stringify({ v: 1, img })); m.gambarV = Date.now(); }
  else { hapus(o.dir, o.periode, o.key); delete m.gambarV; }
  try { if (R) R.close(); } catch (e) {} // hanya menutup jendela tersembunyi kalau tidak ada pekerjaan lain
  return { n, kandidat: cands.length, video: m.bagian.filter(b => b.video).length, notes, ai: !!vcfg };
}

module.exports = { collect, baca, hapus, fileOf, detik, mmss, imgSize, pptxCands, docxCands, pilihTanpaAI };
