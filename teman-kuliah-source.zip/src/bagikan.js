// Bagikan ringkasan: simpan sebagai PDF (lengkap dengan gambar) atau gambar PNG (kartu ringkas untuk dikirim ke grup).
// Desktop saja: dirender di jendela tersembunyi Chromium. Di HP yang tersedia: kirim ke WhatsApp dan salin teks.
const { app, BrowserWindow, dialog, shell } = require("electron");
const fs = require("fs");
const path = require("path");
const { pathToFileURL } = require("url");
const visual = require("./visual");

const BRAND = "Dibuat dengan Teman Kuliah · temankuliah.netlify.app";
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const rich = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
const para = s => String(s || "").split(/\n+/).filter(Boolean).map(x => `<p>${rich(x)}</p>`).join("");
const fontUrl = () => pathToFileURL(path.join(__dirname, "renderer", "fonts", "inter.woff2")).href;
const logoUrl = () => pathToFileURL(path.join(__dirname, "renderer", "icon.png")).href;
const WARNA = { c1: "#2D7FE0", c2: "#E06A26", c3: "#7A5AD8", c4: "#169C78", c5: "#D9487A", c6: "#C0870A", c7: "#4F8F45" };

function htmlPDF(m, c, n, img){
  const cc = WARNA[c.warna] || "#2457F5";
  const tabel = t => `<table><tr>${t[0].map(x => `<th>${rich(x)}</th>`).join("")}</tr>${t.slice(1).map(r => `<tr>${r.map(x => `<td>${rich(x)}</td>`).join("")}</tr>`).join("")}</table>`;
  const fig = g => img[g.id] ? `<figure><img src="${img[g.id]}" alt=""><figcaption>${esc(g.ket || "")}${g.dari ? `<span>${g.ket ? " · " : ""}${esc(g.dari)}</span>` : ""}</figcaption></figure>` : "";
  const bagian = (m.bagian || []).map(b => `<section><h2>${esc(b.h)}</h2>${para(b.p)}${(b.list || []).length ? `<ul>${b.list.map(x => `<li>${rich(x)}</li>`).join("")}</ul>` : ""}${b.table ? tabel(b.table) : ""}${(b.gambar || []).map(fig).join("")}${b.contoh ? `<p class="aside"><b>Contoh:</b> ${rich(b.contoh)}</p>` : ""}${b.note ? `<p class="aside">${rich(b.note)}</p>` : ""}</section>`).join("");
  const istilah = (m.istilah || []).length ? `<section><h2>Istilah penting</h2><table class="ist">${m.istilah.map(([a, b]) => `<tr><th>${esc(a)}</th><td>${esc(b)}</td></tr>`).join("")}</table></section>` : "";
  const kuis = (m.kuis || []).length ? `<section class="brk"><h2>Latihan kuis</h2><ol class="kuis">${m.kuis.map(q => `<li><p>${esc(q.q)}</p><ol type="A">${q.o.map(o => `<li>${esc(o)}</li>`).join("")}</ol></li>`).join("")}</ol>
    <h3>Kunci jawaban</h3><p class="kunci">${m.kuis.map((q, i) => `${i + 1}. ${String.fromCharCode(65 + q.a)}`).join(" &nbsp; ")}</p></section>` : "";
  return `<!doctype html><html lang="id"><head><meta charset="utf-8"><style>
  @font-face{font-family:"Inter";src:url("${fontUrl()}") format("woff2");font-weight:100 900}
  *{box-sizing:border-box} body{font-family:"Inter",Arial,sans-serif;color:#15171C;font-size:11pt;line-height:1.55;margin:0}
  .top{border-left:6px solid ${cc};padding:2px 0 2px 16px;margin-bottom:18px} .top small{color:#62656D;font-size:9.5pt;font-weight:600;letter-spacing:.02em;text-transform:uppercase}
  h1{font-size:22pt;line-height:1.2;margin:6px 0 0;letter-spacing:-.02em} h2{font-size:14pt;margin:22px 0 6px;letter-spacing:-.01em;break-after:avoid} h3{font-size:11.5pt;margin:16px 0 4px}
  p{margin:0 0 7px} ul{margin:4px 0 8px;padding-left:20px} li{margin:2px 0}
  .ringkas{background:#F3F4F7;border-radius:10px;padding:12px 14px;font-size:11.5pt}
  .aside{background:#FFF8D6;border-radius:8px;padding:8px 11px;font-size:10.5pt}
  table{border-collapse:collapse;width:100%;margin:6px 0 10px;font-size:10pt;break-inside:avoid} th,td{border:1px solid #DDDEE3;padding:5px 7px;text-align:left;vertical-align:top} th{background:#F3F4F7}
  table.ist th{width:30%}
  figure{margin:10px 0 12px;break-inside:avoid;text-align:center} figure img{max-width:100%;max-height:330px;border-radius:8px;border:1px solid #E4E5EA} figcaption{font-size:9.5pt;color:#62656D;margin-top:4px} figcaption span{color:#8D9098}
  .brk{break-before:page} ol.kuis>li{margin-bottom:8px;break-inside:avoid} ol.kuis ol{margin:2px 0} .kunci{font-weight:600}
  .brand{margin-top:26px;color:#8D9098;font-size:9pt;display:flex;align-items:center;gap:8px} .brand img{width:18px;height:18px}
  </style></head><body>
  <div class="top"><small>${esc(c.nama)} · Pertemuan ${n}${c.dosen ? " · " + esc(c.dosen) : ""}</small><h1>${esc(m.judul)}</h1></div>
  ${m.ringkas ? `<div class="ringkas">${rich(m.ringkas)}</div>` : ""}
  ${bagian}${istilah}${kuis}
  <div class="brand"><img src="${logoUrl()}" alt="">${esc(BRAND)}</div>
  </body></html>`;
}

function htmlKartu(m, c, n, img){
  const cc = WARNA[c.warna] || "#2457F5";
  const poin = (m.bagian || []).map(b => b.h).filter(Boolean);
  const pertama = (m.bagian || []).flatMap(b => b.gambar || []).find(g => img[g.id]);
  const ist = (m.istilah || []).slice(0, 6);
  return `<!doctype html><html lang="id"><head><meta charset="utf-8"><style>
  @font-face{font-family:"Inter";src:url("${fontUrl()}") format("woff2");font-weight:100 900}
  *{box-sizing:border-box} html,body{margin:0;background:#EDEEF2} body{font-family:"Inter",Arial,sans-serif;color:#15171C;width:1080px;padding:48px}
  .card{background:#fff;border-radius:40px;padding:56px 60px;box-shadow:0 10px 40px rgba(0,0,0,.08);overflow:hidden}
  .chip{display:inline-flex;align-items:center;gap:10px;background:color-mix(in srgb, ${cc} 13%, #fff);color:#15171C;border-radius:999px;padding:9px 18px;font-weight:600;font-size:22px}
  .chip i{width:14px;height:14px;border-radius:50%;background:${cc}}
  h1{font-size:54px;line-height:1.1;letter-spacing:-.03em;margin:24px 0 18px}
  .ringkas{font-size:26px;line-height:1.5;color:#33363D}
  .ringkas b{background:linear-gradient(transparent 55%, rgba(255,214,10,.6) 55%)}
  .hero{margin:30px 0 6px;border-radius:24px;overflow:hidden;border:1px solid #E4E5EA;max-height:520px;display:flex;justify-content:center;background:#fafafa} .hero img{max-width:100%;max-height:520px;display:block}
  h2{font-size:24px;text-transform:uppercase;letter-spacing:.06em;color:#8D9098;margin:36px 0 14px}
  ol{margin:0;padding:0;list-style:none;counter-reset:p} ol li{counter-increment:p;font-size:27px;line-height:1.35;padding:12px 0 12px 62px;position:relative;border-top:1px solid #EEEFF2}
  ol li::before{content:counter(p);position:absolute;left:0;top:10px;width:42px;height:42px;border-radius:50%;background:${cc};color:#fff;font-weight:700;font-size:21px;display:grid;place-items:center}
  .ist{display:grid;grid-template-columns:1fr 1fr;gap:14px} .ist div{background:#F3F4F7;border-radius:20px;padding:16px 20px} .ist b{display:block;font-size:23px} .ist span{font-size:19px;color:#62656D;line-height:1.35;display:block;margin-top:4px}
  .foot{display:flex;align-items:center;gap:14px;margin-top:34px;font-size:21px;color:#62656D} .foot img{width:44px;height:44px} .foot b{color:#15171C}
  .more{font-size:21px;color:#8D9098;margin-top:10px}
  </style></head><body><div class="card">
  <span class="chip"><i></i>${esc(c.singkat || c.nama)} · Pertemuan ${n}</span>
  <h1>${esc(m.judul)}</h1>
  ${m.ringkas ? `<div class="ringkas">${rich(m.ringkas)}</div>` : ""}
  ${pertama ? `<div class="hero"><img src="${img[pertama.id]}" alt=""></div>` : ""}
  ${poin.length ? `<h2>Yang dibahas</h2><ol>${poin.slice(0, 8).map(p => `<li>${esc(p)}</li>`).join("")}</ol>${poin.length > 8 ? `<p class="more">dan ${poin.length - 8} bagian lainnya</p>` : ""}` : ""}
  ${ist.length ? `<h2>Istilah kunci</h2><div class="ist">${ist.map(([a, b]) => `<div><b>${esc(a)}</b><span>${esc(String(b).length > 90 ? String(b).slice(0, 88).replace(/\s+\S*$/, "") + "…" : b)}</span></div>`).join("")}</div>` : ""}
  <div class="foot"><img src="${logoUrl()}" alt=""><span><b>Teman Kuliah</b> · temankuliah.netlify.app</span></div>
  </div></body></html>`;
}

async function render(html, kerja){
  const dir = path.join(app.getPath("temp"), "teman-kuliah-bagikan"); fs.mkdirSync(dir, { recursive: true });
  const f = path.join(dir, "bagikan-" + Date.now() + ".html"); fs.writeFileSync(f, html);
  const w = new BrowserWindow({ show: false, width: 1080, height: 900, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, backgroundThrottling: false } });
  try { await w.loadFile(f); await w.webContents.executeJavaScript("document.fonts ? document.fonts.ready.then(() => Promise.all([...document.images].map(i => i.complete ? 1 : new Promise(r => { i.onload = i.onerror = r; })))).then(() => 1) : 1"); return await kerja(w); }
  finally { if (!w.isDestroyed()) w.destroy(); try { fs.unlinkSync(f); } catch (e) {} }
}

const namaFile = s => String(s || "ringkasan").replace(/[\\/:*?"<>|\x00-\x1f]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 80) || "ringkasan";
async function simpan(store, parent, key, jenis){
  const sem = store.sem(), m = sem && sem.materi[key]; if (!m) throw new Error("Materi tidak ditemukan.");
  const [cid, n] = key.split(/_(?=\d+$)/), c = sem.courses[cid] || { nama: "", singkat: "" };
  const img = visual.baca(path.dirname(store.file), store.data.current, key);
  const pdf = jenis === "pdf";
  const buf = await render(pdf ? htmlPDF(m, c, n, img) : htmlKartu(m, c, n, img), async w => {
    if (pdf) return w.webContents.printToPDF({ pageSize: "A4", printBackground: true, margins: { top: 0.6, bottom: 0.75, left: 0.65, right: 0.65 }, displayHeaderFooter: true,
      headerTemplate: "<span></span>", footerTemplate: `<div style="font-family:Arial;font-size:7.5px;color:#8D9098;width:100%;text-align:center">${esc(BRAND)} · <span class="pageNumber"></span>/<span class="totalPages"></span></div>` });
    const h = Math.min(16000, await w.webContents.executeJavaScript("Math.ceil(document.documentElement.scrollHeight)"));
    w.setContentSize(1080, h); await new Promise(r => setTimeout(r, 250));
    return (await w.webContents.capturePage({ x: 0, y: 0, width: 1080, height: h })).toPNG();
  });
  const def = path.join(app.getPath("downloads"), namaFile(`${c.singkat || c.nama} P${n} ${m.judul}`) + (pdf ? ".pdf" : ".png"));
  const r = await dialog.showSaveDialog(parent, { title: pdf ? "Simpan ringkasan sebagai PDF" : "Simpan kartu ringkasan sebagai gambar", defaultPath: def, filters: pdf ? [{ name: "PDF", extensions: ["pdf"] }] : [{ name: "Gambar PNG", extensions: ["png"] }] });
  if (r.canceled || !r.filePath) return { ok: true, batal: true };
  fs.writeFileSync(r.filePath, buf);
  shell.showItemInFolder(r.filePath);
  return { ok: true, path: r.filePath };
}

module.exports = { simpan, htmlPDF, htmlKartu, render, BRAND };
