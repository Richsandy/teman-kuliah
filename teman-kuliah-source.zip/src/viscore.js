// Pengolah gambar untuk ringkasan materi (berjalan di halaman web, bukan di Node):
// - mencari gambar/diagram di halaman PDF lalu memotongnya,
// - mengambil cuplikan video di menit tertentu,
// - mengecilkan gambar dari slide/dokumen jadi JPEG.
// Desktop: dimuat di jendela tersembunyi (src/visr.js). HP: dipakai langsung di aplikasi (mobile-src/visr.js).
(function(root){
  let lib = null;
  const MAX = 960;
  const canvas = (w, h) => { const c = document.createElement("canvas"); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); return c; };
  const fit = (w, h, max) => { const s = Math.min(1, max / Math.max(w, h)); return [Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s))]; };
  const wait = (ms) => new Promise(r => setTimeout(r, ms));
  const withTimeout = (p, ms, msg) => Promise.race([p, new Promise((_, no) => setTimeout(() => no(new Error(msg || "waktu habis")), ms))]);

  // Sidik kecil gambar: terang rata-rata, sebaran (gambar kosong/polos sebarannya kecil), dan hash 16x16 untuk mencari duplikat
  function stats(src){
    const t = canvas(16, 16), x = t.getContext("2d", { willReadFrequently: true });
    x.drawImage(src, 0, 0, 16, 16);
    const d = x.getImageData(0, 0, 16, 16).data, g = [];
    let sum = 0, sq = 0;
    for (let i = 0; i < d.length; i += 4){ const v = d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11; g.push(v); sum += v; sq += v * v; }
    const mean = sum / 256, sd = Math.sqrt(Math.max(0, sq / 256 - mean * mean));
    let r = 0, gg = 0, b = 0; for (let i = 0; i < d.length; i += 4){ r += d[i]; gg += d[i + 1]; b += d[i + 2]; }
    // hash: 256 bit pola terang-gelap + 3 angka warna rata-rata (slide bertemplate sama tapi beda isi tetap dianggap beda)
    return { mean, sd, hash: g.map(v => v > mean ? "1" : "0").join("") + "|" + [r, gg, b].map(x => Math.round(x / 256)).join(",") };
  }
  const beda = (a, b) => {
    const [pa, ca] = String(a).split("|"), [pb, cb] = String(b).split("|");
    let n = 0; for (let i = 0; i < pa.length; i++) if (pa[i] !== pb[i]) n++;
    if (ca && cb){ const x = ca.split(",").map(Number), y = cb.split(",").map(Number); if (Math.hypot(x[0] - y[0], x[1] - y[1], x[2] - y[2]) > 18) n += 100; }
    return n;
  };
  function out(c, q){
    const [w, h] = fit(c.width, c.height, MAX);
    let src = c;
    if (w !== c.width){ src = canvas(w, h); const x = src.getContext("2d"); x.imageSmoothingQuality = "high"; x.drawImage(c, 0, 0, w, h); }
    const s = stats(src);
    // Versi kecil (maks 384 px) untuk dikirim ke AI saat memilih gambar: hemat kuota
    const [mw, mh] = fit(w, h, 384), mini = canvas(mw, mh); mini.getContext("2d").drawImage(src, 0, 0, mw, mh);
    return { src: src.toDataURL("image/jpeg", q || 0.8), mini: mini.toDataURL("image/jpeg", 0.7), w, h, sd: s.sd, mean: s.mean, hash: s.hash };
  }

  function loadImg(url){
    return new Promise((ok, no) => { const im = new Image(); im.onload = () => ok(im); im.onerror = () => no(new Error("gambar tidak bisa dibuka")); im.src = url; });
  }
  // Gambar dari slide/dokumen: latar putih (PNG transparan), dikecilkan, jadi JPEG
  async function image(url){
    const im = await withTimeout(loadImg(url), 15000, "gambar terlalu lama dibuka");
    const w = im.naturalWidth, h = im.naturalHeight;
    if (!w || !h) throw new Error("ukuran gambar 0");
    const [cw, ch] = fit(w, h, MAX), c = canvas(cw, ch), x = c.getContext("2d");
    x.fillStyle = "#fff"; x.fillRect(0, 0, cw, ch); x.imageSmoothingQuality = "high"; x.drawImage(im, 0, 0, cw, ch);
    const r = out(c, 0.82); r.ow = w; r.oh = h; return r;
  }

  const mul = (m1, m2) => [m1[0] * m2[0] + m1[2] * m2[1], m1[1] * m2[0] + m1[3] * m2[1], m1[0] * m2[2] + m1[2] * m2[3], m1[1] * m2[2] + m1[3] * m2[3], m1[0] * m2[4] + m1[2] * m2[5] + m1[4], m1[1] * m2[4] + m1[3] * m2[5] + m1[5]];
  const v1 = () => /^1\./.test(String(lib.version || ""));
  const viewport = (page, s) => v1() ? page.getViewport(s) : page.getViewport({ scale: s });

  // Kotak gambar di satu halaman PDF (koordinat halaman skala 1), dari daftar perintah gambar pdf.js
  async function kotakGambar(page){
    const ops = await page.getOperatorList(), O = lib.OPS;
    const IMG = new Set([O.paintImageXObject, O.paintJpegXObject, O.paintInlineImageXObject, O.paintImageXObjectRepeat].filter(x => x !== undefined));
    let ctm = [1, 0, 0, 1, 0, 0]; const stack = [], boxes = [];
    for (let i = 0; i < ops.fnArray.length; i++){
      const fn = ops.fnArray[i], a = ops.argsArray[i];
      if (fn === O.save) stack.push(ctm);
      else if (fn === O.restore) ctm = stack.pop() || ctm;
      else if (fn === O.transform) ctm = mul(ctm, a);
      else if (fn === O.paintFormXObjectBegin){ stack.push(ctm); if (a && Array.isArray(a[0]) && a[0].length === 6) ctm = mul(ctm, a[0]); }
      else if (fn === O.paintFormXObjectEnd) ctm = stack.pop() || ctm;
      else if (IMG.has(fn)){
        const pw = a && typeof a[1] === "number" ? a[1] : (a && a[0] && a[0].width) || 999, ph = a && typeof a[2] === "number" ? a[2] : (a && a[0] && a[0].height) || 999;
        if (pw * ph < 110 * 110) continue; // ikon kecil
        const pts = [[0, 0], [1, 0], [0, 1], [1, 1]].map(([x, y]) => [ctm[0] * x + ctm[2] * y + ctm[4], ctm[1] * x + ctm[3] * y + ctm[5]]);
        boxes.push({ x1: Math.min(...pts.map(p => p[0])), y1: Math.min(...pts.map(p => p[1])), x2: Math.max(...pts.map(p => p[0])), y2: Math.max(...pts.map(p => p[1])) });
      }
    }
    return boxes;
  }
  const gabung = (a, b) => ({ x1: Math.min(a.x1, b.x1), y1: Math.min(a.y1, b.y1), x2: Math.max(a.x2, b.x2), y2: Math.max(a.y2, b.y2) });
  const dekat = (a, b, pad) => !(a.x2 + pad < b.x1 || b.x2 + pad < a.x1 || a.y2 + pad < b.y1 || b.y2 + pad < a.y1);

  // PDF: gambar/diagram per halaman dipotong dari halamannya. opts: { url | data, maxPages, maxOut, minCover, maxCover }
  async function pdf(opts){
    if (!lib) throw new Error("pdf.js belum siap");
    const o = Object.assign({ maxPages: 80, maxOut: 12, minCover: 0.05, maxCover: 0.86 }, opts || {});
    const src = o.data ? { data: typeof o.data === "string" ? Uint8Array.from(atob(o.data), c => c.charCodeAt(0)) : o.data } : { url: o.url };
    const task = lib.getDocument(Object.assign(src, { disableFontFace: true, isEvalSupported: false }));
    const doc = await withTimeout(task.promise || task, 60000, "PDF terlalu lama dibuka");
    const hasil = [], hashes = [];
    try {
      const n = Math.min(doc.numPages, o.maxPages);
      for (let p = 1; p <= n && hasil.length < o.maxOut; p++){
        let page;
        try {
          page = await doc.getPage(p);
          const vp1 = viewport(page, 1), area = vp1.width * vp1.height;
          const raw = (await kotakGambar(page)).map(b => {
            const [x1, y1] = vp1.convertToViewportPoint(b.x1, b.y1), [x2, y2] = vp1.convertToViewportPoint(b.x2, b.y2);
            return { x1: Math.max(0, Math.min(x1, x2)), y1: Math.max(0, Math.min(y1, y2)), x2: Math.min(vp1.width, Math.max(x1, x2)), y2: Math.min(vp1.height, Math.max(y1, y2)) };
          }).filter(b => b.x2 - b.x1 > 30 && b.y2 - b.y1 > 30);
          if (!raw.length) continue;
          // Potongan gambar yang berdekatan (diagram yang tersusun dari beberapa gambar) digabung jadi satu
          let boxes = raw.slice();
          for (let changed = true; changed; ){ changed = false;
            for (let i = 0; i < boxes.length && !changed; i++) for (let j = i + 1; j < boxes.length; j++) if (dekat(boxes[i], boxes[j], 12)){ boxes[i] = gabung(boxes[i], boxes[j]); boxes.splice(j, 1); changed = true; break; } }
          boxes = boxes.map(b => Object.assign(b, { cover: (b.x2 - b.x1) * (b.y2 - b.y1) / area })).filter(b => b.cover >= o.minCover && b.cover <= o.maxCover).sort((a, b) => b.cover - a.cover).slice(0, 2);
          if (!boxes.length) continue;
          const tc = await page.getTextContent();
          const teks = tc.items.map(t => t.str).join(" ").replace(/\s+/g, " ").trim().slice(0, 700);
          for (const b of boxes){
            const bw = b.x2 - b.x1, bh = b.y2 - b.y1;
            const s = Math.max(1, Math.min(3, 1100 / Math.max(bw, bh)));
            const vp = viewport(page, s);
            if (vp.width * vp.height > 16e6) continue;
            const full = canvas(vp.width, vp.height), fx = full.getContext("2d");
            fx.fillStyle = "#fff"; fx.fillRect(0, 0, full.width, full.height);
            const rt = page.render({ canvasContext: fx, viewport: vp });
            await withTimeout(rt.promise || rt, 30000, "halaman PDF terlalu lama digambar");
            const pad = 6 * s, cx = Math.max(0, b.x1 * s - pad), cy = Math.max(0, b.y1 * s - pad);
            const cw = Math.min(full.width - cx, bw * s + pad * 2), ch = Math.min(full.height - cy, bh * s + pad * 2);
            const cut = canvas(cw, ch); cut.getContext("2d").drawImage(full, cx, cy, cw, ch, 0, 0, cw, ch);
            const r = out(cut, 0.8);
            if (r.sd < 7) continue; // polos/kosong
            if (hashes.some(h => beda(h, r.hash) <= 12)) continue; // sama dengan gambar sebelumnya (logo, latar)
            hashes.push(r.hash);
            hasil.push(Object.assign(r, { page: p, cover: Math.round(b.cover * 100) / 100, teks }));
            if (hasil.length >= o.maxOut) break;
          }
        } catch (e) { /* halaman ini dilewati */ }
        finally { if (page && page.cleanup) try { page.cleanup(); } catch (e) {} }
        if (p % 5 === 0) await wait(0);
      }
    } finally { try { doc.destroy(); } catch (e) {} }
    return hasil;
  }

  // Video: cuplikan di detik-detik tertentu (times) atau dibagi rata (sample = jumlah). Cuplikan gelap/polos dan yang mirip dibuang.
  async function frames(opts){
    const o = Object.assign({ times: [], sample: 0 }, opts || {});
    const v = document.createElement("video");
    v.muted = true; v.preload = "auto"; v.playsInline = true; v.crossOrigin = "anonymous"; v.src = o.url;
    await withTimeout(new Promise((ok, no) => { v.onloadedmetadata = ok; v.onerror = () => no(new Error("video tidak bisa dibuka (format tidak didukung)")); }), 30000, "video terlalu lama dibuka");
    const dur = isFinite(v.duration) ? v.duration : 0;
    let times = (o.times || []).map(Number).filter(t => t >= 0);
    if (!times.length && o.sample && dur) for (let i = 1; i <= o.sample; i++) times.push(dur * i / (o.sample + 1));
    const hasil = [], hashes = [];
    for (const t0 of times){
      if (dur && t0 > dur - 1){ hasil.push({ t: t0, skip: true }); continue; } // di luar panjang video (biasanya penutup)
      const t = Math.max(0.5, Math.min(dur ? dur - 0.5 : t0, t0));
      try {
        await withTimeout(new Promise((ok, no) => { v.onseeked = ok; v.onerror = () => no(new Error("gagal")); v.currentTime = t; }), 12000, "seek");
        await wait(80);
        const w = v.videoWidth, h = v.videoHeight; if (!w || !h){ hasil.push({ t: t0, skip: true }); continue; }
        const [cw, ch] = fit(w, h, MAX), c = canvas(cw, ch);
        c.getContext("2d").drawImage(v, 0, 0, cw, ch);
        const r = out(c, 0.8);
        if (r.sd < 9 || r.mean < 14){ hasil.push({ t: t0, skip: true }); continue; } // layar hitam / polos
        const dup = hashes.findIndex(h => beda(h, r.hash) <= 8);
        if (dup >= 0){ hasil.push({ t: t0, dup: dup }); continue; }
        hashes.push(r.hash);
        hasil.push(Object.assign(r, { t: t0, idx: hashes.length - 1 }));
      } catch (e) { hasil.push({ t: t0, skip: true }); }
    }
    v.removeAttribute("src"); try { v.load(); } catch (e) {}
    return { dur, frames: hasil };
  }

  const api = { setPdf: l => { lib = l; }, image, pdf, frames, stats: null };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.TKVis = api;
})(typeof window !== "undefined" ? window : this);
