// AI penyusun materi. Pilihan: Gemini (gratis), ChatGPT/OpenAI, Claude/Anthropic (API berbayar), Ollama (offline).
const PROVIDERS = {
  server:    { nama: "AI Teman Kuliah", needsKey: false, maxImg: 2, chars: 90000 },
  auto:      { nama: "AI otomatis", needsKey: false },
  gemini:    { nama: "Gemini",  needsKey: true },
  openai:    { nama: "ChatGPT", needsKey: true },
  anthropic: { nama: "Claude",  needsKey: true },
  ollama:    { nama: "Ollama",  needsKey: false },
  cerebras:  { nama: "Cerebras", needsKey: true, base: "https://api.cerebras.ai/v1", maxImg: 2, chars: 90000 },
  groq:      { nama: "Groq",     needsKey: true, base: "https://api.groq.com/openai/v1", maxImg: 3, chars: 18000 }
};
const COMPAT = p => p === "cerebras" || p === "groq" || p === "server"; // format API mirip OpenAI

// SERVER AI TEMAN KULIAH: pengguna tidak perlu API key. Server memegang key milik pembuat aplikasi
// dan membagi jatah harian per pengguna. Identitas dikirim sebagai kode acak (hash), bukan nama atau NIM.
const ID = { uid: "", device: "" };
function setIdentity(x){ Object.assign(ID, x || {}); }
function serverBase(cfg){
  const u = String((cfg && cfg.serverUrl) || require("./config").SERVER || "").trim().replace(/\/+$/, "");
  return (/^https:\/\//i.test(u) || /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/i.test(u)) && !/GANTI/.test(u) ? u : "";
}
const serverOn = cfg => !!serverBase(cfg);
const TASK = t => t === "chat" ? "chat" : t === "materi" || t === "video" ? "materi" : "lain";
function serverHeaders(task){
  const h = { "X-TK-App": "teman-kuliah", "X-TK-Device": ID.device || "", "X-TK-User": ID.uid || "" };
  if (task) h["X-TK-Task"] = TASK(task);
  return h;
}
async function serverError(r){
  const txt = await r.text().catch(() => ""); let j = null; try { j = JSON.parse(txt); } catch (e) {}
  const code = j && j.error && j.error.code, msg = (j && j.error && j.error.message) || txt || ("HTTP " + r.status);
  const e = new Error(code && /^tk_/.test(code) ? msg : "AI Teman Kuliah: " + String(msg).slice(0, 300)); e.status = r.status; e.raw = msg; e.code = code;
  if (code === "tk_quota"){ e.quota = true; e.busy = true; }
  if (code === "tk_busy" || code === "tk_nokey" || r.status >= 500 || r.status === 429) e.busy = true;
  return e;
}
async function serverQuota(cfg){
  const base = serverBase(cfg); if (!base) throw new Error("Server AI belum diatur.");
  let r; try { r = await fetch(base + "/v1/quota", { headers: serverHeaders(), signal: AbortSignal.timeout(15000) }); }
  catch (e) { throw e.name === "TimeoutError" ? new Error("Server AI tidak merespons. Cek koneksi internet.") : netError(e, "server AI Teman Kuliah"); }
  if (!r.ok) throw await serverError(r);
  return r.json();
}

// MODE OTOMATIS: aplikasi memilih AI sendiri per tugas dan langsung pindah kalau ada yang penuh
const AUTO_ORDER = {
  materi: ["cerebras", "gemini", "groq"],   // menyusun materi: Cerebras (kuota besar), Gemini, Groq
  video:  ["gemini", "cerebras", "groq"],   // ada video: Gemini bisa menonton langsung; lainnya lewat transkrip Whisper
  chat:   ["groq", "cerebras", "gemini"],   // Tanya AI: Groq paling cepat
  long:   ["cerebras", "gemini", "groq"]    // latihan soal, rangkuman, saran
};
const DEFAULT_MODEL = { gemini: "gemini-2.5-flash", cerebras: "gpt-oss-120b", groq: "openai/gpt-oss-120b" };
function autoList(cfg, task){
  const keys = cfg.keys || {};
  return (AUTO_ORDER[task] || AUTO_ORDER.long).filter(p => keys[p]).map(p => ({ provider: p, model: (cfg.model || {})[p] || ((cfg.models || {})[p] || {}).auto || DEFAULT_MODEL[p] }));
}
const canSwitch = e => !!(e && (e.busy || e.net || e.status === 429 || e.status === 413 || e.status >= 500 || /tidak merespons|berhenti mengirim|belum mulai menjawab/i.test(e.message || "")));
async function runAuto(cfg, task, fn, onProgress){
  const list = autoList(cfg, task);
  if (!list.length) throw new Error("Isi minimal satu API key di Pengaturan, bagian AI.");
  let last;
  for (let i = 0; i < list.length; i++){
    const L = list[i], c = { ...cfg, provider: L.provider, model: { ...(cfg.model || {}), [L.provider]: L.model }, quick: i < list.length - 1 };
    if (i > 0) onProgress && onProgress({ phase: "switch", chars: 0, model: PROVIDERS[L.provider].nama });
    try { return await fn(c, L); } catch (e) { last = e; if (!canSwitch(e)) throw e; }
  }
  if (last) last.busy = true; throw last;
}

// ATURAN RINGKASAN (DIKUNCI): berlaku untuk semua AI, tidak bisa diubah dari pengaturan.
const ATURAN_RINGKASAN = Object.freeze([
  "JANGAN TERLALU RINGKAS. Ini bukan ringkasan singkat, melainkan versi materi yang ditulis ulang supaya lebih mudah dipahami. Panjang hasil boleh menyamai atau melebihi materi aslinya.",
  "TETAP DETAIL, BAHASA LEBIH MUDAH. Pertahankan semua detail (definisi, tokoh/ahli, tahun, angka, contoh, daftar, urutan, rumus), lalu jelaskan dengan bahasa yang lebih sederhana daripada slide/PDF dosen. Istilah asing atau teknis dijelaskan artinya. Tambahkan contoh sehari-hari di field \"contoh\" bila membantu, dan tandai bahwa itu contoh penjelas.",
  "TIDAK BOLEH ADA YANG HILANG. Setiap slide, judul, subjudul, poin, definisi, tabel, gambar/diagram yang berisi teks, dan soal latihan di sumber wajib tercakup. Urutan mengikuti urutan materi dosen. Kalau ada bagian sumber yang kurang jelas atau terpotong, tetap tulis apa adanya dan beri catatan, jangan dilewati.",
  "FORMAT ENAK DIBACA. Pecah menjadi bagian-bagian dengan judul yang jelas (sebanyak yang dibutuhkan materi, tanpa batas). Paragraf pendek 2-4 kalimat. Gunakan daftar poin untuk hal yang berurutan atau sejajar, tabel untuk perbandingan, dan **tebal** untuk istilah kunci. Setiap bagian dibuka dengan 1-2 kalimat pengantar yang menjelaskan inti bagian itu."
]);

const SCHEMA_TEXT = `Balas HANYA dengan JSON valid (tanpa teks lain) berbentuk:
{
  "judul": "judul pertemuan",
  "ringkas": "3-5 kalimat gambaran besar materi (pengantar, bukan pengganti isi)",
  "bagian": [ { "h": "judul bagian", "p": "penjelasan (paragraf pendek, boleh beberapa paragraf dipisah baris baru)", "list": ["poin lengkap", "..."], "table": [["kolom1","kolom2"],["isi","isi"]], "contoh": "contoh penjelas sehari-hari (boleh kosong)", "note": "catatan dari dosen/sumber, misal soal latihan modul (boleh kosong)" } ],
  "istilah": [ ["istilah", "arti dengan bahasa sederhana"] ],
  "kuis": [ { "q": "pertanyaan", "o": ["A","B","C","D"], "a": 0, "e": "penjelasan jawaban" } ],
  "komentar": "draft komentar absensi"
}
Field list/table/contoh/note/p boleh dihilangkan kalau tidak perlu. "a" adalah indeks jawaban benar (0-3).`;

function buildPrompt({ course, meet, dosen, kampus, sourceNames, extraText, outline }){
  return `Kamu membantu mahasiswa kuliah ${kampus ? "di " + kampus : "online"} memahami materi dari dosen.
Mata kuliah: ${course}
Pertemuan: ${meet}
Dosen: ${dosen || "tidak diketahui"}
Sumber materi: ${sourceNames.join(", ")}

Tugasmu: tulis ulang materi ini dalam bahasa Indonesia supaya lebih mudah dipahami daripada materi aslinya.

ATURAN WAJIB (tidak boleh dilanggar):
${ATURAN_RINGKASAN.map((r, i) => `${i + 1}. ${r}`).join("\n")}

Aturan lain:
- Pakai HANYA informasi dari sumber. Jangan menambah fakta, angka, nama, atau tanggal yang tidak ada di sumber. Contoh penjelas boleh dibuat sendiri asal ditaruh di field "contoh".
- Jangan mengarang tugas, deadline, atau latihan. Soal/latihan yang memang ada di sumber ditulis lengkap di "note" dengan keterangan bahwa itu dari modul/slide dosen.
- Istilah: semua istilah penting di materi (minimal 6). Kuis: tepat 10 soal pilihan ganda (4 opsi) yang mencakup seluruh bagian materi, jawaban benar tersebar di A, B, C, dan D.
- Komentar absensi: 2 kalimat, diawali "Terima kasih Bapak/Ibu atas materinya." (pakai "Bapak" atau "Ibu" kalau jelas dari nama dosen), lalu satu kalimat kesimpulan isi materi. Untuk mata kuliah Bahasa Inggris, tulis dalam bahasa Inggris.
- Jangan pakai tanda em dash.
${outline && outline.length ? "\nDAFTAR TOPIK DI SUMBER (semuanya WAJIB tercakup):\n" + outline.map(o => "- " + o).join("\n") + "\n" : ""}
Sebelum menjawab, periksa ulang: apakah setiap topik, poin, dan detail di sumber sudah ada di hasilmu? Kalau belum, tambahkan.
${extraText ? "\nISI SUMBER (teks):\n" + extraText : ""}

${SCHEMA_TEXT}`;
}

// Daftar judul slide / subjudul dari teks sumber, dipakai sebagai daftar periksa kelengkapan.
function outlineOf(sources){
  const out = [];
  for (const s of sources){
    const t = s.text || "";
    const slides = t.split(/\[Slide \d+\]\n/).slice(1);
    if (slides.length){ slides.forEach(b => { const first = b.split("\n").map(x => x.trim()).find(x => x && x.length > 2); if (first) out.push(first.split(/(?<=[.:])\s/)[0].slice(0, 90)); }); continue; }
    t.split("\n").map(x => x.trim()).filter(x => x.length > 3 && x.length < 70 && /^([0-9]+(\.[0-9]+)*\.?\s+)?[A-Z]/.test(x) && !/[.,;:]$/.test(x) && x.split(" ").length <= 9).slice(0, 40).forEach(x => out.push(x));
  }
  return [...new Set(out)].slice(0, 80);
}

function clean(s){ return String(s ?? "").replace(/\s*—\s*/g, ", ").replace(/\s*–\s*/g, " - ").trim(); }

function normalize(raw){
  let j = raw;
  if (typeof raw === "string"){
    const t = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
    const a = t.indexOf("{"), b = t.lastIndexOf("}");
    if (a < 0 || b < 0) throw new Error("AI tidak mengirim format yang benar. Coba lagi.");
    j = JSON.parse(t.slice(a, b + 1));
  }
  const out = {
    judul: clean(j.judul || "Materi"),
    ringkas: clean(j.ringkas || ""),
    bagian: (Array.isArray(j.bagian) ? j.bagian : []).map(b => ({
      h: clean(b.h || ""), p: clean(b.p || ""),
      list: Array.isArray(b.list) ? b.list.map(clean).filter(Boolean) : [],
      table: Array.isArray(b.table) && b.table.length > 1 ? b.table.map(r => (Array.isArray(r) ? r : [r]).map(clean)) : null,
      contoh: clean(b.contoh || ""),
      note: clean(b.note || "")
    })).filter(b => b.h || b.p || b.list.length),
    istilah: (Array.isArray(j.istilah) ? j.istilah : []).map(x => Array.isArray(x) ? [clean(x[0]), clean(x[1])] : [clean(x.istilah || x.t || ""), clean(x.arti || x.d || "")]).filter(x => x[0]),
    kuis: (Array.isArray(j.kuis) ? j.kuis : []).map(q => ({ q: clean(q.q), o: (q.o || []).map(clean).slice(0, 4), a: Math.max(0, Math.min(3, Number(q.a) || 0)), e: clean(q.e || "") })).filter(q => q.q && q.o.length >= 2 && q.a < q.o.length),
    komentar: clean(j.komentar || "")
  };
  if (!out.ringkas && !out.bagian.length) throw new Error("AI tidak menghasilkan materi yang bisa dipakai.");
  return out;
}

// Pesan error jaringan yang bisa dimengerti (fetch Node hanya bilang "fetch failed").
function netError(e, label){
  if (e && e.name === "AbortError") return e;
  const code = (e && e.cause && (e.cause.code || (e.cause.errors && e.cause.errors[0] && e.cause.errors[0].code))) || (e && e.code) || "";
  let msg;
  if (label === "Ollama"){
    msg = /ECONNREFUSED|ECONNRESET|EHOSTUNREACH/.test(code) || !code
      ? "Ollama belum berjalan di laptop ini. Install dari ollama.com, buka aplikasinya sampai ikon llama muncul di pojok kanan bawah taskbar, lalu coba lagi."
      : "Tidak bisa terhubung ke Ollama (" + code + "). Cek alamatnya, biasanya http://127.0.0.1:11434";
  } else if (/ENOTFOUND|EAI_AGAIN|ETIMEDOUT|ECONNRESET|ENETUNREACH|UND_ERR_CONNECT_TIMEOUT/.test(code)){
    msg = "Tidak bisa terhubung ke " + label + ". Cek koneksi internet lalu coba lagi.";
  } else msg = "Koneksi ke " + label + " terputus" + (code ? " (" + code + ")" : "") + ". Coba lagi.";
  const err = new Error(msg); err.net = true; return err;
}
async function httpError(r, label){
  const txt = await r.text().catch(() => "");
  let msg = txt, code = ""; try { const j = JSON.parse(txt); msg = j.error?.message || j.error?.type || j.message || j.error || txt; code = String(j.error?.code || ""); } catch (e) {}
  if (/^tk_/.test(code)){ const e = new Error(String(msg)); e.status = r.status; e.raw = String(msg); e.code = code; e.busy = code !== "tk_app" && code !== "tk_bad"; e.quota = code === "tk_quota"; return e; } // pesan dari server Teman Kuliah sudah ramah
  msg = String(msg || r.statusText || r.status);
  if (r.status === 401 || r.status === 403) msg = "API key ditolak. Cek lagi key-nya. (" + msg + ")";
  else if (r.status === 429) msg = "Kuota atau batas pemakaian habis, atau permintaan terlalu cepat. Tunggu beberapa menit atau cek saldo. (" + msg + ")";
  else if (r.status === 503 || r.status === 529) msg = "Server " + label + " sedang sibuk. Coba lagi beberapa menit lagi. (" + msg + ")";
  else if (label === "Ollama" && r.status === 404) msg = "Model belum ada di Ollama. Jalankan di Command Prompt: ollama pull " + "qwen2.5:7b" + " (" + msg + ")";
  const err = new Error(`${label}: ${msg.slice(0, 320)}`); err.status = r.status; err.raw = msg;
  const rd = txt.match(/"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"/); if (rd) err.retryAfter = Math.ceil(Number(rd[1]));
  if (r.status === 429 && /PerDay|per_day|per day|daily/i.test(txt)) err.perDay = true; // kuota harian model ini habis, bukan sekadar sibuk
  return err;
}
async function http(url, opts, label, ms = 30000){
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms);
  let r;
  try { r = await fetch(url, { ...opts, signal: ac.signal }); }
  catch (e) { clearTimeout(t); if (e.name === "AbortError") throw new Error(label + " tidak merespons. Cek koneksi lalu coba lagi."); throw netError(e, label); }
  try {
    if (!r.ok) throw await httpError(r, label);
    return JSON.parse(await r.text());
  } finally { clearTimeout(t); }
}

// Streaming: hasil dikirim sedikit demi sedikit, jadi progres terlihat dan tidak kena batas waktu 5 menit.
// mode "sse" (Gemini/Claude/OpenAI) atau "ndjson" (Ollama). onEvent dipanggil per objek JSON.
async function stream(url, opts, label, mode, onEvent, { firstMs = 180000, idleMs = 90000, totalMs = 20 * 60000 } = {}){
  const ac = new AbortController();
  let why = "", got = false, idle;
  const arm = () => { clearTimeout(idle); idle = setTimeout(() => { why = got ? "idle" : "first"; ac.abort(); }, got ? idleMs : firstMs); };
  const total = setTimeout(() => { why = "total"; ac.abort(); }, totalMs);
  const fail = () => new Error(why === "total" ? label + " terlalu lama (lebih dari " + Math.round(totalMs / 60000) + " menit). Coba pecah materinya jadi lebih kecil atau pilih model lain."
    : why === "first" ? label + " belum mulai menjawab setelah " + Math.round(firstMs / 60000) + " menit. Coba lagi, atau pilih model lain di Pengaturan."
    : label + " berhenti mengirim jawaban di tengah jalan. Coba lagi.");
  arm();
  try {
    let r;
    try { r = await fetch(url, { ...opts, signal: ac.signal }); }
    catch (e) { if (e.name === "AbortError") throw fail(); throw netError(e, label); }
    if (!r.ok) throw await httpError(r, label);
    const reader = r.body.getReader(), dec = new TextDecoder();
    let buf = "";
    const handle = line => {
      line = line.trim(); if (!line) return;
      if (mode === "sse"){ if (!line.startsWith("data:")) return; line = line.slice(5).trim(); if (line === "[DONE]") return; }
      let j; try { j = JSON.parse(line); } catch (e) { return; }
      onEvent(j);
    };
    for (;;){
      let chunk;
      try { chunk = await reader.read(); }
      catch (e) { if (e.name === "AbortError" || why) throw fail(); throw netError(e, label); }
      if (chunk.done) break;
      got = true; arm();
      buf += dec.decode(chunk.value, { stream: true });
      let i; while ((i = buf.indexOf("\n")) >= 0){ handle(buf.slice(0, i)); buf = buf.slice(i + 1); }
    }
    handle(buf);
  } finally { clearTimeout(idle); clearTimeout(total); }
}
const retry = async fn => { try { return await fn(); } catch (e) { if (e.status === 429 || e.status === 500 || e.status === 502 || e.status === 503 || e.status === 529){ await new Promise(r => setTimeout(r, 5000)); return fn(); } throw e; } };
const ver = (n, re) => Number(String((n.match(re) || [0, "0"])[1]).replace("-", "."));
const ollamaBase = u => String(u || "http://127.0.0.1:11434").trim().replace(/\/+$/, "").replace(/\/api$/, "").replace(/^(?!https?:\/\/)/, "http://").replace("://localhost", "://127.0.0.1").replace("://0.0.0.0", "://127.0.0.1");

// Menutup JSON yang terpotong (misalnya karena batas panjang jawaban AI) supaya isinya tetap bisa dipakai.
function closeJSON(s){
  const st = []; let inStr = false, esc = false;
  for (const ch of s){
    if (inStr){ if (esc) esc = false; else if (ch === "\\") esc = true; else if (ch === '"') inStr = false; continue; }
    if (ch === '"') inStr = true; else if (ch === "{" || ch === "[") st.push(ch); else if (ch === "}" || ch === "]") st.pop();
  }
  let out = s; if (inStr) out += '"';
  out = out.replace(/[\s,]+$/, "").replace(/:\s*$/, ": null");
  return out + st.reverse().map(c => c === "{" ? "}" : "]").join("");
}
function repairJSON(t){
  let s = t.slice(t.indexOf("{"));
  for (let n = 0; n < 600 && s.length > 2; n++){
    try { return JSON.parse(closeJSON(s)); } catch (e) {}
    const cut = s.lastIndexOf(","); if (cut <= 0) break; s = s.slice(0, cut);
  }
  return null;
}

/* ---------- daftar model + pilihan otomatis ---------- */
async function listModels(cfg){
  const p = cfg.provider, key = (cfg.keys || {})[p];
  if (p === "gemini"){
    const j = await http("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", { headers: { "x-goog-api-key": key } }, "Gemini");
    return (j.models || []).filter(m => (m.supportedGenerationMethods || []).includes("generateContent")).map(m => m.name.replace(/^models\//, "")).filter(n => /^gemini/.test(n) && !/(image|tts|audio|live|embedding|learnlm)/.test(n));
  }
  if (p === "openai"){
    const j = await http("https://api.openai.com/v1/models", { headers: { Authorization: "Bearer " + key } }, "OpenAI");
    return (j.data || []).map(m => m.id).filter(id => /^(gpt-|o\d|chatgpt)/.test(id) && !/(audio|realtime|search|transcribe|tts|image|embedding|instruct|codex|moderation|-\d{4}-\d{2}-\d{2}$)/.test(id)).sort();
  }
  if (p === "anthropic"){
    const j = await http("https://api.anthropic.com/v1/models?limit=100", { headers: { "x-api-key": key, "anthropic-version": "2023-06-01" } }, "Claude");
    return (j.data || []).map(m => m.id);
  }
  if (COMPAT(p)){
    const j = await http(PROVIDERS[p].base + "/models", { headers: { Authorization: "Bearer " + key } }, PROVIDERS[p].nama);
    return (j.data || []).filter(m => m.active !== false).map(m => m.id).filter(id => !/(whisper|tts|orpheus|guard|embed|playai|distil|safeguard|compound)/i.test(id)).sort();
  }
  const j = await http(`${ollamaBase(cfg.ollamaUrl)}/api/tags`, {}, "Ollama", 8000);
  return (j.models || []).map(m => m.name).filter(n => !/embed/i.test(n));
}
// Otomatis: model menengah yang cerdas tapi hemat (Flash / Sonnet / GPT utama).
function autoPick(p, names){
  if (!names.length) return "";
  if (COMPAT(p)){
    // Utamakan model besar yang bisa membaca gambar (Qwen), lalu GPT-OSS 120B, lalu Llama besar
    const order = [/qwen.*(vl|3\.8|3\.5|vision)/i, /gpt-oss-120b/i, /qwen/i, /llama-3\.3-70b|llama-4/i, /70b|120b|235b/i];
    for (const re of order){ const m = names.find(n => re.test(n)); if (m) return m; }
    return names[0];
  }
  if (p === "gemini"){
    const ok = names.filter(n => /flash/.test(n) && !/(lite|exp|preview|thinking|8b)/.test(n));
    ok.sort((a, b) => ver(b, /gemini-(\d+(?:\.\d+)?)/) - ver(a, /gemini-(\d+(?:\.\d+)?)/) || a.length - b.length);
    return ok[0] || names.find(n => /flash/.test(n)) || names[0];
  }
  if (p === "anthropic"){
    const fam = f => names.filter(n => n.includes(f)).sort((a, b) => ver(b, /(\d+(?:[.-]\d)?)/) - ver(a, /(\d+(?:[.-]\d)?)/) || a.length - b.length)[0];
    return fam("sonnet") || fam("opus") || fam("haiku") || names[0];
  }
  if (p === "openai"){
    const main = names.filter(n => /^gpt-\d/.test(n) && !/(mini|nano|pro|turbo|chat-latest)/.test(n));
    main.sort((a, b) => ver(b, /^gpt-(\d+(?:\.\d+)?)/) - ver(a, /^gpt-(\d+(?:\.\d+)?)/) || a.length - b.length);
    return main[0] || names.find(n => /^gpt-4o$/.test(n)) || names[0];
  }
  return names[0];
}

/* ---------- pemanggilan per penyedia ---------- */
const geminiLimit = {};
// Model Gemini yang sedang "istirahat": kuota hariannya habis (sampai reset tengah malam waktu Pasifik, sekitar 14.00-15.00 WIB)
// atau baru saja penuh (jeda singkat). Model ini dilewati dulu supaya tidak buang waktu dan langsung ke model lain.
const geminiCool = {};
const nextPacificMidnight = () => { const d = new Date(); const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 8, 5)); if (t <= d) t.setUTCDate(t.getUTCDate() + 1); return t.getTime(); };
async function geminiMaxOut(key, model){
  if (geminiLimit[model]) return geminiLimit[model];
  try { const j = await http(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}`, { headers: { "x-goog-api-key": key } }, "Gemini", 15000); geminiLimit[model] = Math.min(Number(j.outputTokenLimit) || 8192, 65536); }
  catch (e) { geminiLimit[model] = 32768; }
  return geminiLimit[model];
}

async function geminiOnce(key, model, parts, json, add, fast){
  const maxOut = await geminiMaxOut(key, model);
  // Mode cepat untuk chat: kurangi "berpikir" model supaya jawaban mulai keluar dalam hitungan detik
  const think = fast ? (/2\.5-flash/.test(model) ? { thinkingBudget: 0 } : /gemini-3/.test(model) ? { thinkingLevel: "low" } : null) : null;
  const body = { contents: [{ role: "user", parts: parts.map(x => x.kind === "text" ? { text: x.text } : x.kind === "youtube" ? { file_data: { file_uri: x.url } } : x.kind === "filedata" ? { file_data: { file_uri: x.uri, mime_type: x.mime } } : { inline_data: { mime_type: x.kind === "pdf" ? "application/pdf" : x.mime, data: x.base64 } }) }],
    generationConfig: { temperature: fast ? 0.6 : 0.35, maxOutputTokens: maxOut, ...(json ? { responseMimeType: "application/json" } : {}), ...(think ? { thinkingConfig: think } : {}) } };
  let text = "", cut = false, block = "";
  await stream(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`,
    { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": key }, body: JSON.stringify(body) }, "Gemini", "sse", j => {
      if (j.error){ const e = new Error("Gemini: " + (j.error.message || "error")); e.status = j.error.code; e.raw = j.error.message; throw e; }
      const c = j.candidates && j.candidates[0];
      if (c){ (c.content && c.content.parts || []).forEach(x => { if (!x.thought && x.text){ text += x.text; add(x.text); } }); if (c.finishReason === "MAX_TOKENS") cut = true; if (/SAFETY|RECITATION|PROHIBITED|BLOCKLIST/.test(c.finishReason || "")) block = c.finishReason; }
      if (j.promptFeedback && j.promptFeedback.blockReason) block = j.promptFeedback.blockReason;
    });
  if (!text) throw new Error("Gemini tidak mengirim jawaban" + (block ? " (diblokir: " + block + "). Coba sumber lain atau AI lain." : ". Coba lagi."));
  return { text, cut };
}
// Urutan cadangan: model Flash lain yang stabil, lalu Flash-Lite. Pro tidak dipakai (kuota gratisnya kecil dan lambat).
function geminiFallbacks(cfg, current){
  const list = ((cfg.models || {}).gemini || {}).list || [];
  const ok = n => /flash/.test(n) && !/(exp|thinking|8b|image|tts|live|audio)/.test(n) && n !== current;
  const v = n => ver(n, /gemini-(\d+(?:\.\d+)?)/);
  const base = ["gemini-flash-latest", "gemini-2.5-flash", "gemini-flash-lite-latest", "gemini-2.5-flash-lite", "gemini-2.0-flash", "gemini-2.0-flash-lite"];
  const pool = (list.length ? list : base).filter(ok);
  const rank = n => (/preview/.test(n) ? 2 : 0) + (/lite/.test(n) ? 1 : 0);
  return [...new Set(pool.sort((a, b) => rank(a) - rank(b) || v(b) - v(a) || a.length - b.length))].slice(0, 6);
}

// Video berukuran besar diunggah dulu lewat Gemini Files API, lalu dipakai sebagai file_data
async function geminiUpload(key, file, mime, onProgress){
  const fs = require("fs"), size = fs.statSync(file).size;
  const start = await fetch("https://generativelanguage.googleapis.com/upload/v1beta/files", { method: "POST", headers: { "x-goog-api-key": key, "X-Goog-Upload-Protocol": "resumable", "X-Goog-Upload-Command": "start", "X-Goog-Upload-Header-Content-Length": String(size), "X-Goog-Upload-Header-Content-Type": mime, "Content-Type": "application/json" }, body: JSON.stringify({ file: { display_name: require("path").basename(file) } }) }).catch(e => { throw netError(e, "Gemini"); });
  if (!start.ok) throw await httpError(start, "Gemini");
  const url = start.headers.get("x-goog-upload-url"); if (!url) throw new Error("Gemini tidak memberi alamat unggah video.");
  onProgress && onProgress({ phase: "upload", chars: 0 });
  const up = await fetch(url, { method: "POST", headers: { "Content-Length": String(size), "X-Goog-Upload-Offset": "0", "X-Goog-Upload-Command": "upload, finalize" }, body: fs.readFileSync(file) }).catch(e => { throw netError(e, "Gemini"); });
  if (!up.ok) throw await httpError(up, "Gemini");
  let f = (await up.json()).file || {};
  for (let i = 0; i < 90 && f.state === "PROCESSING"; i++){ await new Promise(r => setTimeout(r, 4000)); f = await http(`https://generativelanguage.googleapis.com/v1beta/${f.name}`, { headers: { "x-goog-api-key": key } }, "Gemini", 20000); }
  if (f.state && f.state !== "ACTIVE") throw new Error("Gemini gagal memproses video (" + f.state + ").");
  return { uri: f.uri, mime: f.mimeType || mime };
}

// Cerebras / Groq: format OpenAI. Gambar dibatasi; kalau model menolak gambar atau JSON mode, dicoba ulang tanpa itu.
async function compatGenerate(p, key, model, parts, json, add, onProgress, cfg){
  const P = PROVIDERS[p];
  const build = (withImg, withJson) => {
    const imgs = withImg ? parts.filter(x => x.kind === "image").slice(0, P.maxImg) : [];
    const content = [...parts.filter(x => x.kind === "text").map(x => ({ type: "text", text: x.text })), ...imgs.map(x => ({ type: "image_url", image_url: { url: `data:${x.mime};base64,${x.base64}` } }))];
    return { model: isServer ? "auto" : model, stream: true, messages: [{ role: "user", content: imgs.length ? content : content.map(c => c.text).join("\n\n") }], temperature: cfg.fast ? 0.6 : 0.35, ...(withJson ? { response_format: { type: "json_object" } } : {}) };
  };
  let text = "", cut = false;
  const isServer = p === "server";
  const url = (isServer ? serverBase(cfg) + "/v1" : P.base) + "/chat/completions";
  const headers = isServer ? { "Content-Type": "application/json", ...serverHeaders(cfg.task || (cfg.fast ? "chat" : "lain")) } : { "Content-Type": "application/json", Authorization: "Bearer " + key };
  const once = body => stream(url, { method: "POST", headers, body: JSON.stringify(body) }, P.nama, "sse", j => {
    if (j.error){ const e = new Error(P.nama + ": " + (j.error.message || "error")); e.raw = j.error.message; throw e; }
    const c = j.choices && j.choices[0]; if (!c) return;
    const d = c.delta && c.delta.content; if (d){ text += d; add(d); } if (c.finish_reason === "length") cut = true;
  });
  let withImg = parts.some(x => x.kind === "image"), withJson = !!json;
  for (let attempt = 0; attempt < 4; attempt++){
    try { text = ""; await once(build(withImg, withJson)); return { text, cut, model }; }
    catch (e) {
      const raw = String(e.raw || e.message || "");
      if (isServer && /^tk_/.test(e.code || "")) throw e;
      if (withImg && e.status === 400 && /image|vision|multimodal|content type/i.test(raw)){ withImg = false; continue; }
      if (withJson && e.status === 400 && /response_format|json/i.test(raw)){ withJson = false; continue; }
      if (e.status === 413 || /too large|tokens per minute|TPM|context length|maximum context/i.test(raw)){ const x = new Error(P.nama + ": materinya terlalu panjang untuk kuota gratis per menit. Coba AI lain atau bagi file menjadi beberapa bagian."); x.status = 413; x.busy = true; x.raw = raw; throw x; }
      if (e.status === 429 || e.status === 503 || e.status === 500){
        if (attempt < 2 && !cfg.quick && !isServer){ const wait = Math.min(45, e.retryAfter || (attempt ? 20 : 8)); onProgress && onProgress({ phase: "retry", chars: 0, until: Date.now() + wait * 1000, round: attempt + 2, of: 3 }); await new Promise(r => setTimeout(r, wait * 1000)); continue; }
        e.busy = true;
      }
      throw e;
    }
  }
  throw new Error(P.nama + " tidak berhasil menjawab. Coba lagi.");
}

// Transkrip video dengan Whisper lewat Groq (gratis). url: link publik (tanpa batas 25 MB), atau file lokal maks 25 MB.
// key kosong = lewat server AI Teman Kuliah (pengguna tidak perlu API key Groq)
async function whisper(key, { url, file, name }, cfg){
  const fs = require("fs");
  const fd = new FormData();
  fd.append("model", "whisper-large-v3-turbo"); fd.append("response_format", "text"); fd.append("language", "id");
  if (url) fd.append("url", url);
  else {
    const size = fs.statSync(file).size; if (size > 25 * 1024 * 1024) throw new Error("Video lebih dari 25 MB, terlalu besar untuk Whisper gratis.");
    fd.append("file", new Blob([fs.readFileSync(file)]), name || require("path").basename(file));
  }
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), 15 * 60000);
  const viaServer = !key, base = viaServer && serverBase(cfg);
  if (viaServer && !base) throw new Error("Isi API key Groq di Pengaturan supaya video bisa ditranskrip.");
  let r; try { r = await fetch(viaServer ? base + "/v1/audio/transcriptions" : "https://api.groq.com/openai/v1/audio/transcriptions", { method: "POST", headers: viaServer ? serverHeaders("video") : { Authorization: "Bearer " + key }, body: fd, signal: ac.signal }); }
  catch (e) { clearTimeout(t); if (e.name === "AbortError") throw new Error("Whisper terlalu lama mentranskrip video."); throw netError(e, "Groq"); }
  clearTimeout(t);
  if (!r.ok) throw await httpError(r, viaServer ? "Server AI" : "Groq Whisper");
  const txt = (await r.text()).trim(); if (!txt) throw new Error("Whisper tidak menemukan suara di video ini.");
  return txt;
}

// parts: [{kind:"text", text} | {kind:"pdf", base64, name} | {kind:"image", mime, base64} | {kind:"youtube", url}]
// onProgress({ phase: "wait"|"write", chars }) dipanggil selama AI bekerja.
// Hasil: { text, cut } (cut = jawaban terpotong karena batas panjang).
async function generate(cfg, parts, json, onProgress, onDelta){
  if (cfg.provider === "server"){
    // Pembagian tugas: Tanya AI lewat server Teman Kuliah (Groq, cepat) dulu; ringkas materi, latihan,
    // dan rangkuman memakai API key milik pengguna (Gemini) dulu. Yang satu jadi cadangan yang lain.
    const task = cfg.task || (cfg.fast ? "chat" : "long");
    const own = autoList(cfg, task).length > 0, srv = serverOn(cfg);
    const viaServer = () => generate({ ...cfg, provider: "server-direct" }, parts, json, onProgress, onDelta);
    const viaOwn = () => generate({ ...cfg, provider: "auto" }, parts, json, onProgress, onDelta);
    const first = (task === "chat" && srv) || !own ? (srv ? viaServer : viaOwn) : viaOwn;
    const second = first === viaServer ? (own ? viaOwn : null) : (srv ? viaServer : null);
    try { return await first(); }
    catch (e) {
      if (!second || !canSwitch(e)) throw e;
      onProgress && onProgress({ phase: "switch", chars: 0, model: second === viaOwn ? "API key milikmu" : "AI Teman Kuliah" });
      return second();
    }
  }
  if (cfg.provider === "server-direct"){
    let text = "";
    const add = t => { if (!t) return; text += t; onProgress && onProgress({ phase: "write", chars: text.length }); onDelta && onDelta(t); };
    onProgress && onProgress({ phase: "wait", chars: 0 });
    return compatGenerate("server", "", "auto", parts, json, add, onProgress, cfg);
  }
  if (cfg.provider === "auto") return runAuto(cfg, cfg.task || (cfg.fast ? "chat" : "long"), c => generate(c, parts, json, onProgress, onDelta), onProgress);
  const p = cfg.provider, key = (cfg.keys || {})[p], model = (cfg.model || {})[p] || "";
  if (!PROVIDERS[p]) throw new Error("Pilih AI dulu di Pengaturan.");
  if (PROVIDERS[p].needsKey && !key) throw new Error(`Isi dulu API key ${PROVIDERS[p].nama} di Pengaturan.`);
  if (!model) throw new Error(`Pilih model ${PROVIDERS[p].nama} dulu: buka Pengaturan lalu klik Simpan & sambungkan.`);
  let text = "", cut = false;
  const add = t => { if (!t) return; text += t; onProgress && onProgress({ phase: "write", chars: text.length }); onDelta && onDelta(t); };
  onProgress && onProgress({ phase: "wait", chars: 0 });

  if (p === "gemini"){
    // Model Gemini gratis sering penuh ("high demand") atau kuota per model habis.
    // Coba model pilihan dulu, lalu pindah otomatis ke model Gemini lain.
    // "Sibuk" termasuk server penuh, kuota, koneksi putus, dan jawaban yang tidak kunjung datang: semuanya dicoba dengan model lain
    const busy = e => e && (e.status === 503 || e.status === 429 || e.status === 500 || e.status === 502 || e.status === 504 || e.net || /high demand|overloaded|unavailable|resource.?exhausted|quota|rate limit|try again|tidak merespons|berhenti mengirim|belum mulai menjawab|tidak mengirim jawaban\. Coba lagi/i.test(e.raw || e.message || ""));
    const all = [...new Set([model, ...geminiFallbacks(cfg, model)])];
    const fresh = all.filter(m => !(geminiCool[m] > Date.now()));
    const tries = fresh.length ? fresh : all; // semua sedang istirahat: tetap dicoba daripada langsung gagal
    // Chat cukup 2 putaran singkat; menyusun materi lebih sabar (3 putaran dengan jeda makin lama)
    const rounds = cfg.quick ? 1 : cfg.fast ? 2 : 3, pauses = cfg.fast ? [6] : [12, 30];
    let lastErr = null, slow = 0;
    for (let round = 0; round < rounds; round++){
      let wantWait = 0;
      for (let i = 0; i < tries.length; i++){
        const m = tries[i];
        if (round > 0 || i > 0) onProgress && onProgress({ phase: "switch", chars: 0, model: m });
        try {
          text = ""; let r;
          try { r = await geminiOnce(key, m, parts, json, add, cfg.fast); }
          catch (e0) { if (cfg.fast && e0.status === 400 && /think/i.test(e0.raw || e0.message || "")) r = await geminiOnce(key, m, parts, json, add, false); else throw e0; }
          return { text: r.text, cut: r.cut, model: m };
        } catch (e) {
          lastErr = e;
          if (e.status === 404 || (e.status === 400 && /not found|not supported|unsupported/i.test(e.raw || ""))) continue; // model tidak tersedia: coba berikutnya
          if (!busy(e)) throw e;
          geminiCool[m] = e.perDay ? nextPacificMidnight() : Date.now() + (e.status === 429 ? 120000 : 60000);
          // Dua kali tidak ada jawaban sama sekali: Gemini sedang macet, jangan menunggu menit demi menit di semua model; masuk antrean saja
          if (/tidak merespons|berhenti mengirim|belum mulai menjawab/i.test(e.message || "") && ++slow >= 2){ const x = new Error("Gemini sedang lambat sekali dan belum menjawab. Materi dicoba lagi otomatis nanti."); x.busy = true; x.status = 503; throw x; }
          if (e.retryAfter) wantWait = Math.max(wantWait, e.retryAfter);
        }
      }
      if (round < rounds - 1){
        const wait = Math.min(60, Math.max(pauses[round] || 20, wantWait));
        onProgress && onProgress({ phase: "retry", chars: 0, until: Date.now() + wait * 1000, round: round + 2, of: rounds });
        await new Promise(r => setTimeout(r, wait * 1000));
      }
    }
    const err = new Error("Server Gemini sedang penuh untuk akun gratis. Sudah dicoba beberapa kali dengan model lain." + (lastErr ? " (" + String(lastErr.raw || lastErr.message).slice(0, 100) + ")" : ""));
    err.status = lastErr && lastErr.status; err.busy = true; throw err;
  }
  if (p === "anthropic"){
    const content = parts.filter(x => x.kind !== "youtube").map(x => x.kind === "text" ? { type: "text", text: x.text } : x.kind === "pdf" ? { type: "document", source: { type: "base64", media_type: "application/pdf", data: x.base64 } } : { type: "image", source: { type: "base64", media_type: x.mime, data: x.base64 } });
    const go = maxTok => retry(() => { text = ""; return stream("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "Content-Type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model, max_tokens: maxTok, stream: true, messages: [{ role: "user", content }] }) }, "Claude", "sse", j => {
        if (j.type === "error") throw new Error("Claude: " + ((j.error && j.error.message) || "error"));
        if (j.type === "content_block_delta" && j.delta && j.delta.type === "text_delta") add(j.delta.text);
        if (j.type === "message_delta" && j.delta && j.delta.stop_reason === "max_tokens") cut = true;
      }); });
    try { await go(32000); }
    catch (e) { const raw = String(e.raw || ""), m = e.status === 400 && /max_tokens/i.test(raw) && (raw.match(/>\s*(\d{3,6})/) || raw.match(/(\d{3,6})\s*(?:\)|$|for|tokens)/)); if (!m) throw e; await go(Number(m[1])); }
    return { text, cut };
  }
  if (p === "openai"){
    const content = parts.filter(x => x.kind !== "youtube").map(x => x.kind === "text" ? { type: "text", text: x.text } : x.kind === "pdf" ? { type: "file", file: { filename: x.name || "materi.pdf", file_data: "data:application/pdf;base64," + x.base64 } } : { type: "image_url", image_url: { url: `data:${x.mime};base64,${x.base64}` } });
    await retry(() => { text = ""; return stream("https://api.openai.com/v1/chat/completions", { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + key },
      body: JSON.stringify({ model, stream: true, messages: [{ role: "user", content }], ...(json ? { response_format: { type: "json_object" } } : {}) }) }, "ChatGPT", "sse", j => {
        if (j.error) throw new Error("ChatGPT: " + (j.error.message || "error"));
        const c = j.choices && j.choices[0]; if (!c) return;
        add(c.delta && c.delta.content); if (c.finish_reason === "length") cut = true;
      }); });
    return { text, cut };
  }
  if (COMPAT(p)) return compatGenerate(p, key, model, parts, json, add, onProgress, cfg);
  // ollama: teks saja. Konteks disesuaikan panjang materi supaya hemat RAM.
  const prompt = parts.filter(x => x.kind === "text").map(x => x.text).join("\n\n");
  const need = Math.ceil(prompt.length / 3.2) + 8192, ctx = Math.min(32768, Math.max(8192, Math.ceil(need / 4096) * 4096));
  await stream(`${ollamaBase(cfg.ollamaUrl)}/api/chat`, { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, messages: [{ role: "user", content: prompt }], stream: true, ...(json ? { format: "json" } : {}), options: { temperature: 0.35, num_ctx: ctx, num_predict: -1 } }) }, "Ollama", "ndjson", j => {
      if (j.error) throw new Error("Ollama: " + j.error);
      add(j.message && j.message.content); if (j.done && j.done_reason === "length") cut = true;
    }, { firstMs: 10 * 60000, idleMs: 3 * 60000, totalMs: 45 * 60000 });
  return { text, cut };
}

/* ---------- API publik ---------- */
async function test(cfg){
  const p = cfg.provider;
  if (p === "server"){ const q = await serverQuota(cfg); return { models: [], auto: "", pick: "AI Teman Kuliah", quota: q }; }
  if (p === "auto"){ const ok = ["cerebras", "groq", "gemini"].filter(x => (cfg.keys || {})[x]); if (!ok.length) throw new Error("Isi minimal satu API key dulu."); return { models: [], auto: "", pick: ok.map(x => PROVIDERS[x].nama).join(", ") }; }
  if (PROVIDERS[p].needsKey && !(cfg.keys || {})[p]) throw new Error(`Isi dulu API key ${PROVIDERS[p].nama}.`);
  const models = await listModels(cfg);
  if (!models.length) throw new Error(p === "ollama" ? "Ollama jalan, tapi belum ada model. Jalankan: ollama pull qwen2.5:7b" : "Tidak ada model yang bisa dipakai di akun ini.");
  const cur = (cfg.model || {})[p];
  return { models, auto: autoPick(p, models), pick: cur && models.includes(cur) ? cur : autoPick(p, models) };
}

// sources: [{ name, text, inline?, images?, youtube? }]
async function makeMateri(cfg, info, sources, onProgress){
  const p = cfg.provider === "server-direct" ? "server" : cfg.provider, names = sources.map(s => s.name);
  const parts = []; let textBlock = "";
  let budget = 18 * 1024 * 1024;
  const fits = b64 => { if (p === "ollama" || b64.length > budget) return false; budget -= b64.length; return true; };
  const pdfOk = p === "gemini" || p === "openai" || p === "anthropic"; // server, Cerebras, Groq membaca PDF lewat teks hasil ekstraksi // Cerebras/Groq membaca PDF lewat teks hasil ekstraksi
  for (const s of sources){
    if (s.youtube){ if (p === "gemini") parts.push({ kind: "youtube", url: s.youtube }); continue; }
    if (s.video){
      if (p !== "gemini") continue;
      const size = require("fs").statSync(s.video.path).size;
      const b64len = Math.ceil(size * 4 / 3);
      if (size <= 14 * 1024 * 1024 && b64len <= budget){ budget -= b64len; parts.push({ kind: "media", mime: s.video.mime, base64: require("fs").readFileSync(s.video.path).toString("base64") }); }
      else { const f = await geminiUpload(cfg.keys.gemini, s.video.path, s.video.mime, onProgress); parts.push({ kind: "filedata", uri: f.uri, mime: f.mime }); }
      continue;
    }
    const useInline = s.inline && (pdfOk || s.inline.mime !== "application/pdf") && fits(s.inline.base64);
    if (useInline) parts.push(s.inline.mime === "application/pdf" ? { kind: "pdf", base64: s.inline.base64, name: s.name } : { kind: "image", mime: s.inline.mime, base64: s.inline.base64 });
    if (!useInline && s.text) textBlock += `=== ${s.name} ===\n${s.text}\n\n`;
    if (!useInline && s.images) for (const im of s.images) if (fits(im.base64)) parts.push({ kind: "image", mime: im.mime, base64: im.base64 });
  }
  if (!parts.length && !textBlock.trim()) throw new Error("Tidak ada isi yang bisa dibaca dari sumber ini.");
  const limit = p === "ollama" ? 45000 : p === "gemini" ? 400000 : COMPAT(p) ? PROVIDERS[p].chars : 250000;
  parts.unshift({ kind: "text", text: buildPrompt({ ...info, sourceNames: names, extraText: textBlock.slice(0, limit), outline: outlineOf(sources) }) });
  const r = await generate({ ...cfg, task: cfg.task || (sources.some(s => /^Transkrip video/.test(s.name)) ? "video" : "materi") }, parts, true, onProgress);
  let m;
  try { m = normalize(r.text); }
  catch (e) {
    const fixed = repairJSON(r.text);
    if (!fixed) throw new Error(r.cut ? "Jawaban AI terpotong karena materinya sangat panjang. Coba bagi file menjadi beberapa bagian, atau pakai AI lain." : "AI tidak mengirim format yang benar. Coba lagi.");
    m = normalize(fixed); r.cut = true;
  }
  if (r.cut) m.terpotong = true;
  return m;
}

const TUTOR = `Kamu "Teman Kuliah", tutor kuliah yang hangat, sabar, dan sangat jelas untuk mahasiswa S1 kuliah online di Indonesia.
Cara menjawab:
- Bahasa Indonesia yang santai tapi rapi. Langsung ke inti. Jangan membuka dengan basa-basi seperti "Pertanyaan yang menarik" atau "Halo".
- Tulis dalam Markdown yang rapi: **tebal** untuk istilah kunci, daftar poin atau bernomor untuk langkah dan perbandingan, ### judul kecil hanya kalau jawabannya panjang, tabel kalau membandingkan beberapa hal.
- Jelaskan dengan contoh sehari-hari yang dekat dengan kehidupan mahasiswa.
- Dasarkan jawaban pada MATERI. Kalau pertanyaannya di luar materi, tetap bantu, dan sebutkan dalam satu kalimat pendek bahwa itu di luar materi dosen.
- Panjang menyesuaikan pertanyaan: pertanyaan singkat dijawab singkat (2 sampai 5 kalimat); permintaan menjelaskan, membandingkan, atau merangkum boleh lebih panjang dan terstruktur.
- Kalau diminta soal latihan, beri soalnya dulu lalu tunggu jawaban mahasiswa, jangan langsung beri kunci.
- Jangan pakai tanda em dash.`;

// Chat tutor: jawaban dikirim sedikit demi sedikit lewat onDelta
async function chat(cfg, context, history, question, onDelta){
  const conv = (history || []).slice(-12).map(h => (h.role === "user" ? "MAHASISWA: " : "KAMU: ") + h.text).join("\n\n");
  const prompt = `${TUTOR}\n\nMATERI:\n${String(context || "(belum ada materi)").slice(0, 80000)}\n\n${conv ? "PERCAKAPAN SEBELUMNYA:\n" + conv + "\n\n" : ""}MAHASISWA: ${question}\n\nKAMU:`;
  try { const r = await generate({ ...cfg, fast: true }, [{ kind: "text", text: prompt }], false, null, onDelta); return clean(r.text); }
  catch (e) {
    const alt = e.busy && cfg.provider !== "auto" && backupFor(cfg, "chat"); if (!alt) throw e;
    const r = await generate({ ...cfg, provider: alt.provider, model: { ...(cfg.model || {}), [alt.provider]: alt.model }, fast: true }, [{ kind: "text", text: prompt.slice(0, alt.provider === "groq" ? 20000 : 90000) }], false, null, onDelta);
    return clean(r.text);
  }
}

// Cadangan otomatis kalau AI utama penuh: Cerebras dulu untuk materi (kuota besar), Groq dulu untuk chat (paling cepat)
function backupFor(cfg, use){
  const keys = cfg.keys || {}, order = use === "chat" ? ["groq", "cerebras"] : ["cerebras", "groq"];
  for (const p of order){ if (p !== cfg.provider && keys[p]){ const ml = (cfg.models || {})[p]; const model = (cfg.model || {})[p] || (ml && ml.auto) || (p === "cerebras" ? "gpt-oss-120b" : "openai/gpt-oss-120b"); return { provider: p, model }; } }
  return null;
}

const jsonOf = t => { try { return JSON.parse(String(t).trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim().replace(/^[^{]*/, "").replace(/[^}]*$/, "")); } catch (e) { return repairJSON(t); } };

// PANDU TUGAS: memecah tugas dosen jadi langkah-langkah, lalu membimbing mahasiswa satu langkah demi satu langkah.
const PEMBIMBING = `Kamu "Teman Kuliah", pembimbing tugas kuliah yang sabar untuk mahasiswa S1 kuliah online di Indonesia, termasuk yang masih pemula.
Cara membimbing:
- Bahas HANYA langkah yang sedang aktif. Jangan loncat ke langkah lain kecuali ditanya.
- JANGAN menuliskan tugasnya untuk mahasiswa (misalnya menulis seluruh proposal, esai, atau jawaban jadi). Bantu dengan menjelaskan, memberi contoh kecil, memberi pilihan, dan bertanya balik supaya mahasiswa berpikir dan menulis sendiri. Kalau diminta menuliskan semuanya, tolak dengan ramah dan tawarkan kerangka atau contoh satu kalimat.
- Bahasa Indonesia sehari-hari yang sederhana, hindari istilah teknis; kalau terpaksa, jelaskan artinya.
- Jawaban pendek: paling banyak sekitar 150 kata. Pakai Markdown seperlunya (**tebal**, daftar poin, tabel kecil untuk membandingkan).
- Akhiri dengan SATU pertanyaan atau tugas kecil yang jelas untuk mahasiswa.
- Kalau dari percakapan langkah aktif sudah tercapai, beri tahu dan sarankan klik tombol "Tandai langkah selesai".
- Dasarkan semua pada instruksi dosen. Kalau instruksi tidak jelas, katakan dan sarankan bertanya ke dosen.
- Jangan pakai tanda em dash.`;
function panduKonteks(p){
  const L = (p.langkah || []).map((x, i) => `${i + 1}. ${x.judul}${x.done ? " (selesai)" : i === p.aktif ? " (SEDANG DIKERJAKAN)" : ""}`).join("\n");
  return `TUGAS: ${p.judul}\nMATA KULIAH: ${p.matkul || "-"}\nTENGGAT: ${p.tenggat || "-"}\nINTINYA: ${p.intinya || "-"}\n\nINSTRUKSI DOSEN:\n${String(p.instruksi || "(tidak ada)").slice(0, 40000)}\n\nLANGKAH:\n${L}`;
}
async function panduRencana(cfg, info, onProgress){
  const prompt = `${PEMBIMBING}

Baca tugas berikut, lalu susun rencana bimbingan.
TUGAS: ${info.judul}
MATA KULIAH: ${info.matkul || "-"}
TENGGAT: ${info.tenggat || "-"}

INSTRUKSI DOSEN:
${String(info.instruksi || "(instruksi tidak tersedia, gunakan judul tugas)").slice(0, 60000)}

Balas HANYA dengan JSON valid berbentuk:
{
  "intinya": "1 kalimat inti tugas dengan bahasa sehari-hari; tandai 2-5 kata terpenting dengan **...**",
  "diminta": "1-2 kalimat: apa yang harus dikerjakan",
  "hasil": "1-2 kalimat: apa yang dikumpulkan di akhir",
  "tidakPerlu": "1 kalimat hal yang tidak perlu dikhawatirkan (boleh kosong)",
  "langkah": [ { "judul": "maksimal 6 kata", "ket": "maksimal 10 kata" } ],
  "pembuka": "pesan bimbingan pertama untuk langkah 1, maksimal 120 kata, diakhiri satu pertanyaan"
}
Aturan langkah: 4 sampai 7 langkah, berurutan dari awal sampai mengumpulkan. Langkah 1 selalu "Pahami tugasnya". Langkah terakhir selalu cek akhir dan mengumpulkan. Sesuaikan langkah lain dengan isi tugas (misalnya diskusi kelompok kalau tugas kelompok).`;
  const r = await generate({ ...cfg, task: "lain" }, [{ kind: "text", text: prompt }], true, onProgress);
  const j = jsonOf(r.text);
  if (!j || !Array.isArray(j.langkah) || !j.langkah.length) throw new Error("AI tidak mengirim rencana yang benar. Coba lagi.");
  return {
    intinya: clean(j.intinya || ""), diminta: clean(j.diminta || ""), hasil: clean(j.hasil || ""), tidakPerlu: clean(j.tidakPerlu || ""),
    langkah: j.langkah.slice(0, 8).map(x => ({ judul: clean(x.judul || x.title || "Langkah"), ket: clean(x.ket || ""), done: false })),
    pembuka: clean(j.pembuka || "Yuk mulai dari memahami tugasnya. Bagian mana yang paling membingungkan buatmu?")
  };
}
async function panduChat(cfg, p, history, msg, mulai, onDelta){
  const conv = (history || []).slice(-14).map(h => (h.role === "user" ? "MAHASISWA: " : "KAMU: ") + h.text).join("\n\n");
  const semua = (p.langkah || []).every(x => x.done);
  const aktif = (p.langkah || [])[p.aktif];
  const perintah = mulai
    ? (semua ? "Semua langkah sudah selesai. Beri selamat singkat, lalu berikan ceklis akhir 3-5 poin sebelum tugas dikumpulkan, sesuai instruksi dosen."
             : `Mahasiswa baru masuk ke langkah ${p.aktif + 1}: "${aktif ? aktif.judul : ""}". Buka langkah ini: jelaskan tujuannya dalam 1-2 kalimat sederhana, beri arahan singkat, lalu ajukan satu pertanyaan atau tugas kecil.`)
    : `MAHASISWA: ${msg}\n\nKAMU:`;
  const prompt = `${PEMBIMBING}\n\n${panduKonteks(p)}\n\n${conv ? "PERCAKAPAN SEBELUMNYA:\n" + conv + "\n\n" : ""}${perintah}`;
  const r = await generate({ ...cfg, fast: true, task: "lain" }, [{ kind: "text", text: prompt }], false, null, onDelta);
  return clean(r.text);
}

// Latihan soal: pilihan ganda + essay dari materi yang sudah diringkas
async function makeLatihan(cfg, info, text, opt, onProgress){
  const prompt = `Kamu dosen pembuat soal ujian untuk mata kuliah ${info.course} (${info.cakupan}).
Buat latihan dari MATERI berikut, dalam bahasa Indonesia:
- Tepat ${opt.pg} soal pilihan ganda (4 opsi). Sebar merata ke semua pertemuan dan topik. Tingkat: sekitar 40% mudah (ingatan), 40% sedang (pemahaman), 20% sulit (penerapan dan analisis kasus).
- Jawaban benar tersebar acak di A, B, C, dan D. Jangan pakai opsi "semua benar" atau "semua salah". Opsi pengecoh harus masuk akal.
- Tepat ${opt.essay} soal essay yang menguji pemahaman dan penerapan. Untuk tiap essay tulis kunci jawaban berupa poin-poin yang harus ada.
- Setiap soal diberi "topik" singkat (2 sampai 5 kata) dan "p" nomor pertemuan asalnya.
- Pakai HANYA informasi dari materi. Jangan pakai tanda em dash.
Balas HANYA JSON: {"pg":[{"q":"...","o":["A","B","C","D"],"a":0,"e":"penjelasan singkat kenapa benar","topik":"...","p":1}],"essay":[{"q":"...","kunci":["poin 1","poin 2"],"topik":"...","p":1}]}

MATERI:
${String(text).slice(0, 300000)}`;
  const r = await generate(cfg, [{ kind: "text", text: prompt }], true, onProgress);
  const j = jsonOf(r.text) || {};
  const pg = (Array.isArray(j.pg) ? j.pg : []).map(q => ({ q: clean(q.q), o: (q.o || []).map(clean).slice(0, 4), a: Math.max(0, Math.min(3, Number(q.a) || 0)), e: clean(q.e || ""), topik: clean(q.topik || ""), p: Number(q.p) || null })).filter(q => q.q && q.o.length === 4);
  const essay = (Array.isArray(j.essay) ? j.essay : []).map(q => ({ q: clean(q.q), kunci: (Array.isArray(q.kunci) ? q.kunci : [q.kunci]).filter(Boolean).map(clean), topik: clean(q.topik || ""), p: Number(q.p) || null })).filter(q => q.q);
  if (!pg.length && !essay.length) throw new Error("AI tidak berhasil membuat soal. Coba lagi.");
  return { pg, essay };
}

// Menilai jawaban essay dengan kunci jawaban
async function gradeEssay(cfg, items, onProgress){
  const prompt = `Kamu dosen yang menilai jawaban essay mahasiswa secara adil dan membangun. Untuk setiap soal, bandingkan jawaban dengan kunci (poin yang harus ada). Nilai 0 sampai 100 berdasarkan seberapa lengkap dan benar poin-poinnya tercakup; parafrase yang benar tetap dihitung. Jawaban kosong bernilai 0.
Tulis "umpan" (1 sampai 2 kalimat, sapa dengan "kamu") tentang yang sudah bagus, dan "kurang" (poin penting yang belum ada, boleh kosong). Bahasa Indonesia, tanpa em dash.
Balas HANYA JSON: {"hasil":[{"skor":80,"umpan":"...","kurang":"..."}]} dengan urutan sama seperti soal.

${items.map((x, i) => `SOAL ${i + 1}: ${x.q}\nKUNCI: ${(x.kunci || []).join("; ")}\nJAWABAN MAHASISWA: ${x.jawaban || "(kosong)"}`).join("\n\n")}`;
  const r = await generate(cfg, [{ kind: "text", text: prompt }], true, onProgress);
  const j = jsonOf(r.text) || {};
  return items.map((x, i) => { const h = (j.hasil || [])[i] || {}; return { skor: Math.max(0, Math.min(100, Math.round(Number(h.skor) || 0))), umpan: clean(h.umpan || ""), kurang: clean(h.kurang || "") }; });
}

// Rangkuman padat untuk belajar menjelang ujian (Markdown)
async function rangkumanUjian(cfg, info, text, onProgress){
  const prompt = `Kamu membantu mahasiswa belajar untuk ${info.jenis} mata kuliah ${info.course}. Dari MATERI pertemuan ${info.cakupan} berikut, buat rangkuman belajar yang padat tapi tidak ada topik yang hilang.
Format Markdown:
### untuk setiap pertemuan (judul pertemuan), lalu poin-poin inti dengan **istilah kunci** ditebalkan, definisi penting, tokoh, angka, dan perbandingan dalam tabel kalau perlu.
Tutup dengan ### Yang paling mungkin keluar di ujian: 5 sampai 8 poin.
Bahasa Indonesia yang mudah dipahami, tanpa em dash, tanpa basa-basi pembuka.

MATERI:
${String(text).slice(0, 300000)}`;
  const r = await generate(cfg, [{ kind: "text", text: prompt }], false, onProgress);
  return clean(r.text);
}

// Saran belajar dari hasil kuis dan latihan (Markdown)
async function saranBelajar(cfg, stats, onProgress){
  const prompt = `Kamu pembimbing akademik yang suportif. Berikut ringkasan hasil belajar seorang mahasiswa semester ini (skor kuis per materi, latihan soal, dan topik yang sering salah).
Tulis evaluasi dalam Markdown, bahasa Indonesia santai tapi serius, tanpa em dash:
### Gambaran umum (2 sampai 3 kalimat)
### Yang sudah kuat
### Yang perlu diperbaiki (sebut mata kuliah dan topik spesifik)
### Rencana 2 minggu ke depan (langkah konkret per hari atau per minggu, termasuk materi mana yang dibaca ulang dan latihan apa)
Jangan mengarang angka yang tidak ada di data.

DATA:
${stats}`;
  const r = await generate(cfg, [{ kind: "text", text: prompt }], false, onProgress);
  return clean(r.text);
}

async function ask(cfg, question, context){
  const prompt = `Kamu tutor kuliah yang sabar untuk mahasiswa S1 (kuliah online). Jawab dalam bahasa Indonesia yang santai tapi jelas, maksimal 180 kata, pakai contoh sehari-hari. Jangan pakai tanda em dash. Dasarkan jawaban pada materi berikut; kalau pertanyaannya di luar materi, tetap bantu tapi sebutkan bahwa itu di luar materi dosen.\n\nMATERI:\n${context}\n\nPERTANYAAN: ${question}`;
  return clean((await generate(cfg, [{ kind: "text", text: prompt }], false)).text);
}

// Komentar absensi: beberapa pilihan baru yang berbeda dari komentar sebelumnya
async function komentarVariasi(cfg, info, materiTxt, sebelumnya){
  const inggris = /bahasa inggris|english/i.test(info.course || "");
  const sapaan = /\b(ibu|bu|hj|dra|ny)\b\.?/i.test(info.dosen || "") ? "Ibu" : /\b(bapak|pak|h\.|drs)\b/i.test(info.dosen || "") ? "Bapak" : "Bapak/Ibu";
  const prompt = `Tulis 3 pilihan komentar absensi untuk post materi dosen di LMS kuliah online.
Mata kuliah: ${info.course}. Pertemuan: ${info.meet}. Dosen: ${info.dosen || "tidak diketahui"}.
Aturan:
- Singkat: 2 kalimat, paling banyak 3. Sopan, wajar seperti ditulis mahasiswa sendiri, tidak kaku dan tidak lebay.
- Kalimat pertama berterima kasih kepada dosen atas materinya (pakai sapaan "${inggris ? "Sir/Ma'am" : sapaan}").
- Kalimat berikutnya menyebut satu hal spesifik yang dipelajari dari MATERI (konsep, istilah, atau contoh yang benar-benar ada di materi).
- Ketiga pilihan harus berbeda: sudut pandang, poin materi, dan susunan kalimatnya tidak boleh sama, dan tidak boleh mirip dengan komentar sebelumnya.
- ${inggris ? "Tulis dalam bahasa Inggris." : "Tulis dalam bahasa Indonesia."} Jangan pakai emoji, tagar, atau tanda em dash.
${(sebelumnya || []).length ? "\nKOMENTAR SEBELUMNYA (jangan diulang):\n" + sebelumnya.slice(-6).map(x => "- " + x).join("\n") + "\n" : ""}
MATERI:
${String(materiTxt || "").slice(0, 12000)}

Balas HANYA dengan JSON: {"pilihan": ["komentar 1", "komentar 2", "komentar 3"]}`;
  const r = await generate({ ...cfg, fast: true, task: "chat" }, [{ kind: "text", text: prompt }], true);
  const j = jsonOf(r.text);
  const list = (j && Array.isArray(j.pilihan) ? j.pilihan : Array.isArray(j) ? j : []).map(x => clean(String(x || ""))).filter(x => x.length > 10).slice(0, 3);
  if (!list.length) throw new Error("AI tidak mengirim komentar. Coba lagi.");
  return list;
}

module.exports = { panduRencana, panduChat, komentarVariasi, setIdentity, serverOn, serverBase, serverQuota, autoList, runAuto, canSwitch, whisper, backupFor, COMPAT, chat, makeLatihan, gradeEssay, rangkumanUjian, saranBelajar, geminiFallbacks, repairJSON, ollamaBase, generate, PROVIDERS, ATURAN_RINGKASAN, test, makeMateri, ask, normalize, autoPick, buildPrompt, outlineOf };
