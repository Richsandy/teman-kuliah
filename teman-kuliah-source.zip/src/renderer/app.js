(function(){
"use strict";
const api = window.api;
const $ = (s, el=document) => el.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const rich = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");

/* ---------- icons ---------- */
const svg = p => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const I = {
  home: svg('<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M10 21v-6h4v6"/>'),
  cal: svg('<rect x="3" y="4.5" width="18" height="16.5" rx="3"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/><path d="m8.5 15 2 2 4-4"/>'),
  book: svg('<path d="M4 4.5A1.5 1.5 0 0 1 5.5 3H11v17H5.5A1.5 1.5 0 0 0 4 21.5z"/><path d="M20 4.5A1.5 1.5 0 0 0 18.5 3H13v17h5.5a1.5 1.5 0 0 1 1.5 1.5z"/>'),
  todo: svg('<path d="m4 6.5 1.8 1.8L9 5"/><path d="m4 13.5 1.8 1.8L9 12"/><path d="M12.5 7h8M12.5 14h8M12.5 20h8M5 20h3"/>'),
  gear: svg('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
  left: svg('<path d="m15 18-6-6 6-6"/>'), right: svg('<path d="m9 18 6-6-6-6"/>'),
  trash: svg('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'),
  copy: svg('<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>'),
  help: svg('<circle cx="12" cy="12" r="9"/><path d="M9.6 9.2a2.5 2.5 0 0 1 4.8.9c0 1.7-2.4 2.2-2.4 3.6"/><path d="M12 17h.01"/>'),
  plus: svg('<path d="M12 5v14M5 12h14"/>'),
  spark: svg('<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6.3 6.3l2.5 2.5M15.2 15.2l2.5 2.5M6.3 17.7l2.5-2.5M15.2 8.8l2.5-2.5"/>'),
  bell: svg('<path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2.2 2.2 0 0 0 4 0"/>'),
  exam: svg('<path d="M9 3.5h6l.8 2H19v15.5H5V5.5h3.2z"/><path d="m9 13.5 2 2 4-4"/>'),
  sun: svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'),
  moon: svg('<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>'),
  speaker: svg('<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18.2 6.5a7.5 7.5 0 0 1 0 11"/>'),
  share: svg('<path d="M12 3.5v11M7.5 8 12 3.5 16.5 8"/><path d="M5 12.5V19a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 19v-6.5"/>'),
  peta: svg('<circle cx="12" cy="12" r="2.6"/><circle cx="4.5" cy="6" r="1.8"/><circle cx="19.5" cy="6" r="1.8"/><circle cx="5" cy="18.5" r="1.8"/><circle cx="19" cy="18.5" r="1.8"/><path d="m6 7 4 3.3M18 7l-4 3.3M6.4 17.3l3.6-3.4M17.6 17.3 14 13.9"/>'),
  chat: svg('<path d="M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v9a1.5 1.5 0 0 1-1.5 1.5H10l-4.5 4v-4h0A1.5 1.5 0 0 1 4 14.5z"/><path d="M8 9h8M8 12h5"/>')
};
const CHEV = '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>';

/* ---------- dates ---------- */
const HARI = ["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
const BULAN = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
const BULAN_L = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
const DAY = 864e5;
const parseD = s => { const [y,m,d] = String(s).slice(0,10).split("-").map(Number); return new Date(y, m-1, d); };
const ymd = d => d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
const today = () => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate()); };
const fmtShort = d => d.getDate()+" "+BULAN[d.getMonth()];

/* ---------- state ---------- */
let S = null;
const UI = { view: "beranda", week: null, course: null, meet: null, tab: "ringkasan", todoFilter: "aktif", confirmDel: null, quiz: {}, flip: {}, exam: null, ask: {}, status: {}, aiTest: null, plan: null };
const VIEWS = [["beranda","Beranda",I.home],["jadwal","Jadwal",I.cal],["materi","Materi",I.book],["ujian","Ujian",I.exam],["tanya","Tanya AI",I.chat],["todo","To-do",I.todo],["pengaturan","Pengaturan",I.gear]];

const sem = () => S && S.current && S.semesters[S.current];
const courses = () => { const s = sem(); return s ? Object.values(s.courses) : []; };
const geser = () => Number(S.settings.geserHari) || 0;
const courseDay = c => { const i = HARI.indexOf(c.hariKRS); return i < 0 ? "" : HARI[(i + geser()) % 7]; };
const dayIdx = c => { const i = HARI.indexOf(courseDay(c)); return i < 0 ? 9 : (i + 6) % 7; }; // Senin = 0
const sorted = () => courses().sort((a,b) => dayIdx(a) - dayIdx(b) || String(a.jam).localeCompare(String(b.jam)));
const findCourse = id => courses().find(c => c.id === id);
const materi = (cid, n) => { const s = sem(); return s && s.materi[cid + "_" + n]; };
const pKey = (cid, n) => `${S.current}_${cid}_p${n}`;
const getP = (cid, n) => S.progress[pKey(cid, n)] || {};
// Kalau tanggal mulai semester belum diketahui (LMS belum mengirim jadwal), anggap minggu ini pertemuan 1
const semStart = () => { const m = sem() && sem().mulai; if (m) return parseD(m); const t = today(); return new Date(t.getTime() - ((t.getDay() + 6) % 7) * DAY); };
const weekStart = w => new Date(semStart().getTime() + (w-1)*7*DAY);
const rawWeek = d => Math.floor((d - semStart())/DAY/7) + 1;
const weekOf = d => Math.min(16, Math.max(1, rawWeek(d)));
const tugasOf = (c, w) => (c.tugas && c.tugas[w]) || [];
const lampOf = (c, w) => (c.lampiran && c.lampiran[w]) || [];
const lampBaru = (c, w) => { const m = materi(c.id, w), done = new Set((m && m.lampiranIds) || []); return lampOf(c, w).filter(f => !done.has(f.id)); };
const inQueue = (c, w) => (S.antrean || []).some(x => x.cid === c.id && Number(x.meet) === Number(w));
const lampBtn = (c, w, cls = "btn sm") => { const b = lampBaru(c, w); if(!b.length) return ""; const busy = UI.lampBusy === c.id + "_" + w; if (!busy && inQueue(c, w)) return `<button class="${cls}" data-lamp="${c.id}|${w}" title="Server AI sedang penuh. Dicoba lagi otomatis bertahap (5, 10, 20 menit), atau klik untuk coba sekarang.">Dalam antrean, coba sekarang</button>`; return `<button class="${cls}" data-lamp="${c.id}|${w}" ${busy?"disabled":""} title="${esc(b.map(f=>f.name).join(", "))}">${busy ? "Sedang diringkas…" : materi(c.id, w) ? "Ringkas file baru dari dosen" : `Ringkas file dosen (${b.length})`}</button>`; };
const absenOf = (c, w) => (c.absen && c.absen[w]) || null;
const tugasLabel = t => /^(tugas|kuis|quiz|ujian)\b/i.test(t.judul || "") ? t.judul : t.jenis + ": " + t.judul;
// Cara kampus menghitung kehadiran: "komentar" | "keaktifan" | "tidak" | null (belum dipilih)
const absMode = () => S.settings.absensiMode || (S.settings.absensiKomentar === true ? "komentar" : S.settings.absensiKomentar === false ? "tidak" : null);
const absOn = () => absMode() === "komentar"; // template komentar, ceklis, to-do, dan pengingat komentar hanya untuk kampus yang absensinya lewat komentar
const hadirOf = (c, w) => (c.hadir && c.hadir[w]) || null;
const kelOf = c => c.kelompok || { tugas: {}, info: [], semua: [] };
const pctTxt = v => v == null ? null : Math.max(0, Math.min(100, v)) + "%";
// Indikator kehadiran: status resmi dari dosen, atau "menunggu ACC" plus aktivitasmu yang langsung tercatat di SES
function hadirLine(c, w, full){
  const h = hadirOf(c, w); if (!h) return "";
  const s = h.ses || {}, sesi = (c.sesi || {})[w];
  const mulai = sesi && sesi.start ? new Date(String(sesi.start).replace(" ", "T")) : null;
  const ST = { H: ["ok", "Hadir"], I: ["mid", "Izin"], S: ["mid", "Sakit"], A: ["bad", "Tidak hadir"] };
  const a = absOn() ? absenOf(c, w) : null;
  const bits = [];
  if (a && a.total) bits.push(`komentar ${a.done}/${a.total}`); else if (s.komentar != null && s.nKomentar) bits.push(`komentar ${s.nKomentar}`);
  if (s.lihat != null) bits.push(`materi dibuka ${pctTxt(s.lihat)}`);
  if (s.video != null) bits.push(`video ${pctTxt(s.video)}`);
  if (s.skor != null && full) bits.push(`skor SES ${s.skor}`);
  let cls, label, sub = "";
  if (h.st && ST[h.st]){ [cls, label] = ST[h.st]; label += full ? ", sudah dikonfirmasi dosen" : ""; }
  else if (mulai && mulai > new Date() && !s.interaksi && !s.nKomentar) return full ? `<div class="hadir"><span class="pill">Pertemuan belum dimulai</span></div>` : "";
  else {
    cls = "wait"; label = "Menunggu ACC dosen";
    const kurang = [];
    if (a && a.total && a.done < a.total) kurang.push(`${a.total - a.done} komentar`);
    if (s.lihat != null && s.lihat < 100) kurang.push("buka semua materi");
    if (s.video != null && s.video < 90) kurang.push("tonton video sampai habis");
    sub = kurang.length ? "Supaya aman: " + kurang.join(", ") + "." : (bits.length ? "Aktivitasmu sudah lengkap, tinggal dikonfirmasi dosen." : "");
  }
  return `<div class="hadir ${full ? "full" : ""}"><span class="pill ${cls}">${label}</span>${bits.length ? `<span class="act">${bits.join(", ")}</span>` : ""}${sub ? `<small>${sub}</small>` : ""}</div>`;
}
// Tugas kelompok minggu ini (dan kelompokmu kalau sudah dibagi di LMS)
function kelLine(c, w){
  const k = kelOf(c), ts = (k.tugas || {})[w] || [];
  if (!ts.length) return "";
  return `<div class="kel"><span class="pill kel">Tugas kelompok</span>${ts.map(t => `<a href="#" data-open-url="${esc(t.link)}">${esc(t.judul)}</a>`).join("")}${k.tim ? `<small>${esc(k.tim.nama)}: ${k.tim.anggota.map(x => esc(x.me ? "kamu" : x.nama)).join(", ")}</small>` : k.adaTim ? `<small>Kelompok sudah dibagi di LMS. Buka mata kuliah untuk melihat daftarnya.</small>` : `<small>Pembagian kelompok belum ada di LMS.</small>`}</div>`;
}
const ready = () => linked() && !!S.settings.setupDone; // Beranda baru terbuka setelah LMS tersambung dan AI diatur
const linked = () => !!(S && S.lms.connected && sem() && courses().length);
const openTodos = () => Object.entries(S.todos).filter(([,t]) => !t.done);
const initials = c => (c.singkat || c.nama).replace(/[^A-Za-z ]/g,"").split(" ").filter(Boolean).slice(0,2).map(w=>w[0]).join("").toUpperCase();
const icon = c => `<span class="icon" aria-hidden="true">${initials(c)}</span>`;

function weekStats(w){
  let done = 0, total = 0; const per = {}, tot = {};
  courses().forEach(c => { const p = getP(c.id, w), t = tugasOf(c, w).length > 0; const k = absOn(), n = (p.belajar?1:0)+(k&&p.komentar?1:0)+(t&&p.tugas?1:0); per[c.id] = n; tot[c.id] = 1+(k?1:0)+(t?1:0); done += n; total += tot[c.id]; });
  return { done, total, per, tot };
}
const allDone = (c, w) => { const p = getP(c.id, w); return !!(p.belajar && (!absOn() || p.komentar) && (!tugasOf(c, w).length || p.tugas)); };
function dueInfo(due){
  if(!due) return {txt:"", cls:""};
  const diff = Math.round((parseD(due) - today())/DAY);
  if(diff < 0) return {txt:"lewat "+(-diff)+" hari", cls:"late"};
  if(diff === 0) return {txt:"hari ini", cls:"soon"};
  if(diff === 1) return {txt:"besok", cls:"soon"};
  return {txt: fmtShort(parseD(due)), cls: diff <= 3 ? "soon" : ""};
}
const sortTodos = arr => arr.sort((a,b) => (a[1].done - b[1].done) || String(a[1].due||"9999").localeCompare(String(b[1].due||"9999")) || String(b[1].createdAt||"").localeCompare(String(a[1].createdAt||"")));
function toast(msg){ const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(t._h); t._h = setTimeout(()=>t.classList.remove("show"), 2600); }

/* ---------- shared pieces ---------- */
function renderNav(){
  const n = openTodos().length;
  const cur = UI.view === "pandu" ? "todo" : UI.view === "rencana" ? "beranda" : UI.view === "peta" ? "materi" : UI.view;
  const btn = (id,label,ic,mobile) => `<button data-go="${id}" ${cur===id?'aria-current="page"':''}>${mobile?ic:""}<span>${label}</span>${id==="todo"&&n?`<span class="n">${n}</span>`:""}</button>`;
  const vs = !S.settings.welcomed ? [] : ready() ? VIEWS : VIEWS.filter(([id]) => id === "beranda" || id === "pengaturan");
  $("#nav").innerHTML = vs.map(([id,l,ic]) => id === "pengaturan" ? `<button data-go="pengaturan" class="icon-only" aria-label="Pengaturan" title="Pengaturan" ${UI.view===id?'aria-current="page"':''}>${ic}</button>` : btn(id,l,ic,true)).join("");
  $("#tabbar").innerHTML = vs.map(([id,l,ic]) => btn(id,l,ic,true)).join("");
  const sync = $("#sync"), running = UI.status.sync === "running";
  sync.classList.toggle("on", !!S.lms.connected && !S.lms.lastError);
  sync.lastElementChild.textContent = running ? "Menyinkron LMS…" : S.lms.connected ? (S.lms.lastError ? "Sinkron gagal" : "Sinkron " + ago(S.lms.lastSync)) : "LMS belum terhubung";
  $("#syncbtn").hidden = !S.lms.connected || running;
  const gb = $("#guidebtn"); if (gb && !gb.innerHTML.trim()) gb.innerHTML = I.help;
  const tb = $("#themebtn"); if (tb){ const t = S.settings.theme || "auto", dark = t === "dark" || (t === "auto" && matchMedia("(prefers-color-scheme: dark)").matches); tb.innerHTML = dark ? I.sun : I.moon; tb.title = dark ? "Pakai tema terang" : "Pakai tema gelap"; }
}
function ago(iso){ if(!iso) return "belum pernah"; const m = Math.round((Date.now() - new Date(iso))/60000); return m < 1 ? "barusan" : m < 60 ? m+" mnt lalu" : m < 1440 ? Math.round(m/60)+" jam lalu" : Math.round(m/1440)+" hari lalu"; }

function checks(c, w){
  const p = getP(c.id, w);
  const row = (f, label) => `<label class="chk"><input type="checkbox" data-p="${c.id}|${w}|${f}" ${p[f]?"checked":""}><span>${label}</span></label>`;
  return row("belajar","Pelajari materi") + (absOn() ? row("komentar","Komentar absensi") : "") + (tugasOf(c, w).length ? row("tugas", esc(tugasLabel(tugasOf(c,w)[0]))) : "");
}
function absenLine(c, w){
  const a = absenOf(c, w); if(!a || !absOn()) return "";
  if(a.done === a.total) return `<div class="absen"><span class="all">Semua ${a.total} post dosen sudah kamu komentari</span></div>`;
  return `<div class="absen"><span>Komentar ${a.done} dari ${a.total} post</span>${a.belum.map(b=>`<a href="#" data-open-url="${esc(b.link)}">Belum: ${esc(b.judul)}</a>`).join("")}</div>`;
}

/* ---------- halaman selamat datang ---------- */
const host = u => { try { return new URL(u).host; } catch(e){ return u || ""; } };
const kampusHost = () => host(S.settings.kampus && S.settings.kampus.url) || "LMS kampus";
const PEMBUAT = "Nicky Richsandy Pramana";
function viewHello(){
  return `<section class="hello">
    <div class="hello-mark" aria-hidden="true"><img src="logo.svg" alt=""></div>
    <h1>Teman Kuliah</h1>
    <p class="hello-tag">Jadwal, absensi, tugas, dan materi kuliah online dalam satu aplikasi. Tersambung langsung dengan LMS kampus yang memakai Edlink.</p>
    <div class="hello-feats">
      <div class="card hf"><span class="ic">${I.cal}</span><b>Tahu hari ini harus apa</b><span>Kelas, to-do, kuis, dan vicon tersinkron otomatis dari LMS setiap 30 menit.</span></div>
      <div class="card hf"><span class="ic">${I.chat}</span><b>Absensi tidak kelewat</b><span>Kelihatan post dosen mana yang belum kamu komentari, lengkap dengan draft komentarnya.</span></div>
      <div class="card hf"><span class="ic">${I.book}</span><b>Materi lebih mudah dipahami</b><span>File dosen ditulis ulang oleh AI jadi materi yang tetap detail, plus istilah dan kuis latihan.</span></div>
    </div>
    <div class="card hello-ai">
      <h2>AI-nya gratis</h2>
      <div class="rows">
        ${S.serverOn ? `<div class="r"><b>Gemini milikmu</b><span>Meringkas materi, membaca slide bergambar, menonton video kuliah, dan membuat latihan soal. Cukup tempel API key gratis dari akun Google sekali.</span></div>
        <div class="r"><b>Tanya AI</b><span>Disediakan Teman Kuliah, tanpa API key, dengan jatah harian yang terisi lagi setiap jam 00.00 WIB.</span></div>
        <div class="r"><b>Video dosen</b><span>Video kuliah dan link YouTube dari dosen ditonton Gemini lalu diringkas, lengkap dengan poin pentingnya.</span></div>
        <div class="r"><b>Antrean otomatis</b><span>Kalau AI sedang penuh, materi masuk antrean dan diringkas otomatis begitu bisa lagi.</span></div>`
        : `<div class="r"><b>Cerebras</b><span>Menyusun materi, latihan soal, dan rangkuman. Model open source di cloud dengan kuota gratis besar.</span></div>
        <div class="r"><b>Groq</b><span>Menjawab Tanya AI paling cepat dan mentranskrip video dengan Whisper.</span></div>
        <div class="r"><b>Gemini</b><span>Opsional. Menonton video YouTube dan membaca slide bergambar langsung.</span></div>
        <div class="r"><b>Lainnya</b><span>ChatGPT dan Claude (berbayar) atau Ollama (offline) juga bisa dipilih di Pengaturan.</span></div>`}
      </div>
      ${S.serverOn ? "" : `<p class="cap">Cukup tempel API key gratisnya sekali. Kalau satu AI sedang penuh, tugasnya langsung dikerjakan AI lain, jadi tidak perlu antre.</p>`}
    </div>
    <button class="btn dark big" data-act="hello">Mulai</button>
    <p class="hello-by">Dibuat oleh <b>${PEMBUAT}</b>. Butuh bantuan? <button class="link" data-act="guide">Baca panduan</button></p>
  </section>`;
}
function kampusPicker(){
  const k = S.settings.kampus || {}, custom = UI.customLms || (k.url && !/(^|\.)edlink\.id$/i.test(host(k.url)));
  return custom
    ? `<div class="inline"><input id="kampus-url" value="${esc(k.url && !/edlink\.id$/i.test(host(k.url)) ? host(k.url) : "")}" placeholder="Alamat LMS kampusmu, misalnya kuliah.unsia.ac.id" aria-label="Alamat web LMS" spellcheck="false" style="height:40px;border:0;border-radius:14px;background:var(--card-2);padding:0 14px;min-width:300px;flex:1;max-width:460px"></div>
       <p class="cap">Isi kalau kampusmu memakai alamat Edlink sendiri. <button class="link" data-act="lms-default">Pakai Edlink biasa</button></p>`
    : `<p class="cap">Login dengan akun Edlink-mu: Google, Siakad, atau email dan password. <button class="link" data-act="lms-custom">Kampusku punya alamat LMS sendiri</button></p>`;
}

/* ---------- onboarding ---------- */
function viewWelcome(){
  if(!S.settings.welcomed) return viewHello();
  const lmsOk = S.lms.connected, aiOk = aiReady();
  return `<div class="welcome">
    <div><h1 class="large">Siapkan Teman Kuliah</h1><p class="lede">Tiga langkah singkat, lalu jadwal, materi, dan tugas kuliahmu tersusun otomatis.</p></div>
    <div class="steps">
      <section class="card step ${lmsOk?"done":""}"><span class="no">1</span><div class="txt"><h3>Hubungkan Edlink</h3><p class="sub">Login lewat halaman resmi Edlink di jendela aplikasi. Password tidak pernah dilihat atau disimpan aplikasi. Jadwal dan mata kuliahmu muncul setelah ini.</p>${lmsOk ? "" : kampusPicker()}
        <div>${lmsOk ? `<span class="ok-t">Terhubung sebagai ${esc(S.lms.me && S.lms.me.name)}${UI.status.sync==="running"?". Mengambil jadwal dan mata kuliah…":""}</span>` : `<button class="btn dark" data-act="login">Masuk ke Edlink</button>`}</div>${S.lms.lastError?`<p class="err-t">${esc(S.lms.lastError)}</p>`:""}</div></section>
      <section class="card step ${aiOk?"done":""}"><span class="no">2</span><div class="txt">${S.serverOn && S.settings.ai.provider === "server" ? `<h3>Sambungkan Gemini</h3><p class="sub">Tempel API key Gemini gratis milikmu, cukup sekali. Gemini meringkas materi, menonton video kuliah, dan membuat latihan soal. Tanya AI sudah disediakan Teman Kuliah.</p>` : `<h3>Sambungkan AI</h3><p class="sub">Tempel API key gratis, minimal satu. Cerebras dan Groq paling disarankan. Setelah itu aplikasi memilih AI sendiri untuk tiap tugas.</p>`}
        ${aiForm(false)}</div></section>
      <section class="card step ${absMode() ? "done" : ""}"><span class="no">3</span><div class="txt"><h3>Sesuaikan kuliahmu</h3>${absenToggle()}<p class="sub" style="margin-top:8px">Kalau jadwal kuliahmu tidak sama dengan hari di KRS, geser di sini.</p>${geserSelect()}</div></section>
    </div>
    <div class="finish"><button class="btn dark big" data-act="finish" ${lmsOk && aiOk && absMode() ? "" : "disabled"}>Buka Beranda</button>
      <p class="cap">${!lmsOk && !aiOk ? "Hubungkan Edlink dan sambungkan AI dulu." : !lmsOk ? "Hubungkan Edlink dulu." : !aiOk ? (S.serverOn && S.settings.ai.provider === "server" ? "Tempel API key Gemini dulu di langkah 2, supaya file dosen bisa langsung diringkas." : "Sambungkan AI dulu di langkah 2, supaya file dosen bisa langsung diringkas.") : !absMode() ? "Pilih cara absensi kampusmu di langkah 3." : "Semua siap."}</p></div></div>`;
}
const AI_INFO = {
  gemini: { nama: "Gemini", price: "Gratis", free: true, short: "Akun Google. Bisa baca slide bergambar dan video YouTube.",
    steps: [`Buka <a href="#" data-open-url="https://aistudio.google.com/apikey">aistudio.google.com/apikey</a> dan masuk dengan akun Google.`, `Klik <b>Create API key</b>, lalu salin key-nya.`, `Tempel di bawah, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Kuota gratisnya cukup untuk dipakai setiap hari. Kalau muncul pesan kuota habis, tunggu beberapa menit." },
  cerebras: { nama: "Cerebras", price: "Gratis, open source", free: true, short: "Model open source di cloud. Cepat, kuota besar, baca teks dan gambar slide.",
    steps: [`Buka <a href="#" data-open-url="https://cloud.cerebras.ai">cloud.cerebras.ai</a> dan daftar dengan Google atau email.`, `Buka menu <b>API Keys</b>, buat key baru, lalu salin.`, `Tempel di bawah, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Memakai model open source seperti Qwen dan GPT-OSS di server Cerebras, jadi tidak perlu laptop kuat. Membaca teks PDF, PPT, DOCX, dan sampai 2 gambar slide per materi. Video bisa diringkas kalau API key Groq diisi di Cadangan otomatis (transkrip Whisper)." },
  groq: { nama: "Groq", price: "Gratis, open source", free: true, short: "Paling cepat untuk Tanya AI. Punya Whisper untuk transkrip video.",
    steps: [`Buka <a href="#" data-open-url="https://console.groq.com/keys">console.groq.com/keys</a> dan masuk dengan Google atau email.`, `Klik <b>Create API Key</b>, lalu salin.`, `Tempel di bawah, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Jawabannya sangat cepat, cocok untuk Tanya AI, dan videonya ditranskrip otomatis dengan Whisper. Kuota per menitnya kecil, jadi materi yang sangat panjang lebih baik disusun Gemini atau Cerebras." },
  ollama: { nama: "Ollama", price: "Gratis, offline", free: true, short: "Jalan di laptopmu sendiri. RAM 16 GB, hanya teks.",
    steps: [`Unduh dan install Ollama dari <a href="#" data-open-url="https://ollama.com/download">ollama.com/download</a>.`, `Buka Command Prompt, ketik <code class="cmd">ollama pull qwen2.5:7b</code>, lalu tunggu unduhan sekitar 4,7 GB selesai.`, `Pastikan ikon llama muncul di pojok kanan bawah taskbar, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Tidak butuh internet dan tanpa kuota, tapi lebih lambat dan tidak bisa membaca slide bergambar atau video." },
  openai: { nama: "ChatGPT", price: "Berbayar", short: "Bayar sesuai pemakaian lewat saldo API OpenAI.",
    steps: [`Buka <a href="#" data-open-url="https://platform.openai.com/api-keys">platform.openai.com/api-keys</a>, klik <b>Create new secret key</b>, lalu salin.`, `Isi saldo di menu <b>Billing</b>, minimal sekitar USD 5.`, `Tempel key di bawah, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Langganan ChatGPT Plus tidak termasuk akses API, jadi saldonya terpisah." },
  anthropic: { nama: "Claude", price: "Berbayar", short: "Bayar sesuai pemakaian lewat kredit API Anthropic.",
    steps: [`Buka <a href="#" data-open-url="https://console.anthropic.com/settings/keys">console.anthropic.com/settings/keys</a>, klik <b>Create Key</b>, lalu salin.`, `Isi kredit di menu <b>Billing</b>.`, `Tempel key di bawah, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Langganan Claude Pro atau Max tidak termasuk akses API. Model Opus, Sonnet, atau Haiku bisa dipilih di Pengaturan." }
};
const ownKeys = () => ["cerebras", "groq", "gemini"].some(x => S.settings.ai.hasKey && S.settings.ai.hasKey[x]);
const aiReady = () => { const a = S.settings.ai, p = a.provider; if (p === "server") return ownKeys(); if (p === "auto") return ["cerebras", "groq", "gemini"].some(x => a.hasKey && a.hasKey[x]); return !!(a.model && a.model[p]) && (p === "ollama" || !!(a.hasKey && a.hasKey[p])); };
const inputStyle = "height:40px;border:0;border-radius:14px;background:var(--card-2);padding:0 14px;min-width:280px;max-width:100%";
// Mode otomatis: cukup isi API key gratis, aplikasi memilih AI per tugas dan pindah sendiri kalau ada yang penuh
const AUTO_KEYS = [
  ["cerebras", "Cerebras", "Disarankan", "Menyusun materi, latihan soal, dan rangkuman. Kuota gratis besar.", "https://cloud.cerebras.ai", "Daftar dengan Google atau email, buka menu API Keys, buat key."],
  ["groq", "Groq", "Disarankan", "Tanya AI paling cepat, dan transkrip video dengan Whisper.", "https://console.groq.com/keys", "Masuk dengan Google atau email, klik Create API Key."],
  ["gemini", "Gemini", "Opsional", "Menonton video YouTube dan membaca slide bergambar langsung.", "https://aistudio.google.com/apikey", "Masuk dengan akun Google, klik Create API key."]
];
function akRow(k, nm, tag, use, url, how){
  const a = S.settings.ai;
  const on = a.hasKey && a.hasKey[k], mdl = a.model && a.model[k];
      return `<div class="ak ${on ? "on" : ""}"><div class="ak-h"><span class="ak-dot"></span><b>${nm}</b><span class="tagc">${tag}</span><span class="cap ak-use">${use}</span></div>
        <div class="ak-in"><input id="ak-${k}" type="password" placeholder="${on ? "Tersimpan " + esc(a.keys[k]) + (mdl ? ", model " + esc(mdl) : "") : "Tempel API key " + nm}" style="${inputStyle};background:var(--card)"><button class="btn sm ${on ? "" : "dark"}" data-act="auto-save" data-for="${k}">${on ? "Ganti" : "Simpan"}</button><a href="#" class="ak-link" data-open-url="${url}">Ambil key gratis</a></div>
        ${on ? "" : `<p class="cap">${how}</p>`}</div>`;
}
function autoForm(full, skip){
  const a = S.settings.ai, KEYS = AUTO_KEYS.filter(([k]) => k !== skip), n = KEYS.filter(([k]) => a.hasKey && a.hasKey[k]).length;
  if (skip) return `<div class="auto-box">${KEYS.map(([k, nm, tag, use, url, how]) => akRow(k, nm, "Opsional", use, url, how)).join("")}${UI.akMsg && UI.akMsg.for !== "gemini" ? `<p class="${UI.akMsg.ok ? "ok-t" : "err-t"}">${esc(UI.akMsg.t)}</p>` : ""}</div>`;
  return `<div class="auto-box">
    <div class="ab-h"><div><b>AI otomatis</b><span class="price free">Gratis</span></div><p class="cap">${n ? `${n} dari 3 tersambung. ` : ""}Isi satu kali, lalu aplikasi memilih AI yang paling cocok untuk tiap tugas dan langsung pindah ke AI lain kalau ada yang penuh. Tidak perlu antre.</p></div>
    ${AUTO_KEYS.map(([k, nm, tag, use, url, how]) => akRow(k, nm, tag, use, url, how)).join("")}
    ${UI.akMsg ? `<p class="${UI.akMsg.ok ? "ok-t" : "err-t"}">${esc(UI.akMsg.t)}</p>` : ""}
    <p class="ai-note">Cara kerjanya: materi disusun Cerebras, Tanya AI dijawab Groq, video ditonton Gemini atau ditranskrip Whisper. Kalau satu penuh, tugasnya langsung dikerjakan yang lain. API key hanya disimpan di laptop ini.</p>
  </div>`;
}
// AI Teman Kuliah: server milik pembuat aplikasi, pengguna tidak perlu API key
const Q_NAMA = { materi: "Ringkas materi", chat: "Tanya AI", lain: "Latihan & rangkuman", video: "Transkrip video" };
function loadQuota(force){
  if (UI.qLoading || (!force && UI.qAt && Date.now() - UI.qAt < 60000)) return;
  UI.qLoading = true;
  api.aiQuota().then(r => { UI.qLoading = false; UI.qAt = Date.now(); if (r && r.ok === false){ UI.qErr = r.error; UI.quota = null; } else { UI.quota = r; UI.qErr = null; } render(); });
}
function serverCard(){
  setTimeout(() => loadQuota(), 0);
  const q = UI.quota;
  return `<div class="auto-box srv">
    <div class="ab-h"><div><b>AI Teman Kuliah</b><span class="price free">Gratis</span><span class="tagc">Tanpa API key</span></div><p class="cap">Sudah siap, tanpa API key. Tanya AI dijawab cepat oleh server Teman Kuliah, yang juga jadi cadangan kalau Gemini-mu penuh. Jatah harian terisi lagi setiap jam 00.00 WIB.</p></div>
    ${q && q.sisa ? `<div class="qrow">${["chat"].filter(k => k in q.sisa).map(k => `<span class="qchip ${q.sisa[k] ? "" : "out"}">${Q_NAMA[k]} <b>${q.sisa[k]}/${q.jatah[k]}</b></span>`).join("")}</div><p class="cap">Sisa jatah hari ini.</p>`
      : UI.qErr ? `<p class="err-t">${esc(UI.qErr)} <button class="link" data-act="quota-reload">Coba lagi</button></p>` : `<p class="cap">Memuat sisa jatah hari ini…</p>`}
  </div>`;
}
function serverAdv(){
  const a = S.settings.ai;
  return `<details class="manual" data-fold="adv" ${UI.open_adv ? "open" : ""}><summary>Lanjutan</summary><p class="cap">Alamat server AI. Hanya untuk pembuat aplikasi; biarkan kosong untuk memakai alamat bawaan.</p>
    <div class="ak-in"><input id="srv-url" value="${esc(a.serverUrl || "")}" placeholder="https://teman-kuliah-ai.namamu.workers.dev" spellcheck="false" style="${inputStyle};background:var(--card)"><button class="btn sm" data-act="srv-save">Simpan</button></div></details>`;
}
function geminiBox(){
  const a = S.settings.ai, on = a.hasKey && a.hasKey.gemini;
  return `<div class="auto-box gem ${on ? "on" : ""}">
    <div class="ab-h"><div><b>Gemini milikmu</b><span class="price free">Gratis</span><span class="tagc">${on ? "Tersambung" : "Wajib, 1 menit"}</span></div><p class="cap">Dipakai untuk meringkas materi, membaca slide bergambar, menonton video kuliah dan YouTube, dan membuat latihan soal. Cukup akun Google, tanpa kartu.</p></div>
    ${on ? "" : `<ol class="gem-steps"><li>Buka <a href="#" data-open-url="https://aistudio.google.com/apikey">aistudio.google.com/apikey</a> dan masuk dengan akun Google.</li><li>Klik <b>Create API key</b>, lalu salin key-nya.</li><li>Tempel di bawah, lalu klik <b>Simpan</b>.</li></ol>`}
    <div class="ak-in"><input id="ak-gemini" type="password" placeholder="${on ? "Tersimpan " + esc(a.keys.gemini) + (a.model && a.model.gemini ? ", model " + esc(a.model.gemini) : "") : "Tempel API key Gemini"}" style="${inputStyle};background:var(--card)"><button class="btn sm ${on ? "" : "dark"}" data-act="auto-save" data-for="gemini">${on ? "Ganti" : "Simpan"}</button></div>
    ${UI.akMsg && UI.akMsg.for === "gemini" ? `<p class="${UI.akMsg.ok ? "ok-t" : "err-t"}">${esc(UI.akMsg.t)}</p>` : ""}
  </div>`;
}
function aiForm(full){
  const a = S.settings.ai, p = a.provider;
  if (p === "server" && S.serverOn) return geminiBox() + serverCard()
    + `<details class="manual" data-fold="own" ${UI.open_own ? "open" : ""}><summary>Tambah AI lain (opsional)</summary><p class="cap" style="margin:8px 0 10px">Tidak wajib. Cerebras dan Groq milikmu dipakai sebagai cadangan kalau Gemini sedang penuh.</p>${autoForm(full, "gemini")}
      <details class="manual" data-fold="one" ${UI.open_one ? "open" : ""}><summary>Atau pakai satu AI pilihanmu saja</summary>${aiFormManual(full)}</details></details>`
    + (full ? serverAdv() : "");
  if (p === "server") return autoForm(full) + `<details class="manual" data-fold="one" ${UI.open_one ? "open" : ""}><summary>Atau pilih satu AI saja</summary>${aiFormManual(full)}</details>` + (full ? serverAdv() : "");
  const manual = `<details class="manual" ${p !== "auto" || UI.manualOpen ? "open" : ""}><summary>${p === "auto" ? "Atau pilih satu AI saja" : "Pilih AI"}</summary>${aiFormManual(full)}</details>`;
  const toServer = S.serverOn ? `<div class="auto-switch"><p class="cap">Sedang memakai API key sendiri. <button class="link" data-provider="server">Pakai AI Teman Kuliah (gratis, tanpa API key)</button></p></div>` : "";
  return toServer + (p === "auto" ? autoForm(full) : `<div class="auto-switch"><p class="cap">Sedang memakai satu AI saja. <button class="link" data-provider="auto">Pakai AI otomatis dengan API key sendiri</button></p></div>`) + manual + (full ? serverAdv() : "");
}
function aiFormManual(full){
  const a = S.settings.ai, p = a.provider === "auto" || a.provider === "server" ? "" : a.provider, info = AI_INFO[p] || AI_INFO.gemini, t = UI.aiTest, cur = a.model && a.model[p], ml = a.models && a.models[p];
  const status = t ? (t.pick === "menguji…" ? `<p class="cap">Menghubungkan ke ${info.nama}…</p>` : t.ok ? `<p class="ok-t">Tersambung ke ${info.nama}${full ? "" : ". Model dipilih otomatis: " + esc(t.pick)}</p>` : `<p class="err-t">${esc(t.error)}</p>`)
    : aiReady() ? `<p class="ok-t">Tersambung ke ${info.nama}${cur ? ", model " + esc(cur) : ""}</p>` : "";
  if (!p) return `<div class="ai-grid" role="group" aria-label="Pilih AI">${Object.entries(AI_INFO).map(([k,v])=>`<button class="ai-opt" data-provider="${k}" aria-pressed="false"><b>${v.nama}</b><span class="price ${v.free?"free":""}">${v.price}</span><span>${v.short}</span></button>`).join("")}</div>`;
  return `<div class="ai-grid" role="group" aria-label="Pilih AI">${Object.entries(AI_INFO).map(([k,v])=>`<button class="ai-opt" data-provider="${k}" aria-pressed="${p===k}"><b>${v.nama}</b><span class="price ${v.free?"free":""}">${v.price}</span><span>${v.short}</span></button>`).join("")}</div>
    <div class="ai-how">
      <ol>${info.steps.map(x => `<li>${x}</li>`).join("")}</ol>
      <div class="inline">${p==="ollama"
        ? `<input id="ollama-url" value="${esc(a.ollamaUrl || "http://127.0.0.1:11434")}" aria-label="Alamat Ollama" spellcheck="false" style="${inputStyle};background:var(--card)">`
        : `<input id="ai-key" type="password" placeholder="${a.hasKey && a.hasKey[p] ? "Tersimpan " + esc(a.keys[p]) : "Tempel API key " + info.nama}" aria-label="API key ${info.nama}" style="${inputStyle};background:var(--card)">`}
        <button class="btn dark" data-act="test-ai">Simpan & sambungkan</button></div>
      ${status}
      <p class="ai-note">${info.note}${p==="ollama" ? "" : " API key hanya disimpan di laptop ini."}</p>
    </div>
    ${backupForm(p)}
    ${full && ml && ml.list && ml.list.length ? `<div class="field" style="padding:6px 0 0"><label for="ai-model">Model</label>
      <select id="ai-model" style="height:40px;border:0;border-radius:14px;background:var(--card-2);padding:0 12px;max-width:420px">${ml.list.map(m=>`<option value="${esc(m)}" ${m===cur?"selected":""}>${esc(m)}${m===ml.auto?" (otomatis, disarankan)":""}</option>`).join("")}</select>
      <p class="cap">Otomatis memilih model yang pintar tapi hemat${p==="anthropic"?" (Sonnet). Pilih Opus untuk hasil paling teliti, tapi biayanya lebih mahal":p==="openai"?". Varian mini lebih murah, varian pro lebih mahal":p==="gemini"?" (Flash). Pro lebih teliti tapi lebih lambat dan kuota gratisnya lebih kecil":""}.</p></div>` : ""}`;
}
// Cadangan otomatis: dipakai saat AI utama penuh, dan Groq untuk transkrip video (Whisper)
function backupForm(p){
  const a = S.settings.ai, list = ["cerebras", "groq"].filter(x => x !== p);
  return `<details class="backup" ${UI.backupOpen ? "open" : ""}><summary><b>Cadangan otomatis</b><span class="cap">${list.filter(x => a.hasKey && a.hasKey[x]).length ? "Aktif: " + list.filter(x => a.hasKey && a.hasKey[x]).map(x => AI_INFO[x].nama).join(" dan ") : "Opsional, supaya tidak perlu antre saat AI utama penuh"}</span></summary>
    <p class="cap">Kalau ${esc(AI_INFO[p].nama)} sedang penuh, materi langsung disusun ${list.map(x => AI_INFO[x].nama).join(" atau ")}. API key Groq juga dipakai untuk mentranskrip video dosen dengan Whisper kalau AI utamamu tidak bisa menonton video. Keduanya gratis.</p>
    ${list.map(x => `<div class="bk-row"><b>${AI_INFO[x].nama}</b><input id="bk-${x}" type="password" placeholder="${a.hasKey && a.hasKey[x] ? "Tersimpan " + esc(a.keys[x]) : "API key " + AI_INFO[x].nama}" style="${inputStyle};background:var(--card)"><button class="btn sm" data-act="backup-save" data-for="${x}">Simpan</button><a href="#" class="cap" data-open-url="${x === "groq" ? "https://console.groq.com/keys" : "https://cloud.cerebras.ai"}">Ambil key</a></div>`).join("")}
    ${UI.bkMsg ? `<p class="${UI.bkMsg.ok ? "ok-t" : "err-t"}">${esc(UI.bkMsg.t)}</p>` : ""}
  </details>`;
}
function absenToggle(){
  const m = absMode();
  const opt = (v, t, d) => `<label class="opt-card ${m === v ? "on" : ""}"><input type="radio" name="abs-mode" id="abs-${v}" value="${v}" ${m === v ? "checked" : ""}><span class="txt"><b>${t}</b><small>${d}</small></span></label>`;
  return `<fieldset class="abs-choice"><legend>Bagaimana kampusmu menghitung kehadiran?</legend>
    ${opt("komentar", "Komentar di setiap post dosen", "Seperti di UNSIA. Kamu dapat draft komentar yang bisa dibuat ulang, ceklis, to-do komentar, dan pengingat jam 19.00 kalau masih ada yang belum.")}
    ${opt("keaktifan", "Keaktifan di LMS", "Dihitung dari membuka materi, mengunduh file, dan menonton video. Teman Kuliah menampilkan aktivitasmu per pertemuan.")}
    ${opt("tidak", "Tidak keduanya", "Absensi diisi dosen atau lewat cara lain. Template komentar dan ceklisnya disembunyikan.")}
  </fieldset><p class="cap">Status hadir dari dosen tetap tampil di semua pilihan. ${m ? "Bisa diganti kapan saja di Pengaturan." : "Pilih salah satu dulu."}</p>`;
}
function geserSelect(){
  const g = geser();
  return `<select id="geser" aria-label="Geser hari kuliah" style="height:40px;border:0;border-radius:14px;background:var(--card-2);padding:0 12px;max-width:360px">${[0,1,2,3,4,5,6].map(n=>`<option value="${n}" ${n===g?"selected":""}>${n===0?"Sama dengan KRS":`Senin di KRS jadi ${HARI[(1+n)%7]} (geser ${n} hari)`}</option>`).join("")}</select>`;
}

/* ---------- beranda ---------- */
function viewBeranda(){
  if(!ready()) return viewWelcome();
  const t = today(), rw = rawWeek(t), w = weekOf(t), dn = HARI[t.getDay()];
  const todays = sorted().filter(c => courseDay(c) === dn);
  const st = weekStats(w), frac = st.total ? st.done/st.total : 0, pct = Math.round(frac*100), R = 62, C = 2*Math.PI*R;
  const todos = sortTodos(openTodos()).slice(0,5);
  const nextDay = (() => { for(let i=1;i<=7;i++){ const d = new Date(t.getTime()+i*DAY); const cs = sorted().filter(c => courseDay(c) === HARI[d.getDay()]); if(cs.length) return {d, cs}; } return null; })();
  const missing = []; if (absOn()) sorted().forEach(c => { for(let n=1;n<=w;n++){ const a = absenOf(c,n); if(a) a.belum.forEach(b => missing.push({c, n, ...b})); } });
  const status = rw < 1 ? "Semester belum mulai" : rw > 16 ? "Semester sudah selesai" : `Pertemuan ${w} dari 16, ${esc(sem().label)}`;
  return `${S.lms.needsLogin ? `<div class="banner">Sesi LMS kamu habis, jadi data belum diperbarui. <button class="link" data-act="login">Masuk lagi</button></div>` : ""}
  <section class="board" aria-label="Ringkasan hari ini">
    <div class="board-top">
      <div><p class="hi">${sapa()}${S.lms.me && S.lms.me.name ? ", " + esc(firstName(S.lms.me.name)) : ""}</p>
        <h1 class="board-date">${HARI[t.getDay()]}, ${t.getDate()} ${BULAN_L[t.getMonth()]}</h1>
        <p class="board-status">${status}</p></div>
      <button class="btn hl-btn" data-act="add">${I.plus}Tambah materi</button>
    </div>
    <p class="say">${ringkasHari(todays, w, missing)}</p>
    ${dayline(todays)}
  </section>
  <div class="bento">
    <section class="card w w-today">
      <div class="w-h"><h2>${todays.length ? "Kuliah hari ini" : "Hari ini kosong"}</h2><button class="link" data-go="jadwal">Jadwal minggu ini</button></div>
      ${todays.length ? todays.map(c => klass(c, w)).join("") : `<p class="sub">Tidak ada kelas. Pakai waktunya untuk mencicil materi atau to-do.</p>`}
      ${nextDay ? `<p class="next">Berikutnya <b>${HARI[nextDay.d.getDay()]}, ${fmtShort(nextDay.d)}</b>: ${nextDay.cs.map(c=>esc(c.nama)).join(" dan ")}</p>` : ""}
    </section>
    <section class="card w w-ring">
      <div class="w-h"><h2>Minggu ini</h2><span class="cap">${fmtShort(weekStart(w))} sampai ${fmtShort(new Date(weekStart(w).getTime()+6*DAY))}</span></div>
      <div class="ringbox">
        <svg class="ring" viewBox="0 0 150 150" role="img" aria-label="${pct} persen ceklis selesai"><circle class="bg" cx="75" cy="75" r="${R}"/><circle class="fg ${pct>=100?"full":""}" cx="75" cy="75" r="${R}" stroke-dasharray="${C}" stroke-dashoffset="${C*(1-frac)}" transform="rotate(-90 75 75)"/><text class="big" x="75" y="80" text-anchor="middle">${pct}%</text><text class="small" x="75" y="100" text-anchor="middle">${st.done} dari ${st.total}</text></svg>
        <div class="legend">${sorted().map(c => `<span data-c="${c.warna}"><i class="dot"></i><em>${esc(c.singkat)}</em><b>${st.per[c.id]}/${st.tot[c.id]}</b></span>`).join("")}</div>
      </div>
    </section>
    ${kartuRencana()}
    ${kartuHafalMini()}
    <section class="card w w-todo">
      <div class="w-h"><h2>To-do</h2><button class="link" data-go="todo">Lihat semua</button></div>
      <div class="tlist">${todos.length ? todos.map(([id,td]) => { const c = findCourse(td.course), di = dueInfo(td.due); return `<div class="ti" ${c?`data-c="${c.warna}"`:""}><label class="chk"><input type="checkbox" data-todo="${esc(id)}" aria-label="Tandai selesai"></label><div class="txt"><div class="t">${esc(td.text)}</div><div class="s">${c?esc(c.singkat):"Umum"}${td.time?", "+esc(td.time):""}</div></div><span class="due ${di.cls}">${di.txt}</span></div>`; }).join("") : `<p class="sub">Semua beres.</p>`}</div>
    </section>
    ${absOn() ? "" : notesFiles(w)}
    <section class="card w w-note" ${absOn() ? "" : "hidden"}>
      <div class="w-h"><h2>Belum dikomentari</h2><span class="cap">untuk absensi</span></div>
      ${missing.length ? `<div class="missing">${missing.slice(0,6).map(m => `<div class="mi" data-c="${m.c.warna}"><i class="dot" style="margin-top:6px"></i><div class="txt">${esc(m.judul)}<small>${esc(m.c.singkat)}, pertemuan ${m.n}</small></div><button class="btn sm" data-open-url="${esc(m.link)}">Buka</button></div>`).join("")}</div>${missing.length>6?`<p class="cap">dan ${missing.length-6} post lainnya</p>`:""}` : `<p class="sub">Semua post dosen sampai minggu ini sudah kamu komentari.</p>`}
    </section>
  </div>`;
}
function klass(c, w){
  const has = materi(c.id, w);
  return `<div class="klass" data-c="${c.warna}">${c.jam ? `<span class="when">${esc(String(c.jam).split(/[-–]/)[0].trim())}</span>` : ""}${icon(c)}<div style="flex:1; min-width:0">
    <h3>${esc(c.nama)}</h3><p class="cap">${esc(c.dosen)}</p>
    <div class="checks">${checks(c, w)}</div>${absenLine(c, w)}${hadirLine(c, w)}${kelLine(c, w)}
    <div class="acts">${has?`<button class="btn sm" data-open="${c.id}|${w}">Buka materi</button>`:""}${lampBtn(c, w)}${!has && !lampBaru(c,w).length?`<button class="btn sm" data-act="add" data-cid="${c.id}" data-meet="${w}">Tambah materi</button>`:""}<button class="btn sm" data-open-url="${esc(c.lms)}">Kelas di LMS</button></div>
  </div></div>`;
}

function sapa(){ const h = new Date().getHours(); return h < 11 ? "Selamat pagi" : h < 15 ? "Selamat siang" : h < 19 ? "Selamat sore" : "Selamat malam"; }
function firstName(n){ const w = String(n).trim().split(/\s+/)[0] || ""; return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase(); }
// Satu kalimat ringkas tentang hari ini; angka penting diberi stabilo.
function ringkasHari(todays, w, missing){
  const t = today(), soon = openTodos().filter(([,x]) => x.due && (parseD(x.due) - t) / DAY <= 3 && (parseD(x.due) - t) >= 0).length;
  const late = openTodos().filter(([,x]) => x.due && parseD(x.due) < t).length;
  const bits = [];
  bits.push(todays.length ? `ada <mark class="hl">${todays.length} kuliah</mark>` : "tidak ada kuliah");
  if (soon) bits.push(`<mark class="hl">${soon} to-do</mark> tenggatnya 3 hari ke depan`);
  if (late) bits.push(`<mark class="hl">${late} to-do</mark> sudah lewat tenggat`);
  if (missing.length) bits.push(`<mark class="hl">${missing.length} post</mark> belum kamu komentari`);
  const un = ujianNow(); if (un.d != null && un.d >= 0 && un.d <= 14) bits.push(`${UJI_N[un.jenis]} tinggal <mark class="hl">${un.d === 0 ? "hari ini" : un.d + " hari"}</mark>`);
  const last = bits.length > 1 ? bits.pop() : null;
  const s = "Hari ini " + bits.join(", ") + (last ? ", dan " + last : "") + ".";
  return s + (!soon && !late && !missing.length ? ` <span class="muted">Tidak ada yang mendesak.</span>` : "");
}

// Garis waktu hari ini: blok kuliah sesuai jam, jarum menunjukkan sekarang.
function dayline(todays){
  const H0 = 7, H1 = 22, span = (H1 - H0) * 60, toMin = x => { const m = String(x || "").match(/(\d{1,2})[.:](\d{2})/); return m ? (+m[1]) * 60 + (+m[2]) : null; };
  const pos = m => Math.max(0, Math.min(100, (m - H0 * 60) / span * 100));
  const now = new Date(), nm = now.getHours() * 60 + now.getMinutes();
  const blocks = todays.map(c => { const [a, b] = String(c.jam || "").split(/[-–]/); const s0 = toMin(a), e0 = toMin(b) || (s0 != null ? s0 + 100 : null); if (s0 == null) return ""; const live = nm >= s0 && nm < e0, past = nm >= e0;
    return `<button class="blk ${live ? "live" : ""} ${past ? "past" : ""}" data-c="${c.warna}" data-course="${c.id}" style="left:${pos(s0)}%; width:${Math.max(6, pos(e0) - pos(s0))}%" title="${esc(c.nama)}, ${esc(c.jam)}"><b>${esc(c.singkat)}</b><span>${esc(c.jam)}</span></button>`; }).join("");
  const ticks = [7, 10, 13, 16, 19, 22].map(h => `<i style="left:${pos(h * 60)}%"><span>${String(h).padStart(2, "0")}.00</span></i>`).join("");
  const needle = nm >= H0 * 60 && nm <= H1 * 60 ? `<em class="now" style="left:${pos(nm)}%"></em>` : "";
  return `<div class="dayline" aria-hidden="${todays.length ? "false" : "true"}"><div class="track">${ticks}${blocks}${needle}</div></div>`;
}

// Untuk kampus tanpa absensi komentar: kartu file dosen yang belum diringkas
function notesFiles(w){
  const items = []; sorted().forEach(c => { for(let n = w; n >= 1; n--){ const b = lampBaru(c, n); if(b.length) items.push({ c, n, b }); } });
  return `<section class="card w w-note"><div class="w-h"><h2>File dosen belum diringkas</h2><span class="cap">sampai pertemuan ${w}</span></div>
    ${items.length ? `<div class="missing">${items.slice(0,6).map(x => `<div class="mi" data-c="${x.c.warna}"><i class="dot" style="margin-top:6px"></i><div class="txt">${esc(x.b.map(f => f.name).join(", "))}<small>${esc(x.c.singkat)}, pertemuan ${x.n}</small></div>${lampBtn(x.c, x.n)}</div>`).join("")}</div>` : `<p class="sub">Semua file dari dosen sudah tersusun jadi materi.</p>`}</section>`;
}

/* ---------- jadwal ---------- */
function viewJadwal(){
  if(!ready()) return viewWelcome();
  const t = today(); if(UI.week == null) UI.week = weekOf(t);
  const w = UI.week, ws = weekStart(w), st = weekStats(w);
  const used = [...new Set(sorted().map(courseDay))];
  const order = ["Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu"].filter(d => used.includes(d));
  const cols = order.map(day => {
    const d = new Date(ws.getTime() + ((HARI.indexOf(day)+6)%7)*DAY);
    const cs = sorted().filter(c => courseDay(c) === day);
    return `<div class="wday ${ymd(d)===ymd(t)?"today":""}"><div class="wday-h"><span class="num">${d.getDate()}</span><span class="nm">${day}</span></div>
      ${cs.map(c => `<article class="ev ${allDone(c,w)?"complete":""}" data-c="${c.warna}">
        <div class="ev-top">${icon(c)}<div style="min-width:0"><h3>${esc(c.nama)}</h3><p class="cap">Di KRS ${esc(c.hariKRS)}, ${esc(c.jam)}</p></div></div>
        <div>${checks(c, w)}</div>${absenLine(c, w)}${hadirLine(c, w)}${kelLine(c, w)}
        ${allDone(c,w) ? `<span class="done">Semua sudah beres</span>` : ""}
        ${materi(c.id, w) ? `<button class="link" data-open="${c.id}|${w}">Buka materi pertemuan ${w}</button>` : ""}${lampBtn(c, w, "btn sm")}${!materi(c.id, w) && !lampBaru(c, w).length ? `<button class="link" data-act="add" data-cid="${c.id}" data-meet="${w}">Tambah materi pertemuan ${w}</button>` : ""}
      </article>`).join("")}</div>`;
  }).join("");
  return `
  <div class="head"><div><h1 class="large">Jadwal</h1><p class="lede">${st.done} dari ${st.total} ceklis selesai minggu ini</p></div>
    <div class="weeknav"><button class="circle" data-week="-1" ${w<=1?"disabled":""} aria-label="Minggu sebelumnya">${I.left}</button>
    <div class="lbl"><b>Pertemuan ${w}</b><span>${fmtShort(ws)} sampai ${fmtShort(new Date(ws.getTime()+6*DAY))}</span></div>
    <button class="circle" data-week="1" ${w>=16?"disabled":""} aria-label="Minggu berikutnya">${I.right}</button>
    ${w!==weekOf(t)?`<button class="btn sm" data-week="now">Minggu ini</button>`:""}</div></div>
  <div class="week" style="grid-template-columns:repeat(${Math.max(1,Math.min(order.length,5))}, minmax(0,1fr))">${cols}</div>
  ${(() => { const free = sorted().filter(c => !courseDay(c)); return free.length ? `<section><div class="group-t"><h2 class="title3">Tanpa jadwal tetap</h2><span class="cap">Kelas yang di KRS tidak punya hari kuliah</span></div><div class="week" style="grid-template-columns:repeat(auto-fill, minmax(240px,1fr))">${free.map(c => `<article class="ev ${allDone(c,w)?"complete":""}" data-c="${c.warna}"><div class="ev-top">${icon(c)}<div style="min-width:0"><h3>${esc(c.nama)}</h3><p class="cap">${esc(c.dosen || "")}</p></div></div><div>${checks(c, w)}</div>${absenLine(c, w)}${hadirLine(c, w)}${kelLine(c, w)}${lampBtn(c, w, "btn sm")}</article>`).join("")}</div></section>` : ""; })()}`;
}

/* ---------- materi ---------- */
function viewMateri(){
  if(!ready()) return viewWelcome();
  if(UI.course && UI.meet) return viewReader();
  if(UI.course) return viewCourse();
  const s = sem(), total = Object.keys(s.materi).length;
  const sems = Object.keys(S.semesters).sort();
  return `
  <div class="head"><div><h1 class="large">Materi</h1><p class="lede">${total ? total + " materi tersusun." : "Belum ada materi."} Seret file dari folder kuliahmu ke jendela ini untuk menambah.</p></div>
    <div class="inline">${sems.length>1?`<div class="seg" role="group" aria-label="Semester">${sems.map(p=>`<button data-sem="${p}" aria-pressed="${p===S.current}">${esc(S.semesters[p].label)}</button>`).join("")}</div>`:""}<button class="btn dark" data-act="add">${I.plus}Tambah materi</button></div></div>
  <div class="shelf">${sorted().map(c => { const nH = Object.keys(s.materi).filter(k => k.startsWith(c.id+"_")).length, nB = Array.from({length:16},(_,i)=>getP(c.id,i+1).belajar && materi(c.id,i+1)).filter(Boolean).length, baru = Object.keys(c.lampiran||{}).filter(n => lampBaru(c, Number(n)).length).length;
    return `<button class="book" data-c="${c.warna}" data-course="${c.id}">
      <span class="spine"></span>
      <span class="ini">${initials(c)}</span>
      <span class="ttl">${esc(c.nama)}</span>
      <span class="meta">${esc(courseDay(c))}${c.jam ? ", " + esc(String(c.jam).split(/[-–]/)[0].trim()) : ""}</span>
      <span class="bfoot"><span class="pips" aria-label="${nH} materi">${Array.from({length:16},(_,i)=>{ const n=i+1, has=materi(c.id,n), p=getP(c.id,n); return `<i class="${has?"has":""} ${has&&p.belajar?"done":""}"></i>`; }).join("")}</span>
        <span class="cnt">${nH ? nH + " materi" + (nB ? ", " + nB + " dipelajari" : "") : "Belum ada materi"}${baru ? `<mark class="hl">${baru} file dosen baru</mark>` : ""}</span></span>
    </button>`; }).join("")}</div>`;
}
function viewCourse(){
  const c = findCourse(UI.course); if(!c){ UI.course = null; return viewMateri(); }
  const w = weekOf(today());
  const meets = Array.from({length:16}, (_,i) => { const n = i+1, has = materi(c.id, n), p = getP(c.id,n), exam = n===8||n===16;
    if(!has && lampBaru(c, n).length) return `<button class="mt has ${n===w?"now":""}" title="${esc(lampBaru(c, n).map(f => kindOf(f) + ": " + f.name).join("\n"))}" data-lamp="${c.id}|${n}" aria-label="Ringkas file dosen pertemuan ${n}" style="background:var(--card)"><b>${n}</b><small>${UI.lampBusy===c.id+"_"+n?"Diringkas…":"File dosen"}</small></button>`;
    if(!has) return `<button class="mt add ${n===w?"now":""}" data-act="add" data-cid="${c.id}" data-meet="${n}" aria-label="Tambah materi pertemuan ${n}"><b>${n}</b><small>${exam?(n===8?"UTS":"UAS"):"Tambah"}</small></button>`;
    return `<button class="mt has ${p.belajar?"done":""} ${n===w?"now":""}" data-open="${c.id}|${n}" aria-label="Pertemuan ${n}: ${esc(has.judul)}"><b>${n}</b><small>${p.belajar?"Selesai":"Ada"}</small></button>`; }).join("");
  const allQ = Object.entries(sem().materi).filter(([k]) => k.startsWith(c.id+"_")).reduce((a,[,m])=>a+(m.kuis||[]).length,0);
  return `
  <nav class="crumbs"><button data-back="materi">${I.left}Materi</button></nav>
  <div class="chero" data-c="${c.warna}">${icon(c)}<div class="txt"><h1 class="large" style="font-size:clamp(28px,4vw,40px)">${esc(c.nama)}</h1><p class="lede" style="margin-top:4px">${esc(c.dosen)}</p></div>
    <div class="inline">${allQ?`<button class="btn dark" data-exam="${c.id}">Latihan ujian, ${allQ} soal</button>`:""}${Object.keys(sem().materi).some(k => k.startsWith(c.id+"_")) ? `<button class="btn" data-k="peta-open" data-v="${c.id}">${I.peta}Peta konsep</button>` : ""}<button class="btn" data-open-url="${esc(c.lms)}">Kelas di LMS</button></div></div>
  <div class="group"><dl class="facts" style="margin:0">
    <div class="fact"><dt>Jadwal kamu</dt><dd>${esc(courseDay(c))}</dd></div>
    <div class="fact"><dt>Di KRS</dt><dd>${esc(c.hariKRS)}, ${esc(c.jam)}</dd></div>
    <div class="fact"><dt>Kelas</dt><dd>${esc(c.kelas)}</dd></div>
    ${c.rekap ? `<div class="fact"><dt>Kehadiran dari dosen</dt><dd>Hadir ${c.rekap.hadir || 0}${c.rekap.izin ? ", izin " + c.rekap.izin : ""}${c.rekap.sakit ? ", sakit " + c.rekap.sakit : ""}${c.rekap.alfa ? `, <span class="err-t">alfa ${c.rekap.alfa}</span>` : ""}</dd></div>` : ""}
  </dl></div>
  <section data-c="${c.warna}"><div class="group-t"><h2 class="title3">Pertemuan</h2><span class="cap">"File dosen" berarti dosen sudah mengunggah materi, klik untuk meringkas. Kotak putus-putus belum ada materi.</span></div><div class="meets">${meets}</div></section>
  ${materiTable(c)}
  ${kelSection(c)}
  ${UI.exam === c.id ? examBlock(c) : ""}`;
}
function examBlock(c){
  const all = []; Object.entries(sem().materi).filter(([k]) => k.startsWith(c.id+"_")).forEach(([,m]) => (m.kuis||[]).forEach(q => all.push(q)));
  return `<section class="card" data-c="${c.warna}" style="padding:28px 30px; display:flex; flex-direction:column; gap:20px"><div class="w-h"><h2 class="title2">Latihan ujian</h2><button class="btn sm" data-exam="">Tutup</button></div>${quizHTML(all, "exam_"+c.id)}</section>`;
}
function quizHTML(qs, qid){
  const st = UI.quiz[qid] || (UI.quiz[qid] = {});
  const answered = Object.keys(st).length, right = Object.entries(st).filter(([i,a]) => qs[i] && qs[i].a === a).length;
  if(!qs.length) return `<p class="sub">Belum ada soal.</p>`;
  return `<div class="quiz">${qs.map((q,i)=>{ const pick = st[i], dn = pick !== undefined;
    return `<div class="q"><p>${i+1}. ${esc(q.q)}</p><div class="opts">${q.o.map((o,j)=>`<button class="opt ${dn && j===q.a ? "right" : ""} ${dn && j===pick && pick!==q.a ? "wrong":""}" data-q="${qid}|${i}|${j}" ${dn?"disabled":""}><b>${String.fromCharCode(65+j)}</b><span>${esc(o)}</span></button>`).join("")}</div>${dn?`<p class="expl">${pick===q.a?"Benar. ":"Belum tepat. "}${esc(q.e)}</p>`:""}</div>`; }).join("")}
    <div class="score"><b>${right}/${qs.length}</b><span class="sub">${answered < qs.length ? `${qs.length-answered} soal lagi` : right===qs.length ? "Sempurna" : "Coba ulangi soal yang salah"}</span><button class="btn sm" data-qreset="${qid}" style="margin-left:auto">Ulangi</button></div></div>`;
}
function tableHTML(t){ const [h,...rows] = t; return `<div class="tbl"><table><tr>${h.map(x=>`<th>${rich(x)}</th>`).join("")}</tr>${rows.map(r=>`<tr>${r.map(x=>`<td>${rich(x)}</td>`).join("")}</tr>`).join("")}</table></div>`; }
function viewReader(){
  const c = findCourse(UI.course), n = UI.meet, m = c && materi(c.id, n);
  if(!m){ UI.meet = null; return viewCourse(); }
  const tab = UI.tab, p = getP(c.id, n), key = c.id+"_"+n;
  const tabs = [["ringkasan","Ringkasan"],["istilah","Istilah"],["kuis","Kuis"],["tugas","Tugas LMS"]];
  let body = "";
  if(tab === "ringkasan"){
    body = `<p class="summary">${rich(m.ringkas)}</p>` + (m.bagian||[]).map((b, si)=>`<section class="sec" data-sec="${si}"><h2>${esc(b.h)}<button class="sec-say" data-k="dengar-sec" data-v="${key}|${si}" aria-label="Dengarkan dari bagian ini" title="Dengarkan dari bagian ini">${I.speaker}</button></h2>${b.p?String(b.p).split(/\n+/).filter(Boolean).map(x=>`<p>${rich(x)}</p>`).join(""):""}${b.list&&b.list.length?`<ul>${b.list.map(x=>`<li>${rich(x)}</li>`).join("")}</ul>`:""}${b.table?tableHTML(b.table):""}${(b.gambar||[]).map(g => figHTML(key, m, g)).join("")}${b.video && b.video.yt ? videoChip(b.video) : ""}${b.contoh?`<p class="aside"><b>Contoh:</b> ${rich(b.contoh)}</p>`:""}${b.note?`<p class="aside">${rich(b.note)}</p>`:""}</section>`).join("");
  } else if(tab === "istilah"){
    body = `<p class="sub">Klik kartu untuk melihat artinya.</p><div class="flash">${(m.istilah||[]).map(([a,b],i)=>`<button class="fc ${UI.flip[key+"_"+i]?"flip":""}" data-flip="${key}_${i}" aria-label="${esc(a)}"><div class="in"><div class="fa">${esc(a)}</div><div class="fb">${esc(b)}</div></div></button>`).join("")}</div>`;
  } else if(tab === "kuis"){
    body = quizHTML(m.kuis||[], key);
  } else {
    const ts = tugasOf(c, n);
    body = ts.length ? ts.map(t=>`<section class="sec"><h2>${esc(tugasLabel(t))}</h2><p class="aside">${t.tenggat?`Tenggat ${fmtShort(parseD(t.tenggat))}${t.jam?" pukul "+esc(t.jam):""}. `:""}Status di LMS: ${esc(t.status)}. <a href="#" data-open-url="${esc(t.link)}">Buka di LMS</a></p></section>`).join("") : `<p class="sub">Tidak ada tugas dari dosen di LMS untuk pertemuan ini.</p>`;
  }
  const askSt = UI.ask[key] || {};
  return `
  <nav class="crumbs"><button data-back="course">${I.left}${esc(c.nama)}</button></nav>
  <div class="reader" data-c="${c.warna}">
    <article class="card article">
      <header class="art-h"><span class="tag"><i class="dot"></i>Pertemuan ${n}</span><h1>${esc(m.judul)}</h1>
        <div class="art-tools"><button class="btn sm ${Suara.aktif() && Suara.key() === key ? "dark" : ""}" data-k="dengar" data-v="${key}">${I.speaker}${Suara.aktif() && Suara.key() === key ? (Suara.jalan() ? "Jeda" : "Lanjutkan") : "Dengarkan"}</button><button class="btn sm" data-k="bagikan" data-v="${key}">${I.share}Bagikan</button>${(m.bagian||[]).some(b => (b.gambar||[]).length) ? `<span class="cap">${(m.bagian||[]).reduce((a, b) => a + (b.gambar||[]).length, 0)} gambar dari materi dosen</span>` : ""}</div></header>
      <div class="seg" role="tablist" style="align-self:flex-start">${tabs.map(([id,l])=>`<button role="tab" aria-pressed="${tab===id}" data-tab="${id}">${l}</button>`).join("")}</div>
      ${body}
      <div class="pager">${materi(c.id,n-1)?`<button class="btn sm" data-open="${c.id}|${n-1}">${I.left}Pertemuan ${n-1}</button>`:"<span></span>"}${materi(c.id,n+1)?`<button class="btn sm" data-open="${c.id}|${n+1}">Pertemuan ${n+1}${I.right}</button>`:""}</div>
    </article>
    <aside class="side">
      <section class="card"><h2>Ceklis</h2><div>${checks(c, n)}</div>${absenLine(c, n)}${hadirLine(c, n, true)}${p.kuis!=null?`<p class="cap">Skor kuis terakhir ${p.kuis} dari ${(m.kuis||[]).length}</p>`:""}</section>
      ${kelCard(c, n)}
      ${sideChat("m:"+key)}
      ${absOn() ? komentarCard(key, m) : ""}
      ${videoCard(c, n)}
      <section class="card"><h2>Sumber</h2><div class="src">${(m.sumber||[]).map(s=>`<span>${esc(s)}</span>`).join("")}</div>
        ${lampBaru(c, n).some(f => f.pindah) ? `<p class="cap">Ada materi tambahan dari dosen untuk pertemuan ini (diunggah di sesi ${[...new Set(lampBaru(c, n).filter(f => f.pindah).map(f => f.pindah))].join(", ")}). Klik "Ringkas file baru dari dosen" untuk menggabungkannya.</p>` : ""}
        ${unggahOf(c, n).length ? `<details class="ud" ${lampBaru(c, n).length ? "open" : ""}><summary>Yang diunggah dosen (${unggahOf(c, n).length})</summary>${fileList(c, n)}</details>` : ""}
        <div class="inline">${lampBtn(c, n)}<button class="btn sm" data-act="add" data-cid="${c.id}" data-meet="${n}">Tambah sumber</button>${ulangBtn(c, n)}${UI.confirmDel===key?`<span class="confirm">Hapus materi?<button class="btn sm" data-delmateri="${key}">Hapus</button><button class="btn sm line" data-delno="1">Batal</button></span>`:`<button class="btn sm line" data-delask="${key}">Hapus</button>`}</div></section>
    </aside>
  </div>`;
}

// Ringkas ulang: semua file dosen dan sumber lama disusun dari awal, ringkasan lama diganti
function ulangBtn(c, n, cls = "btn sm"){
  const key = c.id + "_" + n, busy = UI.lampBusy === key;
  if (!materi(c.id, n)) return "";
  if (busy) return `<button class="${cls}" disabled>Sedang diringkas…</button>`;
  if (UI.confirmUlang === key) return `<span class="confirm">Ringkas ulang dari awal? Ringkasan lama diganti.<button class="btn sm dark" data-ulangya="${c.id}|${n}">Ringkas ulang</button><button class="btn sm line" data-ulangno="1">Batal</button></span>`;
  return `<button class="${cls}" data-ulang="${c.id}|${n}" title="Susun ulang ringkasan dari semua file dosen dan sumber pertemuan ini">Ringkas ulang</button>`;
}
function komentarCard(key, m){
  const busy = UI.komBusy === key, alt = m.komentarAlt || [];
  return `<section class="card kom"><h2>Komentar absensi</h2>
    ${m.komentar ? `<div class="copybox" id="copytarget">${esc(m.komentar)}</div>` : `<p class="sub">Belum ada draft komentar untuk materi ini.</p>`}
    <div class="inline">${m.komentar ? `<button class="btn dark" data-copy="${key}">${I.copy}Salin</button>` : ""}<button class="btn" data-komalt="${key}" ${busy ? "disabled" : ""}>${busy ? "Membuat pilihan…" : alt.length ? "Buat pilihan lain" : m.komentar ? "Buat ulang" : "Buat komentar"}</button></div>
    ${alt.length ? `<div class="kom-alt"><p class="cap">Pilih yang paling cocok. Komentar yang dipakai akan tersimpan untuk materi ini.</p>${alt.map((t, i) => `<div class="kom-o ${t === m.komentar ? "on" : ""}"><p>${esc(t)}</p><div class="inline"><button class="btn sm" data-kompick="${key}|${i}" ${t === m.komentar ? "disabled" : ""}>${t === m.komentar ? "Dipakai" : "Pakai ini"}</button><button class="btn sm line" data-komcopy="${key}|${i}">Salin</button></div></div>`).join("")}</div>` : ""}
  </section>`;
}
function timHTML(tim){
  return `<div class="tim"><b>${esc(tim.nama)}</b><div class="names">${tim.anggota.map(a => `<span class="${a.me ? "me" : ""}">${esc(a.me ? a.nama + " (kamu)" : a.nama)}</span>`).join("")}</div></div>`;
}
function kelCard(c, n){
  const k = kelOf(c), ts = (k.tugas || {})[n] || [], info = (k.info || []).filter(x => Number(x.meet) === Number(n));
  if (!ts.length && !info.length) return "";
  return `<section class="card kelc"><h2>Kelompok</h2>
    ${ts.map(t => `<div class="kt"><span class="pill kel">Tugas kelompok</span><a href="#" data-open-url="${esc(t.link)}">${esc(t.judul)}</a>${t.tenggat ? `<small>Tenggat ${fmtShort(parseD(t.tenggat))}${t.selesai ? ", sudah dikumpulkan" : ""}</small>` : ""}</div>`).join("")}
    ${info.map(x => `<div class="kt"><span class="pill">Info dosen</span><a href="#" data-open-url="${esc(x.link)}">${esc(x.judul)}</a>${x.text ? `<small>${esc(x.text.slice(0, 160))}${x.text.length > 160 ? "…" : ""}</small>` : ""}</div>`).join("")}
    ${k.tim ? timHTML(k.tim) : k.adaTim ? `<details class="semua"><summary>Kelompok sudah dibagi di LMS. Lihat semua kelompok</summary>${(k.semua || []).map(timHTML).join("")}</details>` : `<p class="cap">Pembagian kelompok belum ada di LMS. Begitu dosen membaginya, anggotanya muncul di sini otomatis.</p>`}
  </section>`;
}
function kelSection(c){
  const k = kelOf(c), meets = Object.keys(k.tugas || {}).filter(n => (k.tugas[n] || []).length).map(Number).sort((a, b) => a - b);
  if (!k.tim && !k.adaTim && !meets.length && !(k.info || []).length) return "";
  return `<section><div class="group-t"><h2 class="title3">Kelompok</h2><span class="cap">Dari LMS, diperbarui setiap sinkron</span></div><div class="card kelc">
    ${k.tim ? timHTML(k.tim) : k.adaTim ? `<p class="sub">Teman Kuliah belum bisa memastikan kelompokmu. Ini daftar kelompok di kelas ini:</p>${(k.semua || []).map(timHTML).join("")}` : `<p class="sub">Pembagian kelompok belum ada di LMS.</p>`}
    ${meets.map(n => k.tugas[n].map(t => `<div class="kt"><span class="pill kel">Pertemuan ${n || "-"}</span><a href="#" data-open-url="${esc(t.link)}">${esc(t.judul)}</a>${t.tenggat ? `<small>Tenggat ${fmtShort(parseD(t.tenggat))}${t.selesai ? ", sudah dikumpulkan" : ""}</small>` : ""}</div>`).join("")).join("")}
  </div></section>`;
}
// Tabel materi per pertemuan: buka, ringkas file baru, atau ringkas ulang
// Semua yang diunggah dosen per pertemuan: jenis file, nama, asal post, dan statusnya
const unggahOf = (c, n) => (c.unggahan && c.unggahan[n]) || lampOf(c, n).map(f => ({ ...f, status: "materi" }));
const KIND = { pdf: "PDF", pptx: "PPT", docx: "Word", ppt: "PPT lama", doc: "Word lama", youtube: "YouTube", video: "Video", link: "Tautan", image: "Gambar", xlsx: "Excel", xls: "Excel" };
const kindOf = f => KIND[f.kind] || KIND[f.ext] || (f.youtube ? "YouTube" : f.video ? "Video" : String(f.kind || "File").toUpperCase());
const sizeTxt = b => { b = Number(b) || 0; return !b ? "" : b >= 1048576 ? (b / 1048576).toFixed(1).replace(".", ",") + " MB" : Math.max(1, Math.round(b / 1024)) + " KB"; };
const tglTxt = t => { if (!t) return ""; const d = new Date(typeof t === "number" || /^\d+$/.test(String(t)) ? Number(t) : String(t).replace(" ", "T")); return isNaN(d) ? "" : fmtShort(d); };
function fileStatus(c, n, f){
  const m = materi(c.id, n), done = new Set((m && m.lampiranIds) || []);
  if (f.status === "materi") return done.has(f.id) ? ["ok", "Sudah diringkas"] : inQueue(c, n) ? ["wait", "Dalam antrean"] : ["kel", "Baru"];
  return f.status === "format" ? ["mid", "Tidak bisa dibaca"] : f.status === "lain" ? ["", "Info"] : ["bad", "Dilewati"];
}
function fileList(c, n){
  const all = unggahOf(c, n); if (!all.length) return "";
  const posts = []; all.forEach(f => { let g = posts.find(x => x.id === (f.postId || "-")); if (!g) posts.push(g = { id: f.postId || "-", judul: f.post, link: f.postLink, tgl: f.tgl, pindah: f.pindah, files: [] }); g.files.push(f); });
  return `<div class="ufiles">${posts.map(g => `<div class="upost">
    <div class="uph">${g.judul ? `<b>${esc(g.judul)}</b>` : `<b>File dari dosen</b>`}<span class="cap">${[tglTxt(g.tgl) && "diunggah " + tglTxt(g.tgl), g.pindah && `dipindah dari sesi ${g.pindah} karena dosen menyebut pertemuan ${n}`].filter(Boolean).join(", ")}</span>${g.link ? `<a href="#" data-open-url="${esc(g.link)}">Buka di LMS</a>` : ""}</div>
    ${g.files.map(f => { const [cls, lbl] = fileStatus(c, n, f); return `<div class="uf"><span class="kind">${esc(kindOf(f))}</span><div class="ut"><span class="un">${esc(f.name)}</span>${f.alasan ? `<small>${esc(f.alasan)}</small>` : ""}</div><span class="us">${esc(sizeTxt(f.size))}</span><span class="pill ${cls}">${lbl}</span>${f.status === "abaikan" || f.status === "rps" ? `<button class="btn sm line" data-paksa="${esc(f.id)}">Tetap ringkas</button>` : ""}</div>`; }).join("")}
  </div>`).join("")}</div>`;
}
// Tabel materi per pertemuan: buka, lihat file dari dosen, ringkas file baru, atau ringkas ulang
function materiTable(c){
  const rows = [];
  for (let n = 1; n <= 16; n++){
    const m = materi(c.id, n), baru = lampBaru(c, n), up = unggahOf(c, n);
    if (!m && !baru.length && !up.length) continue;
    const st = inQueue(c, n) ? `<span class="pill wait">Dalam antrean</span>` : baru.length ? `<span class="pill kel">${baru.length} file baru${baru.some(f => f.pindah) ? ", materi tambahan" : ""}</span>` : m && m.terpotong ? `<span class="pill mid">Terpotong</span>` : m ? `<span class="pill ok">Tersusun</span>` : `<span class="pill mid">Perlu dicek</span>`;
    const ringkas = baru.length ? `Baru: ${baru.map(f => kindOf(f) + " " + f.name).join(", ")}` : "";
    rows.push(`<tr><td class="no">${n}</td><td class="jd">${m ? `<button class="link" data-open="${c.id}|${n}">${esc(m.judul)}</button>` : `<span>${esc(up.find(f => f.post) ? up.find(f => f.post).post : "Belum diringkas")}</span>`}<small>${m ? esc((m.sumber || []).length + " sumber" + (m.dibuat ? ", disusun " + fmtShort(new Date(m.dibuat)) : "")) : "Belum diringkas"}${ringkas ? `<br><span class="newf">${esc(ringkas)}</span>` : ""}</small>
      ${up.length ? `<details class="ud" ${(UI.udOpen || {})[c.id + "_" + n] ? "open" : ""} data-ud="${c.id}_${n}"><summary>Lihat yang diunggah dosen (${up.length})</summary>${fileList(c, n)}</details>` : ""}</td><td>${st}</td><td class="aksi">${lampBtn(c, n)}${ulangBtn(c, n)}</td></tr>`);
  }
  if (!rows.length) return "";
  return `<section><div class="group-t"><h2 class="title3">Daftar materi</h2><span class="cap">Klik "Lihat yang diunggah dosen" untuk tahu file apa saja sebelum diringkas</span></div>
    <div class="card mtable"><div class="tbl"><table><tr><th>Pert.</th><th>Materi</th><th>Status</th><th></th></tr>${rows.join("")}</table></div></div></section>`;
}

/* ---------- to-do ---------- */
function viewTodo(){
  if(!ready()) return viewWelcome();
  const f = UI.todoFilter;
  let arr = Object.entries(S.todos);
  if(f === "aktif") arr = arr.filter(([,t]) => !t.done);
  if(f === "selesai") arr = arr.filter(([,t]) => t.done);
  if(f === "lms") arr = arr.filter(([,t]) => t.source === "lms" || t.source === "absen");
  sortTodos(arr);
  const opts = sorted().map(c => `<option value="${c.id}">${esc(c.singkat)}</option>`).join("");
  return `
  <div class="head"><div><h1 class="large">To-do</h1><p class="lede">${openTodos().length} belum selesai. Kuis, ujian, vicon${absOn() ? ", dan komentar absensi" : ""} dari LMS masuk ke sini otomatis.</p></div>
    <div class="seg" role="group" aria-label="Saring to-do">${[["aktif","Belum"],["semua","Semua"],["selesai","Selesai"],["lms","Dari LMS"]].map(([k,l])=>`<button data-filter="${k}" aria-pressed="${f===k}">${l}</button>`).join("")}</div></div>
  <form class="group adder" id="addform" autocomplete="off">
    <input id="td-text" class="full" placeholder="Tambah to-do baru" required aria-label="Isi to-do">
    <select id="td-course" aria-label="Mata kuliah"><option value="">Umum</option>${opts}</select>
    <input id="td-due" type="date" aria-label="Tenggat">
    <button class="btn dark" type="submit">Tambah</button>
  </form>
  <div class="group todos">${arr.length ? arr.map(([id,t]) => { const c = findCourse(t.course), di = dueInfo(t.due);
    return `<div class="todo ${t.done?"done":""}" ${c?`data-c="${c.warna}"`:""}><label class="chk"><input type="checkbox" data-todo="${esc(id)}" ${t.done?"checked":""} aria-label="Tandai selesai"></label>
      <div class="body"><div class="t">${esc(t.text)}</div>
        <div class="info">${c?`<span class="c"><i class="dot"></i>${esc(c.singkat)}</span>`:`<span>Umum</span>`}${t.due?`<span class="due ${t.done?"":di.cls}" style="padding:0">${fmtShort(parseD(t.due))}${t.time?", "+esc(t.time):""}</span>`:""}${t.source==="lms"?`<span class="lms">${/^kuis/i.test(t.jenis||"") ? "Kuis dari LMS" : /^ujian/i.test(t.jenis||"") ? "Ujian dari LMS" : "Dari LMS"}</span>`:t.source==="absen"?`<span class="lms">Komentar absensi</span>`:""}${t.link?`<a href="#" data-open-url="${esc(t.link)}">Buka di LMS</a>`:""}</div>
        ${t.note?`<p class="note">${esc(t.note)}</p>`:""}
      </div>
      <div class="acts">${canPandu(t) && UI.confirmDel!==id ? `<button class="btn sm pd-btn ${(S.pandu||{})[id] || (t.due && dayDiff(t.due) != null && dayDiff(t.due) <= 7) ? "dark" : ""}" data-k="pandu-open" data-v="${esc(id)}"><i>✦</i> ${(S.pandu||{})[id] ? "Lanjutkan panduan" : "Pandu tugas ini"}</button>` : ""}${UI.confirmDel===id?`<span class="confirm">Hapus?<button class="btn sm" data-del="${esc(id)}">Hapus</button><button class="btn sm line" data-delno="1">Batal</button></span>`:`<button class="iconbtn" data-delask="${esc(id)}" aria-label="Hapus to-do">${I.trash}</button>`}</div>
    </div>`; }).join("") : `<div class="empty">${f==="selesai"?"Belum ada yang selesai.":f==="lms"?"Belum ada to-do dari LMS.":"Tidak ada to-do."}</div>`}</div>`;
}

/* ---------- pengaturan ---------- */
function viewPengaturan(){
  const L = S.lms;
  return `<div class="head"><div><h1 class="large">Pengaturan</h1></div></div>
  <div class="settings">
    <section><div class="group-t"><h2 class="title3">Akun LMS</h2></div><div class="group">
      <div class="field"><label>${L.connected ? "Terhubung sebagai " + esc(L.me && L.me.name) : "Belum terhubung"}</label><p class="cap">${S.settings.kampus && S.settings.kampus.url ? esc(kampusHost()) + ". " : ""}${L.connected ? "Sinkron terakhir " + ago(L.lastSync) + "." : "Login lewat halaman resmi LMS kampusmu."}${L.lastError?` <span class="err-t">${esc(L.lastError)}</span>`:""}</p>
        ${L.connected ? "" : kampusPicker()}
        <div class="inline">${L.connected ? `<button class="btn dark" data-act="sync">Sinkron sekarang</button><button class="btn" data-act="login">Masuk ulang</button><button class="btn line" data-act="logout">Keluar</button>` : `<button class="btn dark" data-act="login">Masuk ke Edlink</button>`}</div>${L.connected ? `<p class="cap">Mau ganti LMS atau akun? Klik Keluar dulu.</p>` : ""}</div>
      <div class="field"><div class="inline" style="justify-content:space-between"><label for="autosync">Sinkron otomatis tiap 30 menit</label><input type="checkbox" class="switch" id="autosync" ${S.settings.autoSync?"checked":""}></div></div>
      <div class="field"><div class="inline" style="justify-content:space-between"><label for="background">Jalan di latar belakang</label><input type="checkbox" class="switch" id="background" ${S.settings.background?"checked":""}></div><p class="cap">Aplikasi menyala saat Windows dinyalakan dan tetap sinkron dari ikon di pojok taskbar walau jendelanya ditutup. Notifikasi muncul setiap dosen posting.</p></div>
    </div></section>
    <section><div class="group-t"><h2 class="title3">AI penyusun materi</h2></div><div class="group"><div class="field">${aiForm(true)}</div>
      <div class="field"><div class="inline" style="justify-content:space-between"><label for="automateri">Ringkas file dosen secara otomatis</label><input type="checkbox" class="switch" id="automateri" ${S.settings.autoMateri?"checked":""}></div><p class="cap">Mati: file dosen baru muncul dengan tombol "Ringkas file dosen", jadi kuota AI cuma terpakai saat kamu klik. Nyala: setiap PPT, PDF, DOCX, atau link YouTube dari dosen langsung diringkas sendiri (lebih boros kuota). Materi buatanmu tidak ditimpa.${S.lms.autoError?` <span class="err-t">Terakhir gagal: ${esc(S.lms.autoError)}</span>`:""}</p></div></div></section>
    ${belajarSettings()}
    <section><div class="group-t"><h2 class="title3">Pengingat</h2><span class="cap">Muncul sebagai notifikasi Windows selama aplikasi menyala</span></div><div class="group">
      ${[["materi","Materi baru dari dosen","Kabar setiap dosen mengunggah PPT, PDF, DOCX, atau video di LMS."],["tenggat","Tenggat tugas dan kuis","Pengingat sehari sebelum tenggat, lalu alarm 3 jam sebelum tenggat yang tetap tampil sampai kamu tutup."],["kelas","Vicon dan jam kuliah","Pengingat 30 menit sebelum vicon dan 15 menit sebelum kuliah dimulai, sesuai hari kuliahmu."],["hafalan","Kartu hafalan","Jam 19.30, kalau masih ada kartu hafalan yang perlu diulang hari ini."], ...(absOn() ? [["komentar","Komentar absensi","Jam 19.00 di hari kuliah, kalau masih ada post dosen pertemuan itu yang belum kamu komentari."]] : [])].map(([k,l,d]) => `<div class="field"><div class="inline" style="justify-content:space-between"><label for="peng-${k}">${l}</label><input type="checkbox" class="switch" id="peng-${k}" data-peng="${k}" ${(S.settings.pengingat||{})[k]!==false?"checked":""}></div><p class="cap">${d}</p></div>`).join("")}
      ${!S.settings.background ? `<div class="field"><p class="cap"><span class="err-t">Jalan di latar belakang sedang mati</span>, jadi pengingat hanya muncul saat jendela aplikasi terbuka.</p></div>` : ""}
    </div></section>
    <section><div class="group-t"><h2 class="title3">Tampilan</h2></div><div class="group"><div class="field"><div class="inline" style="justify-content:space-between"><label>Tema</label><div class="seg" role="group">${[["auto","Ikuti Windows"],["light","Terang"],["dark","Gelap"]].map(([v,l])=>`<button aria-pressed="${(S.settings.theme||"auto")===v}" data-k="theme" data-v="${v}">${l}</button>`).join("")}</div></div><p class="cap">Bisa juga diganti cepat lewat tombol matahari atau bulan di kanan atas.</p></div></div></section>
    <section><div class="group-t"><h2 class="title3">Kuliah</h2></div><div class="group"><div class="field">${absenToggle()}</div><div class="field"><div class="inline" style="justify-content:space-between"><label for="uj-auto">Ringkas otomatis menjelang ujian</label><input type="checkbox" class="switch" id="uj-auto" ${S.settings.ujianOtomatis!==false?"checked":""}></div><p class="cap">Saat UTS atau UAS tinggal 14 hari, file dosen di pertemuan yang diujikan dan belum diringkas langsung disusun jadi materi.</p></div><div class="field"><label for="geser">Geser hari dari KRS</label>${geserSelect()}<p class="cap">Contoh: kalau kuliahmu Rabu sampai Minggu padahal KRS Senin sampai Jumat, pilih geser 2 hari.</p></div></div></section>
    <section><div class="group-t"><h2 class="title3">Panduan</h2></div><div class="group"><div class="field"><label>Panduan pengguna Teman Kuliah</label><p class="cap">Cara memasang, menyambungkan AI, pengingat, sampai menyusun materi, lengkap dengan gambar.</p>
      <div class="inline"><button class="btn dark" data-act="guide">Baca di aplikasi</button><button class="btn" data-act="guide-file">Buka file PDF</button></div></div></div></section>
    <section><div class="group-t"><h2 class="title3">Data</h2></div><div class="group"><div class="field"><p class="cap">Semua data (materi, ceklis, to-do, API key) tersimpan di laptop ini, di folder AppData aplikasi. Tidak ada yang dikirim ke server lain selain LMS kampus dan AI yang kamu pilih.</p></div></div></section>
    <section><div class="group-t"><h2 class="title3">Tentang</h2></div><div class="group"><div class="field" id="upd-field">${updField()}</div><div class="field"><div class="inline" style="justify-content:space-between"><label>Yang baru di versi ${esc(S.appVersion || "")}</label><button class="btn" data-k="yang-baru">Lihat</button></div><p class="cap">Daftar fitur baru dan perbaikan di update terakhir.</p></div><div class="field"><label>Teman Kuliah</label><p class="cap">Dibuat oleh <b>${PEMBUAT}</b>. Bisa dipakai mahasiswa dari kampus mana pun yang memakai LMS Edlink. Aplikasi ini buatan independen, bukan produk resmi Edlink maupun kampus.</p></div></div></section>
  </div>`;
}

/* ---------- tambah materi (drag & drop) ---------- */
function openAdd(prefill){
  UI.plan = { groups: [], skipped: [], prefill: prefill || null, running: false, paste: "" };
  if(prefill && prefill.paths){ planItems(prefill.paths.map(p => ({ path: p })), prefill); } else renderModal();
}
async function planItems(items, prefill){
  const r = await api.planIngest(items, prefill && prefill.meet ? Number(prefill.meet) : weekOf(today()));
  if(!r.ok){ toast(r.error); return; }
  if(!UI.plan) UI.plan = { groups: [], skipped: [], prefill, running: false, paste: "" };
  r.groups.forEach(g => {
    if(prefill && prefill.cid){ g.courseId = prefill.cid; g.meet = Number(prefill.meet) || g.meet; }
    if(!g.meet && sem()) g.meet = weekOf(today());
    const same = UI.plan.groups.find(x => x.courseId === g.courseId && x.meet === g.meet && !x.state);
    if(same) same.items.push(...g.items); else UI.plan.groups.push({ ...g, merge: true });
  });
  UI.plan.skipped.push(...r.skipped);
  renderModal();
}
function renderModal(){
  const m = $("#modal"), P = UI.plan;
  if(!P){ m.hidden = true; m.innerHTML = ""; return; }
  m.hidden = false;
  const ae = document.activeElement, keep = ae && ae.id && m.contains(ae) && /^(INPUT|TEXTAREA)$/.test(ae.tagName) ? { id: ae.id, v: ae.value } : null;
  queueMicrotask(() => { if(keep){ const el = document.getElementById(keep.id); if(el){ el.value = keep.v; el.focus(); } } });
  const cs = sorted();
  const ready = P.groups.filter(g => !g.state || g.state === "err");
  m.innerHTML = `<div class="sheet" role="dialog" aria-modal="true" aria-label="Tambah materi">
    <div class="sheet-h"><div><h2 class="title2">Tambah materi</h2><p class="sub" style="margin-top:4px">Seret file atau folder ke jendela ini, atau tempel link YouTube / ringkasan video.</p></div><button class="circle" data-modal="close" aria-label="Tutup">✕</button></div>
    <div class="sheet-b">
      ${P.groups.map((g,i) => { const exists = g.courseId && g.meet && materi(g.courseId, g.meet); return `<div class="grp">
        <div class="grp-row"><select class="course" data-g="${i}" data-k="courseId" ${g.state==="run"||g.state==="ok"?"disabled":""}><option value="">Pilih mata kuliah</option>${cs.map(c=>`<option value="${c.id}" ${c.id===g.courseId?"selected":""}>${esc(c.nama)}</option>`).join("")}</select>
          <select data-g="${i}" data-k="meet" ${g.state==="run"||g.state==="ok"?"disabled":""}><option value="">Pertemuan</option>${Array.from({length:16},(_,k)=>`<option value="${k+1}" ${k+1===g.meet?"selected":""}>Pertemuan ${k+1}</option>`).join("")}</select>
          ${!g.state?`<button class="iconbtn" data-rmgroup="${i}" aria-label="Hapus dari daftar">${I.trash}</button>`:""}</div>
        <div class="files">${g.items.map(it=>`<span>${esc(it.type==="file"?it.name:it.type==="youtube"?"YouTube: "+it.url:"Teks: "+it.text.slice(0,80))}</span>`).join("")}</div>
        ${exists && !g.state ? `<label class="chk"><input type="checkbox" data-g="${i}" data-k="merge" ${g.merge?"checked":""}><span>Gabungkan dengan materi yang sudah ada</span></label>` : ""}
        ${g.state ? `<span class="state ${g.state}">${g.state==="run"?esc(UI.status.ingest||"Memproses…"):g.state==="ok"?"Selesai, materi tersusun"+(g.warn&&g.warn.length?". Catatan: "+esc(g.warn.join("; ")):""):esc(g.error)}</span>` : ""}
      </div>`; }).join("")}
      ${!P.groups.length ? `<div class="grp" style="text-align:center; padding:28px"><p class="sub">Belum ada file. Seret file/folder ke sini, atau</p><div class="inline" style="justify-content:center"><button class="btn" data-act="pick">Pilih file</button><button class="btn" data-act="pick" data-folder="1">Pilih folder</button></div></div>` : ""}
      <div class="paste"><textarea id="paste" placeholder="Tempel link YouTube atau ringkasan video di sini">${esc(P.paste)}</textarea><div class="inline" style="margin-top:8px"><button class="btn sm" data-act="paste">Tambahkan teks/link</button>${P.groups.length?`<button class="btn sm" data-act="pick">Pilih file lain</button><button class="btn sm" data-act="pick" data-folder="1">Pilih folder</button>`:""}</div></div>
      ${P.skipped.length ? `<p class="skip">Dilewati: ${P.skipped.map(s=>esc(s.name)+" ("+esc(s.reason)+")").join(", ")}</p>` : ""}
    </div>
    <div class="sheet-f"><span class="cap">Diproses ${S.settings.ai.provider === "server" ? "AI Teman Kuliah" : S.settings.ai.provider === "auto" ? "AI otomatis" : (AI_INFO[S.settings.ai.provider]||AI_INFO.gemini).nama}. Biasanya 1 sampai 5 menit per kelompok, tergantung panjang materi.</span>
      ${P.groups.some(g=>g.state==="ok") && !P.running ? `<button class="btn" data-modal="close">Tutup</button>` : ""}
      <button class="btn dark" data-act="run" ${!ready.length||P.running?"disabled":""}>${P.running?"Memproses…":`Susun materi${ready.length>1?" ("+ready.length+")":""}`}</button></div>
  </div>`;
}
async function runPlan(){
  const P = UI.plan; if(!P || P.running) return;
  if(!aiReady()){ toast("Atur AI dulu di Pengaturan."); return; }
  const bad = P.groups.find(g => (!g.state || g.state==="err") && (!g.courseId || !g.meet));
  if(bad){ toast("Pilih mata kuliah dan pertemuan untuk semua kelompok."); return; }
  P.running = true; renderModal();
  for(const g of P.groups){
    if(g.state === "ok") continue;
    g.state = "run"; renderModal();
    const r = await api.runIngest({ courseId: g.courseId, meet: Number(g.meet), items: g.items }, { merge: !!g.merge });
    if(r.ok){ g.state = "ok"; g.warn = r.warnings; } else { g.state = "err"; g.error = r.error; }
    renderModal();
  }
  P.running = false; renderModal();
  const ok = P.groups.filter(g => g.state === "ok");
  if(ok.length === 1 && P.groups.length === 1){ UI.plan = null; renderModal(); go("materi", { course: ok[0].courseId, meet: Number(ok[0].meet), tab: "ringkasan" }); toast("Materi tersusun."); }
}

/* ---------- markdown aman untuk jawaban AI (tanpa tanda * yang berserakan) ---------- */
function md(src){
  const lines = String(src || "").replace(/\r/g, "").split("\n");
  const out = []; let list = null, para = [], table = null;
  const inline = t => esc(t)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+?)\*\*/g, "<b>$1</b>")
    .replace(/__([^_]+?)__/g, "<b>$1</b>")
    .replace(/(^|[\s(])\*([^*\s][^*]*?)\*(?=[\s).,:;!?]|$)/g, "$1<i>$2</i>")
    .replace(/(^|[\s(])_([^_\s][^_]*?)_(?=[\s).,:;!?]|$)/g, "$1<i>$2</i>")
    .replace(/\*\*/g, "").replace(/(^|\s)\*(\s|$)/g, "$1$2");
  const flushP = () => { if (para.length){ out.push(`<p>${inline(para.join(" "))}</p>`); para = []; } };
  const flushL = () => { if (list){ out.push(`<${list.t}>${list.items.map(x => `<li>${inline(x)}</li>`).join("")}</${list.t}>`); list = null; } };
  const flushT = () => { if (!table) return; const cells = r => r.trim().replace(/^\||\|$/g, "").split("|").map(x => x.trim()); const rows = table.filter(r => !/^\s*\|?\s*:?-{2,}/.test(r)); const [h, ...b] = rows; out.push(`<div class="tbl"><table><tr>${cells(h).map(x => `<th>${inline(x)}</th>`).join("")}</tr>${b.map(r => `<tr>${cells(r).map(x => `<td>${inline(x)}</td>`).join("")}</tr>`).join("")}</table></div>`); table = null; };
  for (const raw of lines){
    const l = raw.replace(/\s+$/, "");
    if (/^\s*\|.*\|\s*$/.test(l)){ flushP(); flushL(); (table || (table = [])).push(l); continue; } else flushT();
    let m;
    if (!l.trim()){ flushP(); flushL(); continue; }
    if ((m = l.match(/^\s*#{1,6}\s+(.*)/))){ flushP(); flushL(); out.push(`<h4>${inline(m[1].replace(/\*\*/g, ""))}</h4>`); continue; }
    if (/^\s*(-{3,}|\*{3,})\s*$/.test(l)){ flushP(); flushL(); continue; }
    if ((m = l.match(/^\s*[-*•]\s+(.*)/))){ flushP(); if (!list || list.t !== "ul"){ flushL(); list = { t: "ul", items: [] }; } list.items.push(m[1]); continue; }
    if ((m = l.match(/^\s*\d+[.)]\s+(.*)/))){ flushP(); if (!list || list.t !== "ol"){ flushL(); list = { t: "ol", items: [] }; } list.items.push(m[1]); continue; }
    if (list && /^\s{2,}\S/.test(raw)){ list.items[list.items.length - 1] += " " + l.trim(); continue; }
    flushL(); para.push(l.trim());
  }
  flushP(); flushL(); flushT();
  return out.join("");
}

/* ---------- Pandu Tugas ---------- */
const canPandu = t => t && !t.done && t.source !== "absen" && !/^kuis/i.test(t.jenis || "") && !/^(Kuis|Quiz|Vicon)\b/i.test(t.text || "");
const PANDU_CHIPS = ["Kasih contoh", "Saya belum paham, jelaskan lebih sederhana", "Apa yang harus kulakukan sekarang?"];
const hlBold = s => esc(s || "").replace(/\*\*(.+?)\*\*/g, '<mark class="hl">$1</mark>');
function scrollPandu(){ const l = $("#pdlog"); if (l) l.scrollTop = l.scrollHeight; }
async function panduMulai(id, extra){
  if (UI.panduBusy) return;
  UI.panduBusy = id; render();
  const r = await api.panduStart(id, extra || "");
  UI.panduBusy = null; render(); scrollPandu();
  if (!r.ok){ UI.panduErr = { id, t: r.error }; render(); }
}
async function panduKirim(id, text, mulai){
  const q = String(text || "").trim(); if ((!q && !mulai) || UI.panduLive) return;
  UI.panduLive = { id, text: "", q: mulai ? "" : q }; render(); scrollPandu();
  const r = await api.panduSend(id, q, !!mulai);
  UI.panduLive = null; render(); scrollPandu();
  if (!r.ok) toast(r.error);
}
api.onPanduDelta(d => {
  if (!UI.panduLive || UI.panduLive.id !== d.id) return;
  UI.panduLive.text += d.delta;
  const el = $("#pdlive .md"); if (el){ el.innerHTML = md(UI.panduLive.text); const l = $("#pdlog"); if (l && l.scrollHeight - l.scrollTop - l.clientHeight < 180) l.scrollTop = l.scrollHeight; }
});
function viewPandu(){
  if (!ready()) return viewWelcome();
  const id = UI.panduId, t = S.todos[id], p = (S.pandu || {})[id];
  const crumb = `<div class="pd-crumb"><button class="link" data-go="todo">To-do</button><span>›</span><b>Pandu tugas</b></div>`;
  if (!t && !p) return crumb + `<section class="card pd-start"><h2>Tugas ini sudah tidak ada di To-do.</h2><p class="sub">Mungkin sudah dihapus. Kembali ke To-do untuk memilih tugas lain.</p></section>`;
  const c = findCourse(t ? t.course : null);
  const judul = String((p && p.judul) || (t && t.text) || "").replace(/^(Tugas|Ujian|Kuis):\s*/, "");
  if (!p){
    const err = UI.panduErr && UI.panduErr.id === id ? UI.panduErr.t : "";
    if (UI.panduBusy === id) return crumb + `<section class="card pd-start pd-loading"><p class="thinking"><i></i><i></i><i></i></p><h2>Membaca tugasmu…</h2><p class="sub">Gemini sedang membaca instruksi dosen${(t.files || []).length ? " dan lampirannya" : ""}, lalu memecahnya jadi langkah-langkah. Biasanya kurang dari satu menit.</p></section>`;
    const desc = String(t.desc || "").trim(), files = t.files || [];
    const ada = desc || files.length;
    return crumb + `<section class="card pd-start" ${c ? `data-c="${c.warna}"` : ""}>
      <span class="pd-lbl">${c ? `<i class="dot"></i>${esc(c.nama)}` : "Tugas"}</span>
      <h2>${esc(judul)}</h2>
      ${ada ? `<p class="sub">Instruksi dari dosen sudah terbaca dari LMS${files.length ? `, termasuk ${files.length} lampiran (${files.slice(0, 3).map(f => esc(f.name)).join(", ")})` : ""}. AI akan menjelaskan tugas ini dengan bahasa sederhana, memecahnya jadi langkah-langkah, lalu membimbingmu satu per satu.</p>
        ${desc ? `<blockquote class="pd-quote">${esc(desc.slice(0, 600))}${desc.length > 600 ? "…" : ""}</blockquote>` : ""}
        <label class="pd-l" for="pandu-extra">Tambahan untukmu (opsional)</label><textarea id="pandu-extra" rows="3" placeholder="Misalnya: aku mahasiswa semester 1, kelompok kami belum mulai diskusi, aku masih pemula soal AI."></textarea>`
      : `<p class="sub">Instruksi tugas ini belum terbaca dari LMS. Buka tugasnya di LMS${t.link ? ` (<a href="#" data-open-url="${esc(t.link)}">buka di LMS</a>)` : ""}, salin instruksi dari dosen, lalu tempel di sini.</p>
        <textarea id="pandu-extra" rows="8" placeholder="Tempel instruksi tugas dari dosen di sini. Boleh ditambah keadaanmu, misalnya semester berapa atau sudah sampai mana."></textarea>`}
      ${err ? `<p class="err-t">${esc(err)}</p>` : ""}
      <div class="inline"><button class="btn dark" data-k="pandu-start" data-v="${esc(id)}" ${ada ? "" : 'data-need="1"'}>Mulai pandu</button><span class="cap">Memakai Gemini milikmu. AI membimbing, tidak menuliskan tugasnya untukmu.</span></div>
    </section>`;
  }
  const L = p.langkah || [], nDone = L.filter(x => x.done).length, live = UI.panduLive && UI.panduLive.id === id ? UI.panduLive : null;
  const aktif = L[p.aktif], semua = !aktif;
  const di = t && t.due ? dueInfo(t.due) : null, dd = t && t.due ? dayDiff(t.due) : null;
  const tenggat = dd == null ? "" : dd < 0 ? `Lewat ${-dd} hari` : dd === 0 ? "Tenggat hari ini" : dd === 1 ? "Tenggat besok" : `Tenggat ${dd} hari lagi`;
  const chat = p.chat || [];
  const msgs = chat.map((m, i) => {
    const lbl = i > 0 && m.role === "ai" && m.step !== chat[i - 1].step && L[m.step] ? `<p class="pd-sep">Langkah ${m.step + 1}: ${esc(L[m.step].judul)}</p>` : "";
    return lbl + (m.role === "user" ? `<div class="msg me"><div class="bub">${esc(m.text).replace(/\n/g, "<br>")}</div></div>`
      : `<div class="msg ai"><img class="av" src="logo.svg" alt=""><div class="md">${m.error ? `<p class="err-t">${esc(m.error)}</p>${i === chat.length - 1 && !live ? `<button class="btn sm" data-k="pandu-retry" data-v="${esc(id)}">Coba lagi</button>` : ""}` : md(m.text)}</div></div>`);
  }).join("");
  const liveHTML = live ? `${live.q ? `<div class="msg me"><div class="bub">${esc(live.q).replace(/\n/g, "<br>")}</div></div>` : ""}<div class="msg ai" id="pdlive"><img class="av" src="logo.svg" alt=""><div class="md">${live.text ? md(live.text) : `<p class="thinking"><i></i><i></i><i></i></p>`}</div></div>` : "";
  return crumb + `
  <section class="board pd-board">
    <div class="pd-bmain">
      <span class="pd-blbl">Pandu tugas${p.matkul ? " · " + esc(p.matkul) : ""}</span>
      <h1>${esc(judul)}</h1>
      <span class="pd-bmeta">${p.tenggat ? "Tenggat " + esc(p.tenggat) : "Tanpa tenggat"}${(p.lampiran || []).length ? ` · ${p.lampiran.length} lampiran dibaca` : ""}</span>
      ${p.intinya ? `<p class="say">${hlBold(p.intinya)}</p>` : ""}
    </div>
    <div class="pd-prog">${tenggat ? `<span class="pd-chip ${di && (di.cls === "late" || di.cls === "soon") ? "hot" : ""}">${tenggat}</span>` : ""}
      <div class="pd-big">${semua ? "Selesai" : nDone}<small>${semua ? "" : ` dari ${L.length} langkah`}</small></div>
      <div class="pd-bar"><i style="width:${L.length ? Math.round(nDone / L.length * 100) : 0}%"></i></div>
      <span class="pd-bnote">${semua ? "Semua langkah beres. Jangan lupa kumpulkan di LMS." : "Lanjutkan kapan saja, progres tersimpan."}</span></div>
  </section>
  <div class="pd-cols">
    <div class="pd-left">
      <section class="card pd-card"><h3>Tugas ini dalam bahasa sederhana</h3>
        <dl class="pd-sim">${p.diminta ? `<dt>Yang diminta</dt><dd>${esc(p.diminta)}</dd>` : ""}${p.hasil ? `<dt>Hasil akhir</dt><dd>${esc(p.hasil)}</dd>` : ""}${p.tidakPerlu ? `<dt>Tidak perlu khawatir</dt><dd>${esc(p.tidakPerlu)}</dd>` : ""}</dl>
        ${(p.lampiran || []).map(n => `<div class="pd-lamp"><span class="ic">${esc(String(n).split(".").pop().toUpperCase().slice(0, 4))}</span><div><b>${esc(n)}</b><small>Sudah dibaca AI</small></div></div>`).join("")}
        ${t && t.link ? `<button class="link" data-open-url="${esc(t.link)}">Buka tugas di LMS</button>` : ""}
      </section>
      <section class="card pd-card"><h3>Langkah-langkah</h3>
        <ol class="pd-steps">${L.map((x, i) => `<li class="${x.done ? "done" : i === p.aktif ? "now" : ""}"><button class="ck" data-k="pandu-step" data-v="${i}" aria-label="${x.done ? "Batalkan selesai" : "Tandai selesai"}">${x.done ? "✓" : i + 1}</button><div><span class="t">${esc(x.judul)}</span>${i === p.aktif ? `<small>Sedang dibahas di bimbingan</small>` : x.ket && !x.done ? `<small>${esc(x.ket)}</small>` : ""}</div></li>`).join("")}</ol>
        <div class="pd-reset">${UI.panduConfirm === id ? `<span class="cap">Hapus panduan dan mulai dari awal?</span><button class="btn sm" data-k="pandu-reset" data-v="${esc(id)}">Ya, mulai ulang</button><button class="btn sm line" data-k="pandu-reset-no">Batal</button>` : `<button class="link" data-k="pandu-reset" data-v="${esc(id)}">Mulai ulang panduan</button>`}</div>
      </section>
    </div>
    <section class="card pd-chat">
      <header class="pd-ch"><div><b>Bimbingan</b><span class="cap">${semua ? "Semua langkah selesai" : `Langkah ${p.aktif + 1}: ${esc(aktif.judul)}`}</span></div>
        ${semua ? "" : `<button class="btn sm" data-k="pandu-step" data-v="${p.aktif}" ${live ? "disabled" : ""}>✓ Tandai langkah selesai</button>`}</header>
      <div class="pd-log" id="pdlog">${msgs}${liveHTML}</div>
      ${!live ? `<div class="chips small">${PANDU_CHIPS.map(q => `<button class="chip" data-k="pandu-chip" data-v="${esc(q)}">${esc(q)}</button>`).join("")}</div>` : ""}
      <div class="chat-compose"><textarea id="panduq" rows="1" placeholder="Tulis jawaban atau pertanyaanmu. Enter untuk kirim."></textarea><button class="btn dark" data-k="pandu-send" data-v="${esc(id)}" ${live ? "disabled" : ""}>Kirim</button></div>
      <p class="pd-note"><span>AI membimbing langkah demi langkah, tidak menuliskan tugas untukmu.</span><span>Memakai Gemini milikmu</span></p>
    </section>
  </div>`;
}

/* ---------- Tanya AI (halaman chat) ---------- */
const chatTitle = key => { if (key === "umum") return { t: "Semua mata kuliah", s: "AI melihat daftar semua materimu" }; if (key.startsWith("c:")){ const c = findCourse(key.slice(2)); return { t: c ? c.nama : "Mata kuliah", s: "Semua materi mata kuliah ini", c }; } const k = key.slice(2), [cid, n] = k.split(/_(?=\d+$)/), c = findCourse(cid), m = materi(cid, n); return { t: m ? m.judul : "Materi", s: (c ? c.singkat + ", " : "") + "pertemuan " + n, c }; };
const chatList = key => ((S.chats || {})[key]) || [];
function chatSuggest(key){
  if (key === "umum") return ["Materi apa yang sebaiknya kupelajari dulu minggu ini?", "Ringkas semua yang sudah kupelajari dalam 10 poin", "Buat jadwal belajar 1 minggu untuk persiapan ujian", "Konsep apa saja yang mirip dan sering tertukar?"];
  if (key.startsWith("c:")) return ["Apa benang merah semua materi mata kuliah ini?", "Topik mana yang paling mungkin keluar di ujian?", "Buat 5 soal latihan campuran dari semua pertemuan", "Jelaskan istilah yang paling sering muncul"];
  return ["Jelaskan materi ini dengan bahasa paling sederhana", "Beri contoh nyata dari kehidupan sehari-hari", "Apa poin terpenting yang harus kuingat?", "Uji aku dengan 3 soal, tunggu jawabanku dulu"];
}
function viewTanya(){
  if (!ready()) return viewWelcome();
  const key = UI.chatKey || "umum", T = chatTitle(key), list = chatList(key), live = UI.chatLive && UI.chatLive.key === key ? UI.chatLive : null;
  const recent = Object.entries(S.chats || {}).filter(([k, v]) => k.startsWith("m:") && v.length).sort((a, b) => String(b[1][b[1].length - 1].at).localeCompare(String(a[1][a[1].length - 1].at))).slice(0, 8);
  const item = (k, label, sub, c) => `<button class="cs-item ${k === key ? "on" : ""}" data-k="chat-open" data-v="${esc(k)}" ${c ? `data-c="${c.warna}"` : ""}>${c ? `<i class="dot"></i>` : `<span class="cs-ic">${I.spark}</span>`}<span class="cs-t"><b>${esc(label)}</b><small>${esc(sub)}</small></span></button>`;
  const last = k => { const l = chatList(k); return l.length ? String(l[l.length - 1].text || "").replace(/[#*_`>|]/g, "").slice(0, 60) : ""; };
  const msgs = list.map((mm, i) => mm.role === "user" ? `<div class="msg me"><div class="bub">${esc(mm.text).replace(/\n/g, "<br>")}</div></div>`
    : `<div class="msg ai"><img class="av" src="logo.svg" alt=""><div class="md">${mm.error ? `<p class="err-t">${esc(mm.error)}</p>${i === list.length - 1 && !live ? `<button class="btn sm" data-k="chat-retry" data-v="${esc(key)}">Coba lagi</button>` : ""}` : md(mm.text)}</div></div>`).join("");
  const liveHTML = live ? `<div class="msg ai" id="livemsg"><img class="av" src="logo.svg" alt=""><div class="md">${live.text ? md(live.text) : `<p class="thinking"><i></i><i></i><i></i></p>`}</div></div>` : "";
  const empty = !list.length && !live ? `<div class="chat-empty"><img src="logo.svg" alt="" class="ce-mark"><h2>Mau tanya apa?</h2><p class="sub">${esc(T.s)}. Jawaban disusun dari materimu, jadi tetap nyambung dengan yang diajarkan dosen.</p>
    <div class="chips">${chatSuggest(key).map(q => `<button class="chip" data-k="chat-suggest" data-v="${esc(q)}">${esc(q)}</button>`).join("")}</div></div>` : "";
  return `
  <div class="head"><div><h1 class="large">Tanya AI</h1><p class="lede">Teman belajar yang paham materimu. Tanya, minta contoh, atau minta diuji.</p></div></div>
  <div class="chat">
    <aside class="card chat-side">
      ${item("umum", "Semua mata kuliah", last("umum") || "Pertanyaan umum", null)}
      <p class="cs-h">Mata kuliah</p>
      ${sorted().map(c => item("c:" + c.id, c.singkat, last("c:" + c.id) || c.dosen || "", c)).join("")}
      ${recent.length ? `<p class="cs-h">Materi</p>${recent.map(([k]) => { const t = chatTitle(k); return item(k, t.t, t.s, t.c); }).join("")}` : ""}
    </aside>
    <section class="card chat-main" ${T.c ? `data-c="${T.c.warna}"` : ""}>
      <header class="chat-h"><div class="chat-ht">${T.c ? `<i class="dot"></i>` : ""}<div><b>${esc(T.t)}</b><span class="cap">${esc(T.s)}</span></div></div>
        ${list.length ? `<button class="btn sm line" data-k="chat-clear">Mulai ulang</button>` : ""}</header>
      <div class="chat-log" id="chatlog">${empty}${msgs}${liveHTML}</div>
      ${list.length && !live ? `<div class="chips small">${chatSuggest(key).slice(0, 3).map(q => `<button class="chip" data-k="chat-suggest" data-v="${esc(q)}">${esc(q)}</button>`).join("")}</div>` : ""}
      <div class="chat-compose"><textarea id="chatq" rows="1" placeholder="Tulis pertanyaanmu. Enter untuk kirim, Shift+Enter untuk baris baru."></textarea><button class="btn dark" data-k="chat-send" ${live ? "disabled" : ""}>Kirim</button></div>
    </section>
  </div>`;
}
function scrollChat(){ for (const id of ["#chatlog", "#sidelog"]){ const l = $(id); if (l) l.scrollTop = l.scrollHeight; } }
async function sendChat(text, keyOverride){
  const q = String(text || "").trim(); if (!q || UI.chatLive) return;
  const key = keyOverride || UI.chatKey || "umum";
  UI.chatLive = { key, text: "" }; render(); scrollChat();
  const r = await api.chatSend(key, q);
  UI.chatLive = null; render(); scrollChat();
  if (!r.ok) toast(r.error);
}
api.onChatDelta(d => {
  if (!UI.chatLive || UI.chatLive.key !== d.key) return;
  UI.chatLive.text += d.delta;
  const el = $("#livemsg .md"); if (el){ el.innerHTML = md(UI.chatLive.text); const l = $("#chatlog") || $("#sidelog"); if (l && l.scrollHeight - l.scrollTop - l.clientHeight < 160) l.scrollTop = l.scrollHeight; }
});

// Video yang dibagikan dosen di LMS untuk pertemuan ini
function videoCard(c, n){
  const v = lampOf(c, n).filter(f => f.youtube || f.video); if (!v.length) return "";
  const yid = u => { const m = String(u).match(/[?&]v=([\w-]{11})/); return m ? m[1] : ""; };
  return `<section class="card vids"><h2>Video dari dosen</h2>${v.map(f => `<button class="vid" data-open-url="${esc(f.youtube || f.link)}">${f.youtube ? `<img src="https://i.ytimg.com/vi/${yid(f.youtube)}/mqdefault.jpg" alt="">` : `<span class="vid-ph">${I.book}</span>`}<span class="vid-t"><b>${esc(f.name)}</b><small>${f.youtube ? "YouTube" : "Video dari LMS"}${materi(c.id, n) && (materi(c.id, n).lampiranIds || []).includes(f.id) ? ", sudah masuk ringkasan" : ", belum diringkas"}</small></span></button>`).join("")}</section>`;
}

// Panel Tanya AI di samping halaman materi (percakapan yang sama dengan menu Tanya AI)
function sideChat(ck){
  const list = chatList(ck).slice(-8), live = UI.chatLive && UI.chatLive.key === ck ? UI.chatLive : null;
  const msgs = list.map((mm, i) => mm.role === "user" ? `<div class="msg me"><div class="bub">${esc(mm.text).replace(/\n/g, "<br>")}</div></div>` : `<div class="msg ai"><div class="md">${mm.error ? `<p class="err-t">${esc(mm.error)}</p>${i === list.length - 1 && !live ? `<button class="btn sm" data-k="chat-retry" data-v="${esc(ck)}">Coba lagi</button>` : ""}` : md(mm.text)}</div></div>`).join("");
  const liveHTML = live ? `<div class="msg ai" id="livemsg"><div class="md">${live.text ? md(live.text) : `<p class="thinking"><i></i><i></i><i></i></p>`}</div></div>` : "";
  return `<section class="card side-chat">
    <div class="w-h"><h2><img src="logo.svg" alt="" class="sc-av">Tanya AI</h2><button class="link" data-k="chat-open" data-v="${esc(ck)}">Layar penuh</button></div>
    ${list.length || live ? `<div class="sc-log" id="sidelog">${msgs}${liveHTML}</div>` : `<p class="cap">Tanya bagian yang belum jelas. Jawabannya disusun dari materi ini.</p><div class="chips left">${chatSuggest(ck).slice(0, 3).map(q => `<button class="chip" data-k="side-suggest" data-v="${esc(q)}" data-ck="${esc(ck)}">${esc(q)}</button>`).join("")}</div>`}
    <div class="sc-compose"><textarea id="sideq" rows="1" placeholder="Tanya tentang materi ini" data-ck="${esc(ck)}"></textarea><button class="btn dark sm" data-k="side-send" data-v="${esc(ck)}" ${live ? "disabled" : ""}>Kirim</button></div>
  </section>`;
}

/* ---------- Ujian & latihan ---------- */
const UJI = { uts: [1, 7], uas: [9, 15] };
const UJI_N = { uts: "UTS", uas: "UAS" };
const dayDiff = s => { if (!s) return null; return Math.round((parseD(s) - today()) / DAY); };
function ujianNow(){
  const items = []; courses().forEach(c => ["uts", "uas"].forEach(j => { const u = (c.ujian || {})[j]; const d = u && dayDiff(u.tanggal); if (d != null) items.push({ j, d }); }));
  const up = items.filter(x => x.d >= -1).sort((a, b) => a.d - b.d);
  if (up.length) return { jenis: up[0].j, d: up[0].d };
  return { jenis: rawWeek(today()) <= 8 ? "uts" : "uas", d: null };
}
function ujianStat(c, j){
  const [a, b] = UJI[j]; let ready = 0, file = 0, none = 0;
  for (let n = a; n <= b; n++){ if (materi(c.id, n)) ready++; else if (lampBaru(c, n).length) file++; else none++; }
  return { ready, file, none, total: b - a + 1 };
}
function viewUjian(){
  if (!ready()) return viewWelcome();
  const tab = UI.uTab || "persiapan";
  const tabs = [["persiapan", "Persiapan"], ["hafalan", "Hafalan"], ["latihan", "Latihan soal"], ["simulasi", "Simulasi"], ["kemampuan", "Kemampuanku"]];
  const body = tab === "latihan" ? viewLatihan() : tab === "kemampuan" ? viewKemampuan() : tab === "hafalan" ? viewHafalan() : tab === "simulasi" ? viewSimulasi() : viewPersiapan();
  const nH = statHafal().perlu;
  return `
  <div class="head"><div><h1 class="large">Ujian dan latihan</h1><p class="lede">Bersiap untuk UTS dan UAS: kartu hafalan, latihan soal, simulasi ujian, dan pantau kemampuanmu.</p></div>
    <div class="seg seg-scroll" role="tablist">${tabs.map(([id, l]) => `<button role="tab" aria-pressed="${tab === id}" data-k="utab" data-v="${id}">${l}${id === "hafalan" && nH ? `<span class="n">${nH}</span>` : ""}</button>`).join("")}</div></div>
  ${body}`;
}
function viewPersiapan(){
  const now = ujianNow(), j = UI.uJenis || now.jenis, [a, b] = UJI[j];
  let ready = 0, total = 0, file = 0;
  const cs = sorted(); cs.forEach(c => { const s = ujianStat(c, j); ready += s.ready; total += s.total; file += s.file; });
  const dates = cs.map(c => (c.ujian || {})[j]).filter(u => u && u.tanggal).map(u => u.tanggal).sort();
  const first = dates[0], dd = first ? dayDiff(first) : null;
  const when = first ? `${HARI[parseD(first).getDay()]}, ${parseD(first).getDate()} ${BULAN_L[parseD(first).getMonth()]}` : "Tanggal belum ada di LMS";
  const countdown = dd == null ? "" : dd > 1 ? `${dd} hari lagi` : dd === 1 ? "besok" : dd === 0 ? "hari ini" : "sudah lewat";
  const rk = UI.rangkum && UI.rangkum.endsWith("_" + j) ? UI.rangkum : null;
  const rkData = rk && (S.ujian || {})[rk];
  const rkCourse = rk && findCourse(rk.split("_")[1]);
  return `
  <section class="board exam-board">
    <div class="board-top">
      <div><p class="hi">Ujian berikutnya</p><h1 class="board-date">${UJI_N[j]}${countdown ? `<span class="cd">${countdown}</span>` : ""}</h1><p class="board-status">${esc(when)}. Materi pertemuan ${a} sampai ${b}.</p></div>
      <div class="seg dark-seg" role="group">${["uts", "uas"].map(x => `<button aria-pressed="${x === j}" data-k="ujenis" data-v="${x}">${UJI_N[x]}</button>`).join("")}</div>
    </div>
    <p class="say">Materi siap <mark class="hl">${ready} dari ${total}</mark> pertemuan${file ? `, <mark class="hl">${file} file dosen</mark> belum diringkas` : ""}.${file ? "" : ` <span class="muted">${ready === total ? "Semua materi sudah siap dipelajari." : "Sisanya belum ada file dari dosen."}</span>`}</p>
    <div class="exam-bar"><i style="width:${total ? Math.round(ready / total * 100) : 0}%"></i></div>
    <div class="inline">${file ? `<button class="btn hl-btn" data-k="u-prepare" data-v="">Ringkas semua yang belum (${file})</button>` : ""}<button class="btn line-light" data-k="utab" data-v="latihan" data-scope="${j}">Latihan soal ${UJI_N[j]}</button></div>
    <p class="board-status">${S.settings.ujianOtomatis !== false ? `File dosen yang belum diringkas otomatis disusun saat ${UJI_N[j]} tinggal 14 hari.` : "Ringkas otomatis menjelang ujian sedang mati di Pengaturan."}</p>
  </section>
  ${rkData ? `<section class="card rangkum" ${rkCourse ? `data-c="${rkCourse.warna}"` : ""}><div class="w-h"><h2 class="title2">Rangkuman ${UJI_N[j]}: ${esc(rkCourse ? rkCourse.nama : "")}</h2><button class="btn sm" data-k="rangkum-close">Tutup</button></div><p class="cap">Dibuat dari ${rkData.materi} materi, ${ago(rkData.dibuat)}.</p><div class="md big">${md(rkData.teks)}</div></section>` : ""}
  <div class="exam-grid">${cs.map(c => { const s = ujianStat(c, j), u = (c.ujian || {})[j], rkKey = `${S.current}_${c.id}_${j}`, has = (S.ujian || {})[rkKey];
    const chips = Array.from({ length: b - a + 1 }, (_, i) => { const n = a + i, m = materi(c.id, n), f = lampBaru(c, n).length; return m ? `<button class="pchip ok" data-open="${c.id}|${n}" title="${esc(m.judul)}">P${n}</button>` : f ? `<span class="pchip file" title="File dosen belum diringkas">P${n}</span>` : `<span class="pchip none" title="Belum ada file dari dosen">P${n}</span>`; }).join("");
    return `<section class="card exam-c" data-c="${c.warna}">
      <div class="ec-h">${icon(c)}<div style="min-width:0"><h3>${esc(c.nama)}</h3><p class="cap">${u && u.tanggal ? `${UJI_N[j]} ${fmtShort(parseD(u.tanggal))}${u.jam ? ", " + esc(u.jam) : ""}${u.sumber === "jadwal" ? " (perkiraan dari jadwal)" : ""}` : "Tanggal ujian belum ada"}</p></div></div>
      <div class="pchips">${chips}</div>
      <p class="cap">${s.ready} materi siap${s.file ? `, ${s.file} file dosen belum diringkas` : ""}${s.none ? `, ${s.none} pertemuan belum ada file` : ""}.</p>
      <div class="inline">${s.file ? `<button class="btn sm" data-k="u-prepare" data-v="${c.id}">Ringkas yang belum (${s.file})</button>` : ""}
        ${s.ready ? `<button class="btn sm ${has ? "" : "dark"}" data-k="${has ? "rangkum-open" : "rangkum-make"}" data-v="${c.id}">${has ? "Buka rangkuman" : "Buat rangkuman ujian"}</button>` : ""}
        ${s.ready ? `<button class="btn sm" data-k="lat-quick" data-v="${c.id}" data-scope="${j}">Latihan soal</button>` : ""}</div>
    </section>`; }).join("")}</div>`;
}

// ----- latihan soal
function latList(){ return Object.values(S.latihan || {}).filter(L => L.periode === S.current).sort((x, y) => String(y.dibuat).localeCompare(String(x.dibuat))); }
function viewLatihan(){
  if (UI.latId && (S.latihan || {})[UI.latId]) return viewLatRun(S.latihan[UI.latId]);
  const F = UI.latForm || (UI.latForm = { cid: (sorted()[0] || {}).id, scope: ujianNow().jenis, from: 1, to: 16, pg: 20, essay: 3 });
  const c = findCourse(F.cid) || sorted()[0]; if (c) F.cid = c.id;
  const [fa, fb] = F.scope === "uts" ? UJI.uts : F.scope === "uas" ? UJI.uas : F.scope === "semua" ? [1, 16] : [Number(F.from) || 1, Number(F.to) || 16];
  const nMat = c ? Array.from({ length: fb - fa + 1 }, (_, i) => materi(c.id, fa + i)).filter(Boolean).length : 0;
  const seg = (k, opts) => `<div class="seg" role="group">${opts.map(([v, l]) => `<button aria-pressed="${String(F[k]) === String(v)}" data-k="latf" data-f="${k}" data-v="${v}">${l}</button>`).join("")}</div>`;
  const meetSel = id => `<select id="${id}" class="sel">${Array.from({ length: 16 }, (_, i) => `<option value="${i + 1}" ${Number(F[id === "lf-from" ? "from" : "to"]) === i + 1 ? "selected" : ""}>Pertemuan ${i + 1}</option>`).join("")}</select>`;
  const L = latList().filter(x => !x.sim);
  return `<div class="lat-wrap">
    <section class="card lat-new">
      <h2 class="title2">Buat latihan baru</h2>
      <p class="sub">Soal dibuat AI dari materi yang sudah diringkas. Pilihan ganda dinilai otomatis, essay dinilai AI lengkap dengan masukan.</p>
      <div class="lf"><label>Mata kuliah</label><select id="lf-cid" class="sel">${sorted().map(x => `<option value="${x.id}" ${x.id === F.cid ? "selected" : ""}>${esc(x.nama)}</option>`).join("")}</select></div>
      <div class="lf"><label>Cakupan</label>${seg("scope", [["uts", "UTS (1-7)"], ["uas", "UAS (9-15)"], ["semua", "Semua"], ["pilih", "Pilih sendiri"]])}
        ${F.scope === "pilih" ? `<div class="inline" style="margin-top:8px">${meetSel("lf-from")}<span class="cap">sampai</span>${meetSel("lf-to")}</div>` : ""}</div>
      <div class="lf"><label>Pilihan ganda</label>${seg("pg", [[10, "10"], [20, "20"], [30, "30"], [40, "40"]])}</div>
      <div class="lf"><label>Essay</label>${seg("essay", [[0, "Tidak ada"], [3, "3"], [5, "5"]])}</div>
      <p class="cap">${nMat ? `Diambil dari ${nMat} materi yang sudah diringkas.` : `<span class="err-t">Belum ada materi yang diringkas di cakupan ini.</span> Ringkas file dosen dulu di Persiapan ujian atau halaman Materi.`}</p>
      <button class="btn dark big" data-k="lat-make" ${nMat ? "" : "disabled"}>Buat latihan</button>
    </section>
    <section class="lat-hist">
      <div class="group-t"><h2 class="title3">Riwayat latihan</h2><span class="cap">${L.length} latihan semester ini</span></div>
      ${L.length ? `<div class="group">${L.map(x => { const cc = findCourse(x.cid); return `<div class="row lat-row" data-c="${cc ? cc.warna : ""}"><button class="lat-open" data-k="lat-open" data-v="${x.id}"><span class="dot"></span><span class="txt"><b>${esc(cc ? cc.singkat : "")}: ${esc(x.label)}</b><small>${x.soal.pg.length} pilihan ganda${x.soal.essay.length ? ", " + x.soal.essay.length + " essay" : ""}, ${fmtShort(new Date(x.dibuat))}</small></span>${x.hasil ? `<span class="score-b ${x.hasil.total >= 80 ? "good" : x.hasil.total >= 60 ? "mid" : "low"}">${x.hasil.total}</span>` : `<span class="cap">Belum selesai</span>`}</button><button class="iconbtn" data-k="lat-del" data-v="${x.id}" aria-label="Hapus latihan">${I.trash}</button></div>`; }).join("")}</div>` : `<div class="card empty-c"><p class="sub">Belum ada latihan. Buat satu dari materi yang sudah kamu ringkas.</p></div>`}
    </section>
  </div>`;
}
function viewLatRun(L){
  const c = findCourse(L.cid), H = L.hasil, A = UI.latAns && UI.latAns.id === L.id ? UI.latAns : (UI.latAns = { id: L.id, pg: { ...(L.jawaban.pg || {}) }, essay: { ...(L.jawaban.essay || {}) } });
  const nQ = L.soal.pg.length + L.soal.essay.length, nA = Object.keys(A.pg).length + Object.values(A.essay).filter(x => String(x || "").trim()).length;
  const weak = H ? Object.entries(L.soal.pg.reduce((o, q, i) => { if (!H.pg[i].benar && q.topik) o[q.topik] = (o[q.topik] || 0) + 1; return o; }, {})).sort((a, b) => b[1] - a[1]).slice(0, 5) : [];
  const pgHTML = L.soal.pg.map((q, i) => { const pick = A.pg[i], r = H && H.pg[i];
    return `<div class="lq ${r ? (r.benar ? "is-right" : "is-wrong") : ""}" id="lq${i}"><div class="lq-h"><span class="lq-n">${i + 1}</span>${q.topik ? `<span class="tagc">${esc(q.topik)}</span>` : ""}</div><p class="lq-q">${esc(q.q)}</p>
      <div class="opts">${q.o.map((o, k) => `<button class="opt ${!H && pick === k ? "picked" : ""} ${H && k === q.a ? "right" : ""} ${H && k === pick && pick !== q.a ? "wrong" : ""}" ${H ? "disabled" : `data-k="lat-pick" data-v="${i}|${k}"`}><b>${String.fromCharCode(65 + k)}</b><span>${esc(o)}</span></button>`).join("")}</div>
      ${H ? `<p class="expl">${r.benar ? "Benar." : pick == null ? "Tidak dijawab." : "Belum tepat."} ${esc(q.e)}${!r.benar && q.p && materi(L.cid, q.p) ? ` <button class="link" data-open="${L.cid}|${q.p}">Baca lagi materi P${q.p}</button>` : ""}</p>` : ""}</div>`; }).join("");
  const esHTML = L.soal.essay.map((q, i) => { const r = H && H.essay[i];
    return `<div class="lq essay"><div class="lq-h"><span class="lq-n">E${i + 1}</span>${q.topik ? `<span class="tagc">${esc(q.topik)}</span>` : ""}${r ? `<span class="score-b ${r.skor >= 80 ? "good" : r.skor >= 60 ? "mid" : "low"}">${r.skor}</span>` : ""}</div><p class="lq-q">${esc(q.q)}</p>
      ${H ? `<div class="ans">${esc(A.essay[i] || "(tidak dijawab)").replace(/\n/g, "<br>")}</div><div class="fb-box"><p>${esc(r.umpan)}</p>${r.kurang ? `<p><b>Yang belum ada:</b> ${esc(r.kurang)}</p>` : ""}<p class="cap"><b>Kunci:</b> ${q.kunci.map(esc).join("; ")}</p></div>`
        : `<textarea class="essay-in" data-essay="${i}" placeholder="Tulis jawabanmu di sini">${esc(A.essay[i] || "")}</textarea>`}</div>`; }).join("");
  return `
  <nav class="crumbs">${L.sim ? `<button data-k="sim-back">${I.left}Simulasi ujian</button>` : `<button data-k="lat-back">${I.left}Latihan soal</button>`}</nav>
  <div class="lat-run" ${c ? `data-c="${c.warna}"` : ""}>
    <header class="lat-top"><div><h2 class="title2">${esc(c ? c.nama : "")}</h2><p class="sub">${esc(L.label)}, ${L.soal.pg.length} pilihan ganda${L.soal.essay.length ? " dan " + L.soal.essay.length + " essay" : ""}</p></div></header>
    ${H ? `<section class="board result-board"><div class="rb">
        <div class="rb-score"><b>${H.total}</b><span>nilai akhir</span></div>
        <div class="rb-txt"><p class="say">${H.pgScore != null ? `Pilihan ganda benar <mark class="hl">${H.pg.filter(x => x.benar).length} dari ${H.pg.length}</mark>` : ""}${H.pgScore != null && H.esScore != null ? ", " : ""}${H.esScore != null ? `rata-rata essay <mark class="hl">${Math.round(H.esScore)}</mark>` : ""}.</p>
          ${weak.length ? `<p class="board-status">Perlu diulang: ${weak.map(([t]) => esc(t)).join(", ")}.</p>` : `<p class="board-status">Tidak ada topik yang salah di pilihan ganda. Mantap.</p>`}
          ${H.waktu != null ? `<p class="board-status">Selesai dalam ${jam(H.waktu)} dari ${L.sim.durasi} menit.</p>` : ""}
          <div class="inline">${L.sim ? `<button class="btn hl-btn" data-k="sim-back">Simulasi lagi</button>` : `<button class="btn hl-btn" data-k="lat-again" data-v="${L.id}">Buat latihan baru yang mirip</button>`}${(H.pg.some(x => !x.benar) || (H.essay || []).some(x => x.skor < 70)) ? `<button class="btn line-light" data-k="kartu-lat" data-v="${L.id}" ${L.kartuDibuat ? "disabled" : ""}>${L.kartuDibuat ? "Sudah jadi kartu hafalan" : "Jadikan kartu hafalan"}</button>` : ""}<button class="btn line-light" data-k="chat-from-lat" data-v="${L.id}">Bahas yang salah dengan AI</button></div></div></div></section>
      ${topikHTML(L)}` : ""}
    <div class="lq-list">${pgHTML}${esHTML ? `<h3 class="lq-sec">Essay</h3>${esHTML}` : ""}</div>
    ${H ? "" : `<div class="lat-bar"><div class="lb-prog"><span>Terjawab ${nA} dari ${nQ}</span><div class="exam-bar light"><i style="width:${nQ ? Math.round(nA / nQ * 100) : 0}%"></i></div></div><button class="btn dark" data-k="lat-submit">Kumpulkan dan nilai</button></div>`}
  </div>`;
}

// Hasil per topik (latihan dan simulasi)
function topikHTML(L){
  const H = L.hasil, t = {};
  L.soal.pg.forEach((q, i) => { const k = q.topik || "Lainnya"; const x = t[k] || (t[k] = { b: 0, n: 0, p: new Set() }); x.n++; if (H.pg[i] && H.pg[i].benar) x.b++; if (q.p) x.p.add(q.p); });
  (L.soal.essay || []).forEach((q, i) => { const k = q.topik || "Lainnya"; const x = t[k] || (t[k] = { b: 0, n: 0, p: new Set() }); x.n++; x.b += ((H.essay[i] || {}).skor || 0) / 100; if (q.p) x.p.add(q.p); });
  const rows = Object.entries(t).map(([k, x]) => ({ k, pct: Math.round(x.b / x.n * 100), n: x.n, p: [...x.p].sort((a, b) => a - b) })).sort((a, b) => a.pct - b.pct);
  if (rows.length < 2) return "";
  return `<section class="card topik-c"><div class="w-h"><h2 class="title3">Nilai per topik</h2><span class="cap">Yang paling lemah di atas</span></div>${rows.map(r => `<div class="kb tp"><span>${esc(r.k)}<small>${r.n} soal${r.p.length ? ", P" + r.p.join(", P") : ""}</small></span><div class="kb-t"><i class="${r.pct >= 80 ? "good" : r.pct >= 60 ? "mid" : "low"}" style="width:${r.pct}%"></i></div><b>${r.pct}</b>${r.pct < 60 && r.p[0] && materi(L.cid, r.p[0]) ? `<button class="link" data-open="${L.cid}|${r.p[0]}">Baca P${r.p[0]}</button>` : ""}</div>`).join("")}</section>`;
}

// ----- kemampuan (rapor)
function kemampuan(){
  const out = sorted().map(c => {
    const qz = []; Object.entries(sem().materi).forEach(([k, m]) => { const [cid, n] = k.split(/_(?=\d+$)/); if (cid !== c.id || !(m.kuis || []).length) return; const p = getP(cid, Number(n)); if (p.kuis != null) qz.push({ n: Number(n), pct: Math.round(p.kuis / m.kuis.length * 100), judul: m.judul }); });
    const lat = latList().filter(L => L.cid === c.id && L.hasil);
    const avg = a => a.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length) : null;
    const topik = {}; lat.forEach(L => { L.soal.pg.forEach((q, i) => { if (!L.hasil.pg[i].benar && q.topik) topik[q.topik] = (topik[q.topik] || 0) + 1; }); L.soal.essay.forEach((q, i) => { if (L.hasil.essay[i] && L.hasil.essay[i].skor < 60 && q.topik) topik[q.topik] = (topik[q.topik] || 0) + 1; }); });
    qz.filter(x => x.pct < 60).forEach(x => { topik["Pertemuan " + x.n + ": " + x.judul.slice(0, 40)] = (topik["Pertemuan " + x.n + ": " + x.judul.slice(0, 40)] || 0) + 1; });
    const kuis = avg(qz.map(x => x.pct)), latihan = avg(lat.map(L => L.hasil.total));
    const all = [kuis, latihan].filter(x => x != null);
    return { c, kuis, latihan, nKuis: qz.length, nLat: lat.length, skor: all.length ? Math.round(all.reduce((a, b) => a + b, 0) / all.length) : null, topik: Object.entries(topik).sort((a, b) => b[1] - a[1]).slice(0, 4) };
  });
  return out;
}
function viewKemampuan(){
  const K = kemampuan(), scored = K.filter(x => x.skor != null), overall = scored.length ? Math.round(scored.reduce((a, x) => a + x.skor, 0) / scored.length) : null;
  const best = scored.slice().sort((a, b) => b.skor - a.skor)[0], worst = scored.slice().sort((a, b) => a.skor - b.skor)[0];
  const sar = (S.saran || {})[S.current], endSem = rawWeek(today()) >= 15;
  const bar = (v, lbl) => `<div class="kb"><span>${lbl}</span><div class="kb-t"><i style="width:${v || 0}%"></i></div><b>${v == null ? "-" : v}</b></div>`;
  const R = 54, C = 2 * Math.PI * R;
  return `
  ${endSem ? `<div class="banner">Semester hampir selesai. Ini rapor kemampuanmu dari semua kuis dan latihan soal semester ini.</div>` : ""}
  <section class="board k-board"><div class="rb">
    <div class="rb-ring"><svg viewBox="0 0 130 130" class="ring"><circle class="bg" cx="65" cy="65" r="${R}"/><circle class="fg ${overall >= 100 ? "full" : ""}" cx="65" cy="65" r="${R}" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - (overall || 0) / 100)}" transform="rotate(-90 65 65)"/><text class="big" x="65" y="72" text-anchor="middle">${overall == null ? "-" : overall}</text></svg></div>
    <div class="rb-txt"><p class="hi">Rapor kemampuan semester ini</p>
      <p class="say">${overall == null ? "Belum ada data. Kerjakan kuis di setiap materi atau buat latihan soal supaya kemampuanmu bisa dihitung." : `Rata-rata kemampuanmu <mark class="hl">${overall}</mark>.${best && worst && best !== worst && best.skor - worst.skor >= 5 ? ` Paling kuat di <mark class="hl">${esc(best.c.singkat)}</mark>, perlu latihan lagi di <mark class="hl">${esc(worst.c.singkat)}</mark>.` : ""}`}</p>
      <p class="board-status">Dihitung dari ${K.reduce((a, x) => a + x.nKuis, 0)} kuis materi dan ${K.reduce((a, x) => a + x.nLat, 0)} latihan soal.</p></div></div></section>
  <div class="k-grid">
    <section><div class="group-t"><h2 class="title3">Per mata kuliah</h2><span class="cap">Nilai 0 sampai 100</span></div>
      <div class="group">${K.map(x => `<div class="krow" data-c="${x.c.warna}"><div class="kr-h"><i class="dot"></i><b>${esc(x.c.singkat)}</b><span class="score-b ${x.skor == null ? "" : x.skor >= 80 ? "good" : x.skor >= 60 ? "mid" : "low"}">${x.skor == null ? "belum ada" : x.skor}</span></div>${bar(x.kuis, "Kuis")}${bar(x.latihan, "Latihan")}${x.topik.length ? `<p class="cap">Perlu diulang: ${x.topik.map(([t]) => esc(t)).join(", ")}</p>` : ""}</div>`).join("")}</div></section>
    <section class="card saran"><div class="w-h"><h2 class="title3">Saran belajar dari AI</h2>${sar ? `<span class="cap">${ago(sar.dibuat)}</span>` : ""}</div>
      ${sar ? `<div class="md">${md(sar.teks)}</div>` : `<p class="sub">AI membaca hasil kuis dan latihanmu, lalu memberi tahu apa yang sudah kuat, apa yang perlu diperbaiki, dan rencana belajar 2 minggu.</p>`}
      <button class="btn ${sar ? "" : "dark"}" data-k="saran-make" ${overall == null ? "disabled" : ""}>${sar ? "Perbarui saran" : "Minta saran AI"}</button></section>
  </div>`;
}
function saranStats(){
  return kemampuan().map(x => `${x.c.nama}: rata-rata kuis ${x.kuis == null ? "belum ada" : x.kuis} (${x.nKuis} kuis), rata-rata latihan ${x.latihan == null ? "belum ada" : x.latihan} (${x.nLat} latihan). Topik sering salah: ${x.topik.map(([t, n]) => `${t} (${n}x)`).join(", ") || "tidak ada"}.`).join("\n") + `\nPertemuan saat ini: ${weekOf(today())} dari 16.`;
}

/* aksi fitur belajar */
document.addEventListener("click", async e => {
  const b = e.target.closest("[data-k]"); if (!b) return;
  const k = b.dataset.k, v = b.dataset.v;
  if (k === "pandu-open"){ go("pandu", { panduId: v }); setTimeout(scrollPandu, 0); }
  else if (k === "pandu-start"){ const ta = $("#pandu-extra"); const extra = ta ? ta.value : ""; if (b.dataset.need && !extra.trim()){ toast("Tempel instruksi tugasnya dulu."); return; } panduMulai(v, extra); }
  else if (k === "pandu-send"){ const q = $("#panduq"); const t = q ? q.value : ""; if (q) q.value = ""; panduKirim(v, t); }
  else if (k === "pandu-chip"){ panduKirim(UI.panduId, v); }
  else if (k === "pandu-step"){ const id = UI.panduId; const r = await api.panduStep(id, Number(v)); if (!r.ok){ toast(r.error); return; } if (r.pindah) panduKirim(id, "", true); }
  else if (k === "pandu-retry"){ const r = await api.panduRetry(v); if (!r.ok){ toast(r.error); return; } panduKirim(v, r.q || "", !r.q); }
  else if (k === "pandu-reset"){ if (UI.panduConfirm !== v){ UI.panduConfirm = v; render(); return; } UI.panduConfirm = null; await api.panduDel(v); }
  else if (k === "pandu-reset-no"){ UI.panduConfirm = null; render(); }
  else if (k === "chat-open"){ UI.chatKey = v; if (UI.view !== "tanya") go("tanya"); else render(); scrollChat(); setTimeout(() => { const q = $("#chatq"); if (q) q.focus(); }, 0); }
  else if (k === "chat-send"){ const q = $("#chatq"); const t = q ? q.value : ""; if (q) q.value = ""; sendChat(t); }
  else if (k === "chat-suggest"){ sendChat(v); }
  else if (k === "chat-retry"){ if (UI.chatLive) return; UI.chatLive = { key: v, text: "" }; render(); scrollChat(); const r = await api.chatRetry(v); UI.chatLive = null; render(); scrollChat(); if (!r.ok) toast(r.error); }
  else if (k === "side-send"){ const q = $("#sideq"); const t = q ? q.value : ""; if (q) q.value = ""; sendChat(t, v); }
  else if (k === "side-suggest"){ sendChat(v, b.dataset.ck); }
  else if (k === "chat-clear"){ await api.chatClear(UI.chatKey || "umum"); }
  else if (k === "ask-open"){ const q = ($("#askq") || {}).value || ""; UI.chatKey = "m:" + v; go("tanya"); scrollChat(); if (q.trim()) sendChat(q); }
  else if (k === "utab"){ UI.uTab = v; if (b.dataset.scope) (UI.latForm || (UI.latForm = { cid: (sorted()[0] || {}).id, pg: 20, essay: 3 })).scope = b.dataset.scope; UI.latId = null; render(); window.scrollTo(0, 0); }
  else if (k === "ujenis"){ UI.uJenis = v; render(); }
  else if (k === "u-prepare"){ b.disabled = true; toast("Menyusun materi yang belum diringkas. Progresnya ada di pojok kanan bawah."); const r = await api.prepareUjian(v || null, UI.uJenis || ujianNow().jenis); toast(r.ok ? (r.n ? r.n + " materi selesai diringkas." : "Tidak ada file baru yang bisa diringkas.") : r.error); render(); }
  else if (k === "rangkum-make"){ b.disabled = true; const j = UI.uJenis || ujianNow().jenis; const r = await api.rangkumanUjian(v, j); if (r.ok){ UI.rangkum = `${S.current}_${v}_${j}`; render(); window.scrollTo(0, 0); } else { toast(r.error); render(); } }
  else if (k === "rangkum-open"){ UI.rangkum = `${S.current}_${v}_${UI.uJenis || ujianNow().jenis}`; render(); window.scrollTo(0, 0); }
  else if (k === "rangkum-close"){ UI.rangkum = null; render(); }
  else if (k === "lat-quick"){ UI.uTab = "latihan"; UI.latId = null; UI.latForm = { ...(UI.latForm || { pg: 20, essay: 3 }), cid: v, scope: b.dataset.scope || "semua" }; render(); window.scrollTo(0, 0); }
  else if (k === "latf"){ const F = UI.latForm; F[b.dataset.f] = /^\d+$/.test(v) ? Number(v) : v; render(); }
  else if (k === "lat-make"){ const F = UI.latForm, [fa, fb] = F.scope === "uts" ? UJI.uts : F.scope === "uas" ? UJI.uas : F.scope === "semua" ? [1, 16] : [Math.min(F.from, F.to), Math.max(F.from, F.to)];
    b.disabled = true; b.textContent = "Membuat soal…";
    const r = await api.makeLatihan({ cid: F.cid, from: fa, to: fb, pg: F.pg, essay: F.essay, label: F.scope === "uts" ? "Latihan UTS" : F.scope === "uas" ? "Latihan UAS" : F.scope === "semua" ? "Semua pertemuan" : `Pertemuan ${fa} sampai ${fb}` });
    if (r.ok){ UI.latId = r.id; UI.latAns = null; render(); window.scrollTo(0, 0); } else { toast(r.error); render(); } }
  else if (k === "lat-open"){ UI.latId = v; UI.latAns = null; render(); window.scrollTo(0, 0); }
  else if (k === "lat-back"){ UI.latId = null; render(); }
  else if (k === "lat-del"){ await api.delLatihan(v); toast("Latihan dihapus."); }
  else if (k === "lat-pick"){ const [i, o] = v.split("|").map(Number); UI.latAns.pg[i] = o; const y = window.scrollY; render(); window.scrollTo(0, y); api.saveLatihan(UI.latId, { pg: UI.latAns.pg, essay: UI.latAns.essay }); }
  else if (k === "lat-submit"){ const L = S.latihan[UI.latId], A = UI.latAns, miss = L.soal.pg.length - Object.keys(A.pg).length + L.soal.essay.filter((q, i) => !String(A.essay[i] || "").trim()).length;
    if (miss && !b.dataset.sure){ b.dataset.sure = "1"; b.textContent = `${miss} soal belum dijawab. Klik lagi untuk tetap kumpulkan`; return; }
    b.disabled = true; b.textContent = L.soal.essay.length ? "Menilai essay…" : "Menilai…";
    const r = await api.submitLatihan(UI.latId, { pg: A.pg, essay: A.essay }); if (!r.ok){ toast(r.error); render(); } else { render(); window.scrollTo(0, 0); } }
  else if (k === "lat-again"){ const L = S.latihan[v]; UI.latId = null; UI.latForm = { cid: L.cid, scope: "pilih", from: L.from, to: L.to, pg: L.soal.pg.length, essay: L.soal.essay.length }; render(); window.scrollTo(0, 0); }
  else if (k === "chat-from-lat"){ const L = S.latihan[v], c = findCourse(L.cid); const wrong = L.soal.pg.filter((q, i) => !L.hasil.pg[i].benar).slice(0, 8).map(q => `- ${q.q} (jawaban benar: ${q.o[q.a]})`).join("\n");
    UI.chatKey = "c:" + L.cid; go("tanya"); sendChat(`Aku baru latihan soal ${c ? c.nama : ""} dan salah di soal-soal ini:\n${wrong || "- (tidak ada yang salah di pilihan ganda)"}\nJelaskan konsep di balik soal-soal itu supaya aku paham, lalu beri 3 soal mirip untuk kucoba.`); }
  else if (k === "saran-make"){ b.disabled = true; b.textContent = "AI sedang membaca hasilmu…"; const r = await api.makeSaran(saranStats()); if (!r.ok){ toast(r.error); render(); } }
  else if (k === "theme"){ const cur = S.settings.theme || "auto", dark = cur === "dark" || (cur === "auto" && matchMedia("(prefers-color-scheme: dark)").matches); await api.saveSettings({ theme: v || (dark ? "light" : "dark") }); }
});
document.addEventListener("keydown", e => {
  if (e.target.id === "chatq" && e.key === "Enter" && !e.shiftKey){ e.preventDefault(); const t = e.target.value; e.target.value = ""; sendChat(t); }
  if (e.target.id === "panduq" && e.key === "Enter" && !e.shiftKey){ e.preventDefault(); const t = e.target.value; e.target.value = ""; panduKirim(UI.panduId, t); }
  if (e.target.id === "sideq" && e.key === "Enter" && !e.shiftKey){ e.preventDefault(); const t = e.target.value; e.target.value = ""; sendChat(t, e.target.dataset.ck); }
});
document.addEventListener("input", e => {
  if (e.target.id === "chatq" || e.target.id === "sideq" || e.target.id === "panduq"){ e.target.style.height = "auto"; e.target.style.height = Math.min(180, e.target.scrollHeight) + "px"; }
  if (e.target.dataset && e.target.dataset.essay !== undefined && UI.latAns){ UI.latAns.essay[e.target.dataset.essay] = e.target.value; clearTimeout(UI._essT); UI._essT = setTimeout(() => api.saveLatihan(UI.latId, { pg: UI.latAns.pg, essay: UI.latAns.essay }), 800);
    const bar = $(".lb-prog span"); if (bar){ const L = S.latihan[UI.latId]; const nA = Object.keys(UI.latAns.pg).length + Object.values(UI.latAns.essay).filter(x => String(x || "").trim()).length; bar.textContent = `Terjawab ${nA} dari ${L.soal.pg.length + L.soal.essay.length}`; } }
});
document.addEventListener("change", e => {
  if (!UI.latForm) return;
  if (e.target.id === "lf-cid"){ UI.latForm.cid = e.target.value; render(); }
  if (e.target.id === "lf-from"){ UI.latForm.from = Number(e.target.value); render(); }
  if (e.target.id === "lf-to"){ UI.latForm.to = Number(e.target.value); render(); }
});
function applyTheme(){ const t = S && S.settings.theme || "auto"; if (t === "auto") delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = t; }

/* =====================================================================
   1.0.17: gambar di ringkasan, dengarkan, bagikan, kartu hafalan, rencana belajar,
   peta konsep, simulasi ujian, dan halaman "Yang baru"
   ===================================================================== */
const HP = !!(api && api.platform);
const mnt = x => { x = Math.round(x); if (x < 60) return x + " menit"; const j = Math.floor(x / 60), m = x % 60; return j + " jam" + (m ? " " + m + " menit" : ""); };
const tglPanjang = d => `${HARI[d.getDay()]}, ${d.getDate()} ${BULAN_L[d.getMonth()]}`;
const polos = s => String(s || "").replace(/\*\*/g, "").replace(/\s+/g, " ").trim();

/* ---------- lapisan (overlay) umum: bagikan, gambar besar, yang baru ---------- */
function lapisan(html, cls){
  let el = $("#lapisan");
  if (!el){ el = document.createElement("div"); el.id = "lapisan"; document.body.appendChild(el); }
  if (!html){ el.hidden = true; el.innerHTML = ""; el.className = ""; return; }
  el.className = "lapisan " + (cls || ""); el.hidden = false; el.innerHTML = html;
}
document.addEventListener("click", e => {
  const el = $("#lapisan"); if (!el || el.hidden) return;
  if (e.target === el || e.target.closest("[data-tutup-lapisan]")){ const yb = el.classList.contains("yb"); lapisan(null); if (yb) tandaiYangBaru(); }
});
document.addEventListener("keydown", e => { const el = $("#lapisan"); if (e.key === "Escape" && el && !el.hidden){ const yb = el.classList.contains("yb"); lapisan(null); if (yb) tandaiYangBaru(); } });

/* ---------- gambar di ringkasan ---------- */
UI.gimg = {};
const gKey = (key, m) => key + ":" + (m && m.gambarV || 0);
function figHTML(key, m, g){
  const src = (UI.gimg[gKey(key, m)] || {})[g.id];
  const rasio = g.w && g.h ? `aspect-ratio:${g.w}/${g.h};` : "";
  return `<figure class="fig"><button class="fig-img" data-k="fig-open" data-v="${esc(key)}|${esc(g.id)}" aria-label="Perbesar gambar" style="${rasio}">${src ? `<img src="${src}" alt="${esc(g.ket || g.dari || "Gambar materi")}">` : `<span class="fig-load"></span>`}</button>
    <figcaption>${g.ket ? `<span>${esc(g.ket)}</span>` : ""}${g.dari ? `<small>${esc(g.dari)}</small>` : ""}</figcaption></figure>`;
}
function videoChip(v){
  const t = Number(v.t) || 0, lbl = (t >= 3600 ? Math.floor(t / 3600) + ":" : "") + String(Math.floor(t % 3600 / 60)).padStart(2, "0") + ":" + String(t % 60).padStart(2, "0");
  return `<a class="ytchip" href="#" data-open-url="https://www.youtube.com/watch?v=${esc(v.yt)}&t=${t}s"><img src="https://i.ytimg.com/vi/${esc(v.yt)}/mqdefault.jpg" alt=""><span><b>Tonton penjelasannya di video</b><small>Mulai menit ${lbl}${v.judul ? ", " + esc(v.judul) : ""}</small></span></a>`;
}
function isiGambar(){
  const c = findCourse(UI.course), m = c && UI.meet && materi(c.id, UI.meet);
  if (UI.view !== "materi" || !m || !m.gambarV || UI.tab !== "ringkasan") return;
  const key = c.id + "_" + UI.meet, gk = gKey(key, m);
  // Gambar yang filenya hilang (misalnya data dipindah tanpa file gambar) disembunyikan, bukan dibiarkan memuat terus
  const pasang = img => document.querySelectorAll(".fig-img").forEach(b => { const id = (b.dataset.v || "").split("|")[1]; if (img[id]){ if (!b.querySelector("img")) b.innerHTML = `<img src="${img[id]}" alt="">`; } else { const f = b.closest("figure"); if (f) f.hidden = true; } });
  if (UI.gimg[gk]) return pasang(UI.gimg[gk]);
  if (UI.gimgBusy === gk) return; UI.gimgBusy = gk;
  api.gambarGet(key).then(r => { UI.gimgBusy = null; if (r && r.ok){ UI.gimg[gk] = r.img || {}; pasang(UI.gimg[gk]); } }).catch(() => { UI.gimgBusy = null; });
}
function bukaGambar(key, id){
  const c = findCourse(UI.course), m = c && materi(c.id, UI.meet); if (!m) return;
  const g = (m.bagian || []).flatMap(b => b.gambar || []).find(x => x.id === id), src = (UI.gimg[gKey(key, m)] || {})[id];
  if (!src) return;
  lapisan(`<div class="lb"><img src="${src}" alt=""><div class="lb-cap">${g && g.ket ? `<b>${esc(g.ket)}</b>` : ""}${g && g.dari ? `<span>${esc(g.dari)}</span>` : ""}</div><button class="circle lb-x" data-tutup-lapisan aria-label="Tutup">✕</button></div>`, "gelap");
}

/* ---------- dengarkan ringkasan (dibacakan seperti podcast) ---------- */
const Suara = (() => {
  // Dipilih setiap kali dipakai: HP Android memakai jembatan TKSuara (WebView tidak punya speechSynthesis yang berfungsi)
  const webS = () => (window.TKSuara ? null : window.speechSynthesis) || null;
  const st = { on: false, key: null, judul: "", parts: [], i: 0, j: 0, sub: [], jalan: false, rate: 1 };
  const nat = () => window.TKSuara || null;
  const voices = () => { try { const w = webS(); return w ? w.getVoices() : []; } catch (e) { return []; } };
  const pilihSuara = () => { const vs = voices(), want = (S.settings.suara || {}).voice; return vs.find(v => v.voiceURI === want) || vs.find(v => /^id([-_]|$)/i.test(v.lang)) || null; };
  const adaIndonesia = () => voices().some(v => /^id([-_]|$)/i.test(v.lang));
  const didukung = () => !!webS() || !!nat();
  const pecah = text => {
    const out = [];
    for (const s of polos(text).match(/[^.!?;:]+[.!?;:]*|.+$/g) || []){
      let x = s.trim(); if (!x) continue;
      while (x.length > 220){ let cut = x.lastIndexOf(",", 200); if (cut < 80) cut = x.lastIndexOf(" ", 200); if (cut < 40) cut = 200; out.push(x.slice(0, cut + 1).trim()); x = x.slice(cut + 1).trim(); }
      if (x) out.push(x);
    }
    return out;
  };
  function susun(m, c, n){
    const parts = [{ sec: -1, label: "Pembuka", text: `${m.judul}. ${c ? c.nama + ", pertemuan " + n + "." : ""} ${m.ringkas || ""}` }];
    (m.bagian || []).forEach((b, i) => {
      let t = `${b.h}. ${b.p || ""} ${(b.list || []).map(x => x.replace(/[.;]?$/, ".")).join(" ")}`;
      if (b.table && b.table.length > 1){ const [h, ...rows] = b.table; t += " " + rows.slice(0, 8).map(r => r.map((x, k) => (h[k] ? h[k] + ": " : "") + x).join(", ") + ".").join(" "); }
      if (b.contoh) t += " Contohnya, " + b.contoh;
      parts.push({ sec: i, label: b.h, text: t });
    });
    return parts;
  }
  function tandai(){
    document.querySelectorAll(".sec.dibaca, .summary.dibaca").forEach(x => x.classList.remove("dibaca"));
    const c = findCourse(UI.course); if (!st.on || !c || UI.view !== "materi" || UI.tab !== "ringkasan" || c.id + "_" + UI.meet !== st.key) return;
    const p = st.parts[st.i]; if (!p) return;
    const el = p.sec < 0 ? $(".summary") : document.querySelector(`.sec[data-sec="${p.sec}"]`);
    if (el){ el.classList.add("dibaca"); if (st.gulir){ st.gulir = false; el.scrollIntoView({ behavior: "smooth", block: "center" }); } }
  }
  function bar(){
    let el = $("#player");
    if (!st.on){ if (el) el.remove(); document.body.classList.remove("ada-player"); return; }
    if (!el){ el = document.createElement("div"); el.id = "player"; el.className = "player"; el.setAttribute("role", "region"); el.setAttribute("aria-label", "Pemutar ringkasan"); document.body.appendChild(el); }
    document.body.classList.add("ada-player");
    const p = st.parts[st.i] || {};
    const tanpaId = webS() && voices().length && !adaIndonesia() && !(S.settings.suara || {}).voice;
    el.innerHTML = `<div class="pl-in">
      <button class="circle sm" data-k="sr-prev" aria-label="Bagian sebelumnya" ${st.i <= 0 ? "disabled" : ""}>${I.left}</button>
      <button class="circle pl-play" data-k="sr-toggle" aria-label="${st.jalan ? "Jeda" : "Putar"}">${st.jalan ? '<svg viewBox="0 0 24 24"><rect x="6" y="5" width="4" height="14" rx="1.2" fill="currentColor"/><rect x="14" y="5" width="4" height="14" rx="1.2" fill="currentColor"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M8 5.5v13l11-6.5z" fill="currentColor"/></svg>'}</button>
      <button class="circle sm" data-k="sr-next" aria-label="Bagian berikutnya" ${st.i >= st.parts.length - 1 ? "disabled" : ""}>${I.right}</button>
      <div class="pl-txt"><b>${esc(st.judul)}</b><span>${st.i + 1} dari ${st.parts.length}: ${esc(p.label || "")}</span>${tanpaId ? `<small class="err-t">Suara bahasa Indonesia belum terpasang. Lihat Pengaturan, bagian Belajar.</small>` : ""}<i class="pl-prog" style="width:${Math.round((st.i + (st.sub.length ? st.j / st.sub.length : 0)) / Math.max(1, st.parts.length) * 100)}%"></i></div>
      <button class="btn sm pl-rate" data-k="sr-rate" title="Kecepatan">${String(st.rate).replace(".", ",")}x</button>
      <button class="circle sm" data-k="sr-stop" aria-label="Tutup pemutar">✕</button></div>`;
  }
  function bicara(){
    if (!st.on || !st.jalan) return;
    const p = st.parts[st.i]; if (!p){ selesai(); return; }
    if (!st.sub.length) st.sub = pecah(p.text);
    if (st.j >= st.sub.length){ st.i++; st.j = 0; st.sub = []; st.gulir = true; tandai(); bar(); return bicara(); }
    const teks = st.sub[st.j], tok = st.tok = Math.random();
    const lanjut = () => { if (tok !== st.tok || !st.jalan) return; st.j++; bar(); bicara(); };
    const web = webS();
    if (web){
      const u = st.u = new SpeechSynthesisUtterance(teks); // disimpan supaya tidak dibuang sebelum selesai (onend tidak terpanggil) u.lang = "id-ID"; const v = pilihSuara(); if (v) try { u.voice = v; } catch (e) {} u.rate = st.rate;
      u.onend = lanjut; u.onerror = e => { if (e.error === "interrupted" || e.error === "canceled") return; if (tok !== st.tok) return; berhenti(); toast("Suara tidak bisa diputar (" + (e.error || "galat") + "). Cek suara di Pengaturan, bagian Belajar."); };
      web.speak(u);
    } else if (nat()){
      // Mesin suara HP yang tidak menjawab (belum terpasang/rusak): berhenti dengan pesan, jangan diam selamanya
      const batas = setTimeout(() => { if (tok !== st.tok) return; berhenti(); toast("Suara HP tidak menjawab. Pastikan Google Text-to-speech terpasang dan bahasa Indonesia diunduh."); }, Math.max(12000, teks.length * 220 / st.rate));
      window.__tkSuara = (ev, id) => { if (String(id) !== String(tok)) return; clearTimeout(batas); if (ev === "error"){ berhenti(); toast("Suara HP gagal membacakan teks."); return; } lanjut(); };
      try { nat().bicara(teks, st.rate, String(tok)); } catch (e) { clearTimeout(batas); toast("Suara HP tidak bisa dipakai."); berhenti(); }
    }
  }
  function henti(){ st.tok = 0; try { const web = webS(); if (web) web.cancel(); else if (nat()) nat().stop(); } catch (e) {} }
  function selesai(){ henti(); st.jalan = false; st.i = Math.max(0, st.parts.length - 1); st.j = st.sub.length; bar(); toast("Ringkasan selesai dibacakan."); }
  function mulai(key){
    if (!didukung()){ toast(HP ? "HP ini belum bisa membacakan teks. Perbarui Android System WebView atau Google Text-to-speech di Play Store." : "Perangkat ini belum mendukung suara."); return; }
    const [cid, n] = key.split(/_(?=\d+$)/), m = materi(cid, n), c = findCourse(cid); if (!m) return;
    henti();
    Object.assign(st, { on: true, key, judul: m.judul, parts: susun(m, c, n), i: 0, j: 0, sub: [], jalan: true, rate: Number((S.settings.suara || {}).rate) || 1, gulir: true });
    bar(); tandai(); bicara();
  }
  function berhenti(){ henti(); st.on = false; st.jalan = false; bar(); tandai(); }
  function toggle(){ if (st.jalan){ st.jalan = false; henti(); } else { st.jalan = true; bicara(); } bar(); }
  function loncat(d){ henti(); st.i = Math.max(0, Math.min(st.parts.length - 1, st.i + d)); st.j = 0; st.sub = []; st.gulir = true; tandai(); bar(); if (st.jalan) bicara(); }
  function laju(){ const L = [0.8, 1, 1.25, 1.5, 1.75, 2]; st.rate = L[(L.indexOf(st.rate) + 1) % L.length] || 1; api.saveSettings({ suara: { rate: st.rate } }); if (st.jalan){ henti(); st.jalan = true; bicara(); } bar(); }
  function dariBagian(key, sec){ if (!st.on || st.key !== key) mulai(key); henti(); st.i = Math.max(0, st.parts.findIndex(p => p.sec === sec)); st.j = 0; st.sub = []; st.jalan = true; st.gulir = true; tandai(); bar(); bicara(); }
  try { const w = webS(); if (w) w.onvoiceschanged = () => { if (UI.view === "pengaturan") render(); }; } catch (e) {}
  return { mulai, berhenti, toggle, loncat, laju, dariBagian, tandai, bar, voices, adaIndonesia, didukung, aktif: () => st.on, key: () => st.key, jalan: () => st.jalan };
})();

/* ---------- bagikan ringkasan ---------- */
function teksWA(key){
  const [cid, n] = key.split(/_(?=\d+$)/), m = materi(cid, n), c = findCourse(cid); if (!m) return "";
  let t = `*${polos(m.judul)}*\n_${c ? c.nama : ""}, pertemuan ${n}_\n\n${polos(m.ringkas)}\n`;
  const poin = (m.bagian || []).map(b => polos(b.h)).filter(Boolean);
  if (poin.length) t += `\n*Yang dibahas:*\n${poin.slice(0, 10).map((p, i) => `${i + 1}. ${p}`).join("\n")}${poin.length > 10 ? `\n...dan ${poin.length - 10} bagian lagi` : ""}\n`;
  const ist = (m.istilah || []).slice(0, 6);
  if (ist.length) t += `\n*Istilah penting:*\n${ist.map(([a, b]) => `• ${polos(a)}: ${polos(b).slice(0, 120)}`).join("\n")}\n`;
  t += `\nDibuat dengan Teman Kuliah · temankuliah.netlify.app`;
  return t.length > 3500 ? t.slice(0, 3400) + "…\n\nDibuat dengan Teman Kuliah · temankuliah.netlify.app" : t;
}
function teksLengkap(key){
  const [cid, n] = key.split(/_(?=\d+$)/), m = materi(cid, n), c = findCourse(cid); if (!m) return "";
  const out = [`${polos(m.judul)}`, `${c ? c.nama : ""}, pertemuan ${n}`, "", polos(m.ringkas), ""];
  (m.bagian || []).forEach(b => { out.push(polos(b.h).toUpperCase()); if (b.p) out.push(polos(b.p)); (b.list || []).forEach(x => out.push("- " + polos(x))); if (b.table) b.table.forEach(r => out.push(r.map(polos).join(" | "))); if (b.contoh) out.push("Contoh: " + polos(b.contoh)); if (b.note) out.push(polos(b.note)); out.push(""); });
  if ((m.istilah || []).length){ out.push("ISTILAH"); m.istilah.forEach(([a, b]) => out.push(`- ${polos(a)}: ${polos(b)}`)); out.push(""); }
  out.push("Dibuat dengan Teman Kuliah · temankuliah.netlify.app");
  return out.join("\n");
}
function bukaBagikan(key){
  const m = sem().materi[key]; if (!m) return;
  const opsi = [
    ...(HP ? [] : [["bg-pdf", "Simpan sebagai PDF", "Ringkasan lengkap dengan gambar, istilah, dan latihan kuis. Enak dibaca ulang atau dicetak."],
      ["bg-png", "Simpan sebagai gambar", "Kartu ringkas (judul, poin penting, istilah kunci) yang pas dikirim ke grup kelas."]]),
    ["bg-wa", "Kirim ke WhatsApp", "Ringkasan singkat dalam bentuk teks, langsung terbuka di WhatsApp."],
    ["bg-copy", "Salin teks ringkasan", "Seluruh isi ringkasan sebagai teks biasa, siap ditempel di mana saja."]
  ];
  lapisan(`<div class="sheet kecil" role="dialog" aria-modal="true" aria-label="Bagikan ringkasan"><div class="sheet-h"><div><h2 class="title2">Bagikan ringkasan</h2><p class="sub" style="margin-top:4px">${esc(m.judul)}</p></div><button class="circle" data-tutup-lapisan aria-label="Tutup">✕</button></div>
    <div class="sheet-b bg-list">${opsi.map(([k, l, d]) => `<button class="bg-opt" data-k="${k}" data-v="${esc(key)}"><b>${l}</b><span>${d}</span></button>`).join("")}
    ${HP ? `<p class="cap">Simpan sebagai PDF atau gambar tersedia di aplikasi laptop.</p>` : ""}</div></div>`);
}

/* ---------- kartu hafalan ---------- */
const JEDA_H = [0, 1, 3, 7, 14, 30, 60];
const kartuS = () => ((S.hafalan || {}).kartu || {});
const hariStr = () => ymd(today());
function antreanHafal(cid){
  const K = kartuS(), t = hariStr(), H = S.hafalan || {};
  const semua = Object.entries(K).filter(([, k]) => k.p === S.current && (!cid || k.cid === cid));
  const tempo = semua.filter(([, k]) => k.due && k.due <= t).sort((a, b) => a[1].due.localeCompare(b[1].due) || a[1].box - b[1].box).map(([id]) => id);
  const sisa = Math.max(0, (H.batasBaru == null ? 20 : Number(H.batasBaru)) - (((H.hari || {})[t] || {}).baru || 0));
  const baru = semua.filter(([, k]) => !k.due).sort((a, b) => a[1].n - b[1].n || String(a[1].cid).localeCompare(String(b[1].cid)) || (a[1].t === "istilah" ? -1 : 1)).slice(0, sisa).map(([id]) => id);
  return { tempo, baru, semua: semua.length };
}
function statHafal(){
  const K = Object.values(kartuS()).filter(k => k.p === S.current), H = S.hafalan || {}, t = hariStr();
  let streak = 0; for (let i = 0; i < 400; i++){ const d = ymd(new Date(today().getTime() - i * DAY)); if (((H.hari || {})[d] || {}).ulang) streak++; else if (i > 0) break; }
  const a = antreanHafal();
  return { total: K.length, hafal: K.filter(k => k.box >= 4).length, belum: K.filter(k => !k.due).length, perlu: a.tempo.length + a.baru.length, tempo: a.tempo.length, baru: a.baru.length, streak, hari: (H.hari || {})[t] || { ulang: 0, baru: 0, ingat: 0 } };
}
const jedaTeks = (k, r) => { const box = r === 0 ? 0 : r === 1 ? Math.max(1, k.box || 0) : !k.due ? 2 : Math.min(6, (k.box || 0) + 1); const d = r === 0 ? 0 : r === 1 ? Math.max(1, Math.round(JEDA_H[box] / 2)) : JEDA_H[box]; return d === 0 ? "lagi nanti" : d === 1 ? "besok" : d < 30 ? d + " hari" : Math.round(d / 30) + " bulan"; };
function viewHafalan(){
  const F = UI.hfCid || "", s = statHafal(), H = S.hafalan || {};
  const ses = UI.hf;
  if (ses && ses.q.length && ses.i < ses.q.length) return viewSesiHafal(ses);
  if (ses && ses.q.length && ses.i >= ses.q.length){
    const n = ses.dinilai;
    return `<section class="board hf-done"><div><p class="hi">Sesi selesai</p><h1 class="board-date">${n} kartu diulang</h1>
      <p class="say">Ingat <mark class="hl">${ses.ingat}</mark>, ragu ${ses.ragu}, lupa ${ses.lupa}.${s.streak > 1 ? ` Kamu sudah <mark class="hl">${s.streak} hari berturut-turut</mark> mengulang kartu.` : ""}</p>
      <div class="inline">${s.perlu ? `<button class="btn hl-btn" data-k="hf-start">Lanjut ${s.perlu} kartu lagi</button>` : ""}<button class="btn line-light" data-k="hf-close">Kembali</button></div></div></section>`;
  }
  const per = sorted().map(c => { const a = antreanHafal(c.id); const tot = Object.values(kartuS()).filter(k => k.p === S.current && k.cid === c.id); return { c, perlu: a.tempo.length + a.baru.length, total: tot.length, hafal: tot.filter(k => k.box >= 4).length }; }).filter(x => x.total);
  const a = antreanHafal(F || null), perlu = a.tempo.length + a.baru.length;
  return `
  <section class="board hf-board"><div class="board-top"><div><p class="hi">Kartu hafalan</p><h1 class="board-date">${s.perlu ? s.perlu + " kartu hari ini" : s.total ? "Hari ini beres" : "Belum ada kartu"}</h1>
    <p class="board-status">${s.total ? `${s.total} kartu dari istilah dan kuis materimu, ${s.hafal} sudah hafal.` : "Kartu dibuat otomatis dari istilah dan soal kuis setiap materi yang sudah diringkas."}</p></div>
    ${s.streak ? `<div class="hf-streak"><b>${s.streak}</b><span>hari<br>berturut-turut</span></div>` : ""}</div>
    <p class="say">${s.total ? `Kartu muncul lagi tepat sebelum kamu lupa: <mark class="hl">makin sering ingat, makin jarang muncul</mark>. Cukup 5 sampai 10 menit sehari.` : "Ringkas materi dulu, kartunya langsung muncul di sini."}</p>
    <div class="inline">${sorted().length > 1 && s.total ? `<select class="sel dark-sel" id="hf-cid" aria-label="Pilih mata kuliah"><option value="">Semua mata kuliah</option>${per.map(x => `<option value="${x.c.id}" ${x.c.id === F ? "selected" : ""}>${esc(x.c.singkat)} (${x.perlu})</option>`).join("")}</select>` : ""}
      <button class="btn hl-btn" data-k="hf-start" ${perlu ? "" : "disabled"}>${perlu ? `Mulai ${perlu} kartu` : "Tidak ada kartu yang perlu diulang"}</button></div>
    <p class="board-status">Hari ini: ${s.hari.ulang || 0} kartu diulang, ${s.tempo} jatuh tempo, ${s.baru} kartu baru.</p>
  </section>
  ${per.length ? `<section><div class="group-t"><h2 class="title3">Per mata kuliah</h2><label class="cap" for="hf-batas">Kartu baru per hari <select id="hf-batas" class="sel mini">${[5, 10, 20, 30, 50].map(v => `<option value="${v}" ${Number(H.batasBaru == null ? 20 : H.batasBaru) === v ? "selected" : ""}>${v}</option>`).join("")}</select></label></div>
    <div class="group">${per.map(x => `<div class="krow hf-row" data-c="${x.c.warna}"><div class="kr-h"><i class="dot"></i><b>${esc(x.c.singkat)}</b><span class="cap">${x.total} kartu, ${x.hafal} hafal</span>${x.perlu ? `<button class="btn sm" data-k="hf-start" data-v="${x.c.id}">Ulang ${x.perlu}</button>` : `<span class="score-b good">beres</span>`}</div><div class="kb-t"><i style="width:${Math.round(x.hafal / x.total * 100)}%"></i></div></div>`).join("")}</div></section>` : ""}`;
}
function viewSesiHafal(ses){
  const id = ses.q[ses.i], k = kartuS()[id];
  if (!k){ ses.i++; return viewHafalan(); }
  const c = findCourse(k.cid), buka = ses.buka;
  const opsi = k.o && k.o.length ? `<div class="hf-opts">${k.o.map((o, j) => `<div class="hf-o ${buka && j === k.a ? "right" : ""}"><b>${String.fromCharCode(65 + j)}</b><span>${esc(o)}</span></div>`).join("")}</div>` : "";
  return `<div class="hf-sesi" ${c ? `data-c="${c.warna}"` : ""}>
    <div class="hf-top"><button class="btn sm line" data-k="hf-close">${I.left}Selesai dulu</button><div class="exam-bar light hf-bar"><i style="width:${Math.round(ses.i / ses.q.length * 100)}%"></i></div><span class="cap">${ses.i + 1} / ${ses.q.length}</span></div>
    <section class="card hf-card ${buka ? "buka" : ""}">
      <div class="hf-meta"><span class="tag"><i class="dot"></i>${esc(c ? c.singkat : "")}, P${k.n || "?"}</span><span class="cap">${k.t === "istilah" ? "Istilah" : k.t === "salah" ? "Soal yang pernah salah" : "Soal kuis"}${!k.due ? " · kartu baru" : ""}</span></div>
      <div class="hf-depan">${k.t === "istilah" ? `<p class="cap">Apa arti istilah ini?</p><h2>${esc(k.d)}</h2>` : `<p class="hf-q">${esc(k.d)}</p>`}${opsi}</div>
      ${buka ? `<div class="hf-belakang">${k.t === "istilah" ? `<p>${rich(k.b)}</p>` : k.o && k.o.length ? `<p><b>Jawaban: ${String.fromCharCode(65 + (k.a || 0))}. ${esc(k.b)}</b></p>${k.e ? `<p class="cap">${esc(k.e)}</p>` : ""}` : `<p class="cap">Poin yang harus ada:</p><p>${esc(k.b).replace(/\n/g, "<br>")}</p>`}
        <button class="link" data-open="${k.cid}|${k.n}">Buka materi pertemuan ${k.n}</button></div>` : ""}
    </section>
    ${buka ? `<div class="hf-rate">${[[0, "Lupa", "lupa"], [1, "Ragu", "ragu"], [2, "Ingat", "ingat"]].map(([r, l, cls]) => `<button class="hf-r ${cls}" data-k="hf-rate" data-v="${r}"><b>${l}</b><span>${jedaTeks(k, r)}</span><kbd>${r + 1}</kbd></button>`).join("")}</div>`
      : `<div class="hf-rate"><button class="btn dark big hf-show" data-k="hf-show">Tunjukkan jawaban <kbd>Spasi</kbd></button></div>`}
    <p class="cap hf-hint">Jujur saja menilai dirimu: kartu yang "Lupa" muncul lagi di sesi ini, yang "Ingat" baru muncul beberapa hari lagi.</p>
  </div>`;
}
async function nilaiKartu(r){
  const ses = UI.hf; if (!ses || ses.sibuk) return;
  const id = ses.q[ses.i]; if (!id) return;
  ses.sibuk = true;
  const res = await api.hafalanNilai(id, r);
  ses.sibuk = false;
  if (!res || res.ok === false){ toast((res && res.error) || "Gagal menyimpan."); return; }
  ses.dinilai++; ses[r === 0 ? "lupa" : r === 1 ? "ragu" : "ingat"]++;
  if (r === 0 && (ses.ulang[id] || 0) < 2){ ses.ulang[id] = (ses.ulang[id] || 0) + 1; ses.q.push(id); }
  ses.i++; ses.buka = false; render();
}

/* ---------- rencana belajar otomatis ---------- */
function kapasitas(d){ const k = S.settings.kapasitas || {}; const libur = d.getDay() === 0 || d.getDay() === 6; return libur ? (Number(k.libur) || 150) : (Number(k.kerja) || 90); }
function itemRencana(){
  const t = today(), w = weekOf(t), items = [];
  for (const [id, td] of openTodos()){
    if (/^Vicon:/i.test(td.text || "")) continue;
    const dd = td.due ? dayDiff(td.due) : null;
    if (dd != null && dd < -14) continue;
    const est = td.source === "absen" ? 5 : /kuis|quiz/i.test(td.jenis || td.text) ? 30 : /ujian/i.test(td.jenis || "") ? 60 : /kelompok/i.test(td.jenis || "") ? 60 : td.source === "lms" ? 60 : 30;
    items.push({ id: "t:" + id, jenis: "todo", label: td.text, cid: td.course, due: td.due || null, est, aksi: td.link ? { url: td.link } : null, todo: id });
  }
  for (const c of sorted()){
    for (let n = Math.max(1, w - 3); n <= w; n++){
      const m = materi(c.id, n);
      if (m && !getP(c.id, n).belajar) items.push({ id: `m:${c.id}_${n}`, jenis: "materi", label: `Pelajari materi P${n}: ${m.judul}`, cid: c.id, due: null, est: Math.min(60, Math.max(20, Math.round((m.bagian || []).length * 4))), aksi: { open: `${c.id}|${n}` }, n, lama: w - n });
      else if (!m && lampBaru(c, n).length) items.push({ id: `f:${c.id}_${n}`, jenis: "file", label: `Ringkas file dosen pertemuan ${n}`, cid: c.id, due: null, est: 5, aksi: { lamp: `${c.id}|${n}` }, n, lama: w - n });
    }
  }
  return items;
}
function susunRencana(){
  const t = today(), hari = [], done = S.rencana || {};
  for (let i = 0; i < 7; i++){ const d = new Date(t.getTime() + i * DAY); hari.push({ d, s: ymd(d), cap: kapasitas(d), isi: [], kelas: sorted().filter(c => courseDay(c) === HARI[d.getDay()]) }); }
  const pakai = h => h.isi.reduce((a, x) => a + x.est, 0);
  // Harian: kartu hafalan dan persiapan ujian yang sudah dekat
  const sh = statHafal();
  const K = Object.values(kartuS()).filter(k => k.p === S.current), batas = (S.hafalan || {}).batasBaru == null ? 20 : Number((S.hafalan || {}).batasBaru);
  let sisaBaru = Math.max(0, sh.belum - sh.baru);
  hari.forEach((h, i) => { let n = sh.perlu; if (i > 0){ const nb = Math.min(batas, sisaBaru); sisaBaru -= nb; n = K.filter(k => k.due === h.s).length + nb; } if (n) h.isi.push({ id: "h:" + h.s, jenis: "hafalan", label: `Kartu hafalan (${i === 0 ? n : "sekitar " + n} kartu)`, est: Math.max(5, Math.min(25, Math.round(n * 0.25))), aksi: { hafalan: 1 }, tetap: true }); });
  for (const c of sorted()) for (const j of ["uts", "uas"]){
    const u = (c.ujian || {})[j], dd = u && dayDiff(u.tanggal); if (dd == null || dd < 0 || dd > 14) continue;
    hari.forEach((h, i) => { if (i < dd) h.isi.push({ id: `u:${c.id}_${j}:${h.s}`, jenis: "ujian", label: `Persiapan ${UJI_N[j]} ${c.singkat}${i === dd - 1 ? " (besok ujian)" : `, ${dd - i} hari lagi`}`, cid: c.id, est: dd - i <= 3 ? 60 : 40, aksi: { ujian: j }, tetap: true }); });
  }
  const urut = itemRencana().map(x => ({ ...x, dd: x.due ? dayDiff(x.due) : null })).sort((a, b) => (a.dd == null ? 99 : a.dd) - (b.dd == null ? 99 : b.dd) || (b.lama || 0) - (a.lama || 0) || a.est - b.est);
  const nanti = [];
  for (const x of urut){
    const akhir = x.dd == null ? 6 : Math.max(0, Math.min(6, x.dd));
    if (x.dd != null && x.dd > 9){ nanti.push(x); continue; }
    let pilih = null;
    for (let i = 0; i <= akhir; i++) if (pakai(hari[i]) + x.est <= hari[i].cap){ pilih = hari[i]; break; }
    if (!pilih){
      if (x.dd == null){ nanti.push(x); continue; }
      pilih = hari.slice(0, akhir + 1).reduce((a, b) => (b.cap - pakai(b)) > (a.cap - pakai(a)) ? b : a);
    }
    pilih.isi.push(x);
  }
  hari.forEach(h => { const dn = new Set((done[h.s] || {}).done || []); h.isi.forEach(x => { x.cek = dn.has(x.id); }); h.pakai = pakai(h); });
  // Peringatan: tenggat menumpuk di hari yang sama, hari terlalu padat, dan yang sudah lewat tenggat
  const peringatan = [], perTgl = {};
  for (const [, td] of openTodos()){ if (!td.due || /^Vicon:/i.test(td.text || "") || td.source === "absen") continue; const dd = dayDiff(td.due); if (dd == null || dd < 0 || dd > 14) continue; (perTgl[td.due] ||= []).push(td); }
  Object.entries(perTgl).filter(([, a]) => a.length >= 2).sort((a, b) => a[0].localeCompare(b[0])).forEach(([tg, a]) => {
    const dd = dayDiff(tg);
    peringatan.push({ jenis: "tumpuk", t: `${tglPanjang(parseD(tg))}${dd === 0 ? " (hari ini)" : dd === 1 ? " (besok)" : ""} ada ${a.length} tenggat sekaligus: ${a.slice(0, 3).map(x => esc(x.text)).join(", ")}${a.length > 3 ? ", dan lainnya" : ""}.`, saran: dd <= 1 ? "Kerjakan yang paling cepat dulu." : "Mulai cicil dari sekarang supaya tidak menumpuk di hari itu." });
  });
  hari.forEach((h, i) => { if (h.pakai > h.cap * 1.15 && h.pakai - h.cap >= 20) peringatan.push({ jenis: "padat", t: `${i === 0 ? "Hari ini" : i === 1 ? "Besok" : tglPanjang(h.d)} terlalu padat: ${mnt(h.pakai)} dari waktu belajarmu ${mnt(h.cap)}.`, saran: "Naikkan waktu belajar di atas, atau kerjakan sebagian lebih awal." }); });
  const lewat = openTodos().filter(([, td]) => td.due && dayDiff(td.due) < 0 && td.source !== "absen" && !/^Vicon:/i.test(td.text || ""));
  if (lewat.length) peringatan.unshift({ jenis: "lewat", t: `${lewat.length} to-do sudah lewat tenggat: ${lewat.slice(0, 2).map(([, x]) => esc(x.text)).join(", ")}${lewat.length > 2 ? ", dan lainnya" : ""}.`, saran: "Cek di LMS apakah masih bisa dikumpulkan, atau hapus dari to-do kalau sudah tidak berlaku." });
  return { hari, nanti, peringatan };
}
function itemHTML(x, s){
  const c = findCourse(x.cid), dd = x.dd != null ? x.dd : (x.due ? dayDiff(x.due) : null);
  const dueT = dd == null ? "" : dd < 0 ? `<span class="due late">lewat ${-dd} hari</span>` : dd === 0 ? `<span class="due soon">tenggat hari ini</span>` : dd === 1 ? `<span class="due soon">tenggat besok</span>` : `<span class="due">tenggat ${fmtShort(parseD(x.due))}</span>`;
  const a = x.aksi || {};
  const tombol = a.open ? `<button class="link" data-open="${a.open}">Buka</button>` : a.lamp ? `<button class="link" data-lamp="${a.lamp}">Ringkas</button>` : a.hafalan ? `<button class="link" data-k="go-hafalan">Mulai</button>` : a.ujian ? `<button class="link" data-k="go-ujian" data-v="${a.ujian}">Buka</button>` : x.todo && canPandu(S.todos[x.todo]) ? `<button class="link" data-k="pandu-open" data-v="${esc(x.todo)}">Pandu</button>` : a.url ? `<button class="link" data-open-url="${esc(a.url)}">LMS</button>` : "";
  return `<div class="ri ${x.cek ? "cek" : ""}" ${c ? `data-c="${c.warna}"` : ""}><label class="chk"><input type="checkbox" data-rencana="${esc(s)}|${esc(x.id)}|${x.jenis}" ${x.cek ? "checked" : ""} aria-label="Tandai sudah dikerjakan"></label>
    <div class="txt"><div class="t">${esc(x.label)}</div><div class="s">${c ? `<span><i class="dot"></i>${esc(c.singkat)}</span>` : ""}<span>${mnt(x.est)}</span>${dueT}</div></div>${tombol}</div>`;
}
function kartuRencana(){
  const R = susunRencana(), h = R.hari[0], sisa = h.isi.filter(x => !x.cek), menit = sisa.reduce((a, x) => a + x.est, 0);
  const tumpuk = R.peringatan.filter(p => p.jenis !== "padat").slice(0, 2);
  return `<section class="card w w-plan"><div class="w-h"><h2>Rencana belajar hari ini</h2><button class="link" data-go="rencana">7 hari ke depan</button></div>
    ${tumpuk.map(p => `<p class="warn-chip">${p.t}</p>`).join("")}
    ${h.isi.length ? `<p class="cap">${sisa.length ? `${sisa.length} hal, sekitar ${mnt(menit)}. Yang paling mendesak di atas.` : "Semua rencana hari ini sudah dikerjakan. Mantap."}</p><div class="rlist">${h.isi.slice(0, 6).map(x => itemHTML(x, h.s)).join("")}</div>${h.isi.length > 6 ? `<button class="link" data-go="rencana">dan ${h.isi.length - 6} lainnya</button>` : ""}`
      : `<p class="sub">Tidak ada yang perlu dikerjakan hari ini. Bisa dipakai untuk mencicil materi minggu depan atau kartu hafalan.</p>`}</section>`;
}
function kartuHafalMini(){
  const s = statHafal();
  return `<section class="card w w-hafal"><div class="w-h"><h2>Kartu hafalan</h2>${s.streak ? `<span class="cap">${s.streak} hari berturut-turut</span>` : ""}</div>
    <div class="hm-num"><b>${s.perlu}</b><span>kartu perlu<br>diulang hari ini</span></div>
    <p class="cap">${s.total ? `${s.hafal} dari ${s.total} kartu sudah hafal.` : "Kartu dibuat otomatis dari istilah dan kuis materimu."}</p>
    ${s.perlu ? `<div class="hm-per">${sorted().map(c => { const a = antreanHafal(c.id), n = a.tempo.length + a.baru.length; return n ? `<button data-k="hf-start-go" data-v="${c.id}" data-c="${c.warna}"><i class="dot"></i><span>${esc(c.singkat)}</span><b>${n}</b></button>` : ""; }).join("")}</div>` : ""}
    <button class="btn ${s.perlu ? "dark" : ""} sm" data-k="go-hafalan" ${s.total ? "" : "disabled"}>${s.perlu ? "Mulai sekarang" : "Lihat kartu"}</button></section>`;
}
function viewRencana(){
  if (!ready()) return viewWelcome();
  const R = susunRencana(), k = S.settings.kapasitas || {};
  const sel = (id, v, opts) => `<select id="${id}" class="sel mini">${opts.map(o => `<option value="${o}" ${Number(v) === o ? "selected" : ""}>${mnt(o)}</option>`).join("")}</select>`;
  return `
  <nav class="crumbs"><button data-go="beranda">${I.left}Beranda</button></nav>
  <div class="head"><div><h1 class="large">Rencana belajar</h1><p class="lede">Disusun otomatis dari tenggat, materi yang belum dipelajari, kartu hafalan, dan ujian yang mendekat.</p></div>
    <div class="cap-set"><label>Waktu belajar hari kuliah ${sel("kap-kerja", k.kerja || 90, [30, 45, 60, 90, 120, 150, 180, 240])}</label><label>Akhir pekan ${sel("kap-libur", k.libur || 150, [30, 60, 90, 120, 150, 180, 240, 300])}</label></div></div>
  ${R.peringatan.length ? `<section class="warn-box">${R.peringatan.map(p => `<div class="wb ${p.jenis}"><b>${p.t}</b><span>${p.saran}</span></div>`).join("")}</section>` : ""}
  <div class="rweek">${R.hari.map((h, i) => { const pct = Math.min(100, Math.round(h.pakai / h.cap * 100)), lebih = h.pakai > h.cap;
    return `<section class="card rday ${i === 0 ? "today" : ""}"><div class="rd-h"><div><b>${i === 0 ? "Hari ini" : i === 1 ? "Besok" : HARI[h.d.getDay()]}</b><span class="cap">${fmtShort(h.d)}${h.kelas.length ? ", kuliah " + h.kelas.map(c => esc(c.singkat)).join(", ") : ""}</span></div><span class="cap ${lebih ? "err-t" : ""}">${mnt(h.pakai)} / ${mnt(h.cap)}</span></div>
      <div class="load ${lebih ? "over" : ""}"><i style="width:${pct}%"></i></div>
      ${h.isi.length ? `<div class="rlist">${h.isi.map(x => itemHTML(x, h.s)).join("")}</div>` : `<p class="cap">Kosong. Waktu bebas.</p>`}</section>`; }).join("")}</div>
  ${R.nanti.length ? `<section><div class="group-t"><h2 class="title3">Belum masuk jadwal</h2><span class="cap">Tidak muat di 7 hari ini atau tenggatnya masih jauh</span></div><div class="group rlist pad">${R.nanti.map(x => itemHTML(x, ymd(today()))).join("")}</div></section>` : ""}`;
}

/* ---------- peta konsep per mata kuliah ---------- */
function petaDariIstilah(c){
  const pertemuan = [];
  for (let n = 1; n <= 16; n++){ const m = materi(c.id, n); if (!m) continue; pertemuan.push({ meet: n, judul: m.judul, konsep: (m.istilah || []).slice(0, 5).map(([a, b], i) => ({ id: `p${n}-${i}`, nama: a, arti: b })) }); }
  return { pusat: c.nama, pertemuan: pertemuan.filter(p => p.konsep.length), hubungan: [], cepat: true };
}
function tataPeta(P){
  const N = P.pertemuan.length || 1, totalK0 = P.pertemuan.reduce((a, p) => a + p.konsep.length, 0), r1 = Math.max(150, N * 40, totalK0 * 9), nodes = [], pos = {};
  const totalK = P.pertemuan.reduce((a, p) => a + p.konsep.length, 0) || 1;
  let sudut = -Math.PI / 2;
  P.pertemuan.forEach(p => {
    const lebar = 2 * Math.PI * (p.konsep.length + 1) / (totalK + N), tengah = sudut + lebar / 2;
    const px = Math.cos(tengah) * r1, py = Math.sin(tengah) * r1;
    nodes.push({ t: "p", p, x: px, y: py }); pos["P" + p.meet] = [px, py];
    p.konsep.forEach((k, i) => {
      const a = sudut + lebar * (i + 1) / (p.konsep.length + 1), rr = r1 + 135 + (i % 2) * 64;
      const x = Math.cos(a) * rr, y = Math.sin(a) * rr; nodes.push({ t: "k", k, p, x, y }); pos[k.id] = [x, y];
    });
    sudut += lebar;
  });
  return { nodes, pos, r1 };
}
function wrap(s, max){ const w = String(s).split(/\s+/), out = []; let cur = ""; for (const x of w){ if ((cur + " " + x).trim().length > max && cur){ out.push(cur); cur = x; } else cur = (cur + " " + x).trim(); } if (cur) out.push(cur); return out.slice(0, 3); }
function viewPeta(){
  if (!ready()) return viewWelcome();
  const c = findCourse(UI.petaCid) || sorted()[0]; if (!c) return "";
  UI.petaCid = c.id;
  const simpan = (S.peta || {})[`${S.current}_${c.id}`];
  const keys = Object.keys(sem().materi).filter(k => k.startsWith(c.id + "_")).sort((a, b) => +a.split("_").pop() - +b.split("_").pop());
  const sig = keys.map(k => k + ":" + (sem().materi[k].dibuat || "")).join("|"), basi = simpan && simpan.sig !== sig;
  const P = simpan ? simpan.data : UI.petaCepat === c.id ? petaDariIstilah(c) : null;
  const head = `<nav class="crumbs"><button data-k="peta-back">${I.left}${esc(c.nama)}</button></nav>
  <div class="head"><div><h1 class="large">Peta konsep</h1><p class="lede">${esc(c.nama)}: konsep penting tiap pertemuan dan hubungannya.</p></div>
    <div class="inline"><select id="peta-cid" class="sel" aria-label="Mata kuliah">${sorted().map(x => `<option value="${x.id}" ${x.id === c.id ? "selected" : ""}>${esc(x.singkat)}</option>`).join("")}</select>${keys.length ? `<button class="btn ${simpan && !basi ? "" : "dark"}" data-k="peta-make" data-v="${c.id}">${simpan ? "Perbarui peta" : "Buat dengan AI"}</button>` : ""}</div></div>`;
  if (!keys.length) return head + `<section class="card empty-c"><p class="sub">Belum ada materi yang diringkas di mata kuliah ini. Peta konsep dibuat dari ringkasan materi.</p></section>`;
  if (!P) return head + `<section class="card peta-intro"><h2 class="title2">Lihat gambaran besar ${esc(c.singkat)}</h2><p class="sub">AI membaca ${keys.length} ringkasan materi, mengambil konsep paling penting di tiap pertemuan, lalu menghubungkan konsep yang saling terkait antarpertemuan. Cocok untuk belajar menjelang ujian.</p><div class="inline"><button class="btn dark" data-k="peta-make" data-v="${c.id}">Buat peta konsep</button><button class="btn" data-k="peta-cepat" data-v="${c.id}">Lihat versi cepat dari istilah</button></div></section>`;
  const L = tataPeta(P), sel = UI.petaSel, cari = String(UI.petaCari || "").toLowerCase();
  const xs = L.nodes.map(n => n.x), ys = L.nodes.map(n => n.y), pad = 110;
  const vb0 = [Math.min(...xs, 0) - pad, Math.min(...ys, 0) - pad, Math.max(...xs, 0) - Math.min(...xs, 0) + pad * 2, Math.max(...ys, 0) - Math.min(...ys, 0) + pad * 2];
  const vb = UI.petaVB && UI.petaVB.cid === c.id ? UI.petaVB.v : vb0;
  const terkait = new Set(); if (sel) P.hubungan.forEach(h => { if (h.dari === sel || h.ke === sel){ terkait.add(h.dari); terkait.add(h.ke); } });
  const kOf = id => { for (const p of P.pertemuan) for (const k of p.konsep) if (k.id === id) return { k, p }; return null; };
  const garis = [];
  L.nodes.forEach(n => { if (n.t === "p") garis.push(`<line class="e0" x1="0" y1="0" x2="${n.x}" y2="${n.y}"/>`); else { const [px, py] = L.pos["P" + n.p.meet]; garis.push(`<line class="e1 ${sel && (sel === n.k.id) ? "on" : ""}" x1="${px}" y1="${py}" x2="${n.x}" y2="${n.y}"/>`); } });
  const rel = P.hubungan.map((h, i) => { const a = L.pos[h.dari], b = L.pos[h.ke]; if (!a || !b) return ""; const mx = (a[0] + b[0]) / 2 * 0.55, my = (a[1] + b[1]) / 2 * 0.55; const on = sel && (h.dari === sel || h.ke === sel);
    const tx = (a[0] + 2 * mx + b[0]) / 4, ty = (a[1] + 2 * my + b[1]) / 4;
    return `<path class="e2 ${on ? "on" : sel ? "redup" : ""}" d="M${a[0]},${a[1]} Q${mx},${my} ${b[0]},${b[1]}" marker-end="url(#panah)"/>${on || (!sel && P.hubungan.length <= 14) ? `<text class="elbl ${on ? "on" : ""}" x="${tx}" y="${ty}" text-anchor="middle">${esc(h.label)}</text>` : ""}`; }).join("");
  const simpul = L.nodes.map(n => {
    if (n.t === "p") return `<g class="np" data-open="${c.id}|${n.p.meet}" style="cursor:pointer" transform="translate(${n.x},${n.y})"><circle r="30"/><text class="np-n" y="6" text-anchor="middle">P${n.p.meet}</text>${wrap(n.p.judul, 18).map((l, i) => `<text class="np-l" y="${50 + i * 16}" text-anchor="middle">${esc(l)}</text>`).join("")}</g>`;
    const lines = wrap(n.k.nama, 16), w = Math.max(...lines.map(l => l.length)) * 8 + 28, h = lines.length * 18 + 16;
    const hit = cari && (n.k.nama.toLowerCase().includes(cari) || String(n.k.arti).toLowerCase().includes(cari));
    const cls = [sel === n.k.id ? "sel" : "", sel && terkait.has(n.k.id) && sel !== n.k.id ? "rel" : "", (sel && !terkait.has(n.k.id) && sel !== n.k.id) || (cari && !hit) ? "redup" : "", hit ? "hit" : ""].join(" ");
    return `<g class="nk ${cls}" data-k="peta-k" data-v="${esc(n.k.id)}" transform="translate(${n.x},${n.y})"><rect x="${-w / 2}" y="${-h / 2}" width="${w}" height="${h}" rx="${Math.min(14, h / 2)}"/>${lines.map((l, i) => `<text y="${-h / 2 + 24 + i * 18}" text-anchor="middle">${esc(l)}</text>`).join("")}</g>`;
  }).join("");
  const info = sel && kOf(sel);
  const relList = info ? P.hubungan.filter(h => h.dari === sel || h.ke === sel).map(h => { const o = kOf(h.dari === sel ? h.ke : h.dari); return o ? `<button class="pk-rel" data-k="peta-k" data-v="${esc(o.k.id)}"><span>${h.dari === sel ? `${esc(info.k.nama)} <i>${esc(h.label)}</i> <b>${esc(o.k.nama)}</b>` : `<b>${esc(o.k.nama)}</b> <i>${esc(h.label)}</i> ${esc(info.k.nama)}`}</span><small>P${o.p.meet}</small></button>` : ""; }).join("") : "";
  return head + `
  ${basi ? `<div class="banner">Ada materi baru atau diringkas ulang sejak peta ini dibuat. Klik Perbarui peta supaya ikut masuk.</div>` : ""}${P.cepat ? `<div class="banner">Ini versi cepat dari istilah tiap pertemuan, tanpa hubungan antarkonsep. Buat dengan AI untuk peta yang lengkap.</div>` : ""}
  <div class="peta-wrap" data-c="${c.warna}">
    <div class="peta-tool"><input id="peta-cari" class="sel" placeholder="Cari konsep" value="${esc(UI.petaCari || "")}" aria-label="Cari konsep"><button class="circle sm" data-k="peta-zoom" data-v="0.8" aria-label="Perbesar">+</button><button class="circle sm" data-k="peta-zoom" data-v="1.25" aria-label="Perkecil">−</button><button class="btn sm" data-k="peta-reset">Pas layar</button></div>
    <svg id="peta" class="peta" viewBox="${vb.join(" ")}" role="img" aria-label="Peta konsep ${esc(c.nama)}"><defs><marker id="panah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" class="mk"/></marker></defs>
      ${garis.join("")}${rel}<g class="np pusat"><circle r="${Math.max(54, Math.min(80, P.pusat.length * 3.6))}"/>${wrap(P.pusat, 14).map((l, i, a) => `<text y="${(i - (a.length - 1) / 2) * 18 + 6}" text-anchor="middle">${esc(l)}</text>`).join("")}</g>${simpul}</svg>
    ${info ? `<aside class="card peta-info"><button class="circle sm" data-k="peta-k" data-v="" aria-label="Tutup" style="float:right">✕</button><span class="tag"><i class="dot"></i>Pertemuan ${info.p.meet}</span><h2 class="title2">${esc(info.k.nama)}</h2><p>${esc(info.k.arti)}</p>${relList ? `<div class="pk-rels"><p class="cap">Terhubung dengan</p>${relList}</div>` : ""}<button class="btn sm dark" data-open="${c.id}|${info.p.meet}">Buka materi P${info.p.meet}</button></aside>`
      : `<p class="cap peta-hint">Klik konsep untuk melihat artinya dan konsep lain yang terhubung. Geser untuk berpindah, gulir atau cubit untuk memperbesar.</p>`}
  </div>`;
}
// geser dan perbesar peta tanpa menggambar ulang seluruh halaman
(() => {
  let tarik = null;
  const vbOf = svg => svg.getAttribute("viewBox").split(/\s+/).map(Number);
  const setVB = (svg, v) => { svg.setAttribute("viewBox", v.join(" ")); UI.petaVB = { cid: UI.petaCid, v }; };
  const zoom = (svg, f, cx, cy) => { const v = vbOf(svg), r = svg.getBoundingClientRect(); const px = cx == null ? 0.5 : (cx - r.left) / r.width, py = cy == null ? 0.5 : (cy - r.top) / r.height; const w = Math.max(200, Math.min(9000, v[2] * f)), h = v[3] * (w / v[2]); setVB(svg, [v[0] + (v[2] - w) * px, v[1] + (v[3] - h) * py, w, h]); };
  window.__tkZoomPeta = f => { const s = $("#peta"); if (s) zoom(s, f); };
  document.addEventListener("wheel", e => { const s = e.target.closest && e.target.closest("#peta"); if (!s) return; e.preventDefault(); zoom(s, e.deltaY > 0 ? 1.12 : 0.89, e.clientX, e.clientY); }, { passive: false });
  document.addEventListener("pointerdown", e => { const s = e.target.closest && e.target.closest("#peta"); if (!s || e.target.closest(".nk, .np")) return; tarik = { s, x: e.clientX, y: e.clientY, v: vbOf(s), id: e.pointerId, gerak: 0 }; });
  document.addEventListener("pointermove", e => { if (!tarik || e.pointerId !== tarik.id) return; const r = tarik.s.getBoundingClientRect(), k = tarik.v[2] / r.width; tarik.gerak += Math.abs(e.movementX) + Math.abs(e.movementY); setVB(tarik.s, [tarik.v[0] - (e.clientX - tarik.x) * k, tarik.v[1] - (e.clientY - tarik.y) * k, tarik.v[2], tarik.v[3]]); });
  document.addEventListener("pointerup", () => { tarik = null; });
  let jari = null;
  document.addEventListener("touchmove", e => { const s = e.target.closest && e.target.closest("#peta"); if (!s || e.touches.length !== 2) { jari = null; return; } e.preventDefault(); const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); if (jari) zoom(s, jari / d, (e.touches[0].clientX + e.touches[1].clientX) / 2, (e.touches[0].clientY + e.touches[1].clientY) / 2); jari = d; }, { passive: false });
  document.addEventListener("touchend", () => { jari = null; });
})();

/* ---------- simulasi ujian berwaktu ---------- */
const simList = () => latList().filter(L => L.sim);
function sisaDetik(L){ if (!L.sim || !L.sim.mulai) return L.sim ? L.sim.durasi * 60 : 0; return Math.round(L.sim.durasi * 60 - (Date.now() - new Date(L.sim.mulai)) / 1000); }
const jam = s => { s = Math.max(0, s); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), d = s % 60; return (h ? h + ":" + String(m).padStart(2, "0") : String(m).padStart(2, "0")) + ":" + String(d).padStart(2, "0"); };
function topikLemah(cid){ const K = kemampuan().find(x => x.c.id === cid); return K ? K.topik.map(([t]) => t).filter(t => !/^Pertemuan \d+:/.test(t)).slice(0, 5) : []; }
function viewSimulasi(){
  if (UI.simId && (S.latihan || {})[UI.simId]){ const L = S.latihan[UI.simId]; return L.hasil ? viewLatRun(L) : viewSimRun(L); }
  const F = UI.simForm || (UI.simForm = { cid: (sorted()[0] || {}).id, scope: ujianNow().jenis, durasi: 90, pg: 40, essay: 3 });
  const c = findCourse(F.cid) || sorted()[0]; if (c) F.cid = c.id;
  const [fa, fb] = F.scope === "semua" ? [1, 16] : UJI[F.scope] || UJI.uts;
  const nMat = c ? Array.from({ length: fb - fa + 1 }, (_, i) => materi(c.id, fa + i)).filter(Boolean).length : 0;
  const seg = (k, opts) => `<div class="seg" role="group">${opts.map(([v, l]) => `<button aria-pressed="${String(F[k]) === String(v)}" data-k="simf" data-f="${k}" data-v="${v}">${l}</button>`).join("")}</div>`;
  const lemah = c ? topikLemah(c.id) : [], L = simList();
  return `<div class="lat-wrap">
    <section class="card lat-new">
      <h2 class="title2">Simulasi ujian</h2>
      <p class="sub">Seperti ujian sungguhan: soal setara ujian dosen, waktu berjalan terus, bisa tandai soal ragu-ragu, dan otomatis dikumpulkan saat waktu habis.</p>
      <div class="lf"><label>Mata kuliah</label><select id="sf-cid" class="sel">${sorted().map(x => `<option value="${x.id}" ${x.id === F.cid ? "selected" : ""}>${esc(x.nama)}</option>`).join("")}</select></div>
      <div class="lf"><label>Ujian</label>${seg("scope", [["uts", "UTS (1-7)"], ["uas", "UAS (9-15)"], ["semua", "Semua pertemuan"]])}</div>
      <div class="lf"><label>Waktu</label>${seg("durasi", [[60, "60 menit"], [90, "90 menit"], [120, "120 menit"], [150, "150 menit"]])}</div>
      <div class="lf"><label>Pilihan ganda</label>${seg("pg", [[30, "30"], [40, "40"], [50, "50"], [60, "60"]])}</div>
      <div class="lf"><label>Essay</label>${seg("essay", [[0, "Tidak ada"], [3, "3"], [5, "5"], [10, "10"]])}</div>
      <p class="cap">Jumlah soal dibuat seperti ujian sungguhan, jauh lebih banyak dari kuis tiap materi. Pembuatannya bisa 1 sampai 3 menit.</p>
      ${lemah.length ? `<p class="cap">Topik yang sering kamu salah ikut diberi porsi lebih: ${lemah.map(esc).join(", ")}.</p>` : ""}
      <p class="cap">${nMat ? `Soal dari ${nMat} materi yang sudah diringkas, bobotnya mengikuti panjang tiap materi.` : `<span class="err-t">Belum ada materi yang diringkas di cakupan ini.</span>`}</p>
      <button class="btn dark big" data-k="sim-make" ${nMat ? "" : "disabled"}>Siapkan simulasi</button>
    </section>
    <section class="lat-hist">
      <div class="group-t"><h2 class="title3">Riwayat simulasi</h2><span class="cap">${L.length} simulasi semester ini</span></div>
      ${L.length ? `<div class="group">${L.map(x => { const cc = findCourse(x.cid); return `<div class="row lat-row" data-c="${cc ? cc.warna : ""}"><button class="lat-open" data-k="sim-open" data-v="${x.id}"><span class="dot"></span><span class="txt"><b>${esc(cc ? cc.singkat : "")}: ${esc(x.label)}</b><small>${x.soal.pg.length + x.soal.essay.length} soal, ${x.sim.durasi} menit, ${fmtShort(new Date(x.dibuat))}</small></span>${x.hasil ? `<span class="score-b ${x.hasil.total >= 80 ? "good" : x.hasil.total >= 60 ? "mid" : "low"}">${x.hasil.total}</span>` : `<span class="cap">${x.sim.mulai ? "Sedang berjalan" : "Belum dimulai"}</span>`}</button><button class="iconbtn" data-k="lat-del" data-v="${x.id}" aria-label="Hapus simulasi">${I.trash}</button></div>`; }).join("")}</div>` : `<div class="card empty-c"><p class="sub">Belum ada simulasi. Coba satu menjelang UTS atau UAS supaya terbiasa dengan waktunya.</p></div>`}
    </section></div>`;
}
function simAns(L){ if (!UI.simAns || UI.simAns.id !== L.id) UI.simAns = { id: L.id, pg: { ...(L.jawaban.pg || {}) }, essay: { ...(L.jawaban.essay || {}) }, ragu: [...(L.jawaban.ragu || [])] }; return UI.simAns; }
function viewSimRun(L){
  const c = findCourse(L.cid), nPG = L.soal.pg.length, nQ = nPG + L.soal.essay.length;
  if (!L.sim.mulai) return `<nav class="crumbs"><button data-k="sim-back">${I.left}Simulasi ujian</button></nav>
    <section class="board sim-intro" ${c ? `data-c="${c.warna}"` : ""}><div><p class="hi">${esc(c ? c.nama : "")}</p><h1 class="board-date">${esc(L.label)}</h1>
      <p class="say"><mark class="hl">${nQ} soal</mark> (${nPG} pilihan ganda${L.soal.essay.length ? ", " + L.soal.essay.length + " essay" : ""}) dalam <mark class="hl">${L.sim.durasi} menit</mark>.</p>
      <ul class="sim-rules"><li>Waktu mulai berjalan saat kamu klik Mulai dan tetap berjalan walau halaman ini ditinggal.</li><li>Tandai soal yang belum yakin dengan "Ragu-ragu", lalu cek lagi lewat nomor soal.</li><li>5 menit sebelum habis ada pengingat. Saat waktu habis, jawabanmu otomatis dikumpulkan.</li><li>Nilai akhir: pilihan ganda 70%, essay 30% (essay dinilai AI).</li></ul>
      <div class="inline"><button class="btn hl-btn" data-k="sim-start" data-v="${L.id}">Mulai sekarang</button><button class="btn line-light" data-k="sim-back">Nanti saja</button></div></div></section>`;
  const A = simAns(L), q = Math.max(0, Math.min(nQ - 1, UI.simQ || 0)), sisa = sisaDetik(L);
  const terjawab = i => i < nPG ? A.pg[i] != null : String(A.essay[i - nPG] || "").trim().length > 0;
  const nA = Array.from({ length: nQ }, (_, i) => terjawab(i)).filter(Boolean).length;
  let isi;
  if (q < nPG){ const s = L.soal.pg[q];
    isi = `<p class="lq-q">${esc(s.q)}</p><div class="opts">${s.o.map((o, k) => `<button class="opt ${A.pg[q] === k ? "picked" : ""}" data-k="sim-pick" data-v="${q}|${k}"><b>${String.fromCharCode(65 + k)}</b><span>${esc(o)}</span></button>`).join("")}</div>`; }
  else { const e = q - nPG, s = L.soal.essay[e]; isi = `<p class="lq-q">${esc(s.q)}</p><textarea class="essay-in" id="sim-essay" data-sim-essay="${e}" placeholder="Tulis jawabanmu di sini">${esc(A.essay[e] || "")}</textarea>`; }
  return `<div class="sim-run" ${c ? `data-c="${c.warna}"` : ""}>
    <header class="sim-top"><div><b>${esc(c ? c.singkat : "")}: ${esc(L.label)}</b><span class="cap">Terjawab ${nA} dari ${nQ}</span></div><div class="sim-time ${sisa <= 300 ? "warn" : ""}" id="simtime" aria-live="off">${jam(sisa)}</div><button class="btn dark sm" data-k="sim-submit">Kumpulkan</button></header>
    <div class="sim-body">
      <section class="card sim-q"><div class="lq-h"><span class="lq-n">${q < nPG ? q + 1 : "E" + (q - nPG + 1)}</span>${q >= nPG ? `<span class="tagc">Essay</span>` : ""}<label class="chk sim-ragu"><input type="checkbox" data-sim-ragu="${q}" ${A.ragu.includes(q) ? "checked" : ""}><span>Ragu-ragu</span></label></div>${isi}
        <div class="sim-nav"><button class="btn" data-k="sim-go" data-v="${q - 1}" ${q <= 0 ? "disabled" : ""}>${I.left}Sebelumnya</button><button class="btn ${q >= nQ - 1 ? "" : "dark"}" data-k="sim-go" data-v="${q + 1}" ${q >= nQ - 1 ? "disabled" : ""}>Berikutnya${I.right}</button></div></section>
      <aside class="card sim-grid"><p class="cap">Nomor soal</p><div class="sg">${Array.from({ length: nQ }, (_, i) => `<button class="sgb ${i === q ? "now" : ""} ${terjawab(i) ? "isi" : ""} ${A.ragu.includes(i) ? "ragu" : ""}" data-k="sim-go" data-v="${i}">${i < nPG ? i + 1 : "E" + (i - nPG + 1)}</button>`).join("")}</div>
        <div class="sg-leg"><span><i class="isi"></i>Terjawab</span><span><i class="ragu"></i>Ragu-ragu</span><span><i></i>Belum</span></div></aside>
    </div></div>`;
}
function simpanSim(){ const A = UI.simAns; if (!A) return; clearTimeout(UI._simT); UI._simT = setTimeout(() => api.saveLatihan(A.id, { pg: A.pg, essay: A.essay, ragu: A.ragu }), 500); }
async function kumpulkanSim(otomatis){
  const L = S.latihan[UI.simId]; if (!L || L.hasil || UI.simKirim) return;
  const A = simAns(L); UI.simKirim = true;
  toast(otomatis ? "Waktu habis. Jawabanmu dikumpulkan dan dinilai." : L.soal.essay.length ? "Menilai jawaban, essay dinilai AI…" : "Menilai…");
  const r = await api.submitLatihan(L.id, { pg: A.pg, essay: A.essay, ragu: A.ragu });
  UI.simKirim = false;
  // Gagal (misalnya offline atau AI penuh saat menilai essay): jangan dicoba ulang tiap detik, tunggu tombol Kumpulkan
  if (!r.ok){ UI.simGagal = L.id; toast("Gagal mengumpulkan: " + r.error + " Klik Kumpulkan untuk mencoba lagi."); render(); return; }
  UI.simGagal = null;
  render(); window.scrollTo(0, 0);
}
setInterval(() => {
  const L = UI.view === "ujian" && UI.uTab === "simulasi" && UI.simId && (S && S.latihan || {})[UI.simId];
  if (!L || !L.sim || !L.sim.mulai || L.hasil) return;
  const s = sisaDetik(L), el = $("#simtime");
  if (el){ el.textContent = jam(s); el.classList.toggle("warn", s <= 300); }
  if (s <= 300 && s > 0 && UI.simWarn !== L.id){ UI.simWarn = L.id; toast("Waktu tinggal 5 menit. Cek lagi soal yang ragu-ragu."); }
  if (s <= 0 && UI.simGagal !== L.id) kumpulkanSim(true);
}, 1000);

/* ---------- halaman "Yang baru" setelah update ---------- */
const CHANGELOG = {
  "1.0.17": {
    judul: "Belajar jadi lebih lengkap",
    baru: [
      ["Gambar di ringkasan", "Diagram, grafik, dan gambar penting dari slide, PDF, dokumen, dan video dosen sekarang ikut tampil di bagian ringkasan yang cocok, lengkap dengan keterangannya. Klik gambar untuk memperbesar. Untuk video YouTube ada tombol yang langsung membuka menit pembahasannya."],
      ["Kartu hafalan pintar", "Di Ujian > Hafalan. Kartu dibuat otomatis dari istilah dan soal kuis setiap materi, lalu muncul lagi tepat sebelum kamu lupa. Ada pengingat jam 19.30 kalau ada kartu yang perlu diulang."],
      ["Dengarkan ringkasan", "Tombol Dengarkan di halaman materi membacakan ringkasan seperti podcast. Bisa dijeda, lompat bagian, dan diatur kecepatannya."],
      ["Rencana belajar otomatis", "Kartu baru di Beranda menyusun apa yang perlu dikerjakan hari ini dan 7 hari ke depan sesuai waktu belajarmu, dan memberi peringatan kalau tenggat menumpuk di hari yang sama."],
      ["Peta konsep per mata kuliah", "Di halaman mata kuliah. Semua konsep penting dari tiap pertemuan dan hubungannya dalam satu gambar, enak untuk belajar menjelang ujian."],
      ["Simulasi ujian berwaktu", "Di Ujian > Simulasi. Seperti ujian sungguhan: soalnya banyak (30 sampai 60 pilihan ganda plus essay, tidak sedikit seperti kuis), ada timer, tanda ragu-ragu, otomatis dikumpulkan saat waktu habis, dan nilai per topik. Soal yang salah bisa langsung dijadikan kartu hafalan."],
      ["Bagikan ringkasan", "Tombol Bagikan di halaman materi: kirim ke WhatsApp atau salin teksnya. Di laptop juga bisa disimpan sebagai PDF lengkap dengan gambar, atau sebagai gambar kartu ringkas."],
      ["Halaman Yang baru", "Setiap selesai update, halaman ini muncul supaya kamu tahu apa saja yang baru. Bisa dibuka lagi dari Pengaturan > Tentang."]
    ],
    perbaikan: [
      "Kuis yang belum dikerjakan tidak lagi tercentang sendiri di To-do. Status kuis dari LMS sekarang selalu dicek ulang setiap sinkron, jadi kuis yang dulu salah tercentang kembali muncul sebagai belum selesai.",
      "To-do kuis tampil sebagai kuis. To-do untuk komentar absensi di post kuis sekarang diberi nama jelas (\"Tulis komentar absensi di post: ...\") dan terpisah dari to-do mengerjakan kuisnya.",
      "Tugas biasa yang selesai lewat komentar tetap tercentang walau data komentar dari LMS sesekali gagal dimuat."
    ]
  }
};
function yangBaruHTML(v){
  const C = CHANGELOG[v] || CHANGELOG[Object.keys(CHANGELOG).pop()];
  return `<div class="sheet yb-sheet" role="dialog" aria-modal="true" aria-label="Yang baru di versi ${esc(v)}"><div class="sheet-h"><div><p class="cap yb-ver">Versi ${esc(v)}</p><h2 class="title2">Yang baru: ${esc(C.judul)}</h2></div><button class="circle" data-tutup-lapisan aria-label="Tutup">✕</button></div>
    <div class="sheet-b"><h3 class="title3">Fitur baru</h3><div class="yb-list">${C.baru.map(([j, d], i) => `<div class="yb-i"><span class="yb-n">${i + 1}</span><div><b>${esc(j)}</b><p>${esc(d)}</p></div></div>`).join("")}</div>
      <h3 class="title3">Yang diperbaiki</h3><ul class="yb-fix">${C.perbaikan.map(p => `<li>${esc(p)}</li>`).join("")}</ul></div>
    <div class="sheet-f"><span class="cap">Dibuat oleh ${PEMBUAT}</span><button class="btn dark" data-tutup-lapisan>Oke, mengerti</button></div></div>`;
}
function bukaYangBaru(v){ lapisan(yangBaruHTML(v || (S && S.appVersion) || "1.0.17"), "yb"); }
function tandaiYangBaru(){ if (S && S.appVersion && S.settings.lastSeenVersion !== S.appVersion) api.saveSettings({ lastSeenVersion: S.appVersion }); }
function cekYangBaru(){
  if (!S || !S.appVersion || UI.ybDicek) return; UI.ybDicek = true;
  const lihat = S.settings.lastSeenVersion;
  if (lihat === S.appVersion) return;
  // Pengguna baru (belum selesai persiapan) tidak perlu melihat daftar perubahan
  if (!S.settings.setupDone){ api.saveSettings({ lastSeenVersion: S.appVersion }); return; }
  if (CHANGELOG[S.appVersion]) setTimeout(() => bukaYangBaru(S.appVersion), 600); else tandaiYangBaru();
}

/* ---------- pengaturan belajar (1.0.17) ---------- */
function belajarSettings(){
  const sv = S.settings.suara || {}, vs = Suara.voices(), idv = vs.filter(v => /^id([-_]|$)/i.test(v.lang)), lain = vs.filter(v => !/^id([-_]|$)/i.test(v.lang));
  const k = S.settings.kapasitas || {};
  const opt = (v, lbl) => `<option value="${esc(v.voiceURI)}" ${sv.voice === v.voiceURI ? "selected" : ""}>${esc(lbl || v.name)}</option>`;
  return `<section><div class="group-t"><h2 class="title3">Belajar</h2></div><div class="group">
    <div class="field"><div class="inline" style="justify-content:space-between"><label for="gbr-on">Gambar di ringkasan</label><input type="checkbox" class="switch" id="gbr-on" ${S.settings.gambarRingkasan !== false ? "checked" : ""}></div><p class="cap">Diagram dan gambar penting dari slide, PDF, dokumen, dan video dosen ikut ditaruh di ringkasan. Kalau ada API key Gemini, gambarnya dipilih dan diberi keterangan oleh Gemini Flash-Lite (sekali per materi, hemat kuota). Berlaku untuk materi yang diringkas setelah ini, atau klik Ringkas ulang.</p></div>
    <div class="field"><label for="sr-voice">Suara untuk Dengarkan</label>${!Suara.didukung() ? `<p class="cap">${HP ? "HP ini belum bisa membacakan teks. Pastikan Google Text-to-speech terpasang dan diperbarui di Play Store." : "Perangkat ini belum mendukung suara."}</p>` : vs.length ? `<select id="sr-voice" class="sel"><option value="">Otomatis${idv.length ? " (bahasa Indonesia)" : ""}</option>${idv.length ? `<optgroup label="Bahasa Indonesia">${idv.map(v => opt(v)).join("")}</optgroup>` : ""}<optgroup label="Bahasa lain">${lain.map(v => opt(v, v.name + " (" + v.lang + ")")).join("")}</optgroup></select>
      ${idv.length ? "" : HP ? `<p class="cap"><span class="err-t">Suara bahasa Indonesia belum terpasang di perangkat ini.</span> Tambahkan di pengaturan suara (text-to-speech) perangkat.</p>` : `<p class="cap"><span class="err-t">Suara bahasa Indonesia belum terpasang di Windows.</span> Buka Settings Windows > Time &amp; language > Speech > Add voices, pilih Indonesian, lalu buka ulang Teman Kuliah.</p>`}` : `<p class="cap">${HP ? "Memakai suara bawaan HP (Google Text-to-speech)." : "Daftar suara sedang dimuat. Kalau tetap kosong, perangkat ini belum punya suara text-to-speech."}</p>`}
      <div class="inline" style="margin-top:6px"><span class="cap">Kecepatan</span><div class="seg" role="group">${[0.8, 1, 1.25, 1.5, 1.75].map(r => `<button aria-pressed="${(Number(sv.rate) || 1) === r}" data-k="sr-setrate" data-v="${r}">${String(r).replace(".", ",")}x</button>`).join("")}</div></div></div>
    <div class="field"><label>Waktu belajar per hari (untuk rencana belajar)</label><div class="inline"><label class="cap">Hari kuliah <select id="kap-kerja" class="sel mini">${[30, 45, 60, 90, 120, 150, 180, 240].map(o => `<option value="${o}" ${Number(k.kerja || 90) === o ? "selected" : ""}>${mnt(o)}</option>`).join("")}</select></label><label class="cap">Akhir pekan <select id="kap-libur" class="sel mini">${[30, 60, 90, 120, 150, 180, 240, 300].map(o => `<option value="${o}" ${Number(k.libur || 150) === o ? "selected" : ""}>${mnt(o)}</option>`).join("")}</select></label></div><p class="cap">Rencana belajar di Beranda tidak mengisi lebih dari waktu ini, dan memberi tahu kalau ada hari yang terlalu padat.</p></div>
  </div></section>`;
}

/* ---------- aksi fitur 1.0.17 ---------- */
document.addEventListener("click", async e => {
  const b = e.target.closest("[data-k]"); if (!b) return;
  const k = b.dataset.k, v = b.dataset.v;
  if (k === "fig-open"){ const [key, id] = v.split("|"); bukaGambar(key, id); }
  else if (k === "dengar"){ if (Suara.aktif() && Suara.key() === v) Suara.toggle(); else Suara.mulai(v); render(); }
  else if (k === "dengar-sec"){ const [key, i] = v.split("|"); Suara.dariBagian(key, Number(i)); }
  else if (k === "sr-toggle"){ Suara.toggle(); render(); }
  else if (k === "sr-prev"){ Suara.loncat(-1); }
  else if (k === "sr-next"){ Suara.loncat(1); }
  else if (k === "sr-rate"){ Suara.laju(); }
  else if (k === "sr-stop"){ Suara.berhenti(); render(); }
  else if (k === "sr-setrate"){ await api.saveSettings({ suara: { rate: Number(v) } }); }
  else if (k === "bagikan"){ bukaBagikan(v); }
  else if (k === "bg-wa"){ const t = teksWA(v); lapisan(null); api.open("https://wa.me/?text=" + encodeURIComponent(t)); }
  else if (k === "bg-copy"){ try { await navigator.clipboard.writeText(teksLengkap(v)); toast("Ringkasan tersalin."); } catch (err) { toast("Gagal menyalin."); } lapisan(null); }
  else if (k === "bg-pdf" || k === "bg-png"){ b.disabled = true; b.querySelector("b").textContent = "Menyiapkan…"; const r = await api.bagikanFile(v, k === "bg-pdf" ? "pdf" : "png"); lapisan(null); if (!r.ok) toast(r.error); else if (!r.batal) toast(k === "bg-pdf" ? "PDF tersimpan." : "Gambar tersimpan."); }
  else if (k === "hf-start-go"){ UI.uTab = "hafalan"; const a = antreanHafal(v); UI.hf = { q: [...a.tempo, ...a.baru], i: 0, buka: false, dinilai: 0, ingat: 0, ragu: 0, lupa: 0, ulang: {} }; go("ujian"); }
  else if (k === "go-hafalan"){ UI.uTab = "hafalan"; UI.hf = null; go("ujian"); }
  else if (k === "go-ujian"){ UI.uTab = "persiapan"; UI.uJenis = v; go("ujian"); }
  else if (k === "hf-start"){ const a = antreanHafal(v || UI.hfCid || null); const q = [...a.tempo, ...a.baru]; if (!q.length){ toast("Tidak ada kartu yang perlu diulang."); return; } UI.hf = { q, i: 0, buka: false, dinilai: 0, ingat: 0, ragu: 0, lupa: 0, ulang: {} }; render(); window.scrollTo(0, 0); }
  else if (k === "hf-show"){ if (UI.hf){ UI.hf.buka = true; render(); } }
  else if (k === "hf-rate"){ nilaiKartu(Number(v)); }
  else if (k === "hf-close"){ UI.hf = null; render(); }
  else if (k === "peta-open"){ go("peta", { petaCid: v, petaSel: null, petaVB: null, petaCari: "" }); }
  else if (k === "peta-back"){ go("materi", { course: UI.petaCid, meet: null }); }
  else if (k === "peta-make"){ b.disabled = true; b.textContent = "AI sedang membaca materi…"; const r = await api.petaMake(v); if (!r.ok){ toast(r.error); render(); } else { UI.petaVB = null; UI.petaCepat = null; toast("Peta konsep siap."); } }
  else if (k === "peta-cepat"){ UI.petaCepat = v; render(); }
  else if (k === "peta-k"){ UI.petaSel = v || null; render(); }
  else if (k === "peta-zoom"){ window.__tkZoomPeta && window.__tkZoomPeta(Number(v)); }
  else if (k === "peta-reset"){ UI.petaVB = null; render(); }
  else if (k === "sim-make"){ const F = UI.simForm, [fa, fb] = F.scope === "semua" ? [1, 16] : UJI[F.scope]; b.disabled = true; b.textContent = "Menyiapkan soal…";
    const r = await api.makeLatihan({ cid: F.cid, from: fa, to: fb, pg: F.pg, essay: F.essay, label: `Simulasi ${F.scope === "semua" ? "semua pertemuan" : UJI_N[F.scope]}`, sim: { durasi: F.durasi, jenis: F.scope === "semua" ? "ujian akhir" : UJI_N[F.scope], lemah: topikLemah(F.cid) } });
    if (r.ok){ UI.simId = r.id; UI.simQ = 0; UI.simAns = null; render(); window.scrollTo(0, 0); } else { toast(r.error); render(); } }
  else if (k === "sim-open"){ UI.simId = v; UI.simQ = 0; UI.simAns = null; render(); window.scrollTo(0, 0); }
  else if (k === "sim-back"){ UI.simId = null; render(); }
  else if (k === "sim-start"){ const r = await api.mulaiSimulasi(v); if (!r.ok) toast(r.error); UI.simQ = 0; }
  else if (k === "sim-go"){ UI.simQ = Number(v); render(); window.scrollTo(0, 0); }
  else if (k === "sim-pick"){ const [i, o] = v.split("|").map(Number); const A = UI.simAns; if (!A) return; A.pg[i] = o; simpanSim(); render(); }
  else if (k === "sim-submit"){ const L = S.latihan[UI.simId], A = simAns(L), nQ = L.soal.pg.length + L.soal.essay.length;
    const belum = nQ - Object.keys(A.pg).length - L.soal.essay.filter((q, i) => String(A.essay[i] || "").trim()).length;
    if ((belum || A.ragu.length) && !b.dataset.sure){ b.dataset.sure = "1"; b.textContent = belum ? `${belum} belum dijawab. Klik lagi` : `${A.ragu.length} ragu-ragu. Klik lagi`; return; }
    kumpulkanSim(false); }
  else if (k === "simf"){ const F = UI.simForm; F[b.dataset.f] = /^\d+$/.test(v) ? Number(v) : v; render(); }
  else if (k === "kartu-lat"){ b.disabled = true; const r = await api.hafalanDariLatihan(v); toast(r.ok ? (r.n ? `${r.n} kartu hafalan dibuat dari soal yang salah.` : "Soal yang salah sudah jadi kartu sebelumnya.") : r.error); }
  else if (k === "yang-baru"){ bukaYangBaru(); }
});
document.addEventListener("change", async e => {
  const t = e.target;
  if (t.dataset && t.dataset.rencana){ const [tgl, id, jenis] = t.dataset.rencana.split("|"); await api.rencanaCek(tgl, id, t.checked); if (jenis === "materi" && t.checked){ const [cid, n] = id.slice(2).split(/_(?=\d+$)/); await api.setProgress(pKey(cid, Number(n)), "belajar", true); } }
  else if (t.id === "hf-cid"){ UI.hfCid = t.value; render(); }
  else if (t.id === "hf-batas"){ await api.hafalanSet({ batasBaru: Number(t.value) }); }
  else if (t.id === "kap-kerja" || t.id === "kap-libur"){ await api.saveSettings({ kapasitas: { [t.id === "kap-kerja" ? "kerja" : "libur"]: Number(t.value) } }); toast("Waktu belajar disimpan, rencana disusun ulang."); }
  else if (t.id === "gbr-on"){ await api.saveSettings({ gambarRingkasan: t.checked }); }
  else if (t.id === "sr-voice"){ await api.saveSettings({ suara: { voice: t.value } }); }
  else if (t.id === "peta-cid"){ UI.petaCid = t.value; UI.petaSel = null; UI.petaVB = null; render(); }
  else if (t.id === "sf-cid" && UI.simForm){ UI.simForm.cid = t.value; render(); }
  else if (t.dataset && t.dataset.simRagu !== undefined && UI.simAns){ const i = Number(t.dataset.simRagu), A = UI.simAns; A.ragu = A.ragu.filter(x => x !== i); if (t.checked) A.ragu.push(i); simpanSim(); render(); }
});
document.addEventListener("input", e => {
  const t = e.target;
  if (t.id === "peta-cari"){ UI.petaCari = t.value; clearTimeout(UI._pc); UI._pc = setTimeout(render, 220); }
  if (t.dataset && t.dataset.simEssay !== undefined && UI.simAns){ UI.simAns.essay[t.dataset.simEssay] = t.value; simpanSim(); }
});
document.addEventListener("keydown", e => {
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
  const el = $("#lapisan"); if (el && !el.hidden) return;
  if (UI.view === "ujian" && UI.uTab === "hafalan" && UI.hf && UI.hf.i < UI.hf.q.length){
    if (!UI.hf.buka && (e.key === " " || e.key === "Enter")){ e.preventDefault(); UI.hf.buka = true; render(); }
    else if (UI.hf.buka && ["1", "2", "3"].includes(e.key)){ e.preventDefault(); nilaiKartu(Number(e.key) - 1); }
  }
});

/* ---------- render ---------- */
function go(v, opts={}){ UI.view = v; Object.assign(UI, opts); UI.confirmDel = null; render(); window.scrollTo(0,0); }
function render(){
  if(!S) return;
  renderNav();
  const v = UI.view;
  const html = v==="jadwal" ? viewJadwal() : v==="materi" ? viewMateri() : v==="ujian" ? viewUjian() : v==="tanya" ? viewTanya() : v==="todo" ? viewTodo() : v==="pandu" ? viewPandu() : v==="rencana" ? viewRencana() : v==="peta" ? viewPeta() : v==="pengaturan" ? viewPengaturan() : viewBeranda();
  // Isian yang sedang diketik tidak boleh hilang saat data baru masuk dari sinkron
  const ae = document.activeElement, focus = ae && ae.id && /^(INPUT|TEXTAREA)$/.test(ae.tagName) ? { id: ae.id, v: ae.value, a: ae.selectionStart, b: ae.selectionEnd } : null;
  $("#view").innerHTML = html;
  if(focus){ const el = document.getElementById(focus.id); if(el){ if(el.type !== "checkbox") el.value = focus.v; el.focus(); try { el.setSelectionRange(focus.a, focus.b); } catch(e){} } }
  isiGambar(); Suara.tandai(); cekYangBaru();
}
document.addEventListener("input", e => { if(e.target.id === "paste" && UI.plan) UI.plan.paste = e.target.value; });

/* ---------- events ---------- */
document.addEventListener("click", async e => {
  const b = e.target.closest("[data-paksa],[data-ulang],[data-ulangya],[data-ulangno],[data-komalt],[data-kompick],[data-komcopy],[data-lamp],[data-go],[data-open],[data-course],[data-back],[data-week],[data-sem],[data-tab],[data-flip],[data-q],[data-qreset],[data-copy],[data-filter],[data-delask],[data-del],[data-delno],[data-delmateri],[data-exam],[data-ask],[data-act],[data-open-url],[data-provider],[data-modal],[data-rmgroup]");
  if(!b) return;
  const d = b.dataset;
  if(d.openUrl){ e.preventDefault(); api.open(d.openUrl); }
  else if(d.go){ go(d.go, d.go==="materi"?{course:null, meet:null}:{}); }
  else if(d.open){ const [cid,n] = d.open.split("|"); go("materi", {course:cid, meet:Number(n), tab:"ringkasan"}); }
  else if(d.course){ UI.course = d.course; UI.meet = null; UI.exam = null; render(); scrollTo(0,0); }
  else if(d.back){ if(d.back==="materi"){ UI.course=null; UI.meet=null; } else UI.meet=null; render(); scrollTo(0,0); }
  else if(d.week){ UI.week = d.week==="now" ? weekOf(today()) : Math.min(16, Math.max(1, UI.week + Number(d.week))); render(); }
  else if(d.sem){ S.current = d.sem; render(); api.setSemester(d.sem); }
  else if(d.tab){ UI.tab = d.tab; render(); }
  else if(d.flip){ UI.flip[d.flip] = !UI.flip[d.flip]; b.classList.toggle("flip"); }
  else if(d.q){ const [qid,i,j] = d.q.split("|"); (UI.quiz[qid] ||= {})[i] = Number(j); onQuiz(qid); render(); }
  else if(d.qreset){ UI.quiz[d.qreset] = {}; render(); }
  else if(d.copy){ const m = sem().materi[d.copy]; try{ await navigator.clipboard.writeText(m.komentar); toast("Tersalin. Tinggal tempel di kolom komentar LMS."); }catch(err){ toast("Gagal menyalin."); } }
  else if(d.filter){ UI.todoFilter = d.filter; render(); }
  else if(d.delask){ UI.confirmDel = d.delask; render(); }
  else if(d.delno){ UI.confirmDel = null; render(); }
  else if(d.del){ UI.confirmDel = null; await api.delTodo(d.del); toast("To-do dihapus."); }
  else if(d.delmateri){ UI.confirmDel = null; await api.deleteMateri(d.delmateri); UI.meet = null; toast("Materi dihapus."); }
  else if(d.exam !== undefined){ UI.exam = d.exam || null; if(d.exam) UI.quiz["exam_"+d.exam] = {}; render(); }
  else if(d.paksa){ const r = await api.forceLampiran(d.paksa); toast(r.ok ? "File ini akan ikut diringkas. Klik tombol Ringkas di pertemuannya." : r.error); }
  else if(d.ulang){ UI.confirmUlang = d.ulang.replace("|", "_"); render(); }
  else if(d.ulangno){ UI.confirmUlang = null; render(); }
  else if(d.ulangya){ const [cid, n] = d.ulangya.split("|"); UI.confirmUlang = null; UI.lampBusy = cid + "_" + n; render(); const r = await api.resummarize(cid, Number(n)); UI.lampBusy = null; render(); toast(r.ok ? (r.warnings && r.warnings.length ? "Materi diringkas ulang. Catatan: " + r.warnings[0] : "Materi diringkas ulang.") : r.error); }
  else if(d.komalt){ UI.komBusy = d.komalt; render(); const r = await api.komentarAlt(d.komalt); UI.komBusy = null; render(); if(!r.ok) toast(r.error); }
  else if(d.kompick){ const [key, i] = d.kompick.split("|"), m = sem().materi[key], t = m && (m.komentarAlt || [])[Number(i)]; if(!t) return; const r = await api.komentarPick(key, t); toast(r.ok ? "Komentar diganti." : r.error); }
  else if(d.komcopy){ const [key, i] = d.komcopy.split("|"), m = sem().materi[key], t = m && (m.komentarAlt || [])[Number(i)]; if(!t) return; try{ await navigator.clipboard.writeText(t); toast("Tersalin. Tinggal tempel di kolom komentar LMS."); }catch(err){ toast("Gagal menyalin."); } }
  else if(d.lamp){ const [cid, n] = d.lamp.split("|"); UI.lampBusy = cid + "_" + n; render(); const r = await api.summarizeLMS(cid, Number(n)); UI.lampBusy = null; if(r.ok){ toast(r.warnings && r.warnings.length ? "Materi tersusun. Catatan: " + r.warnings[0] : "Materi tersusun."); go("materi", { course: cid, meet: Number(n), tab: "ringkasan" }); } else { render(); toast(r.error); } }
  else if(d.ask){ const q = ($("#askq").value||"").trim(); if(!q) return; UI.ask[d.ask] = { q, busy: true }; render(); const r = await api.ask(q, d.ask); UI.ask[d.ask] = { q, a: r.ok ? r.text : r.error }; render(); }
  else if(d.provider){ UI.aiTest = null; await api.saveSettings({ ai: { provider: d.provider } }); }
  else if(d.modal === "close"){ if(!UI.plan || !UI.plan.running){ UI.plan = null; renderModal(); } }
  else if(d.rmgroup){ UI.plan.groups.splice(Number(d.rmgroup),1); renderModal(); }
  else if(d.act){
    const a = d.act;
    if(a === "hello"){ await api.saveSettings({ welcomed: true }); }
    else if(a === "finish"){ if(!(S.lms.connected && aiReady())){ toast("Selesaikan langkah 1 dan 2 dulu."); return; } if(!absMode()){ toast("Pilih cara absensi kampusmu di langkah 3."); return; } await api.saveSettings({ setupDone: true }); go("beranda"); }
    else if(a === "lms-custom"){ UI.customLms = true; render(); setTimeout(()=>{ const i = $("#kampus-url"); if(i) i.focus(); }, 0); }
    else if(a === "lms-default"){ UI.customLms = false; await api.saveSettings({ kampus: { nama: "", url: "https://edlink.id" } }); }
    else if(a === "login"){ const inp = $("#kampus-url"); if(!inp && !(S.settings.kampus && S.settings.kampus.url)) await api.saveSettings({ kampus: { nama: "", url: "https://edlink.id" } }); if(inp){ const u = (inp.value||"").trim(); if(!u){ toast("Isi alamat LMS kampusmu, atau pilih Pakai Edlink biasa."); inp.focus(); return; } const sv = await api.saveSettings({ kampus: { nama: "", url: u } }); if(!sv.ok){ toast(sv.error); return; } } toast("Jendela login LMS dibuka."); const r = await api.lmsLogin(); toast(r.ok ? "LMS terhubung dan tersinkron." : r.error); }
    else if(a === "sync"){ const r = await api.lmsSync(); toast(r.ok ? (r.baru ? r.baru+" post baru dari LMS." : "Sudah tersinkron.") : r.error); }
    else if(a === "logout"){ await api.lmsLogout(); toast("Keluar dari LMS."); }
    else if(a === "quota-reload"){ UI.qErr = null; loadQuota(true); }
    else if(a === "srv-save"){ const inp = $("#srv-url"); UI.open_adv = true; const r = await api.saveSettings({ ai: { serverUrl: inp ? inp.value : "", provider: "server" } }); if (r && r.ok === false){ toast(r.error); return; } UI.quota = null; UI.qErr = null; UI.qAt = 0; toast("Alamat server disimpan."); }
    else if(a === "auto-save"){ const x = d.for, inp = $("#ak-" + x), k = inp && inp.value.trim(); if(!k){ toast("Tempel API key " + x + " dulu."); return; } await api.saveSettings({ ai: { provider: S.settings.ai.provider === "server" ? "server" : "auto", key: k, keyFor: x } }); UI.akMsg = { ok: true, t: "Menghubungkan…", for: x }; render(); const r = await api.testAI(x); UI.akMsg = r.ok ? { ok: true, t: ({cerebras:"Cerebras",groq:"Groq",gemini:"Gemini"})[x] + " tersambung, model " + r.pick + ".", for: x } : { ok: false, t: r.error, for: x }; render(); }
    else if(a === "backup-save"){ const x = d.for, inp = $("#bk-" + x), k = inp && inp.value.trim(); if(!k){ toast("Tempel API key " + AI_INFO[x].nama + " dulu."); return; } UI.backupOpen = true; await api.saveSettings({ ai: { key: k, keyFor: x } }); UI.bkMsg = { ok: true, t: "Menghubungkan " + AI_INFO[x].nama + "…" }; render(); const r = await api.testAI(x); UI.bkMsg = r.ok ? { ok: true, t: AI_INFO[x].nama + " tersambung sebagai cadangan, model " + r.pick + "." } : { ok: false, t: r.error }; render(); }
    else if(a === "test-ai"){
      const patch = { ai: {} };
      const k = $("#ai-key"); if(k && k.value.trim()) patch.ai.key = k.value.trim();
      const u = $("#ollama-url"); if(u) patch.ai.ollamaUrl = u.value.trim();
      await api.saveSettings(patch);
      UI.aiTest = { ok: true, pick: "menguji…" }; render();
      UI.aiTest = await api.testAI(); render();
    }
    else if(a === "guide"){ const r = await api.openGuide(); if(!r.ok) toast(r.error); }
    else if(a === "guide-file"){ const r = await api.openGuideFile(); if(!r.ok) toast(r.error); }
    else if(a === "cek-update"){ const u = await api.checkUpdate(); if (u && u.state){ UI.status.upd = u; renderUpd(); } }
    else if(a === "install-update"){ api.installUpdate(); }
    else if(a === "add"){ openAdd(d.cid ? { cid: d.cid, meet: d.meet } : null); }
    else if(a === "pick"){ const r = await api.pickFiles(!!d.folder); if(r.paths && r.paths.length){ if(!UI.plan) openAdd(UI.plan && UI.plan.prefill); planItems(r.paths.map(p=>({path:p})), UI.plan && UI.plan.prefill); } }
    else if(a === "paste"){ const t = ($("#paste").value||"").trim(); if(!t) return; UI.plan.paste = ""; const items = /^https?:\/\/\S+$/.test(t) ? [{ url: t }] : [{ text: t }]; planItems(items, UI.plan.prefill); }
    else if(a === "run"){ runPlan(); }
  }
});
// Ingat daftar file dosen yang sedang dibuka supaya tidak tertutup saat data diperbarui
document.addEventListener("toggle", e => { const k = e.target && e.target.dataset && e.target.dataset.ud; if (k) (UI.udOpen ||= {})[k] = e.target.open; }, true);
document.addEventListener("change", async e => {
  const t = e.target;
  if(t.dataset.p){ const [cid,n,f] = t.dataset.p.split("|"); await api.setProgress(pKey(cid, Number(n)), f, t.checked); }
  else if(t.dataset.todo){ const id = t.dataset.todo, td = S.todos[id]; if(td) await api.putTodo(id, { ...td, done: t.checked }); }
  else if(t.id === "geser"){ await api.saveSettings({ geserHari: Number(t.value) }); toast("Hari kuliah disesuaikan."); }
  else if(t.id === "autosync"){ await api.saveSettings({ autoSync: t.checked }); }
  else if(t.id === "background"){ await api.saveSettings({ background: t.checked }); }
  else if(t.id === "uj-auto"){ await api.saveSettings({ ujianOtomatis: t.checked }); }
  else if(t.name === "abs-mode"){ await api.saveSettings({ absensiMode: t.value }); toast(t.value === "komentar" ? "Template, ceklis, to-do, dan pengingat komentar dinyalakan." : t.value === "keaktifan" ? "Aktivitasmu di LMS ditampilkan per pertemuan." : "Template dan ceklis komentar disembunyikan."); }
  else if(t.dataset && t.dataset.peng){ await api.saveSettings({ pengingat: { [t.dataset.peng]: t.checked } }); toast(t.checked ? "Pengingat dinyalakan." : "Pengingat dimatikan."); }
  else if(t.id === "automateri"){ await api.saveSettings({ autoMateri: t.checked }); if(t.checked) toast("Materi dari LMS akan disusun otomatis."); }
  else if(t.id === "ai-model"){ await api.saveSettings({ ai: { model: t.value } }); toast("Model diganti ke " + t.value); }
  else if(t.dataset.g !== undefined){ const g = UI.plan.groups[Number(t.dataset.g)]; const k = t.dataset.k; g[k] = k === "merge" ? t.checked : k === "meet" ? Number(t.value) || null : t.value || null; renderModal(); }
});
document.addEventListener("submit", async e => {
  if(e.target.id !== "addform") return;
  e.preventDefault();
  const text = $("#td-text").value.trim(); if(!text) return;
  const id = "m" + Date.now().toString(36) + Math.random().toString(36).slice(2,6);
  await api.putTodo(id, { text, course: $("#td-course").value, due: $("#td-due").value, time: "", done: false, source: "manual", createdAt: new Date().toISOString() });
  toast("To-do ditambahkan."); const el = $("#td-text"); if(el){ el.value = ""; el.focus(); }
});
function onQuiz(qid){
  if(qid.startsWith("exam_")) return;
  const m = sem().materi[qid]; if(!m) return;
  const st = UI.quiz[qid];
  if(Object.keys(st).length === m.kuis.length){ const r = Object.entries(st).filter(([i,a]) => m.kuis[i].a === a).length; const [cid, n] = qid.split(/_(?=\d+$)/); api.setProgress(pKey(cid, Number(n)), "kuis", r); toast("Skor kuis: "+r+"/"+m.kuis.length); }
}

/* drag & drop dari mana saja */
let dragDepth = 0;
window.addEventListener("dragenter", e => { e.preventDefault(); dragDepth++; if(linked()) $("#drop").hidden = false; });
window.addEventListener("dragleave", e => { dragDepth = Math.max(0, dragDepth-1); if(!dragDepth) $("#drop").hidden = true; });
window.addEventListener("dragover", e => e.preventDefault());
window.addEventListener("drop", e => {
  e.preventDefault(); dragDepth = 0; $("#drop").hidden = true;
  if(!linked()){ toast("Hubungkan akun LMS dulu supaya daftar mata kuliah muncul."); return; }
  const items = [];
  for(const f of e.dataTransfer.files){ const p = api.pathOf(f); if(p) items.push({ path: p }); }
  if(!items.length){ const t = (e.dataTransfer.getData("text/uri-list") || e.dataTransfer.getData("text/plain") || "").trim(); if(t) items.push(/^https?:\/\/\S+$/.test(t.split("\n")[0]) ? { url: t.split("\n")[0] } : { text: t }); }
  if(!items.length) return;
  const pre = UI.plan ? UI.plan.prefill : (UI.view === "materi" && UI.course ? { cid: UI.course, meet: UI.meet || weekOf(today()) } : null);
  if(!UI.plan) UI.plan = { groups: [], skipped: [], prefill: pre, running: false, paste: "" };
  planItems(items, pre);
});

/* ---------- boot ---------- */
api.onState(s => { S = s; applyTheme(); if(!ready() && UI.view !== "pengaturan") UI.view = "beranda"; render(); if(UI.plan) renderModal(); });
function renderJob(){
  const el = $("#job"), msg = UI.status.auto || (!UI.plan && UI.status.ingestOn ? UI.status.ingest : null);
  if (!msg){ el.hidden = true; return; }
  const i = msg.indexOf(": "), head = i > 0 && i < 40 ? msg.slice(0, i) : "Menyusun materi", body = i > 0 && i < 40 ? msg.slice(i + 2) : msg;
  el.innerHTML = `<b>${esc(head)}</b><span>${esc(body)}</span><div class="bar"><i></i></div>`; el.hidden = false;
}
api.onStatus(st => { Object.assign(UI.status, st); if(st.ingest && UI.plan) renderModal(); if("sync" in st) renderNav(); if("auto" in st || "ingest" in st) renderJob(); if(st.update) showUpdate(st.update); if(st.upd) renderUpd(); });
// Versi dan status update di Pengaturan > Tentang
function updLine(u){
  const pakai = `<button class="link" data-act="install-update">Pasang sekarang</button>`;
  switch (u.state){
    case "checking": return "Mengecek update...";
    case "downloading": return `Mengunduh versi ${esc(u.baru || "baru")}${u.persen ? ` (${u.persen}%)` : ""}. Tombol pasang muncul setelah selesai.`;
    case "downloaded": return `Versi ${esc(u.baru || "baru")} siap dipasang. ${pakai}`;
    case "latest": return "Sudah versi terbaru.";
    case "error": return `Gagal mengecek update: ${esc(u.msg || "")}`;
    case "off": return esc(u.msg || "Update otomatis tidak aktif.");
    default: return "Update dicek otomatis setiap aplikasi dibuka.";
  }
}
function updField(){
  const u = UI.status.upd || {}, sibuk = (u.state === "checking" || u.state === "downloading") && !UI.updBuka;
  return `<div class="inline" style="justify-content:space-between"><label>Versi ${esc(u.version || "")}</label><button class="btn" data-act="cek-update" ${sibuk || u.state === "off" ? "disabled" : ""}>${sibuk ? "Mengecek..." : "Cek update"}</button></div><p class="cap">${updLine(u)}</p>`;
}
function renderUpd(){
  const f = $("#upd-field"); if (f) f.innerHTML = updField();
  clearTimeout(renderUpd.t); UI.updBuka = false;
  const st = (UI.status.upd || {}).state;
  if (st === "checking" || st === "downloading") renderUpd.t = setTimeout(() => { UI.updBuka = true; const g = $("#upd-field"); if (g) g.innerHTML = updField(); }, st === "checking" ? 60000 : 300000);
}
api.updateState && api.updateState().then(u => { if (u && u.state){ UI.status.upd = u; renderUpd(); if (u.state === "downloaded" && u.baru) showUpdate(u.baru); } }).catch(() => {});
function showUpdate(v){ if($("#updbtn")) return; const b = document.createElement("button"); b.id = "updbtn"; b.className = "btn dark update"; b.textContent = "Versi " + v + " siap. Mulai ulang untuk update"; b.onclick = () => api.installUpdate(); document.body.appendChild(b); }
$("#syncbtn").addEventListener("click", async () => { const r = await api.lmsSync(); toast(r.ok ? (r.baru ? r.baru+" post baru dari LMS." : "Sudah tersinkron.") : r.error); });
api.getState().then(s => { S = s; applyTheme(); if(!ready()) UI.view = "beranda"; render(); });
// Ingat bagian lipat (details) yang dibuka, supaya tidak tertutup lagi saat layar diperbarui
document.addEventListener("toggle", e => { const d = e.target; if (d && d.dataset && d.dataset.fold) UI["open_" + d.dataset.fold] = d.open; }, true);
})();
