(function(){
"use strict";
const api = window.api;
const $ = (s, el=document) => el.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const rich = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");

/* ---------- icons ---------- */
const svg = p => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const I = {
  home: svg('<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M10 21v-6h4v6"/>'),
  cal: svg('<rect x="3" y="4.5" width="18" height="16.5" rx="3"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/><path d="m8.5 15 2 2 4-4"/>'),
  book: svg('<path d="M4 4.5A1.5 1.5 0 0 1 5.5 3H11v17H5.5A1.5 1.5 0 0 0 4 21.5z"/><path d="M20 4.5A1.5 1.5 0 0 0 18.5 3H13v17h5.5a1.5 1.5 0 0 1 1.5 1.5z"/>'),
  todo: svg('<path d="m4 6.5 1.8 1.8L9 5"/><path d="m4 13.5 1.8 1.8L9 12"/><path d="M12.5 7h8M12.5 14h8M12.5 20h8M5 20h3"/>'),
  gear: svg('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
  left: svg('<path d="m15 18-6-6 6-6"/>'), right: svg('<path d="m9 18 6-6-6-6"/>'),
  trash: svg('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'),
  copy: svg('<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>'),
  help: svg('<circle cx="12" cy="12" r="9"/><path d="M9.6 9.2a2.5 2.5 0 0 1 4.8.9c0 1.7-2.4 2.2-2.4 3.6"/><path d="M12 17h.01"/>'),
  plus: svg('<path d="M12 5v14M5 12h14"/>'),
  spark: svg('<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6.3 6.3l2.5 2.5M15.2 15.2l2.5 2.5M6.3 17.7l2.5-2.5M15.2 8.8l2.5-2.5"/>'),
  bell: svg('<path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2.2 2.2 0 0 0 4 0"/>'),
  exam: svg('<path d="M9 3.5h6l.8 2H19v15.5H5V5.5h3.2z"/><path d="m9 13.5 2 2 4-4"/>'),
  sun: svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'),
  moon: svg('<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>'),
  chat: svg('<path d="M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v9a1.5 1.5 0 0 1-1.5 1.5H10l-4.5 4v-4h0A1.5 1.5 0 0 1 4 14.5z"/><path d="M8 9h8M8 12h5"/>')
};
const CHEV = '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>';

/* ---------- dates ---------- */
const HARI = ["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
const BULAN = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
const BULAN_L = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
const DAY = 864e5;
const parseD = s => { const [y,m,d] = String(s).slice(0,10).split("-").map(Number); return new Date(y, m-1, d); };
const ymd = d => d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
const today = () => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate()); };
const fmtShort = d => d.getDate()+" "+BULAN[d.getMonth()];

/* ---------- state ---------- */
let S = null;
const UI = { view: "beranda", week: null, course: null, meet: null, tab: "ringkasan", todoFilter: "aktif", confirmDel: null, quiz: {}, flip: {}, exam: null, ask: {}, status: {}, aiTest: null, plan: null };
const VIEWS = [["beranda","Beranda",I.home],["jadwal","Jadwal",I.cal],["materi","Materi",I.book],["ujian","Ujian",I.exam],["tanya","Tanya AI",I.chat],["todo","To-do",I.todo],["pengaturan","Pengaturan",I.gear]];

const sem = () => S && S.current && S.semesters[S.current];
const courses = () => { const s = sem(); return s ? Object.values(s.courses) : []; };
const geser = () => Number(S.settings.geserHari) || 0;
const courseDay = c => { const i = HARI.indexOf(c.hariKRS); return i < 0 ? "" : HARI[(i + geser()) % 7]; };
const dayIdx = c => { const i = HARI.indexOf(courseDay(c)); return i < 0 ? 9 : (i + 6) % 7; }; // Senin = 0
const sorted = () => courses().sort((a,b) => dayIdx(a) - dayIdx(b) || String(a.jam).localeCompare(String(b.jam)));
const findCourse = id => courses().find(c => c.id === id);
const materi = (cid, n) => { const s = sem(); return s && s.materi[cid + "_" + n]; };
const pKey = (cid, n) => `${S.current}_${cid}_p${n}`;
const getP = (cid, n) => S.progress[pKey(cid, n)] || {};
// Kalau tanggal mulai semester belum diketahui (LMS belum mengirim jadwal), anggap minggu ini pertemuan 1
const semStart = () => { const m = sem() && sem().mulai; if (m) return parseD(m); const t = today(); return new Date(t.getTime() - ((t.getDay() + 6) % 7) * DAY); };
const weekStart = w => new Date(semStart().getTime() + (w-1)*7*DAY);
const rawWeek = d => Math.floor((d - semStart())/DAY/7) + 1;
const weekOf = d => Math.min(16, Math.max(1, rawWeek(d)));
const tugasOf = (c, w) => (c.tugas && c.tugas[w]) || [];
const lampOf = (c, w) => (c.lampiran && c.lampiran[w]) || [];
const lampBaru = (c, w) => { const m = materi(c.id, w), done = new Set((m && m.lampiranIds) || []); return lampOf(c, w).filter(f => !done.has(f.id)); };
const inQueue = (c, w) => (S.antrean || []).some(x => x.cid === c.id && Number(x.meet) === Number(w));
const lampBtn = (c, w, cls = "btn sm") => { const b = lampBaru(c, w); if(!b.length) return ""; const busy = UI.lampBusy === c.id + "_" + w; if (!busy && inQueue(c, w)) return `<button class="${cls}" data-lamp="${c.id}|${w}" title="Server AI sedang penuh. Dicoba lagi otomatis bertahap (5, 10, 20 menit), atau klik untuk coba sekarang.">Dalam antrean, coba sekarang</button>`; return `<button class="${cls}" data-lamp="${c.id}|${w}" ${busy?"disabled":""} title="${esc(b.map(f=>f.name).join(", "))}">${busy ? "Sedang diringkas…" : materi(c.id, w) ? "Ringkas file baru dari dosen" : `Ringkas file dosen (${b.length})`}</button>`; };
const absenOf = (c, w) => (c.absen && c.absen[w]) || null;
const tugasLabel = t => /^(tugas|kuis|quiz|ujian)\b/i.test(t.judul || "") ? t.judul : t.jenis + ": " + t.judul;
// Cara kampus menghitung kehadiran: "komentar" | "keaktifan" | "tidak" | null (belum dipilih)
const absMode = () => S.settings.absensiMode || (S.settings.absensiKomentar === true ? "komentar" : S.settings.absensiKomentar === false ? "tidak" : null);
const absOn = () => absMode() === "komentar"; // template komentar, ceklis, to-do, dan pengingat komentar hanya untuk kampus yang absensinya lewat komentar
const hadirOf = (c, w) => (c.hadir && c.hadir[w]) || null;
const kelOf = c => c.kelompok || { tugas: {}, info: [], semua: [] };
const pctTxt = v => v == null ? null : Math.max(0, Math.min(100, v)) + "%";
// Indikator kehadiran: status resmi dari dosen, atau "menunggu ACC" plus aktivitasmu yang langsung tercatat di SES
function hadirLine(c, w, full){
  const h = hadirOf(c, w); if (!h) return "";
  const s = h.ses || {}, sesi = (c.sesi || {})[w];
  const mulai = sesi && sesi.start ? new Date(String(sesi.start).replace(" ", "T")) : null;
  const ST = { H: ["ok", "Hadir"], I: ["mid", "Izin"], S: ["mid", "Sakit"], A: ["bad", "Tidak hadir"] };
  const a = absOn() ? absenOf(c, w) : null;
  const bits = [];
  if (a && a.total) bits.push(`komentar ${a.done}/${a.total}`); else if (s.komentar != null && s.nKomentar) bits.push(`komentar ${s.nKomentar}`);
  if (s.lihat != null) bits.push(`materi dibuka ${pctTxt(s.lihat)}`);
  if (s.video != null) bits.push(`video ${pctTxt(s.video)}`);
  if (s.skor != null && full) bits.push(`skor SES ${s.skor}`);
  let cls, label, sub = "";
  if (h.st && ST[h.st]){ [cls, label] = ST[h.st]; label += full ? ", sudah dikonfirmasi dosen" : ""; }
  else if (mulai && mulai > new Date() && !s.interaksi && !s.nKomentar) return full ? `<div class="hadir"><span class="pill">Pertemuan belum dimulai</span></div>` : "";
  else {
    cls = "wait"; label = "Menunggu ACC dosen";
    const kurang = [];
    if (a && a.total && a.done < a.total) kurang.push(`${a.total - a.done} komentar`);
    if (s.lihat != null && s.lihat < 100) kurang.push("buka semua materi");
    if (s.video != null && s.video < 90) kurang.push("tonton video sampai habis");
    sub = kurang.length ? "Supaya aman: " + kurang.join(", ") + "." : (bits.length ? "Aktivitasmu sudah lengkap, tinggal dikonfirmasi dosen." : "");
  }
  return `<div class="hadir ${full ? "full" : ""}"><span class="pill ${cls}">${label}</span>${bits.length ? `<span class="act">${bits.join(", ")}</span>` : ""}${sub ? `<small>${sub}</small>` : ""}</div>`;
}
// Tugas kelompok minggu ini (dan kelompokmu kalau sudah dibagi di LMS)
function kelLine(c, w){
  const k = kelOf(c), ts = (k.tugas || {})[w] || [];
  if (!ts.length) return "";
  return `<div class="kel"><span class="pill kel">Tugas kelompok</span>${ts.map(t => `<a href="#" data-open-url="${esc(t.link)}">${esc(t.judul)}</a>`).join("")}${k.tim ? `<small>${esc(k.tim.nama)}: ${k.tim.anggota.map(x => esc(x.me ? "kamu" : x.nama)).join(", ")}</small>` : k.adaTim ? `<small>Kelompok sudah dibagi di LMS. Buka mata kuliah untuk melihat daftarnya.</small>` : `<small>Pembagian kelompok belum ada di LMS.</small>`}</div>`;
}
const ready = () => linked() && !!S.settings.setupDone; // Beranda baru terbuka setelah LMS tersambung dan AI diatur
const linked = () => !!(S && S.lms.connected && sem() && courses().length);
const openTodos = () => Object.entries(S.todos).filter(([,t]) => !t.done);
const initials = c => (c.singkat || c.nama).replace(/[^A-Za-z ]/g,"").split(" ").filter(Boolean).slice(0,2).map(w=>w[0]).join("").toUpperCase();
const icon = c => `<span class="icon" aria-hidden="true">${initials(c)}</span>`;

function weekStats(w){
  let done = 0, total = 0; const per = {}, tot = {};
  courses().forEach(c => { const p = getP(c.id, w), t = tugasOf(c, w).length > 0; const k = absOn(), n = (p.belajar?1:0)+(k&&p.komentar?1:0)+(t&&p.tugas?1:0); per[c.id] = n; tot[c.id] = 1+(k?1:0)+(t?1:0); done += n; total += tot[c.id]; });
  return { done, total, per, tot };
}
const allDone = (c, w) => { const p = getP(c.id, w); return !!(p.belajar && (!absOn() || p.komentar) && (!tugasOf(c, w).length || p.tugas)); };
function dueInfo(due){
  if(!due) return {txt:"", cls:""};
  const diff = Math.round((parseD(due) - today())/DAY);
  if(diff < 0) return {txt:"lewat "+(-diff)+" hari", cls:"late"};
  if(diff === 0) return {txt:"hari ini", cls:"soon"};
  if(diff === 1) return {txt:"besok", cls:"soon"};
  return {txt: fmtShort(parseD(due)), cls: diff <= 3 ? "soon" : ""};
}
const sortTodos = arr => arr.sort((a,b) => (a[1].done - b[1].done) || String(a[1].due||"9999").localeCompare(String(b[1].due||"9999")) || String(b[1].createdAt||"").localeCompare(String(a[1].createdAt||"")));
function toast(msg){ const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(t._h); t._h = setTimeout(()=>t.classList.remove("show"), 2600); }

/* ---------- shared pieces ---------- */
function renderNav(){
  const n = openTodos().length;
  const cur = UI.view === "pandu" ? "todo" : UI.view;
  const btn = (id,label,ic,mobile) => `<button data-go="${id}" ${cur===id?'aria-current="page"':''}>${mobile?ic:""}<span>${label}</span>${id==="todo"&&n?`<span class="n">${n}</span>`:""}</button>`;
  const vs = !S.settings.welcomed ? [] : ready() ? VIEWS : VIEWS.filter(([id]) => id === "beranda" || id === "pengaturan");
  $("#nav").innerHTML = vs.map(([id,l,ic]) => id === "pengaturan" ? `<button data-go="pengaturan" class="icon-only" aria-label="Pengaturan" title="Pengaturan" ${UI.view===id?'aria-current="page"':''}>${ic}</button>` : btn(id,l,ic,true)).join("");
  $("#tabbar").innerHTML = vs.map(([id,l,ic]) => btn(id,l,ic,true)).join("");
  const sync = $("#sync"), running = UI.status.sync === "running";
  sync.classList.toggle("on", !!S.lms.connected && !S.lms.lastError);
  sync.lastElementChild.textContent = running ? "Menyinkron LMS…" : S.lms.connected ? (S.lms.lastError ? "Sinkron gagal" : "Sinkron " + ago(S.lms.lastSync)) : "LMS belum terhubung";
  $("#syncbtn").hidden = !S.lms.connected || running;
  const gb = $("#guidebtn"); if (gb && !gb.innerHTML.trim()) gb.innerHTML = I.help;
  const tb = $("#themebtn"); if (tb){ const t = S.settings.theme || "auto", dark = t === "dark" || (t === "auto" && matchMedia("(prefers-color-scheme: dark)").matches); tb.innerHTML = dark ? I.sun : I.moon; tb.title = dark ? "Pakai tema terang" : "Pakai tema gelap"; }
}
function ago(iso){ if(!iso) return "belum pernah"; const m = Math.round((Date.now() - new Date(iso))/60000); return m < 1 ? "barusan" : m < 60 ? m+" mnt lalu" : m < 1440 ? Math.round(m/60)+" jam lalu" : Math.round(m/1440)+" hari lalu"; }

function checks(c, w){
  const p = getP(c.id, w);
  const row = (f, label) => `<label class="chk"><input type="checkbox" data-p="${c.id}|${w}|${f}" ${p[f]?"checked":""}><span>${label}</span></label>`;
  return row("belajar","Pelajari materi") + (absOn() ? row("komentar","Komentar absensi") : "") + (tugasOf(c, w).length ? row("tugas", esc(tugasLabel(tugasOf(c,w)[0]))) : "");
}
function absenLine(c, w){
  const a = absenOf(c, w); if(!a || !absOn()) return "";
  if(a.done === a.total) return `<div class="absen"><span class="all">Semua ${a.total} post dosen sudah kamu komentari</span></div>`;
  return `<div class="absen"><span>Komentar ${a.done} dari ${a.total} post</span>${a.belum.map(b=>`<a href="#" data-open-url="${esc(b.link)}">Belum: ${esc(b.judul)}</a>`).join("")}</div>`;
}

/* ---------- halaman selamat datang ---------- */
const host = u => { try { return new URL(u).host; } catch(e){ return u || ""; } };
const kampusHost = () => host(S.settings.kampus && S.settings.kampus.url) || "LMS kampus";
const PEMBUAT = "Nicky Richsandy Pramana";
function viewHello(){
  return `<section class="hello">
    <div class="hello-mark" aria-hidden="true"><img src="logo.svg" alt=""></div>
    <h1>Teman Kuliah</h1>
    <p class="hello-tag">Jadwal, absensi, tugas, dan materi kuliah online dalam satu aplikasi. Tersambung langsung dengan LMS kampus yang memakai Edlink.</p>
    <div class="hello-feats">
      <div class="card hf"><span class="ic">${I.cal}</span><b>Tahu hari ini harus apa</b><span>Kelas, to-do, kuis, dan vicon tersinkron otomatis dari LMS setiap 30 menit.</span></div>
      <div class="card hf"><span class="ic">${I.chat}</span><b>Absensi tidak kelewat</b><span>Kelihatan post dosen mana yang belum kamu komentari, lengkap dengan draft komentarnya.</span></div>
      <div class="card hf"><span class="ic">${I.book}</span><b>Materi lebih mudah dipahami</b><span>File dosen ditulis ulang oleh AI jadi materi yang tetap detail, plus istilah dan kuis latihan.</span></div>
    </div>
    <div class="card hello-ai">
      <h2>AI-nya gratis</h2>
      <div class="rows">
        ${S.serverOn ? `<div class="r"><b>Gemini milikmu</b><span>Meringkas materi, membaca slide bergambar, menonton video kuliah, dan membuat latihan soal. Cukup tempel API key gratis dari akun Google sekali.</span></div>
        <div class="r"><b>Tanya AI</b><span>Disediakan Teman Kuliah, tanpa API key, dengan jatah harian yang terisi lagi setiap jam 00.00 WIB.</span></div>
        <div class="r"><b>Video dosen</b><span>Video kuliah dan link YouTube dari dosen ditonton Gemini lalu diringkas, lengkap dengan poin pentingnya.</span></div>
        <div class="r"><b>Antrean otomatis</b><span>Kalau AI sedang penuh, materi masuk antrean dan diringkas otomatis begitu bisa lagi.</span></div>`
        : `<div class="r"><b>Cerebras</b><span>Menyusun materi, latihan soal, dan rangkuman. Model open source di cloud dengan kuota gratis besar.</span></div>
        <div class="r"><b>Groq</b><span>Menjawab Tanya AI paling cepat dan mentranskrip video dengan Whisper.</span></div>
        <div class="r"><b>Gemini</b><span>Opsional. Menonton video YouTube dan membaca slide bergambar langsung.</span></div>
        <div class="r"><b>Lainnya</b><span>ChatGPT dan Claude (berbayar) atau Ollama (offline) juga bisa dipilih di Pengaturan.</span></div>`}
      </div>
      ${S.serverOn ? "" : `<p class="cap">Cukup tempel API key gratisnya sekali. Kalau satu AI sedang penuh, tugasnya langsung dikerjakan AI lain, jadi tidak perlu antre.</p>`}
    </div>
    <button class="btn dark big" data-act="hello">Mulai</button>
    <p class="hello-by">Dibuat oleh <b>${PEMBUAT}</b>. Butuh bantuan? <button class="link" data-act="guide">Baca panduan</button></p>
  </section>`;
}
function kampusPicker(){
  const k = S.settings.kampus || {}, custom = UI.customLms || (k.url && !/(^|\.)edlink\.id$/i.test(host(k.url)));
  return custom
    ? `<div class="inline"><input id="kampus-url" value="${esc(k.url && !/edlink\.id$/i.test(host(k.url)) ? host(k.url) : "")}" placeholder="Alamat LMS kampusmu, misalnya kuliah.unsia.ac.id" aria-label="Alamat web LMS" spellcheck="false" style="height:40px;border:0;border-radius:14px;background:var(--card-2);padding:0 14px;min-width:300px;flex:1;max-width:460px"></div>
       <p class="cap">Isi kalau kampusmu memakai alamat Edlink sendiri. <button class="link" data-act="lms-default">Pakai Edlink biasa</button></p>`
    : `<p class="cap">Login dengan akun Edlink-mu: Google, Siakad, atau email dan password. <button class="link" data-act="lms-custom">Kampusku punya alamat LMS sendiri</button></p>`;
}

/* ---------- onboarding ---------- */
function viewWelcome(){
  if(!S.settings.welcomed) return viewHello();
  const lmsOk = S.lms.connected, aiOk = aiReady();
  return `<div class="welcome">
    <div><h1 class="large">Siapkan Teman Kuliah</h1><p class="lede">Tiga langkah singkat, lalu jadwal, materi, dan tugas kuliahmu tersusun otomatis.</p></div>
    <div class="steps">
      <section class="card step ${lmsOk?"done":""}"><span class="no">1</span><div class="txt"><h3>Hubungkan Edlink</h3><p class="sub">Login lewat halaman resmi Edlink di jendela aplikasi. Password tidak pernah dilihat atau disimpan aplikasi. Jadwal dan mata kuliahmu muncul setelah ini.</p>${lmsOk ? "" : kampusPicker()}
        <div>${lmsOk ? `<span class="ok-t">Terhubung sebagai ${esc(S.lms.me && S.lms.me.name)}${UI.status.sync==="running"?". Mengambil jadwal dan mata kuliah…":""}</span>` : `<button class="btn dark" data-act="login">Masuk ke Edlink</button>`}</div>${S.lms.lastError?`<p class="err-t">${esc(S.lms.lastError)}</p>`:""}</div></section>
      <section class="card step ${aiOk?"done":""}"><span class="no">2</span><div class="txt">${S.serverOn && S.settings.ai.provider === "server" ? `<h3>Sambungkan Gemini</h3><p class="sub">Tempel API key Gemini gratis milikmu, cukup sekali. Gemini meringkas materi, menonton video kuliah, dan membuat latihan soal. Tanya AI sudah disediakan Teman Kuliah.</p>` : `<h3>Sambungkan AI</h3><p class="sub">Tempel API key gratis, minimal satu. Cerebras dan Groq paling disarankan. Setelah itu aplikasi memilih AI sendiri untuk tiap tugas.</p>`}
        ${aiForm(false)}</div></section>
      <section class="card step ${absMode() ? "done" : ""}"><span class="no">3</span><div class="txt"><h3>Sesuaikan kuliahmu</h3>${absenToggle()}<p class="sub" style="margin-top:8px">Kalau jadwal kuliahmu tidak sama dengan hari di KRS, geser di sini.</p>${geserSelect()}</div></section>
    </div>
    <div class="finish"><button class="btn dark big" data-act="finish" ${lmsOk && aiOk && absMode() ? "" : "disabled"}>Buka Beranda</button>
      <p class="cap">${!lmsOk && !aiOk ? "Hubungkan Edlink dan sambungkan AI dulu." : !lmsOk ? "Hubungkan Edlink dulu." : !aiOk ? (S.serverOn && S.settings.ai.provider === "server" ? "Tempel API key Gemini dulu di langkah 2, supaya file dosen bisa langsung diringkas." : "Sambungkan AI dulu di langkah 2, supaya file dosen bisa langsung diringkas.") : !absMode() ? "Pilih cara absensi kampusmu di langkah 3." : "Semua siap."}</p></div></div>`;
}
const AI_INFO = {
  gemini: { nama: "Gemini", price: "Gratis", free: true, short: "Akun Google. Bisa baca slide bergambar dan video YouTube.",
    steps: [`Buka <a href="#" data-open-url="https://aistudio.google.com/apikey">aistudio.google.com/apikey</a> dan masuk dengan akun Google.`, `Klik <b>Create API key</b>, lalu salin key-nya.`, `Tempel di bawah, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Kuota gratisnya cukup untuk dipakai setiap hari. Kalau muncul pesan kuota habis, tunggu beberapa menit." },
  cerebras: { nama: "Cerebras", price: "Gratis, open source", free: true, short: "Model open source di cloud. Cepat, kuota besar, baca teks dan gambar slide.",
    steps: [`Buka <a href="#" data-open-url="https://cloud.cerebras.ai">cloud.cerebras.ai</a> dan daftar dengan Google atau email.`, `Buka menu <b>API Keys</b>, buat key baru, lalu salin.`, `Tempel di bawah, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Memakai model open source seperti Qwen dan GPT-OSS di server Cerebras, jadi tidak perlu laptop kuat. Membaca teks PDF, PPT, DOCX, dan sampai 2 gambar slide per materi. Video bisa diringkas kalau API key Groq diisi di Cadangan otomatis (transkrip Whisper)." },
  groq: { nama: "Groq", price: "Gratis, open source", free: true, short: "Paling cepat untuk Tanya AI. Punya Whisper untuk transkrip video.",
    steps: [`Buka <a href="#" data-open-url="https://console.groq.com/keys">console.groq.com/keys</a> dan masuk dengan Google atau email.`, `Klik <b>Create API Key</b>, lalu salin.`, `Tempel di bawah, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Jawabannya sangat cepat, cocok untuk Tanya AI, dan videonya ditranskrip otomatis dengan Whisper. Kuota per menitnya kecil, jadi materi yang sangat panjang lebih baik disusun Gemini atau Cerebras." },
  ollama: { nama: "Ollama", price: "Gratis, offline", free: true, short: "Jalan di laptopmu sendiri. RAM 16 GB, hanya teks.",
    steps: [`Unduh dan install Ollama dari <a href="#" data-open-url="https://ollama.com/download">ollama.com/download</a>.`, `Buka Command Prompt, ketik <code class="cmd">ollama pull qwen2.5:7b</code>, lalu tunggu unduhan sekitar 4,7 GB selesai.`, `Pastikan ikon llama muncul di pojok kanan bawah taskbar, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Tidak butuh internet dan tanpa kuota, tapi lebih lambat dan tidak bisa membaca slide bergambar atau video." },
  openai: { nama: "ChatGPT", price: "Berbayar", short: "Bayar sesuai pemakaian lewat saldo API OpenAI.",
    steps: [`Buka <a href="#" data-open-url="https://platform.openai.com/api-keys">platform.openai.com/api-keys</a>, klik <b>Create new secret key</b>, lalu salin.`, `Isi saldo di menu <b>Billing</b>, minimal sekitar USD 5.`, `Tempel key di bawah, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Langganan ChatGPT Plus tidak termasuk akses API, jadi saldonya terpisah." },
  anthropic: { nama: "Claude", price: "Berbayar", short: "Bayar sesuai pemakaian lewat kredit API Anthropic.",
    steps: [`Buka <a href="#" data-open-url="https://console.anthropic.com/settings/keys">console.anthropic.com/settings/keys</a>, klik <b>Create Key</b>, lalu salin.`, `Isi kredit di menu <b>Billing</b>.`, `Tempel key di bawah, lalu klik <b>Simpan & sambungkan</b>.`],
    note: "Langganan Claude Pro atau Max tidak termasuk akses API. Model Opus, Sonnet, atau Haiku bisa dipilih di Pengaturan." }
};
const ownKeys = () => ["cerebras", "groq", "gemini"].some(x => S.settings.ai.hasKey && S.settings.ai.hasKey[x]);
const aiReady = () => { const a = S.settings.ai, p = a.provider; if (p === "server") return ownKeys(); if (p === "auto") return ["cerebras", "groq", "gemini"].some(x => a.hasKey && a.hasKey[x]); return !!(a.model && a.model[p]) && (p === "ollama" || !!(a.hasKey && a.hasKey[p])); };
const inputStyle = "height:40px;border:0;border-radius:14px;background:var(--card-2);padding:0 14px;min-width:280px;max-width:100%";
// Mode otomatis: cukup isi API key gratis, aplikasi memilih AI per tugas dan pindah sendiri kalau ada yang penuh
const AUTO_KEYS = [
  ["cerebras", "Cerebras", "Disarankan", "Menyusun materi, latihan soal, dan rangkuman. Kuota gratis besar.", "https://cloud.cerebras.ai", "Daftar dengan Google atau email, buka menu API Keys, buat key."],
  ["groq", "Groq", "Disarankan", "Tanya AI paling cepat, dan transkrip video dengan Whisper.", "https://console.groq.com/keys", "Masuk dengan Google atau email, klik Create API Key."],
  ["gemini", "Gemini", "Opsional", "Menonton video YouTube dan membaca slide bergambar langsung.", "https://aistudio.google.com/apikey", "Masuk dengan akun Google, klik Create API key."]
];
function akRow(k, nm, tag, use, url, how){
  const a = S.settings.ai;
  const on = a.hasKey && a.hasKey[k], mdl = a.model && a.model[k];
      return `<div class="ak ${on ? "on" : ""}"><div class="ak-h"><span class="ak-dot"></span><b>${nm}</b><span class="tagc">${tag}</span><span class="cap ak-use">${use}</span></div>
        <div class="ak-in"><input id="ak-${k}" type="password" placeholder="${on ? "Tersimpan " + esc(a.keys[k]) + (mdl ? ", model " + esc(mdl) : "") : "Tempel API key " + nm}" style="${inputStyle};background:var(--card)"><button class="btn sm ${on ? "" : "dark"}" data-act="auto-save" data-for="${k}">${on ? "Ganti" : "Simpan"}</button><a href="#" class="ak-link" data-open-url="${url}">Ambil key gratis</a></div>
        ${on ? "" : `<p class="cap">${how}</p>`}</div>`;
}
function autoForm(full, skip){
  const a = S.settings.ai, KEYS = AUTO_KEYS.filter(([k]) => k !== skip), n = KEYS.filter(([k]) => a.hasKey && a.hasKey[k]).length;
  if (skip) return `<div class="auto-box">${KEYS.map(([k, nm, tag, use, url, how]) => akRow(k, nm, "Opsional", use, url, how)).join("")}${UI.akMsg && UI.akMsg.for !== "gemini" ? `<p class="${UI.akMsg.ok ? "ok-t" : "err-t"}">${esc(UI.akMsg.t)}</p>` : ""}</div>`;
  return `<div class="auto-box">
    <div class="ab-h"><div><b>AI otomatis</b><span class="price free">Gratis</span></div><p class="cap">${n ? `${n} dari 3 tersambung. ` : ""}Isi satu kali, lalu aplikasi memilih AI yang paling cocok untuk tiap tugas dan langsung pindah ke AI lain kalau ada yang penuh. Tidak perlu antre.</p></div>
    ${AUTO_KEYS.map(([k, nm, tag, use, url, how]) => akRow(k, nm, tag, use, url, how)).join("")}
    ${UI.akMsg ? `<p class="${UI.akMsg.ok ? "ok-t" : "err-t"}">${esc(UI.akMsg.t)}</p>` : ""}
    <p class="ai-note">Cara kerjanya: materi disusun Cerebras, Tanya AI dijawab Groq, video ditonton Gemini atau ditranskrip Whisper. Kalau satu penuh, tugasnya langsung dikerjakan yang lain. API key hanya disimpan di laptop ini.</p>
  </div>`;
}
// AI Teman Kuliah: server milik pembuat aplikasi, pengguna tidak perlu API key
const Q_NAMA = { materi: "Ringkas materi", chat: "Tanya AI", lain: "Latihan & rangkuman", video: "Transkrip video" };
function loadQuota(force){
  if (UI.qLoading || (!force && UI.qAt && Date.now() - UI.qAt < 60000)) return;
  UI.qLoading = true;
  api.aiQuota().then(r => { UI.qLoading = false; UI.qAt = Date.now(); if (r && r.ok === false){ UI.qErr = r.error; UI.quota = null; } else { UI.quota = r; UI.qErr = null; } render(); });
}
function serverCard(){
  setTimeout(() => loadQuota(), 0);
  const q = UI.quota;
  return `<div class="auto-box srv">
    <div class="ab-h"><div><b>AI Teman Kuliah</b><span class="price free">Gratis</span><span class="tagc">Tanpa API key</span></div><p class="cap">Sudah siap, tanpa API key. Tanya AI dijawab cepat oleh server Teman Kuliah, yang juga jadi cadangan kalau Gemini-mu penuh. Jatah harian terisi lagi setiap jam 00.00 WIB.</p></div>
    ${q && q.sisa ? `<div class="qrow">${["chat"].filter(k => k in q.sisa).map(k => `<span class="qchip ${q.sisa[k] ? "" : "out"}">${Q_NAMA[k]} <b>${q.sisa[k]}/${q.jatah[k]}</b></span>`).join("")}</div><p class="cap">Sisa jatah hari ini.</p>`
      : UI.qErr ? `<p class="err-t">${esc(UI.qErr)} <button class="link" data-act="quota-reload">Coba lagi</button></p>` : `<p class="cap">Memuat sisa jatah hari ini…</p>`}
  </div>`;
}
function serverAdv(){
  const a = S.settings.ai;
  return `<details class="manual" data-fold="adv" ${UI.open_adv ? "open" : ""}><summary>Lanjutan</summary><p class="cap">Alamat server AI. Hanya untuk pembuat aplikasi; biarkan kosong untuk memakai alamat bawaan.</p>
    <div class="ak-in"><input id="srv-url" value="${esc(a.serverUrl || "")}" placeholder="https://teman-kuliah-ai.namamu.workers.dev" spellcheck="false" style="${inputStyle};background:var(--card)"><button class="btn sm" data-act="srv-save">Simpan</button></div></details>`;
}
function geminiBox(){
  const a = S.settings.ai, on = a.hasKey && a.hasKey.gemini;
  return `<div class="auto-box gem ${on ? "on" : ""}">
    <div class="ab-h"><div><b>Gemini milikmu</b><span class="price free">Gratis</span><span class="tagc">${on ? "Tersambung" : "Wajib, 1 menit"}</span></div><p class="cap">Dipakai untuk meringkas materi, membaca slide bergambar, menonton video kuliah dan YouTube, dan membuat latihan soal. Cukup akun Google, tanpa kartu.</p></div>
    ${on ? "" : `<ol class="gem-steps"><li>Buka <a href="#" data-open-url="https://aistudio.google.com/apikey">aistudio.google.com/apikey</a> dan masuk dengan akun Google.</li><li>Klik <b>Create API key</b>, lalu salin key-nya.</li><li>Tempel di bawah, lalu klik <b>Simpan</b>.</li></ol>`}
    <div class="ak-in"><input id="ak-gemini" type="password" placeholder="${on ? "Tersimpan " + esc(a.keys.gemini) + (a.model && a.model.gemini ? ", model " + esc(a.model.gemini) : "") : "Tempel API key Gemini"}" style="${inputStyle};background:var(--card)"><button class="btn sm ${on ? "" : "dark"}" data-act="auto-save" data-for="gemini">${on ? "Ganti" : "Simpan"}</button></div>
    ${UI.akMsg && UI.akMsg.for === "gemini" ? `<p class="${UI.akMsg.ok ? "ok-t" : "err-t"}">${esc(UI.akMsg.t)}</p>` : ""}
  </div>`;
}
function aiForm(full){
  const a = S.settings.ai, p = a.provider;
  if (p === "server" && S.serverOn) return geminiBox() + serverCard()
    + `<details class="manual" data-fold="own" ${UI.open_own ? "open" : ""}><summary>Tambah AI lain (opsional)</summary><p class="cap" style="margin:8px 0 10px">Tidak wajib. Cerebras dan Groq milikmu dipakai sebagai cadangan kalau Gemini sedang penuh.</p>${autoForm(full, "gemini")}
      <details class="manual" data-fold="one" ${UI.open_one ? "open" : ""}><summary>Atau pakai satu AI pilihanmu saja</summary>${aiFormManual(full)}</details></details>`
    + (full ? serverAdv() : "");
  if (p === "server") return autoForm(full) + `<details class="manual" data-fold="one" ${UI.open_one ? "open" : ""}><summary>Atau pilih satu AI saja</summary>${aiFormManual(full)}</details>` + (full ? serverAdv() : "");
  const manual = `<details class="manual" ${p !== "auto" || UI.manualOpen ? "open" : ""}><summary>${p === "auto" ? "Atau pilih satu AI saja" : "Pilih AI"}</summary>${aiFormManual(full)}</details>`;
  const toServer = S.serverOn ? `<div class="auto-switch"><p class="cap">Sedang memakai API key sendiri. <button class="link" data-provider="server">Pakai AI Teman Kuliah (gratis, tanpa API key)</button></p></div>` : "";
  return toServer + (p === "auto" ? autoForm(full) : `<div class="auto-switch"><p class="cap">Sedang memakai satu AI saja. <button class="link" data-provider="auto">Pakai AI otomatis dengan API key sendiri</button></p></div>`) + manual + (full ? serverAdv() : "");
}
function aiFormManual(full){
  const a = S.settings.ai, p = a.provider === "auto" || a.provider === "server" ? "" : a.provider, info = AI_INFO[p] || AI_INFO.gemini, t = UI.aiTest, cur = a.model && a.model[p], ml = a.models && a.models[p];
  const status = t ? (t.pick === "menguji…" ? `<p class="cap">Menghubungkan ke ${info.nama}…</p>` : t.ok ? `<p class="ok-t">Tersambung ke ${info.nama}${full ? "" : ". Model dipilih otomatis: " + esc(t.pick)}</p>` : `<p class="err-t">${esc(t.error)}</p>`)
    : aiReady() ? `<p class="ok-t">Tersambung ke ${info.nama}${cur ? ", model " + esc(cur) : ""}</p>` : "";
  if (!p) return `<div class="ai-grid" role="group" aria-label="Pilih AI">${Object.entries(AI_INFO).map(([k,v])=>`<button class="ai-opt" data-provider="${k}" aria-pressed="false"><b>${v.nama}</b><span class="price ${v.free?"free":""}">${v.price}</span><span>${v.short}</span></button>`).join("")}</div>`;
  return `<div class="ai-grid" role="group" aria-label="Pilih AI">${Object.entries(AI_INFO).map(([k,v])=>`<button class="ai-opt" data-provider="${k}" aria-pressed="${p===k}"><b>${v.nama}</b><span class="price ${v.free?"free":""}">${v.price}</span><span>${v.short}</span></button>`).join("")}</div>
    <div class="ai-how">
      <ol>${info.steps.map(x => `<li>${x}</li>`).join("")}</ol>
      <div class="inline">${p==="ollama"
        ? `<input id="ollama-url" value="${esc(a.ollamaUrl || "http://127.0.0.1:11434")}" aria-label="Alamat Ollama" spellcheck="false" style="${inputStyle};background:var(--card)">`
        : `<input id="ai-key" type="password" placeholder="${a.hasKey && a.hasKey[p] ? "Tersimpan " + esc(a.keys[p]) : "Tempel API key " + info.nama}" aria-label="API key ${info.nama}" style="${inputStyle};background:var(--card)">`}
        <button class="btn dark" data-act="test-ai">Simpan & sambungkan</button></div>
      ${status}
      <p class="ai-note">${info.note}${p==="ollama" ? "" : " API key hanya disimpan di laptop ini."}</p>
    </div>
    ${backupForm(p)}
    ${full && ml && ml.list && ml.list.length ? `<div class="field" style="padding:6px 0 0"><label for="ai-model">Model</label>
      <select id="ai-model" style="height:40px;border:0;border-radius:14px;background:var(--card-2);padding:0 12px;max-width:420px">${ml.list.map(m=>`<option value="${esc(m)}" ${m===cur?"selected":""}>${esc(m)}${m===ml.auto?" (otomatis, disarankan)":""}</option>`).join("")}</select>
      <p class="cap">Otomatis memilih model yang pintar tapi hemat${p==="anthropic"?" (Sonnet). Pilih Opus untuk hasil paling teliti, tapi biayanya lebih mahal":p==="openai"?". Varian mini lebih murah, varian pro lebih mahal":p==="gemini"?" (Flash). Pro lebih teliti tapi lebih lambat dan kuota gratisnya lebih kecil":""}.</p></div>` : ""}`;
}
// Cadangan otomatis: dipakai saat AI utama penuh, dan Groq untuk transkrip video (Whisper)
function backupForm(p){
  const a = S.settings.ai, list = ["cerebras", "groq"].filter(x => x !== p);
  return `<details class="backup" ${UI.backupOpen ? "open" : ""}><summary><b>Cadangan otomatis</b><span class="cap">${list.filter(x => a.hasKey && a.hasKey[x]).length ? "Aktif: " + list.filter(x => a.hasKey && a.hasKey[x]).map(x => AI_INFO[x].nama).join(" dan ") : "Opsional, supaya tidak perlu antre saat AI utama penuh"}</span></summary>
    <p class="cap">Kalau ${esc(AI_INFO[p].nama)} sedang penuh, materi langsung disusun ${list.map(x => AI_INFO[x].nama).join(" atau ")}. API key Groq juga dipakai untuk mentranskrip video dosen dengan Whisper kalau AI utamamu tidak bisa menonton video. Keduanya gratis.</p>
    ${list.map(x => `<div class="bk-row"><b>${AI_INFO[x].nama}</b><input id="bk-${x}" type="password" placeholder="${a.hasKey && a.hasKey[x] ? "Tersimpan " + esc(a.keys[x]) : "API key " + AI_INFO[x].nama}" style="${inputStyle};background:var(--card)"><button class="btn sm" data-act="backup-save" data-for="${x}">Simpan</button><a href="#" class="cap" data-open-url="${x === "groq" ? "https://console.groq.com/keys" : "https://cloud.cerebras.ai"}">Ambil key</a></div>`).join("")}
    ${UI.bkMsg ? `<p class="${UI.bkMsg.ok ? "ok-t" : "err-t"}">${esc(UI.bkMsg.t)}</p>` : ""}
  </details>`;
}
function absenToggle(){
  const m = absMode();
  const opt = (v, t, d) => `<label class="opt-card ${m === v ? "on" : ""}"><input type="radio" name="abs-mode" id="abs-${v}" value="${v}" ${m === v ? "checked" : ""}><span class="txt"><b>${t}</b><small>${d}</small></span></label>`;
  return `<fieldset class="abs-choice"><legend>Bagaimana kampusmu menghitung kehadiran?</legend>
    ${opt("komentar", "Komentar di setiap post dosen", "Seperti di UNSIA. Kamu dapat draft komentar yang bisa dibuat ulang, ceklis, to-do komentar, dan pengingat jam 19.00 kalau masih ada yang belum.")}
    ${opt("keaktifan", "Keaktifan di LMS", "Dihitung dari membuka materi, mengunduh file, dan menonton video. Teman Kuliah menampilkan aktivitasmu per pertemuan.")}
    ${opt("tidak", "Tidak keduanya", "Absensi diisi dosen atau lewat cara lain. Template komentar dan ceklisnya disembunyikan.")}
  </fieldset><p class="cap">Status hadir dari dosen tetap tampil di semua pilihan. ${m ? "Bisa diganti kapan saja di Pengaturan." : "Pilih salah satu dulu."}</p>`;
}
function geserSelect(){
  const g = geser();
  return `<select id="geser" aria-label="Geser hari kuliah" style="height:40px;border:0;border-radius:14px;background:var(--card-2);padding:0 12px;max-width:360px">${[0,1,2,3,4,5,6].map(n=>`<option value="${n}" ${n===g?"selected":""}>${n===0?"Sama dengan KRS":`Senin di KRS jadi ${HARI[(1+n)%7]} (geser ${n} hari)`}</option>`).join("")}</select>`;
}

/* ---------- beranda ---------- */
function viewBeranda(){
  if(!ready()) return viewWelcome();
  const t = today(), rw = rawWeek(t), w = weekOf(t), dn = HARI[t.getDay()];
  const todays = sorted().filter(c => courseDay(c) === dn);
  const st = weekStats(w), frac = st.total ? st.done/st.total : 0, pct = Math.round(frac*100), R = 62, C = 2*Math.PI*R;
  const todos = sortTodos(openTodos()).slice(0,5);
  const nextDay = (() => { for(let i=1;i<=7;i++){ const d = new Date(t.getTime()+i*DAY); const cs = sorted().filter(c => courseDay(c) === HARI[d.getDay()]); if(cs.length) return {d, cs}; } return null; })();
  const missing = []; if (absOn()) sorted().forEach(c => { for(let n=1;n<=w;n++){ const a = absenOf(c,n); if(a) a.belum.forEach(b => missing.push({c, n, ...b})); } });
  const status = rw < 1 ? "Semester belum mulai" : rw > 16 ? "Semester sudah selesai" : `Pertemuan ${w} dari 16, ${esc(sem().label)}`;
  return `${S.lms.needsLogin ? `<div class="banner">Sesi LMS kamu habis, jadi data belum diperbarui. <button class="link" data-act="login">Masuk lagi</button></div>` : ""}
  <section class="board" aria-label="Ringkasan hari ini">
    <div class="board-top">
      <div><p class="hi">${sapa()}${S.lms.me && S.lms.me.name ? ", " + esc(firstName(S.lms.me.name)) : ""}</p>
        <h1 class="board-date">${HARI[t.getDay()]}, ${t.getDate()} ${BULAN_L[t.getMonth()]}</h1>
        <p class="board-status">${status}</p></div>
      <button class="btn hl-btn" data-act="add">${I.plus}Tambah materi</button>
    </div>
    <p class="say">${ringkasHari(todays, w, missing)}</p>
    ${dayline(todays)}
  </section>
  <div class="bento">
    <section class="card w w-today">
      <div class="w-h"><h2>${todays.length ? "Kuliah hari ini" : "Hari ini kosong"}</h2><button class="link" data-go="jadwal">Jadwal minggu ini</button></div>
      ${todays.length ? todays.map(c => klass(c, w)).join("") : `<p class="sub">Tidak ada kelas. Pakai waktunya untuk mencicil materi atau to-do.</p>`}
      ${nextDay ? `<p class="next">Berikutnya <b>${HARI[nextDay.d.getDay()]}, ${fmtShort(nextDay.d)}</b>: ${nextDay.cs.map(c=>esc(c.nama)).join(" dan ")}</p>` : ""}
    </section>
    <section class="card w w-ring">
      <div class="w-h"><h2>Minggu ini</h2><span class="cap">${fmtShort(weekStart(w))} sampai ${fmtShort(new Date(weekStart(w).getTime()+6*DAY))}</span></div>
      <div class="ringbox">
        <svg class="ring" viewBox="0 0 150 150" role="img" aria-label="${pct} persen ceklis selesai"><circle class="bg" cx="75" cy="75" r="${R}"/><circle class="fg ${pct>=100?"full":""}" cx="75" cy="75" r="${R}" stroke-dasharray="${C}" stroke-dashoffset="${C*(1-frac)}" transform="rotate(-90 75 75)"/><text class="big" x="75" y="80" text-anchor="middle">${pct}%</text><text class="small" x="75" y="100" text-anchor="middle">${st.done} dari ${st.total}</text></svg>
        <div class="legend">${sorted().map(c => `<span data-c="${c.warna}"><i class="dot"></i><em>${esc(c.singkat)}</em><b>${st.per[c.id]}/${st.tot[c.id]}</b></span>`).join("")}</div>
      </div>
    </section>
    <section class="card w w-todo">
      <div class="w-h"><h2>To-do</h2><button class="link" data-go="todo">Lihat semua</button></div>
      <div class="tlist">${todos.length ? todos.map(([id,td]) => { const c = findCourse(td.course), di = dueInfo(td.due); return `<div class="ti" ${c?`data-c="${c.warna}"`:""}><label class="chk"><input type="checkbox" data-todo="${esc(id)}" aria-label="Tandai selesai"></label><div class="txt"><div class="t">${esc(td.text)}</div><div class="s">${c?esc(c.singkat):"Umum"}${td.time?", "+esc(td.time):""}</div></div><span class="due ${di.cls}">${di.txt}</span></div>`; }).join("") : `<p class="sub">Semua beres.</p>`}</div>
    </section>
    ${absOn() ? "" : notesFiles(w)}
    <section class="card w w-note" ${absOn() ? "" : "hidden"}>
      <div class="w-h"><h2>Belum dikomentari</h2><span class="cap">untuk absensi</span></div>
      ${missing.length ? `<div class="missing">${missing.slice(0,6).map(m => `<div class="mi" data-c="${m.c.warna}"><i class="dot" style="margin-top:6px"></i><div class="txt">${esc(m.judul)}<small>${esc(m.c.singkat)}, pertemuan ${m.n}</small></div><button class="btn sm" data-open-url="${esc(m.link)}">Buka</button></div>`).join("")}</div>${missing.length>6?`<p class="cap">dan ${missing.length-6} post lainnya</p>`:""}` : `<p class="sub">Semua post dosen sampai minggu ini sudah kamu komentari.</p>`}
    </section>
  </div>`;
}
function klass(c, w){
  const has = materi(c.id, w);
  return `<div class="klass" data-c="${c.warna}">${c.jam ? `<span class="when">${esc(String(c.jam).split(/[-–]/)[0].trim())}</span>` : ""}${icon(c)}<div style="flex:1; min-width:0">
    <h3>${esc(c.nama)}</h3><p class="cap">${esc(c.dosen)}</p>
    <div class="checks">${checks(c, w)}</div>${absenLine(c, w)}${hadirLine(c, w)}${kelLine(c, w)}
    <div class="acts">${has?`<button class="btn sm" data-open="${c.id}|${w}">Buka materi</button>`:""}${lampBtn(c, w)}${!has && !lampBaru(c,w).length?`<button class="btn sm" data-act="add" data-cid="${c.id}" data-meet="${w}">Tambah materi</button>`:""}<button class="btn sm" data-open-url="${esc(c.lms)}">Kelas di LMS</button></div>
  </div></div>`;
}

function sapa(){ const h = new Date().getHours(); return h < 11 ? "Selamat pagi" : h < 15 ? "Selamat siang" : h < 19 ? "Selamat sore" : "Selamat malam"; }
function firstName(n){ const w = String(n).trim().split(/\s+/)[0] || ""; return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase(); }
// Satu kalimat ringkas tentang hari ini; angka penting diberi stabilo.
function ringkasHari(todays, w, missing){
  const t = today(), soon = openTodos().filter(([,x]) => x.due && (parseD(x.due) - t) / DAY <= 3 && (parseD(x.due) - t) >= 0).length;
  const late = openTodos().filter(([,x]) => x.due && parseD(x.due) < t).length;
  const bits = [];
  bits.push(todays.length ? `ada <mark class="hl">${todays.length} kuliah</mark>` : "tidak ada kuliah");
  if (soon) bits.push(`<mark class="hl">${soon} to-do</mark> tenggatnya 3 hari ke depan`);
  if (late) bits.push(`<mark class="hl">${late} to-do</mark> sudah lewat tenggat`);
  if (missing.length) bits.push(`<mark class="hl">${missing.length} post</mark> belum kamu komentari`);
  const un = ujianNow(); if (un.d != null && un.d >= 0 && un.d <= 14) bits.push(`${UJI_N[un.jenis]} tinggal <mark class="hl">${un.d === 0 ? "hari ini" : un.d + " hari"}</mark>`);
  const last = bits.length > 1 ? bits.pop() : null;
  const s = "Hari ini " + bits.join(", ") + (last ? ", dan " + last : "") + ".";
  return s + (!soon && !late && !missing.length ? ` <span class="muted">Tidak ada yang mendesak.</span>` : "");
}

// Garis waktu hari ini: blok kuliah sesuai jam, jarum menunjukkan sekarang.
function dayline(todays){
  const H0 = 7, H1 = 22, span = (H1 - H0) * 60, toMin = x => { const m = String(x || "").match(/(\d{1,2})[.:](\d{2})/); return m ? (+m[1]) * 60 + (+m[2]) : null; };
  const pos = m => Math.max(0, Math.min(100, (m - H0 * 60) / span * 100));
  const now = new Date(), nm = now.getHours() * 60 + now.getMinutes();
  const blocks = todays.map(c => { const [a, b] = String(c.jam || "").split(/[-–]/); const s0 = toMin(a), e0 = toMin(b) || (s0 != null ? s0 + 100 : null); if (s0 == null) return ""; const live = nm >= s0 && nm < e0, past = nm >= e0;
    return `<button class="blk ${live ? "live" : ""} ${past ? "past" : ""}" data-c="${c.warna}" data-course="${c.id}" style="left:${pos(s0)}%; width:${Math.max(6, pos(e0) - pos(s0))}%" title="${esc(c.nama)}, ${esc(c.jam)}"><b>${esc(c.singkat)}</b><span>${esc(c.jam)}</span></button>`; }).join("");
  const ticks = [7, 10, 13, 16, 19, 22].map(h => `<i style="left:${pos(h * 60)}%"><span>${String(h).padStart(2, "0")}.00</span></i>`).join("");
  const needle = nm >= H0 * 60 && nm <= H1 * 60 ? `<em class="now" style="left:${pos(nm)}%"></em>` : "";
  return `<div class="dayline" aria-hidden="${todays.length ? "false" : "true"}"><div class="track">${ticks}${blocks}${needle}</div></div>`;
}

// Untuk kampus tanpa absensi komentar: kartu file dosen yang belum diringkas
function notesFiles(w){
  const items = []; sorted().forEach(c => { for(let n = w; n >= 1; n--){ const b = lampBaru(c, n); if(b.length) items.push({ c, n, b }); } });
  return `<section class="card w w-note"><div class="w-h"><h2>File dosen belum diringkas</h2><span class="cap">sampai pertemuan ${w}</span></div>
    ${items.length ? `<div class="missing">${items.slice(0,6).map(x => `<div class="mi" data-c="${x.c.warna}"><i class="dot" style="margin-top:6px"></i><div class="txt">${esc(x.b.map(f => f.name).join(", "))}<small>${esc(x.c.singkat)}, pertemuan ${x.n}</small></div>${lampBtn(x.c, x.n)}</div>`).join("")}</div>` : `<p class="sub">Semua file dari dosen sudah tersusun jadi materi.</p>`}</section>`;
}

/* ---------- jadwal ---------- */
function viewJadwal(){
  if(!ready()) return viewWelcome();
  const t = today(); if(UI.week == null) UI.week = weekOf(t);
  const w = UI.week, ws = weekStart(w), st = weekStats(w);
  const used = [...new Set(sorted().map(courseDay))];
  const order = ["Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu"].filter(d => used.includes(d));
  const cols = order.map(day => {
    const d = new Date(ws.getTime() + ((HARI.indexOf(day)+6)%7)*DAY);
    const cs = sorted().filter(c => courseDay(c) === day);
    return `<div class="wday ${ymd(d)===ymd(t)?"today":""}"><div class="wday-h"><span class="num">${d.getDate()}</span><span class="nm">${day}</span></div>
      ${cs.map(c => `<article class="ev ${allDone(c,w)?"complete":""}" data-c="${c.warna}">
        <div class="ev-top">${icon(c)}<div style="min-width:0"><h3>${esc(c.nama)}</h3><p class="cap">Di KRS ${esc(c.hariKRS)}, ${esc(c.jam)}</p></div></div>
        <div>${checks(c, w)}</div>${absenLine(c, w)}${hadirLine(c, w)}${kelLine(c, w)}
        ${allDone(c,w) ? `<span class="done">Semua sudah beres</span>` : ""}
        ${materi(c.id, w) ? `<button class="link" data-open="${c.id}|${w}">Buka materi pertemuan ${w}</button>` : ""}${lampBtn(c, w, "btn sm")}${!materi(c.id, w) && !lampBaru(c, w).length ? `<button class="link" data-act="add" data-cid="${c.id}" data-meet="${w}">Tambah materi pertemuan ${w}</button>` : ""}
      </article>`).join("")}</div>`;
  }).join("");
  return `
  <div class="head"><div><h1 class="large">Jadwal</h1><p class="lede">${st.done} dari ${st.total} ceklis selesai minggu ini</p></div>
    <div class="weeknav"><button class="circle" data-week="-1" ${w<=1?"disabled":""} aria-label="Minggu sebelumnya">${I.left}</button>
    <div class="lbl"><b>Pertemuan ${w}</b><span>${fmtShort(ws)} sampai ${fmtShort(new Date(ws.getTime()+6*DAY))}</span></div>
    <button class="circle" data-week="1" ${w>=16?"disabled":""} aria-label="Minggu berikutnya">${I.right}</button>
    ${w!==weekOf(t)?`<button class="btn sm" data-week="now">Minggu ini</button>`:""}</div></div>
  <div class="week" style="grid-template-columns:repeat(${Math.max(1,Math.min(order.length,5))}, minmax(0,1fr))">${cols}</div>
  ${(() => { const free = sorted().filter(c => !courseDay(c)); return free.length ? `<section><div class="group-t"><h2 class="title3">Tanpa jadwal tetap</h2><span class="cap">Kelas yang di KRS tidak punya hari kuliah</span></div><div class="week" style="grid-template-columns:repeat(auto-fill, minmax(240px,1fr))">${free.map(c => `<article class="ev ${allDone(c,w)?"complete":""}" data-c="${c.warna}"><div class="ev-top">${icon(c)}<div style="min-width:0"><h3>${esc(c.nama)}</h3><p class="cap">${esc(c.dosen || "")}</p></div></div><div>${checks(c, w)}</div>${absenLine(c, w)}${hadirLine(c, w)}${kelLine(c, w)}${lampBtn(c, w, "btn sm")}</article>`).join("")}</div></section>` : ""; })()}`;
}

/* ---------- materi ---------- */
function viewMateri(){
  if(!ready()) return viewWelcome();
  if(UI.course && UI.meet) return viewReader();
  if(UI.course) return viewCourse();
  const s = sem(), total = Object.keys(s.materi).length;
  const sems = Object.keys(S.semesters).sort();
  return `
  <div class="head"><div><h1 class="large">Materi</h1><p class="lede">${total ? total + " materi tersusun." : "Belum ada materi."} Seret file dari folder kuliahmu ke jendela ini untuk menambah.</p></div>
    <div class="inline">${sems.length>1?`<div class="seg" role="group" aria-label="Semester">${sems.map(p=>`<button data-sem="${p}" aria-pressed="${p===S.current}">${esc(S.semesters[p].label)}</button>`).join("")}</div>`:""}<button class="btn dark" data-act="add">${I.plus}Tambah materi</button></div></div>
  <div class="shelf">${sorted().map(c => { const nH = Object.keys(s.materi).filter(k => k.startsWith(c.id+"_")).length, nB = Array.from({length:16},(_,i)=>getP(c.id,i+1).belajar && materi(c.id,i+1)).filter(Boolean).length, baru = Object.keys(c.lampiran||{}).filter(n => lampBaru(c, Number(n)).length).length;
    return `<button class="book" data-c="${c.warna}" data-course="${c.id}">
      <span class="spine"></span>
      <span class="ini">${initials(c)}</span>
      <span class="ttl">${esc(c.nama)}</span>
      <span class="meta">${esc(courseDay(c))}${c.jam ? ", " + esc(String(c.jam).split(/[-–]/)[0].trim()) : ""}</span>
      <span class="bfoot"><span class="pips" aria-label="${nH} materi">${Array.from({length:16},(_,i)=>{ const n=i+1, has=materi(c.id,n), p=getP(c.id,n); return `<i class="${has?"has":""} ${has&&p.belajar?"done":""}"></i>`; }).join("")}</span>
        <span class="cnt">${nH ? nH + " materi" + (nB ? ", " + nB + " dipelajari" : "") : "Belum ada materi"}${baru ? `<mark class="hl">${baru} file dosen baru</mark>` : ""}</span></span>
    </button>`; }).join("")}</div>`;
}
function viewCourse(){
  const c = findCourse(UI.course); if(!c){ UI.course = null; return viewMateri(); }
  const w = weekOf(today());
  const meets = Array.from({length:16}, (_,i) => { const n = i+1, has = materi(c.id, n), p = getP(c.id,n), exam = n===8||n===16;
    if(!has && lampBaru(c, n).length) return `<button class="mt has ${n===w?"now":""}" title="${esc(lampBaru(c, n).map(f => kindOf(f) + ": " + f.name).join("\n"))}" data-lamp="${c.id}|${n}" aria-label="Ringkas file dosen pertemuan ${n}" style="background:var(--card)"><b>${n}</b><small>${UI.lampBusy===c.id+"_"+n?"Diringkas…":"File dosen"}</small></button>`;
    if(!has) return `<button class="mt add ${n===w?"now":""}" data-act="add" data-cid="${c.id}" data-meet="${n}" aria-label="Tambah materi pertemuan ${n}"><b>${n}</b><small>${exam?(n===8?"UTS":"UAS"):"Tambah"}</small></button>`;
    return `<button class="mt has ${p.belajar?"done":""} ${n===w?"now":""}" data-open="${c.id}|${n}" aria-label="Pertemuan ${n}: ${esc(has.judul)}"><b>${n}</b><small>${p.belajar?"Selesai":"Ada"}</small></button>`; }).join("");
  const allQ = Object.entries(sem().materi).filter(([k]) => k.startsWith(c.id+"_")).reduce((a,[,m])=>a+(m.kuis||[]).length,0);
  return `
  <nav class="crumbs"><button data-back="materi">${I.left}Materi</button></nav>
  <div class="chero" data-c="${c.warna}">${icon(c)}<div class="txt"><h1 class="large" style="font-size:clamp(28px,4vw,40px)">${esc(c.nama)}</h1><p class="lede" style="margin-top:4px">${esc(c.dosen)}</p></div>
    <div class="inline">${allQ?`<button class="btn dark" data-exam="${c.id}">Latihan ujian, ${allQ} soal</button>`:""}<button class="btn" data-open-url="${esc(c.lms)}">Kelas di LMS</button></div></div>
  <div class="group"><dl class="facts" style="margin:0">
    <div class="fact"><dt>Jadwal kamu</dt><dd>${esc(courseDay(c))}</dd></div>
    <div class="fact"><dt>Di KRS</dt><dd>${esc(c.hariKRS)}, ${esc(c.jam)}</dd></div>
    <div class="fact"><dt>Kelas</dt><dd>${esc(c.kelas)}</dd></div>
    ${c.rekap ? `<div class="fact"><dt>Kehadiran dari dosen</dt><dd>Hadir ${c.rekap.hadir || 0}${c.rekap.izin ? ", izin " + c.rekap.izin : ""}${c.rekap.sakit ? ", sakit " + c.rekap.sakit : ""}${c.rekap.alfa ? `, <span class="err-t">alfa ${c.rekap.alfa}</span>` : ""}</dd></div>` : ""}
  </dl></div>
  <section data-c="${c.warna}"><div class="group-t"><h2 class="title3">Pertemuan</h2><span class="cap">"File dosen" berarti dosen sudah mengunggah materi, klik untuk meringkas. Kotak putus-putus belum ada materi.</span></div><div class="meets">${meets}</div></section>
  ${materiTable(c)}
  ${kelSection(c)}
  ${UI.exam === c.id ? examBlock(c) : ""}`;
}
function examBlock(c){
  const all = []; Object.entries(sem().materi).filter(([k]) => k.startsWith(c.id+"_")).forEach(([,m]) => (m.kuis||[]).forEach(q => all.push(q)));
  return `<section class="card" data-c="${c.warna}" style="padding:28px 30px; display:flex; flex-direction:column; gap:20px"><div class="w-h"><h2 class="title2">Latihan ujian</h2><button class="btn sm" data-exam="">Tutup</button></div>${quizHTML(all, "exam_"+c.id)}</section>`;
}
function quizHTML(qs, qid){
  const st = UI.quiz[qid] || (UI.quiz[qid] = {});
  const answered = Object.keys(st).length, right = Object.entries(st).filter(([i,a]) => qs[i] && qs[i].a === a).length;
  if(!qs.length) return `<p class="sub">Belum ada soal.</p>`;
  return `<div class="quiz">${qs.map((q,i)=>{ const pick = st[i], dn = pick !== undefined;
    return `<div class="q"><p>${i+1}. ${esc(q.q)}</p><div class="opts">${q.o.map((o,j)=>`<button class="opt ${dn && j===q.a ? "right" : ""} ${dn && j===pick && pick!==q.a ? "wrong":""}" data-q="${qid}|${i}|${j}" ${dn?"disabled":""}><b>${String.fromCharCode(65+j)}</b><span>${esc(o)}</span></button>`).join("")}</div>${dn?`<p class="expl">${pick===q.a?"Benar. ":"Belum tepat. "}${esc(q.e)}</p>`:""}</div>`; }).join("")}
    <div class="score"><b>${right}/${qs.length}</b><span class="sub">${answered < qs.length ? `${qs.length-answered} soal lagi` : right===qs.length ? "Sempurna" : "Coba ulangi soal yang salah"}</span><button class="btn sm" data-qreset="${qid}" style="margin-left:auto">Ulangi</button></div></div>`;
}
function tableHTML(t){ const [h,...rows] = t; return `<div class="tbl"><table><tr>${h.map(x=>`<th>${rich(x)}</th>`).join("")}</tr>${rows.map(r=>`<tr>${r.map(x=>`<td>${rich(x)}</td>`).join("")}</tr>`).join("")}</table></div>`; }
function viewReader(){
  const c = findCourse(UI.course), n = UI.meet, m = c && materi(c.id, n);
  if(!m){ UI.meet = null; return viewCourse(); }
  const tab = UI.tab, p = getP(c.id, n), key = c.id+"_"+n;
  const tabs = [["ringkasan","Ringkasan"],["istilah","Istilah"],["kuis","Kuis"],["tugas","Tugas LMS"]];
  let body = "";
  if(tab === "ringkasan"){
    body = `<p class="summary">${rich(m.ringkas)}</p>` + (m.bagian||[]).map(b=>`<section class="sec"><h2>${esc(b.h)}</h2>${b.p?String(b.p).split(/\n+/).filter(Boolean).map(x=>`<p>${rich(x)}</p>`).join(""):""}${b.list&&b.list.length?`<ul>${b.list.map(x=>`<li>${rich(x)}</li>`).join("")}</ul>`:""}${b.table?tableHTML(b.table):""}${b.contoh?`<p class="aside"><b>Contoh:</b> ${rich(b.contoh)}</p>`:""}${b.note?`<p class="aside">${rich(b.note)}</p>`:""}</section>`).join("");
  } else if(tab === "istilah"){
    body = `<p class="sub">Klik kartu untuk melihat artinya.</p><div class="flash">${(m.istilah||[]).map(([a,b],i)=>`<button class="fc ${UI.flip[key+"_"+i]?"flip":""}" data-flip="${key}_${i}" aria-label="${esc(a)}"><div class="in"><div class="fa">${esc(a)}</div><div class="fb">${esc(b)}</div></div></button>`).join("")}</div>`;
  } else if(tab === "kuis"){
    body = quizHTML(m.kuis||[], key);
  } else {
    const ts = tugasOf(c, n);
    body = ts.length ? ts.map(t=>`<section class="sec"><h2>${esc(tugasLabel(t))}</h2><p class="aside">${t.tenggat?`Tenggat ${fmtShort(parseD(t.tenggat))}${t.jam?" pukul "+esc(t.jam):""}. `:""}Status di LMS: ${esc(t.status)}. <a href="#" data-open-url="${esc(t.link)}">Buka di LMS</a></p></section>`).join("") : `<p class="sub">Tidak ada tugas dari dosen di LMS untuk pertemuan ini.</p>`;
  }
  const askSt = UI.ask[key] || {};
  return `
  <nav class="crumbs"><button data-back="course">${I.left}${esc(c.nama)}</button></nav>
  <div class="reader" data-c="${c.warna}">
    <article class="card article">
      <header class="art-h"><span class="tag"><i class="dot"></i>Pertemuan ${n}</span><h1>${esc(m.judul)}</h1></header>
      <div class="seg" role="tablist" style="align-self:flex-start">${tabs.map(([id,l])=>`<button role="tab" aria-pressed="${tab===id}" data-tab="${id}">${l}</button>`).join("")}</div>
      ${body}
      <div class="pager">${materi(c.id,n-1)?`<button class="btn sm" data-open="${c.id}|${n-1}">${I.left}Pertemuan ${n-1}</button>`:"<span></span>"}${materi(c.id,n+1)?`<button class="btn sm" data-open="${c.id}|${n+1}">Pertemuan ${n+1}${I.right}</button>`:""}</div>
    </article>
    <aside class="side">
      <section class="card"><h2>Ceklis</h2><div>${checks(c, n)}</div>${absenLine(c, n)}${hadirLine(c, n, true)}${p.kuis!=null?`<p class="cap">Skor kuis terakhir ${p.kuis} dari ${(m.kuis||[]).length}</p>`:""}</section>
      ${kelCard(c, n)}
      ${sideChat("m:"+key)}
      ${absOn() ? komentarCard(key, m) : ""}
      ${videoCard(c, n)}
      <section class="card"><h2>Sumber</h2><div class="src">${(m.sumber||[]).map(s=>`<span>${esc(s)}</span>`).join("")}</div>
        ${lampBaru(c, n).some(f => f.pindah) ? `<p class="cap">Ada materi tambahan dari dosen untuk pertemuan ini (diunggah di sesi ${[...new Set(lampBaru(c, n).filter(f => f.pindah).map(f => f.pindah))].join(", ")}). Klik "Ringkas file baru dari dosen" untuk menggabungkannya.</p>` : ""}
        ${unggahOf(c, n).length ? `<details class="ud" ${lampBaru(c, n).length ? "open" : ""}><summary>Yang diunggah dosen (${unggahOf(c, n).length})</summary>${fileList(c, n)}</details>` : ""}
        <div class="inline">${lampBtn(c, n)}<button class="btn sm" data-act="add" data-cid="${c.id}" data-meet="${n}">Tambah sumber</button>${ulangBtn(c, n)}${UI.confirmDel===key?`<span class="confirm">Hapus materi?<button class="btn sm" data-delmateri="${key}">Hapus</button><button class="btn sm line" data-delno="1">Batal</button></span>`:`<button class="btn sm line" data-delask="${key}">Hapus</button>`}</div></section>
    </aside>
  </div>`;
}

// Ringkas ulang: semua file dosen dan sumber lama disusun dari awal, ringkasan lama diganti
function ulangBtn(c, n, cls = "btn sm"){
  const key = c.id + "_" + n, busy = UI.lampBusy === key;
  if (!materi(c.id, n)) return "";
  if (busy) return `<button class="${cls}" disabled>Sedang diringkas…</button>`;
  if (UI.confirmUlang === key) return `<span class="confirm">Ringkas ulang dari awal? Ringkasan lama diganti.<button class="btn sm dark" data-ulangya="${c.id}|${n}">Ringkas ulang</button><button class="btn sm line" data-ulangno="1">Batal</button></span>`;
  return `<button class="${cls}" data-ulang="${c.id}|${n}" title="Susun ulang ringkasan dari semua file dosen dan sumber pertemuan ini">Ringkas ulang</button>`;
}
function komentarCard(key, m){
  const busy = UI.komBusy === key, alt = m.komentarAlt || [];
  return `<section class="card kom"><h2>Komentar absensi</h2>
    ${m.komentar ? `<div class="copybox" id="copytarget">${esc(m.komentar)}</div>` : `<p class="sub">Belum ada draft komentar untuk materi ini.</p>`}
    <div class="inline">${m.komentar ? `<button class="btn dark" data-copy="${key}">${I.copy}Salin</button>` : ""}<button class="btn" data-komalt="${key}" ${busy ? "disabled" : ""}>${busy ? "Membuat pilihan…" : alt.length ? "Buat pilihan lain" : m.komentar ? "Buat ulang" : "Buat komentar"}</button></div>
    ${alt.length ? `<div class="kom-alt"><p class="cap">Pilih yang paling cocok. Komentar yang dipakai akan tersimpan untuk materi ini.</p>${alt.map((t, i) => `<div class="kom-o ${t === m.komentar ? "on" : ""}"><p>${esc(t)}</p><div class="inline"><button class="btn sm" data-kompick="${key}|${i}" ${t === m.komentar ? "disabled" : ""}>${t === m.komentar ? "Dipakai" : "Pakai ini"}</button><button class="btn sm line" data-komcopy="${key}|${i}">Salin</button></div></div>`).join("")}</div>` : ""}
  </section>`;
}
function timHTML(tim){
  return `<div class="tim"><b>${esc(tim.nama)}</b><div class="names">${tim.anggota.map(a => `<span class="${a.me ? "me" : ""}">${esc(a.me ? a.nama + " (kamu)" : a.nama)}</span>`).join("")}</div></div>`;
}
function kelCard(c, n){
  const k = kelOf(c), ts = (k.tugas || {})[n] || [], info = (k.info || []).filter(x => Number(x.meet) === Number(n));
  if (!ts.length && !info.length) return "";
  return `<section class="card kelc"><h2>Kelompok</h2>
    ${ts.map(t => `<div class="kt"><span class="pill kel">Tugas kelompok</span><a href="#" data-open-url="${esc(t.link)}">${esc(t.judul)}</a>${t.tenggat ? `<small>Tenggat ${fmtShort(parseD(t.tenggat))}${t.selesai ? ", sudah dikumpulkan" : ""}</small>` : ""}</div>`).join("")}
    ${info.map(x => `<div class="kt"><span class="pill">Info dosen</span><a href="#" data-open-url="${esc(x.link)}">${esc(x.judul)}</a>${x.text ? `<small>${esc(x.text.slice(0, 160))}${x.text.length > 160 ? "…" : ""}</small>` : ""}</div>`).join("")}
    ${k.tim ? timHTML(k.tim) : k.adaTim ? `<details class="semua"><summary>Kelompok sudah dibagi di LMS. Lihat semua kelompok</summary>${(k.semua || []).map(timHTML).join("")}</details>` : `<p class="cap">Pembagian kelompok belum ada di LMS. Begitu dosen membaginya, anggotanya muncul di sini otomatis.</p>`}
  </section>`;
}
function kelSection(c){
  const k = kelOf(c), meets = Object.keys(k.tugas || {}).filter(n => (k.tugas[n] || []).length).map(Number).sort((a, b) => a - b);
  if (!k.tim && !k.adaTim && !meets.length && !(k.info || []).length) return "";
  return `<section><div class="group-t"><h2 class="title3">Kelompok</h2><span class="cap">Dari LMS, diperbarui setiap sinkron</span></div><div class="card kelc">
    ${k.tim ? timHTML(k.tim) : k.adaTim ? `<p class="sub">Teman Kuliah belum bisa memastikan kelompokmu. Ini daftar kelompok di kelas ini:</p>${(k.semua || []).map(timHTML).join("")}` : `<p class="sub">Pembagian kelompok belum ada di LMS.</p>`}
    ${meets.map(n => k.tugas[n].map(t => `<div class="kt"><span class="pill kel">Pertemuan ${n || "-"}</span><a href="#" data-open-url="${esc(t.link)}">${esc(t.judul)}</a>${t.tenggat ? `<small>Tenggat ${fmtShort(parseD(t.tenggat))}${t.selesai ? ", sudah dikumpulkan" : ""}</small>` : ""}</div>`).join("")).join("")}
  </div></section>`;
}
// Tabel materi per pertemuan: buka, ringkas file baru, atau ringkas ulang
// Semua yang diunggah dosen per pertemuan: jenis file, nama, asal post, dan statusnya
const unggahOf = (c, n) => (c.unggahan && c.unggahan[n]) || lampOf(c, n).map(f => ({ ...f, status: "materi" }));
const KIND = { pdf: "PDF", pptx: "PPT", docx: "Word", ppt: "PPT lama", doc: "Word lama", youtube: "YouTube", video: "Video", link: "Tautan", image: "Gambar", xlsx: "Excel", xls: "Excel" };
const kindOf = f => KIND[f.kind] || KIND[f.ext] || (f.youtube ? "YouTube" : f.video ? "Video" : String(f.kind || "File").toUpperCase());
const sizeTxt = b => { b = Number(b) || 0; return !b ? "" : b >= 1048576 ? (b / 1048576).toFixed(1).replace(".", ",") + " MB" : Math.max(1, Math.round(b / 1024)) + " KB"; };
const tglTxt = t => { if (!t) return ""; const d = new Date(typeof t === "number" || /^\d+$/.test(String(t)) ? Number(t) : String(t).replace(" ", "T")); return isNaN(d) ? "" : fmtShort(d); };
function fileStatus(c, n, f){
  const m = materi(c.id, n), done = new Set((m && m.lampiranIds) || []);
  if (f.status === "materi") return done.has(f.id) ? ["ok", "Sudah diringkas"] : inQueue(c, n) ? ["wait", "Dalam antrean"] : ["kel", "Baru"];
  return f.status === "format" ? ["mid", "Tidak bisa dibaca"] : f.status === "lain" ? ["", "Info"] : ["bad", "Dilewati"];
}
function fileList(c, n){
  const all = unggahOf(c, n); if (!all.length) return "";
  const posts = []; all.forEach(f => { let g = posts.find(x => x.id === (f.postId || "-")); if (!g) posts.push(g = { id: f.postId || "-", judul: f.post, link: f.postLink, tgl: f.tgl, pindah: f.pindah, files: [] }); g.files.push(f); });
  return `<div class="ufiles">${posts.map(g => `<div class="upost">
    <div class="uph">${g.judul ? `<b>${esc(g.judul)}</b>` : `<b>File dari dosen</b>`}<span class="cap">${[tglTxt(g.tgl) && "diunggah " + tglTxt(g.tgl), g.pindah && `dipindah dari sesi ${g.pindah} karena dosen menyebut pertemuan ${n}`].filter(Boolean).join(", ")}</span>${g.link ? `<a href="#" data-open-url="${esc(g.link)}">Buka di LMS</a>` : ""}</div>
    ${g.files.map(f => { const [cls, lbl] = fileStatus(c, n, f); return `<div class="uf"><span class="kind">${esc(kindOf(f))}</span><div class="ut"><span class="un">${esc(f.name)}</span>${f.alasan ? `<small>${esc(f.alasan)}</small>` : ""}</div><span class="us">${esc(sizeTxt(f.size))}</span><span class="pill ${cls}">${lbl}</span>${f.status === "abaikan" || f.status === "rps" ? `<button class="btn sm line" data-paksa="${esc(f.id)}">Tetap ringkas</button>` : ""}</div>`; }).join("")}
  </div>`).join("")}</div>`;
}
// Tabel materi per pertemuan: buka, lihat file dari dosen, ringkas file baru, atau ringkas ulang
function materiTable(c){
  const rows = [];
  for (let n = 1; n <= 16; n++){
    const m = materi(c.id, n), baru = lampBaru(c, n), up = unggahOf(c, n);
    if (!m && !baru.length && !up.length) continue;
    const st = inQueue(c, n) ? `<span class="pill wait">Dalam antrean</span>` : baru.length ? `<span class="pill kel">${baru.length} file baru${baru.some(f => f.pindah) ? ", materi tambahan" : ""}</span>` : m && m.terpotong ? `<span class="pill mid">Terpotong</span>` : m ? `<span class="pill ok">Tersusun</span>` : `<span class="pill mid">Perlu dicek</span>`;
    const ringkas = baru.length ? `Baru: ${baru.map(f => kindOf(f) + " " + f.name).join(", ")}` : "";
    rows.push(`<tr><td class="no">${n}</td><td class="jd">${m ? `<button class="link" data-open="${c.id}|${n}">${esc(m.judul)}</button>` : `<span>${esc(up.find(f => f.post) ? up.find(f => f.post).post : "Belum diringkas")}</span>`}<small>${m ? esc((m.sumber || []).length + " sumber" + (m.dibuat ? ", disusun " + fmtShort(new Date(m.dibuat)) : "")) : "Belum diringkas"}${ringkas ? `<br><span class="newf">${esc(ringkas)}</span>` : ""}</small>
      ${up.length ? `<details class="ud" ${(UI.udOpen || {})[c.id + "_" + n] ? "open" : ""} data-ud="${c.id}_${n}"><summary>Lihat yang diunggah dosen (${up.length})</summary>${fileList(c, n)}</details>` : ""}</td><td>${st}</td><td class="aksi">${lampBtn(c, n)}${ulangBtn(c, n)}</td></tr>`);
  }
  if (!rows.length) return "";
  return `<section><div class="group-t"><h2 class="title3">Daftar materi</h2><span class="cap">Klik "Lihat yang diunggah dosen" untuk tahu file apa saja sebelum diringkas</span></div>
    <div class="card mtable"><div class="tbl"><table><tr><th>Pert.</th><th>Materi</th><th>Status</th><th></th></tr>${rows.join("")}</table></div></div></section>`;
}

/* ---------- to-do ---------- */
function viewTodo(){
  if(!ready()) return viewWelcome();
  const f = UI.todoFilter;
  let arr = Object.entries(S.todos);
  if(f === "aktif") arr = arr.filter(([,t]) => !t.done);
  if(f === "selesai") arr = arr.filter(([,t]) => t.done);
  if(f === "lms") arr = arr.filter(([,t]) => t.source === "lms" || t.source === "absen");
  sortTodos(arr);
  const opts = sorted().map(c => `<option value="${c.id}">${esc(c.singkat)}</option>`).join("");
  return `
  <div class="head"><div><h1 class="large">To-do</h1><p class="lede">${openTodos().length} belum selesai. Kuis, ujian, vicon${absOn() ? ", dan komentar absensi" : ""} dari LMS masuk ke sini otomatis.</p></div>
    <div class="seg" role="group" aria-label="Saring to-do">${[["aktif","Belum"],["semua","Semua"],["selesai","Selesai"],["lms","Dari LMS"]].map(([k,l])=>`<button data-filter="${k}" aria-pressed="${f===k}">${l}</button>`).join("")}</div></div>
  <form class="group adder" id="addform" autocomplete="off">
    <input id="td-text" class="full" placeholder="Tambah to-do baru" required aria-label="Isi to-do">
    <select id="td-course" aria-label="Mata kuliah"><option value="">Umum</option>${opts}</select>
    <input id="td-due" type="date" aria-label="Tenggat">
    <button class="btn dark" type="submit">Tambah</button>
  </form>
  <div class="group todos">${arr.length ? arr.map(([id,t]) => { const c = findCourse(t.course), di = dueInfo(t.due);
    return `<div class="todo ${t.done?"done":""}" ${c?`data-c="${c.warna}"`:""}><label class="chk"><input type="checkbox" data-todo="${esc(id)}" ${t.done?"checked":""} aria-label="Tandai selesai"></label>
      <div class="body"><div class="t">${esc(t.text)}</div>
        <div class="info">${c?`<span class="c"><i class="dot"></i>${esc(c.singkat)}</span>`:`<span>Umum</span>`}${t.due?`<span class="due ${t.done?"":di.cls}" style="padding:0">${fmtShort(parseD(t.due))}${t.time?", "+esc(t.time):""}</span>`:""}${t.source==="lms"?`<span class="lms">Dari LMS</span>`:t.source==="absen"?`<span class="lms">Absensi</span>`:""}${t.link?`<a href="#" data-open-url="${esc(t.link)}">Buka di LMS</a>`:""}</div>
        ${t.note?`<p class="note">${esc(t.note)}</p>`:""}
      </div>
      <div class="acts">${canPandu(t) && UI.confirmDel!==id ? `<button class="btn sm pd-btn ${(S.pandu||{})[id] || (t.due && dayDiff(t.due) != null && dayDiff(t.due) <= 7) ? "dark" : ""}" data-k="pandu-open" data-v="${esc(id)}"><i>✦</i> ${(S.pandu||{})[id] ? "Lanjutkan panduan" : "Pandu tugas ini"}</button>` : ""}${UI.confirmDel===id?`<span class="confirm">Hapus?<button class="btn sm" data-del="${esc(id)}">Hapus</button><button class="btn sm line" data-delno="1">Batal</button></span>`:`<button class="iconbtn" data-delask="${esc(id)}" aria-label="Hapus to-do">${I.trash}</button>`}</div>
    </div>`; }).join("") : `<div class="empty">${f==="selesai"?"Belum ada yang selesai.":f==="lms"?"Belum ada to-do dari LMS.":"Tidak ada to-do."}</div>`}</div>`;
}

/* ---------- pengaturan ---------- */
function viewPengaturan(){
  const L = S.lms;
  return `<div class="head"><div><h1 class="large">Pengaturan</h1></div></div>
  <div class="settings">
    <section><div class="group-t"><h2 class="title3">Akun LMS</h2></div><div class="group">
      <div class="field"><label>${L.connected ? "Terhubung sebagai " + esc(L.me && L.me.name) : "Belum terhubung"}</label><p class="cap">${S.settings.kampus && S.settings.kampus.url ? esc(kampusHost()) + ". " : ""}${L.connected ? "Sinkron terakhir " + ago(L.lastSync) + "." : "Login lewat halaman resmi LMS kampusmu."}${L.lastError?` <span class="err-t">${esc(L.lastError)}</span>`:""}</p>
        ${L.connected ? "" : kampusPicker()}
        <div class="inline">${L.connected ? `<button class="btn dark" data-act="sync">Sinkron sekarang</button><button class="btn" data-act="login">Masuk ulang</button><button class="btn line" data-act="logout">Keluar</button>` : `<button class="btn dark" data-act="login">Masuk ke Edlink</button>`}</div>${L.connected ? `<p class="cap">Mau ganti LMS atau akun? Klik Keluar dulu.</p>` : ""}</div>
      <div class="field"><div class="inline" style="justify-content:space-between"><label for="autosync">Sinkron otomatis tiap 30 menit</label><input type="checkbox" class="switch" id="autosync" ${S.settings.autoSync?"checked":""}></div></div>
      <div class="field"><div class="inline" style="justify-content:space-between"><label for="background">Jalan di latar belakang</label><input type="checkbox" class="switch" id="background" ${S.settings.background?"checked":""}></div><p class="cap">Aplikasi menyala saat Windows dinyalakan dan tetap sinkron dari ikon di pojok taskbar walau jendelanya ditutup. Notifikasi muncul setiap dosen posting.</p></div>
    </div></section>
    <section><div class="group-t"><h2 class="title3">AI penyusun materi</h2></div><div class="group"><div class="field">${aiForm(true)}</div>
      <div class="field"><div class="inline" style="justify-content:space-between"><label for="automateri">Ringkas file dosen secara otomatis</label><input type="checkbox" class="switch" id="automateri" ${S.settings.autoMateri?"checked":""}></div><p class="cap">Mati: file dosen baru muncul dengan tombol "Ringkas file dosen", jadi kuota AI cuma terpakai saat kamu klik. Nyala: setiap PPT, PDF, DOCX, atau link YouTube dari dosen langsung diringkas sendiri (lebih boros kuota). Materi buatanmu tidak ditimpa.${S.lms.autoError?` <span class="err-t">Terakhir gagal: ${esc(S.lms.autoError)}</span>`:""}</p></div></div></section>
    <section><div class="group-t"><h2 class="title3">Pengingat</h2><span class="cap">Muncul sebagai notifikasi Windows selama aplikasi menyala</span></div><div class="group">
      ${[["materi","Materi baru dari dosen","Kabar setiap dosen mengunggah PPT, PDF, DOCX, atau video di LMS."],["tenggat","Tenggat tugas dan kuis","Pengingat sehari sebelum tenggat, lalu alarm 3 jam sebelum tenggat yang tetap tampil sampai kamu tutup."],["kelas","Vicon dan jam kuliah","Pengingat 30 menit sebelum vicon dan 15 menit sebelum kuliah dimulai, sesuai hari kuliahmu."], ...(absOn() ? [["komentar","Komentar absensi","Jam 19.00 di hari kuliah, kalau masih ada post dosen pertemuan itu yang belum kamu komentari."]] : [])].map(([k,l,d]) => `<div class="field"><div class="inline" style="justify-content:space-between"><label for="peng-${k}">${l}</label><input type="checkbox" class="switch" id="peng-${k}" data-peng="${k}" ${(S.settings.pengingat||{})[k]!==false?"checked":""}></div><p class="cap">${d}</p></div>`).join("")}
      ${!S.settings.background ? `<div class="field"><p class="cap"><span class="err-t">Jalan di latar belakang sedang mati</span>, jadi pengingat hanya muncul saat jendela aplikasi terbuka.</p></div>` : ""}
    </div></section>
    <section><div class="group-t"><h2 class="title3">Tampilan</h2></div><div class="group"><div class="field"><div class="inline" style="justify-content:space-between"><label>Tema</label><div class="seg" role="group">${[["auto","Ikuti Windows"],["light","Terang"],["dark","Gelap"]].map(([v,l])=>`<button aria-pressed="${(S.settings.theme||"auto")===v}" data-k="theme" data-v="${v}">${l}</button>`).join("")}</div></div><p class="cap">Bisa juga diganti cepat lewat tombol matahari atau bulan di kanan atas.</p></div></div></section>
    <section><div class="group-t"><h2 class="title3">Kuliah</h2></div><div class="group"><div class="field">${absenToggle()}</div><div class="field"><div class="inline" style="justify-content:space-between"><label for="uj-auto">Ringkas otomatis menjelang ujian</label><input type="checkbox" class="switch" id="uj-auto" ${S.settings.ujianOtomatis!==false?"checked":""}></div><p class="cap">Saat UTS atau UAS tinggal 14 hari, file dosen di pertemuan yang diujikan dan belum diringkas langsung disusun jadi materi.</p></div><div class="field"><label for="geser">Geser hari dari KRS</label>${geserSelect()}<p class="cap">Contoh: kalau kuliahmu Rabu sampai Minggu padahal KRS Senin sampai Jumat, pilih geser 2 hari.</p></div></div></section>
    <section><div class="group-t"><h2 class="title3">Panduan</h2></div><div class="group"><div class="field"><label>Panduan pengguna Teman Kuliah</label><p class="cap">Cara memasang, menyambungkan AI, pengingat, sampai menyusun materi, lengkap dengan gambar.</p>
      <div class="inline"><button class="btn dark" data-act="guide">Baca di aplikasi</button><button class="btn" data-act="guide-file">Buka file PDF</button></div></div></div></section>
    <section><div class="group-t"><h2 class="title3">Data</h2></div><div class="group"><div class="field"><p class="cap">Semua data (materi, ceklis, to-do, API key) tersimpan di laptop ini, di folder AppData aplikasi. Tidak ada yang dikirim ke server lain selain LMS kampus dan AI yang kamu pilih.</p></div></div></section>
    <section><div class="group-t"><h2 class="title3">Tentang</h2></div><div class="group"><div class="field"><label>Teman Kuliah</label><p class="cap">Dibuat oleh <b>${PEMBUAT}</b>. Bisa dipakai mahasiswa dari kampus mana pun yang memakai LMS Edlink. Aplikasi ini buatan independen, bukan produk resmi Edlink maupun kampus.</p></div></div></section>
  </div>`;
}

/* ---------- tambah materi (drag & drop) ---------- */
function openAdd(prefill){
  UI.plan = { groups: [], skipped: [], prefill: prefill || null, running: false, paste: "" };
  if(prefill && prefill.paths){ planItems(prefill.paths.map(p => ({ path: p })), prefill); } else renderModal();
}
async function planItems(items, prefill){
  const r = await api.planIngest(items, prefill && prefill.meet ? Number(prefill.meet) : weekOf(today()));
  if(!r.ok){ toast(r.error); return; }
  if(!UI.plan) UI.plan = { groups: [], skipped: [], prefill, running: false, paste: "" };
  r.groups.forEach(g => {
    if(prefill && prefill.cid){ g.courseId = prefill.cid; g.meet = Number(prefill.meet) || g.meet; }
    if(!g.meet && sem()) g.meet = weekOf(today());
    const same = UI.plan.groups.find(x => x.courseId === g.courseId && x.meet === g.meet && !x.state);
    if(same) same.items.push(...g.items); else UI.plan.groups.push({ ...g, merge: true });
  });
  UI.plan.skipped.push(...r.skipped);
  renderModal();
}
function renderModal(){
  const m = $("#modal"), P = UI.plan;
  if(!P){ m.hidden = true; m.innerHTML = ""; return; }
  m.hidden = false;
  const ae = document.activeElement, keep = ae && ae.id && m.contains(ae) && /^(INPUT|TEXTAREA)$/.test(ae.tagName) ? { id: ae.id, v: ae.value } : null;
  queueMicrotask(() => { if(keep){ const el = document.getElementById(keep.id); if(el){ el.value = keep.v; el.focus(); } } });
  const cs = sorted();
  const ready = P.groups.filter(g => !g.state || g.state === "err");
  m.innerHTML = `<div class="sheet" role="dialog" aria-modal="true" aria-label="Tambah materi">
    <div class="sheet-h"><div><h2 class="title2">Tambah materi</h2><p class="sub" style="margin-top:4px">Seret file atau folder ke jendela ini, atau tempel link YouTube / ringkasan video.</p></div><button class="circle" data-modal="close" aria-label="Tutup">✕</button></div>
    <div class="sheet-b">
      ${P.groups.map((g,i) => { const exists = g.courseId && g.meet && materi(g.courseId, g.meet); return `<div class="grp">
        <div class="grp-row"><select class="course" data-g="${i}" data-k="courseId" ${g.state==="run"||g.state==="ok"?"disabled":""}><option value="">Pilih mata kuliah</option>${cs.map(c=>`<option value="${c.id}" ${c.id===g.courseId?"selected":""}>${esc(c.nama)}</option>`).join("")}</select>
          <select data-g="${i}" data-k="meet" ${g.state==="run"||g.state==="ok"?"disabled":""}><option value="">Pertemuan</option>${Array.from({length:16},(_,k)=>`<option value="${k+1}" ${k+1===g.meet?"selected":""}>Pertemuan ${k+1}</option>`).join("")}</select>
          ${!g.state?`<button class="iconbtn" data-rmgroup="${i}" aria-label="Hapus dari daftar">${I.trash}</button>`:""}</div>
        <div class="files">${g.items.map(it=>`<span>${esc(it.type==="file"?it.name:it.type==="youtube"?"YouTube: "+it.url:"Teks: "+it.text.slice(0,80))}</span>`).join("")}</div>
        ${exists && !g.state ? `<label class="chk"><input type="checkbox" data-g="${i}" data-k="merge" ${g.merge?"checked":""}><span>Gabungkan dengan materi yang sudah ada</span></label>` : ""}
        ${g.state ? `<span class="state ${g.state}">${g.state==="run"?esc(UI.status.ingest||"Memproses…"):g.state==="ok"?"Selesai, materi tersusun"+(g.warn&&g.warn.length?". Catatan: "+esc(g.warn.join("; ")):""):esc(g.error)}</span>` : ""}
      </div>`; }).join("")}
      ${!P.groups.length ? `<div class="grp" style="text-align:center; padding:28px"><p class="sub">Belum ada file. Seret file/folder ke sini, atau</p><div class="inline" style="justify-content:center"><button class="btn" data-act="pick">Pilih file</button><button class="btn" data-act="pick" data-folder="1">Pilih folder</button></div></div>` : ""}
      <div class="paste"><textarea id="paste" placeholder="Tempel link YouTube atau ringkasan video di sini">${esc(P.paste)}</textarea><div class="inline" style="margin-top:8px"><button class="btn sm" data-act="paste">Tambahkan teks/link</button>${P.groups.length?`<button class="btn sm" data-act="pick">Pilih file lain</button><button class="btn sm" data-act="pick" data-folder="1">Pilih folder</button>`:""}</div></div>
      ${P.skipped.length ? `<p class="skip">Dilewati: ${P.skipped.map(s=>esc(s.name)+" ("+esc(s.reason)+")").join(", ")}</p>` : ""}
    </div>
    <div class="sheet-f"><span class="cap">Diproses ${S.settings.ai.provider === "server" ? "AI Teman Kuliah" : S.settings.ai.provider === "auto" ? "AI otomatis" : (AI_INFO[S.settings.ai.provider]||AI_INFO.gemini).nama}. Biasanya 1 sampai 5 menit per kelompok, tergantung panjang materi.</span>
      ${P.groups.some(g=>g.state==="ok") && !P.running ? `<button class="btn" data-modal="close">Tutup</button>` : ""}
      <button class="btn dark" data-act="run" ${!ready.length||P.running?"disabled":""}>${P.running?"Memproses…":`Susun materi${ready.length>1?" ("+ready.length+")":""}`}</button></div>
  </div>`;
}
async function runPlan(){
  const P = UI.plan; if(!P || P.running) return;
  if(!aiReady()){ toast("Atur AI dulu di Pengaturan."); return; }
  const bad = P.groups.find(g => (!g.state || g.state==="err") && (!g.courseId || !g.meet));
  if(bad){ toast("Pilih mata kuliah dan pertemuan untuk semua kelompok."); return; }
  P.running = true; renderModal();
  for(const g of P.groups){
    if(g.state === "ok") continue;
    g.state = "run"; renderModal();
    const r = await api.runIngest({ courseId: g.courseId, meet: Number(g.meet), items: g.items }, { merge: !!g.merge });
    if(r.ok){ g.state = "ok"; g.warn = r.warnings; } else { g.state = "err"; g.error = r.error; }
    renderModal();
  }
  P.running = false; renderModal();
  const ok = P.groups.filter(g => g.state === "ok");
  if(ok.length === 1 && P.groups.length === 1){ UI.plan = null; renderModal(); go("materi", { course: ok[0].courseId, meet: Number(ok[0].meet), tab: "ringkasan" }); toast("Materi tersusun."); }
}

/* ---------- markdown aman untuk jawaban AI (tanpa tanda * yang berserakan) ---------- */
function md(src){
  const lines = String(src || "").replace(/\r/g, "").split("\n");
  const out = []; let list = null, para = [], table = null;
  const inline = t => esc(t)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+?)\*\*/g, "<b>$1</b>")
    .replace(/__([^_]+?)__/g, "<b>$1</b>")
    .replace(/(^|[\s(])\*([^*\s][^*]*?)\*(?=[\s).,:;!?]|$)/g, "$1<i>$2</i>")
    .replace(/(^|[\s(])_([^_\s][^_]*?)_(?=[\s).,:;!?]|$)/g, "$1<i>$2</i>")
    .replace(/\*\*/g, "").replace(/(^|\s)\*(\s|$)/g, "$1$2");
  const flushP = () => { if (para.length){ out.push(`<p>${inline(para.join(" "))}</p>`); para = []; } };
  const flushL = () => { if (list){ out.push(`<${list.t}>${list.items.map(x => `<li>${inline(x)}</li>`).join("")}</${list.t}>`); list = null; } };
  const flushT = () => { if (!table) return; const cells = r => r.trim().replace(/^\||\|$/g, "").split("|").map(x => x.trim()); const rows = table.filter(r => !/^\s*\|?\s*:?-{2,}/.test(r)); const [h, ...b] = rows; out.push(`<div class="tbl"><table><tr>${cells(h).map(x => `<th>${inline(x)}</th>`).join("")}</tr>${b.map(r => `<tr>${cells(r).map(x => `<td>${inline(x)}</td>`).join("")}</tr>`).join("")}</table></div>`); table = null; };
  for (const raw of lines){
    const l = raw.replace(/\s+$/, "");
    if (/^\s*\|.*\|\s*$/.test(l)){ flushP(); flushL(); (table || (table = [])).push(l); continue; } else flushT();
    let m;
    if (!l.trim()){ flushP(); flushL(); continue; }
    if ((m = l.match(/^\s*#{1,6}\s+(.*)/))){ flushP(); flushL(); out.push(`<h4>${inline(m[1].replace(/\*\*/g, ""))}</h4>`); continue; }
    if (/^\s*(-{3,}|\*{3,})\s*$/.test(l)){ flushP(); flushL(); continue; }
    if ((m = l.match(/^\s*[-*•]\s+(.*)/))){ flushP(); if (!list || list.t !== "ul"){ flushL(); list = { t: "ul", items: [] }; } list.items.push(m[1]); continue; }
    if ((m = l.match(/^\s*\d+[.)]\s+(.*)/))){ flushP(); if (!list || list.t !== "ol"){ flushL(); list = { t: "ol", items: [] }; } list.items.push(m[1]); continue; }
    if (list && /^\s{2,}\S/.test(raw)){ list.items[list.items.length - 1] += " " + l.trim(); continue; }
    flushL(); para.push(l.trim());
  }
  flushP(); flushL(); flushT();
  return out.join("");
}

/* ---------- Pandu Tugas ---------- */
const canPandu = t => t && !t.done && t.source !== "absen" && !/^kuis/i.test(t.jenis || "") && !/^(Kuis|Quiz|Vicon)\b/i.test(t.text || "");
const PANDU_CHIPS = ["Kasih contoh", "Saya belum paham, jelaskan lebih sederhana", "Apa yang harus kulakukan sekarang?"];
const hlBold = s => esc(s || "").replace(/\*\*(.+?)\*\*/g, '<mark class="hl">$1</mark>');
function scrollPandu(){ const l = $("#pdlog"); if (l) l.scrollTop = l.scrollHeight; }
async function panduMulai(id, extra){
  if (UI.panduBusy) return;
  UI.panduBusy = id; render();
  const r = await api.panduStart(id, extra || "");
  UI.panduBusy = null; render(); scrollPandu();
  if (!r.ok){ UI.panduErr = { id, t: r.error }; render(); }
}
async function panduKirim(id, text, mulai){
  const q = String(text || "").trim(); if ((!q && !mulai) || UI.panduLive) return;
  UI.panduLive = { id, text: "", q: mulai ? "" : q }; render(); scrollPandu();
  const r = await api.panduSend(id, q, !!mulai);
  UI.panduLive = null; render(); scrollPandu();
  if (!r.ok) toast(r.error);
}
api.onPanduDelta(d => {
  if (!UI.panduLive || UI.panduLive.id !== d.id) return;
  UI.panduLive.text += d.delta;
  const el = $("#pdlive .md"); if (el){ el.innerHTML = md(UI.panduLive.text); const l = $("#pdlog"); if (l && l.scrollHeight - l.scrollTop - l.clientHeight < 180) l.scrollTop = l.scrollHeight; }
});
function viewPandu(){
  if (!ready()) return viewWelcome();
  const id = UI.panduId, t = S.todos[id], p = (S.pandu || {})[id];
  const crumb = `<div class="pd-crumb"><button class="link" data-go="todo">To-do</button><span>›</span><b>Pandu tugas</b></div>`;
  if (!t && !p) return crumb + `<section class="card pd-start"><h2>Tugas ini sudah tidak ada di To-do.</h2><p class="sub">Mungkin sudah dihapus. Kembali ke To-do untuk memilih tugas lain.</p></section>`;
  const c = findCourse(t ? t.course : null);
  const judul = String((p && p.judul) || (t && t.text) || "").replace(/^(Tugas|Ujian|Kuis):\s*/, "");
  if (!p){
    const err = UI.panduErr && UI.panduErr.id === id ? UI.panduErr.t : "";
    if (UI.panduBusy === id) return crumb + `<section class="card pd-start pd-loading"><p class="thinking"><i></i><i></i><i></i></p><h2>Membaca tugasmu…</h2><p class="sub">Gemini sedang membaca instruksi dosen${(t.files || []).length ? " dan lampirannya" : ""}, lalu memecahnya jadi langkah-langkah. Biasanya kurang dari satu menit.</p></section>`;
    const desc = String(t.desc || "").trim(), files = t.files || [];
    const ada = desc || files.length;
    return crumb + `<section class="card pd-start" ${c ? `data-c="${c.warna}"` : ""}>
      <span class="pd-lbl">${c ? `<i class="dot"></i>${esc(c.nama)}` : "Tugas"}</span>
      <h2>${esc(judul)}</h2>
      ${ada ? `<p class="sub">Instruksi dari dosen sudah terbaca dari LMS${files.length ? `, termasuk ${files.length} lampiran (${files.slice(0, 3).map(f => esc(f.name)).join(", ")})` : ""}. AI akan menjelaskan tugas ini dengan bahasa sederhana, memecahnya jadi langkah-langkah, lalu membimbingmu satu per satu.</p>
        ${desc ? `<blockquote class="pd-quote">${esc(desc.slice(0, 600))}${desc.length > 600 ? "…" : ""}</blockquote>` : ""}
        <label class="pd-l" for="pandu-extra">Tambahan untukmu (opsional)</label><textarea id="pandu-extra" rows="3" placeholder="Misalnya: aku mahasiswa semester 1, kelompok kami belum mulai diskusi, aku masih pemula soal AI."></textarea>`
      : `<p class="sub">Instruksi tugas ini belum terbaca dari LMS. Buka tugasnya di LMS${t.link ? ` (<a href="#" data-open-url="${esc(t.link)}">buka di LMS</a>)` : ""}, salin instruksi dari dosen, lalu tempel di sini.</p>
        <textarea id="pandu-extra" rows="8" placeholder="Tempel instruksi tugas dari dosen di sini. Boleh ditambah keadaanmu, misalnya semester berapa atau sudah sampai mana."></textarea>`}
      ${err ? `<p class="err-t">${esc(err)}</p>` : ""}
      <div class="inline"><button class="btn dark" data-k="pandu-start" data-v="${esc(id)}" ${ada ? "" : 'data-need="1"'}>Mulai pandu</button><span class="cap">Memakai Gemini milikmu. AI membimbing, tidak menuliskan tugasnya untukmu.</span></div>
    </section>`;
  }
  const L = p.langkah || [], nDone = L.filter(x => x.done).length, live = UI.panduLive && UI.panduLive.id === id ? UI.panduLive : null;
  const aktif = L[p.aktif], semua = !aktif;
  const di = t && t.due ? dueInfo(t.due) : null, dd = t && t.due ? dayDiff(t.due) : null;
  const tenggat = dd == null ? "" : dd < 0 ? `Lewat ${-dd} hari` : dd === 0 ? "Tenggat hari ini" : dd === 1 ? "Tenggat besok" : `Tenggat ${dd} hari lagi`;
  const chat = p.chat || [];
  const msgs = chat.map((m, i) => {
    const lbl = i > 0 && m.role === "ai" && m.step !== chat[i - 1].step && L[m.step] ? `<p class="pd-sep">Langkah ${m.step + 1}: ${esc(L[m.step].judul)}</p>` : "";
    return lbl + (m.role === "user" ? `<div class="msg me"><div class="bub">${esc(m.text).replace(/\n/g, "<br>")}</div></div>`
      : `<div class="msg ai"><img class="av" src="logo.svg" alt=""><div class="md">${m.error ? `<p class="err-t">${esc(m.error)}</p>${i === chat.length - 1 && !live ? `<button class="btn sm" data-k="pandu-retry" data-v="${esc(id)}">Coba lagi</button>` : ""}` : md(m.text)}</div></div>`);
  }).join("");
  const liveHTML = live ? `${live.q ? `<div class="msg me"><div class="bub">${esc(live.q).replace(/\n/g, "<br>")}</div></div>` : ""}<div class="msg ai" id="pdlive"><img class="av" src="logo.svg" alt=""><div class="md">${live.text ? md(live.text) : `<p class="thinking"><i></i><i></i><i></i></p>`}</div></div>` : "";
  return crumb + `
  <section class="board pd-board">
    <div class="pd-bmain">
      <span class="pd-blbl">Pandu tugas${p.matkul ? " · " + esc(p.matkul) : ""}</span>
      <h1>${esc(judul)}</h1>
      <span class="pd-bmeta">${p.tenggat ? "Tenggat " + esc(p.tenggat) : "Tanpa tenggat"}${(p.lampiran || []).length ? ` · ${p.lampiran.length} lampiran dibaca` : ""}</span>
      ${p.intinya ? `<p class="say">${hlBold(p.intinya)}</p>` : ""}
    </div>
    <div class="pd-prog">${tenggat ? `<span class="pd-chip ${di && (di.cls === "late" || di.cls === "soon") ? "hot" : ""}">${tenggat}</span>` : ""}
      <div class="pd-big">${semua ? "Selesai" : nDone}<small>${semua ? "" : ` dari ${L.length} langkah`}</small></div>
      <div class="pd-bar"><i style="width:${L.length ? Math.round(nDone / L.length * 100) : 0}%"></i></div>
      <span class="pd-bnote">${semua ? "Semua langkah beres. Jangan lupa kumpulkan di LMS." : "Lanjutkan kapan saja, progres tersimpan."}</span></div>
  </section>
  <div class="pd-cols">
    <div class="pd-left">
      <section class="card pd-card"><h3>Tugas ini dalam bahasa sederhana</h3>
        <dl class="pd-sim">${p.diminta ? `<dt>Yang diminta</dt><dd>${esc(p.diminta)}</dd>` : ""}${p.hasil ? `<dt>Hasil akhir</dt><dd>${esc(p.hasil)}</dd>` : ""}${p.tidakPerlu ? `<dt>Tidak perlu khawatir</dt><dd>${esc(p.tidakPerlu)}</dd>` : ""}</dl>
        ${(p.lampiran || []).map(n => `<div class="pd-lamp"><span class="ic">${esc(String(n).split(".").pop().toUpperCase().slice(0, 4))}</span><div><b>${esc(n)}</b><small>Sudah dibaca AI</small></div></div>`).join("")}
        ${t && t.link ? `<button class="link" data-open-url="${esc(t.link)}">Buka tugas di LMS</button>` : ""}
      </section>
      <section class="card pd-card"><h3>Langkah-langkah</h3>
        <ol class="pd-steps">${L.map((x, i) => `<li class="${x.done ? "done" : i === p.aktif ? "now" : ""}"><button class="ck" data-k="pandu-step" data-v="${i}" aria-label="${x.done ? "Batalkan selesai" : "Tandai selesai"}">${x.done ? "✓" : i + 1}</button><div><span class="t">${esc(x.judul)}</span>${i === p.aktif ? `<small>Sedang dibahas di bimbingan</small>` : x.ket && !x.done ? `<small>${esc(x.ket)}</small>` : ""}</div></li>`).join("")}</ol>
        <div class="pd-reset">${UI.panduConfirm === id ? `<span class="cap">Hapus panduan dan mulai dari awal?</span><button class="btn sm" data-k="pandu-reset" data-v="${esc(id)}">Ya, mulai ulang</button><button class="btn sm line" data-k="pandu-reset-no">Batal</button>` : `<button class="link" data-k="pandu-reset" data-v="${esc(id)}">Mulai ulang panduan</button>`}</div>
      </section>
    </div>
    <section class="card pd-chat">
      <header class="pd-ch"><div><b>Bimbingan</b><span class="cap">${semua ? "Semua langkah selesai" : `Langkah ${p.aktif + 1}: ${esc(aktif.judul)}`}</span></div>
        ${semua ? "" : `<button class="btn sm" data-k="pandu-step" data-v="${p.aktif}" ${live ? "disabled" : ""}>✓ Tandai langkah selesai</button>`}</header>
      <div class="pd-log" id="pdlog">${msgs}${liveHTML}</div>
      ${!live ? `<div class="chips small">${PANDU_CHIPS.map(q => `<button class="chip" data-k="pandu-chip" data-v="${esc(q)}">${esc(q)}</button>`).join("")}</div>` : ""}
      <div class="chat-compose"><textarea id="panduq" rows="1" placeholder="Tulis jawaban atau pertanyaanmu. Enter untuk kirim."></textarea><button class="btn dark" data-k="pandu-send" data-v="${esc(id)}" ${live ? "disabled" : ""}>Kirim</button></div>
      <p class="pd-note"><span>AI membimbing langkah demi langkah, tidak menuliskan tugas untukmu.</span><span>Memakai Gemini milikmu</span></p>
    </section>
  </div>`;
}

/* ---------- Tanya AI (halaman chat) ---------- */
const chatTitle = key => { if (key === "umum") return { t: "Semua mata kuliah", s: "AI melihat daftar semua materimu" }; if (key.startsWith("c:")){ const c = findCourse(key.slice(2)); return { t: c ? c.nama : "Mata kuliah", s: "Semua materi mata kuliah ini", c }; } const k = key.slice(2), [cid, n] = k.split(/_(?=\d+$)/), c = findCourse(cid), m = materi(cid, n); return { t: m ? m.judul : "Materi", s: (c ? c.singkat + ", " : "") + "pertemuan " + n, c }; };
const chatList = key => ((S.chats || {})[key]) || [];
function chatSuggest(key){
  if (key === "umum") return ["Materi apa yang sebaiknya kupelajari dulu minggu ini?", "Ringkas semua yang sudah kupelajari dalam 10 poin", "Buat jadwal belajar 1 minggu untuk persiapan ujian", "Konsep apa saja yang mirip dan sering tertukar?"];
  if (key.startsWith("c:")) return ["Apa benang merah semua materi mata kuliah ini?", "Topik mana yang paling mungkin keluar di ujian?", "Buat 5 soal latihan campuran dari semua pertemuan", "Jelaskan istilah yang paling sering muncul"];
  return ["Jelaskan materi ini dengan bahasa paling sederhana", "Beri contoh nyata dari kehidupan sehari-hari", "Apa poin terpenting yang harus kuingat?", "Uji aku dengan 3 soal, tunggu jawabanku dulu"];
}
function viewTanya(){
  if (!ready()) return viewWelcome();
  const key = UI.chatKey || "umum", T = chatTitle(key), list = chatList(key), live = UI.chatLive && UI.chatLive.key === key ? UI.chatLive : null;
  const recent = Object.entries(S.chats || {}).filter(([k, v]) => k.startsWith("m:") && v.length).sort((a, b) => String(b[1][b[1].length - 1].at).localeCompare(String(a[1][a[1].length - 1].at))).slice(0, 8);
  const item = (k, label, sub, c) => `<button class="cs-item ${k === key ? "on" : ""}" data-k="chat-open" data-v="${esc(k)}" ${c ? `data-c="${c.warna}"` : ""}>${c ? `<i class="dot"></i>` : `<span class="cs-ic">${I.spark}</span>`}<span class="cs-t"><b>${esc(label)}</b><small>${esc(sub)}</small></span></button>`;
  const last = k => { const l = chatList(k); return l.length ? String(l[l.length - 1].text || "").replace(/[#*_`>|]/g, "").slice(0, 60) : ""; };
  const msgs = list.map((mm, i) => mm.role === "user" ? `<div class="msg me"><div class="bub">${esc(mm.text).replace(/\n/g, "<br>")}</div></div>`
    : `<div class="msg ai"><img class="av" src="logo.svg" alt=""><div class="md">${mm.error ? `<p class="err-t">${esc(mm.error)}</p>${i === list.length - 1 && !live ? `<button class="btn sm" data-k="chat-retry" data-v="${esc(key)}">Coba lagi</button>` : ""}` : md(mm.text)}</div></div>`).join("");
  const liveHTML = live ? `<div class="msg ai" id="livemsg"><img class="av" src="logo.svg" alt=""><div class="md">${live.text ? md(live.text) : `<p class="thinking"><i></i><i></i><i></i></p>`}</div></div>` : "";
  const empty = !list.length && !live ? `<div class="chat-empty"><img src="logo.svg" alt="" class="ce-mark"><h2>Mau tanya apa?</h2><p class="sub">${esc(T.s)}. Jawaban disusun dari materimu, jadi tetap nyambung dengan yang diajarkan dosen.</p>
    <div class="chips">${chatSuggest(key).map(q => `<button class="chip" data-k="chat-suggest" data-v="${esc(q)}">${esc(q)}</button>`).join("")}</div></div>` : "";
  return `
  <div class="head"><div><h1 class="large">Tanya AI</h1><p class="lede">Teman belajar yang paham materimu. Tanya, minta contoh, atau minta diuji.</p></div></div>
  <div class="chat">
    <aside class="card chat-side">
      ${item("umum", "Semua mata kuliah", last("umum") || "Pertanyaan umum", null)}
      <p class="cs-h">Mata kuliah</p>
      ${sorted().map(c => item("c:" + c.id, c.singkat, last("c:" + c.id) || c.dosen || "", c)).join("")}
      ${recent.length ? `<p class="cs-h">Materi</p>${recent.map(([k]) => { const t = chatTitle(k); return item(k, t.t, t.s, t.c); }).join("")}` : ""}
    </aside>
    <section class="card chat-main" ${T.c ? `data-c="${T.c.warna}"` : ""}>
      <header class="chat-h"><div class="chat-ht">${T.c ? `<i class="dot"></i>` : ""}<div><b>${esc(T.t)}</b><span class="cap">${esc(T.s)}</span></div></div>
        ${list.length ? `<button class="btn sm line" data-k="chat-clear">Mulai ulang</button>` : ""}</header>
      <div class="chat-log" id="chatlog">${empty}${msgs}${liveHTML}</div>
      ${list.length && !live ? `<div class="chips small">${chatSuggest(key).slice(0, 3).map(q => `<button class="chip" data-k="chat-suggest" data-v="${esc(q)}">${esc(q)}</button>`).join("")}</div>` : ""}
      <div class="chat-compose"><textarea id="chatq" rows="1" placeholder="Tulis pertanyaanmu. Enter untuk kirim, Shift+Enter untuk baris baru."></textarea><button class="btn dark" data-k="chat-send" ${live ? "disabled" : ""}>Kirim</button></div>
    </section>
  </div>`;
}
function scrollChat(){ for (const id of ["#chatlog", "#sidelog"]){ const l = $(id); if (l) l.scrollTop = l.scrollHeight; } }
async function sendChat(text, keyOverride){
  const q = String(text || "").trim(); if (!q || UI.chatLive) return;
  const key = keyOverride || UI.chatKey || "umum";
  UI.chatLive = { key, text: "" }; render(); scrollChat();
  const r = await api.chatSend(key, q);
  UI.chatLive = null; render(); scrollChat();
  if (!r.ok) toast(r.error);
}
api.onChatDelta(d => {
  if (!UI.chatLive || UI.chatLive.key !== d.key) return;
  UI.chatLive.text += d.delta;
  const el = $("#livemsg .md"); if (el){ el.innerHTML = md(UI.chatLive.text); const l = $("#chatlog") || $("#sidelog"); if (l && l.scrollHeight - l.scrollTop - l.clientHeight < 160) l.scrollTop = l.scrollHeight; }
});

// Video yang dibagikan dosen di LMS untuk pertemuan ini
function videoCard(c, n){
  const v = lampOf(c, n).filter(f => f.youtube || f.video); if (!v.length) return "";
  const yid = u => { const m = String(u).match(/[?&]v=([\w-]{11})/); return m ? m[1] : ""; };
  return `<section class="card vids"><h2>Video dari dosen</h2>${v.map(f => `<button class="vid" data-open-url="${esc(f.youtube || f.link)}">${f.youtube ? `<img src="https://i.ytimg.com/vi/${yid(f.youtube)}/mqdefault.jpg" alt="">` : `<span class="vid-ph">${I.book}</span>`}<span class="vid-t"><b>${esc(f.name)}</b><small>${f.youtube ? "YouTube" : "Video dari LMS"}${materi(c.id, n) && (materi(c.id, n).lampiranIds || []).includes(f.id) ? ", sudah masuk ringkasan" : ", belum diringkas"}</small></span></button>`).join("")}</section>`;
}

// Panel Tanya AI di samping halaman materi (percakapan yang sama dengan menu Tanya AI)
function sideChat(ck){
  const list = chatList(ck).slice(-8), live = UI.chatLive && UI.chatLive.key === ck ? UI.chatLive : null;
  const msgs = list.map((mm, i) => mm.role === "user" ? `<div class="msg me"><div class="bub">${esc(mm.text).replace(/\n/g, "<br>")}</div></div>` : `<div class="msg ai"><div class="md">${mm.error ? `<p class="err-t">${esc(mm.error)}</p>${i === list.length - 1 && !live ? `<button class="btn sm" data-k="chat-retry" data-v="${esc(ck)}">Coba lagi</button>` : ""}` : md(mm.text)}</div></div>`).join("");
  const liveHTML = live ? `<div class="msg ai" id="livemsg"><div class="md">${live.text ? md(live.text) : `<p class="thinking"><i></i><i></i><i></i></p>`}</div></div>` : "";
  return `<section class="card side-chat">
    <div class="w-h"><h2><img src="logo.svg" alt="" class="sc-av">Tanya AI</h2><button class="link" data-k="chat-open" data-v="${esc(ck)}">Layar penuh</button></div>
    ${list.length || live ? `<div class="sc-log" id="sidelog">${msgs}${liveHTML}</div>` : `<p class="cap">Tanya bagian yang belum jelas. Jawabannya disusun dari materi ini.</p><div class="chips left">${chatSuggest(ck).slice(0, 3).map(q => `<button class="chip" data-k="side-suggest" data-v="${esc(q)}" data-ck="${esc(ck)}">${esc(q)}</button>`).join("")}</div>`}
    <div class="sc-compose"><textarea id="sideq" rows="1" placeholder="Tanya tentang materi ini" data-ck="${esc(ck)}"></textarea><button class="btn dark sm" data-k="side-send" data-v="${esc(ck)}" ${live ? "disabled" : ""}>Kirim</button></div>
  </section>`;
}

/* ---------- Ujian & latihan ---------- */
const UJI = { uts: [1, 7], uas: [9, 15] };
const UJI_N = { uts: "UTS", uas: "UAS" };
const dayDiff = s => { if (!s) return null; return Math.round((parseD(s) - today()) / DAY); };
function ujianNow(){
  const items = []; courses().forEach(c => ["uts", "uas"].forEach(j => { const u = (c.ujian || {})[j]; const d = u && dayDiff(u.tanggal); if (d != null) items.push({ j, d }); }));
  const up = items.filter(x => x.d >= -1).sort((a, b) => a.d - b.d);
  if (up.length) return { jenis: up[0].j, d: up[0].d };
  return { jenis: rawWeek(today()) <= 8 ? "uts" : "uas", d: null };
}
function ujianStat(c, j){
  const [a, b] = UJI[j]; let ready = 0, file = 0, none = 0;
  for (let n = a; n <= b; n++){ if (materi(c.id, n)) ready++; else if (lampBaru(c, n).length) file++; else none++; }
  return { ready, file, none, total: b - a + 1 };
}
function viewUjian(){
  if (!ready()) return viewWelcome();
  const tab = UI.uTab || "persiapan";
  const tabs = [["persiapan", "Persiapan ujian"], ["latihan", "Latihan soal"], ["kemampuan", "Kemampuanku"]];
  const body = tab === "latihan" ? viewLatihan() : tab === "kemampuan" ? viewKemampuan() : viewPersiapan();
  return `
  <div class="head"><div><h1 class="large">Ujian dan latihan</h1><p class="lede">Bersiap untuk UTS dan UAS, latihan soal, dan pantau kemampuanmu.</p></div>
    <div class="seg" role="tablist">${tabs.map(([id, l]) => `<button role="tab" aria-pressed="${tab === id}" data-k="utab" data-v="${id}">${l}</button>`).join("")}</div></div>
  ${body}`;
}
function viewPersiapan(){
  const now = ujianNow(), j = UI.uJenis || now.jenis, [a, b] = UJI[j];
  let ready = 0, total = 0, file = 0;
  const cs = sorted(); cs.forEach(c => { const s = ujianStat(c, j); ready += s.ready; total += s.total; file += s.file; });
  const dates = cs.map(c => (c.ujian || {})[j]).filter(u => u && u.tanggal).map(u => u.tanggal).sort();
  const first = dates[0], dd = first ? dayDiff(first) : null;
  const when = first ? `${HARI[parseD(first).getDay()]}, ${parseD(first).getDate()} ${BULAN_L[parseD(first).getMonth()]}` : "Tanggal belum ada di LMS";
  const countdown = dd == null ? "" : dd > 1 ? `${dd} hari lagi` : dd === 1 ? "besok" : dd === 0 ? "hari ini" : "sudah lewat";
  const rk = UI.rangkum && UI.rangkum.endsWith("_" + j) ? UI.rangkum : null;
  const rkData = rk && (S.ujian || {})[rk];
  const rkCourse = rk && findCourse(rk.split("_")[1]);
  return `
  <section class="board exam-board">
    <div class="board-top">
      <div><p class="hi">Ujian berikutnya</p><h1 class="board-date">${UJI_N[j]}${countdown ? `<span class="cd">${countdown}</span>` : ""}</h1><p class="board-status">${esc(when)}. Materi pertemuan ${a} sampai ${b}.</p></div>
      <div class="seg dark-seg" role="group">${["uts", "uas"].map(x => `<button aria-pressed="${x === j}" data-k="ujenis" data-v="${x}">${UJI_N[x]}</button>`).join("")}</div>
    </div>
    <p class="say">Materi siap <mark class="hl">${ready} dari ${total}</mark> pertemuan${file ? `, <mark class="hl">${file} file dosen</mark> belum diringkas` : ""}.${file ? "" : ` <span class="muted">${ready === total ? "Semua materi sudah siap dipelajari." : "Sisanya belum ada file dari dosen."}</span>`}</p>
    <div class="exam-bar"><i style="width:${total ? Math.round(ready / total * 100) : 0}%"></i></div>
    <div class="inline">${file ? `<button class="btn hl-btn" data-k="u-prepare" data-v="">Ringkas semua yang belum (${file})</button>` : ""}<button class="btn line-light" data-k="utab" data-v="latihan" data-scope="${j}">Latihan soal ${UJI_N[j]}</button></div>
    <p class="board-status">${S.settings.ujianOtomatis !== false ? `File dosen yang belum diringkas otomatis disusun saat ${UJI_N[j]} tinggal 14 hari.` : "Ringkas otomatis menjelang ujian sedang mati di Pengaturan."}</p>
  </section>
  ${rkData ? `<section class="card rangkum" ${rkCourse ? `data-c="${rkCourse.warna}"` : ""}><div class="w-h"><h2 class="title2">Rangkuman ${UJI_N[j]}: ${esc(rkCourse ? rkCourse.nama : "")}</h2><button class="btn sm" data-k="rangkum-close">Tutup</button></div><p class="cap">Dibuat dari ${rkData.materi} materi, ${ago(rkData.dibuat)}.</p><div class="md big">${md(rkData.teks)}</div></section>` : ""}
  <div class="exam-grid">${cs.map(c => { const s = ujianStat(c, j), u = (c.ujian || {})[j], rkKey = `${S.current}_${c.id}_${j}`, has = (S.ujian || {})[rkKey];
    const chips = Array.from({ length: b - a + 1 }, (_, i) => { const n = a + i, m = materi(c.id, n), f = lampBaru(c, n).length; return m ? `<button class="pchip ok" data-open="${c.id}|${n}" title="${esc(m.judul)}">P${n}</button>` : f ? `<span class="pchip file" title="File dosen belum diringkas">P${n}</span>` : `<span class="pchip none" title="Belum ada file dari dosen">P${n}</span>`; }).join("");
    return `<section class="card exam-c" data-c="${c.warna}">
      <div class="ec-h">${icon(c)}<div style="min-width:0"><h3>${esc(c.nama)}</h3><p class="cap">${u && u.tanggal ? `${UJI_N[j]} ${fmtShort(parseD(u.tanggal))}${u.jam ? ", " + esc(u.jam) : ""}${u.sumber === "jadwal" ? " (perkiraan dari jadwal)" : ""}` : "Tanggal ujian belum ada"}</p></div></div>
      <div class="pchips">${chips}</div>
      <p class="cap">${s.ready} materi siap${s.file ? `, ${s.file} file dosen belum diringkas` : ""}${s.none ? `, ${s.none} pertemuan belum ada file` : ""}.</p>
      <div class="inline">${s.file ? `<button class="btn sm" data-k="u-prepare" data-v="${c.id}">Ringkas yang belum (${s.file})</button>` : ""}
        ${s.ready ? `<button class="btn sm ${has ? "" : "dark"}" data-k="${has ? "rangkum-open" : "rangkum-make"}" data-v="${c.id}">${has ? "Buka rangkuman" : "Buat rangkuman ujian"}</button>` : ""}
        ${s.ready ? `<button class="btn sm" data-k="lat-quick" data-v="${c.id}" data-scope="${j}">Latihan soal</button>` : ""}</div>
    </section>`; }).join("")}</div>`;
}

// ----- latihan soal
function latList(){ return Object.values(S.latihan || {}).filter(L => L.periode === S.current).sort((x, y) => String(y.dibuat).localeCompare(String(x.dibuat))); }
function viewLatihan(){
  if (UI.latId && (S.latihan || {})[UI.latId]) return viewLatRun(S.latihan[UI.latId]);
  const F = UI.latForm || (UI.latForm = { cid: (sorted()[0] || {}).id, scope: ujianNow().jenis, from: 1, to: 16, pg: 20, essay: 3 });
  const c = findCourse(F.cid) || sorted()[0]; if (c) F.cid = c.id;
  const [fa, fb] = F.scope === "uts" ? UJI.uts : F.scope === "uas" ? UJI.uas : F.scope === "semua" ? [1, 16] : [Number(F.from) || 1, Number(F.to) || 16];
  const nMat = c ? Array.from({ length: fb - fa + 1 }, (_, i) => materi(c.id, fa + i)).filter(Boolean).length : 0;
  const seg = (k, opts) => `<div class="seg" role="group">${opts.map(([v, l]) => `<button aria-pressed="${String(F[k]) === String(v)}" data-k="latf" data-f="${k}" data-v="${v}">${l}</button>`).join("")}</div>`;
  const meetSel = id => `<select id="${id}" class="sel">${Array.from({ length: 16 }, (_, i) => `<option value="${i + 1}" ${Number(F[id === "lf-from" ? "from" : "to"]) === i + 1 ? "selected" : ""}>Pertemuan ${i + 1}</option>`).join("")}</select>`;
  const L = latList();
  return `<div class="lat-wrap">
    <section class="card lat-new">
      <h2 class="title2">Buat latihan baru</h2>
      <p class="sub">Soal dibuat AI dari materi yang sudah diringkas. Pilihan ganda dinilai otomatis, essay dinilai AI lengkap dengan masukan.</p>
      <div class="lf"><label>Mata kuliah</label><select id="lf-cid" class="sel">${sorted().map(x => `<option value="${x.id}" ${x.id === F.cid ? "selected" : ""}>${esc(x.nama)}</option>`).join("")}</select></div>
      <div class="lf"><label>Cakupan</label>${seg("scope", [["uts", "UTS (1-7)"], ["uas", "UAS (9-15)"], ["semua", "Semua"], ["pilih", "Pilih sendiri"]])}
        ${F.scope === "pilih" ? `<div class="inline" style="margin-top:8px">${meetSel("lf-from")}<span class="cap">sampai</span>${meetSel("lf-to")}</div>` : ""}</div>
      <div class="lf"><label>Pilihan ganda</label>${seg("pg", [[10, "10"], [20, "20"], [30, "30"], [40, "40"]])}</div>
      <div class="lf"><label>Essay</label>${seg("essay", [[0, "Tidak ada"], [3, "3"], [5, "5"]])}</div>
      <p class="cap">${nMat ? `Diambil dari ${nMat} materi yang sudah diringkas.` : `<span class="err-t">Belum ada materi yang diringkas di cakupan ini.</span> Ringkas file dosen dulu di Persiapan ujian atau halaman Materi.`}</p>
      <button class="btn dark big" data-k="lat-make" ${nMat ? "" : "disabled"}>Buat latihan</button>
    </section>
    <section class="lat-hist">
      <div class="group-t"><h2 class="title3">Riwayat latihan</h2><span class="cap">${L.length} latihan semester ini</span></div>
      ${L.length ? `<div class="group">${L.map(x => { const cc = findCourse(x.cid); return `<div class="row lat-row" data-c="${cc ? cc.warna : ""}"><button class="lat-open" data-k="lat-open" data-v="${x.id}"><span class="dot"></span><span class="txt"><b>${esc(cc ? cc.singkat : "")}: ${esc(x.label)}</b><small>${x.soal.pg.length} pilihan ganda${x.soal.essay.length ? ", " + x.soal.essay.length + " essay" : ""}, ${fmtShort(new Date(x.dibuat))}</small></span>${x.hasil ? `<span class="score-b ${x.hasil.total >= 80 ? "good" : x.hasil.total >= 60 ? "mid" : "low"}">${x.hasil.total}</span>` : `<span class="cap">Belum selesai</span>`}</button><button class="iconbtn" data-k="lat-del" data-v="${x.id}" aria-label="Hapus latihan">${I.trash}</button></div>`; }).join("")}</div>` : `<div class="card empty-c"><p class="sub">Belum ada latihan. Buat satu dari materi yang sudah kamu ringkas.</p></div>`}
    </section>
  </div>`;
}
function viewLatRun(L){
  const c = findCourse(L.cid), H = L.hasil, A = UI.latAns && UI.latAns.id === L.id ? UI.latAns : (UI.latAns = { id: L.id, pg: { ...(L.jawaban.pg || {}) }, essay: { ...(L.jawaban.essay || {}) } });
  const nQ = L.soal.pg.length + L.soal.essay.length, nA = Object.keys(A.pg).length + Object.values(A.essay).filter(x => String(x || "").trim()).length;
  const weak = H ? Object.entries(L.soal.pg.reduce((o, q, i) => { if (!H.pg[i].benar && q.topik) o[q.topik] = (o[q.topik] || 0) + 1; return o; }, {})).sort((a, b) => b[1] - a[1]).slice(0, 5) : [];
  const pgHTML = L.soal.pg.map((q, i) => { const pick = A.pg[i], r = H && H.pg[i];
    return `<div class="lq ${r ? (r.benar ? "is-right" : "is-wrong") : ""}" id="lq${i}"><div class="lq-h"><span class="lq-n">${i + 1}</span>${q.topik ? `<span class="tagc">${esc(q.topik)}</span>` : ""}</div><p class="lq-q">${esc(q.q)}</p>
      <div class="opts">${q.o.map((o, k) => `<button class="opt ${!H && pick === k ? "picked" : ""} ${H && k === q.a ? "right" : ""} ${H && k === pick && pick !== q.a ? "wrong" : ""}" ${H ? "disabled" : `data-k="lat-pick" data-v="${i}|${k}"`}><b>${String.fromCharCode(65 + k)}</b><span>${esc(o)}</span></button>`).join("")}</div>
      ${H ? `<p class="expl">${r.benar ? "Benar." : pick == null ? "Tidak dijawab." : "Belum tepat."} ${esc(q.e)}</p>` : ""}</div>`; }).join("");
  const esHTML = L.soal.essay.map((q, i) => { const r = H && H.essay[i];
    return `<div class="lq essay"><div class="lq-h"><span class="lq-n">E${i + 1}</span>${q.topik ? `<span class="tagc">${esc(q.topik)}</span>` : ""}${r ? `<span class="score-b ${r.skor >= 80 ? "good" : r.skor >= 60 ? "mid" : "low"}">${r.skor}</span>` : ""}</div><p class="lq-q">${esc(q.q)}</p>
      ${H ? `<div class="ans">${esc(A.essay[i] || "(tidak dijawab)").replace(/\n/g, "<br>")}</div><div class="fb-box"><p>${esc(r.umpan)}</p>${r.kurang ? `<p><b>Yang belum ada:</b> ${esc(r.kurang)}</p>` : ""}<p class="cap"><b>Kunci:</b> ${q.kunci.map(esc).join("; ")}</p></div>`
        : `<textarea class="essay-in" data-essay="${i}" placeholder="Tulis jawabanmu di sini">${esc(A.essay[i] || "")}</textarea>`}</div>`; }).join("");
  return `
  <nav class="crumbs"><button data-k="lat-back">${I.left}Latihan soal</button></nav>
  <div class="lat-run" ${c ? `data-c="${c.warna}"` : ""}>
    <header class="lat-top"><div><h2 class="title2">${esc(c ? c.nama : "")}</h2><p class="sub">${esc(L.label)}, ${L.soal.pg.length} pilihan ganda${L.soal.essay.length ? " dan " + L.soal.essay.length + " essay" : ""}</p></div></header>
    ${H ? `<section class="board result-board"><div class="rb">
        <div class="rb-score"><b>${H.total}</b><span>nilai akhir</span></div>
        <div class="rb-txt"><p class="say">${H.pgScore != null ? `Pilihan ganda benar <mark class="hl">${H.pg.filter(x => x.benar).length} dari ${H.pg.length}</mark>` : ""}${H.pgScore != null && H.esScore != null ? ", " : ""}${H.esScore != null ? `rata-rata essay <mark class="hl">${Math.round(H.esScore)}</mark>` : ""}.</p>
          ${weak.length ? `<p class="board-status">Perlu diulang: ${weak.map(([t]) => esc(t)).join(", ")}.</p>` : `<p class="board-status">Tidak ada topik yang salah di pilihan ganda. Mantap.</p>`}
          <div class="inline"><button class="btn hl-btn" data-k="lat-again" data-v="${L.id}">Buat latihan baru yang mirip</button><button class="btn line-light" data-k="chat-from-lat" data-v="${L.id}">Bahas yang salah dengan AI</button></div></div></div></section>` : ""}
    <div class="lq-list">${pgHTML}${esHTML ? `<h3 class="lq-sec">Essay</h3>${esHTML}` : ""}</div>
    ${H ? "" : `<div class="lat-bar"><div class="lb-prog"><span>Terjawab ${nA} dari ${nQ}</span><div class="exam-bar light"><i style="width:${nQ ? Math.round(nA / nQ * 100) : 0}%"></i></div></div><button class="btn dark" data-k="lat-submit">Kumpulkan dan nilai</button></div>`}
  </div>`;
}

// ----- kemampuan (rapor)
function kemampuan(){
  const out = sorted().map(c => {
    const qz = []; Object.entries(sem().materi).forEach(([k, m]) => { const [cid, n] = k.split(/_(?=\d+$)/); if (cid !== c.id || !(m.kuis || []).length) return; const p = getP(cid, Number(n)); if (p.kuis != null) qz.push({ n: Number(n), pct: Math.round(p.kuis / m.kuis.length * 100), judul: m.judul }); });
    const lat = latList().filter(L => L.cid === c.id && L.hasil);
    const avg = a => a.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length) : null;
    const topik = {}; lat.forEach(L => { L.soal.pg.forEach((q, i) => { if (!L.hasil.pg[i].benar && q.topik) topik[q.topik] = (topik[q.topik] || 0) + 1; }); L.soal.essay.forEach((q, i) => { if (L.hasil.essay[i] && L.hasil.essay[i].skor < 60 && q.topik) topik[q.topik] = (topik[q.topik] || 0) + 1; }); });
    qz.filter(x => x.pct < 60).forEach(x => { topik["Pertemuan " + x.n + ": " + x.judul.slice(0, 40)] = (topik["Pertemuan " + x.n + ": " + x.judul.slice(0, 40)] || 0) + 1; });
    const kuis = avg(qz.map(x => x.pct)), latihan = avg(lat.map(L => L.hasil.total));
    const all = [kuis, latihan].filter(x => x != null);
    return { c, kuis, latihan, nKuis: qz.length, nLat: lat.length, skor: all.length ? Math.round(all.reduce((a, b) => a + b, 0) / all.length) : null, topik: Object.entries(topik).sort((a, b) => b[1] - a[1]).slice(0, 4) };
  });
  return out;
}
function viewKemampuan(){
  const K = kemampuan(), scored = K.filter(x => x.skor != null), overall = scored.length ? Math.round(scored.reduce((a, x) => a + x.skor, 0) / scored.length) : null;
  const best = scored.slice().sort((a, b) => b.skor - a.skor)[0], worst = scored.slice().sort((a, b) => a.skor - b.skor)[0];
  const sar = (S.saran || {})[S.current], endSem = rawWeek(today()) >= 15;
  const bar = (v, lbl) => `<div class="kb"><span>${lbl}</span><div class="kb-t"><i style="width:${v || 0}%"></i></div><b>${v == null ? "-" : v}</b></div>`;
  const R = 54, C = 2 * Math.PI * R;
  return `
  ${endSem ? `<div class="banner">Semester hampir selesai. Ini rapor kemampuanmu dari semua kuis dan latihan soal semester ini.</div>` : ""}
  <section class="board k-board"><div class="rb">
    <div class="rb-ring"><svg viewBox="0 0 130 130" class="ring"><circle class="bg" cx="65" cy="65" r="${R}"/><circle class="fg ${overall >= 100 ? "full" : ""}" cx="65" cy="65" r="${R}" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - (overall || 0) / 100)}" transform="rotate(-90 65 65)"/><text class="big" x="65" y="72" text-anchor="middle">${overall == null ? "-" : overall}</text></svg></div>
    <div class="rb-txt"><p class="hi">Rapor kemampuan semester ini</p>
      <p class="say">${overall == null ? "Belum ada data. Kerjakan kuis di setiap materi atau buat latihan soal supaya kemampuanmu bisa dihitung." : `Rata-rata kemampuanmu <mark class="hl">${overall}</mark>.${best && worst && best !== worst && best.skor - worst.skor >= 5 ? ` Paling kuat di <mark class="hl">${esc(best.c.singkat)}</mark>, perlu latihan lagi di <mark class="hl">${esc(worst.c.singkat)}</mark>.` : ""}`}</p>
      <p class="board-status">Dihitung dari ${K.reduce((a, x) => a + x.nKuis, 0)} kuis materi dan ${K.reduce((a, x) => a + x.nLat, 0)} latihan soal.</p></div></div></section>
  <div class="k-grid">
    <section><div class="group-t"><h2 class="title3">Per mata kuliah</h2><span class="cap">Nilai 0 sampai 100</span></div>
      <div class="group">${K.map(x => `<div class="krow" data-c="${x.c.warna}"><div class="kr-h"><i class="dot"></i><b>${esc(x.c.singkat)}</b><span class="score-b ${x.skor == null ? "" : x.skor >= 80 ? "good" : x.skor >= 60 ? "mid" : "low"}">${x.skor == null ? "belum ada" : x.skor}</span></div>${bar(x.kuis, "Kuis")}${bar(x.latihan, "Latihan")}${x.topik.length ? `<p class="cap">Perlu diulang: ${x.topik.map(([t]) => esc(t)).join(", ")}</p>` : ""}</div>`).join("")}</div></section>
    <section class="card saran"><div class="w-h"><h2 class="title3">Saran belajar dari AI</h2>${sar ? `<span class="cap">${ago(sar.dibuat)}</span>` : ""}</div>
      ${sar ? `<div class="md">${md(sar.teks)}</div>` : `<p class="sub">AI membaca hasil kuis dan latihanmu, lalu memberi tahu apa yang sudah kuat, apa yang perlu diperbaiki, dan rencana belajar 2 minggu.</p>`}
      <button class="btn ${sar ? "" : "dark"}" data-k="saran-make" ${overall == null ? "disabled" : ""}>${sar ? "Perbarui saran" : "Minta saran AI"}</button></section>
  </div>`;
}
function saranStats(){
  return kemampuan().map(x => `${x.c.nama}: rata-rata kuis ${x.kuis == null ? "belum ada" : x.kuis} (${x.nKuis} kuis), rata-rata latihan ${x.latihan == null ? "belum ada" : x.latihan} (${x.nLat} latihan). Topik sering salah: ${x.topik.map(([t, n]) => `${t} (${n}x)`).join(", ") || "tidak ada"}.`).join("\n") + `\nPertemuan saat ini: ${weekOf(today())} dari 16.`;
}

/* aksi fitur belajar */
document.addEventListener("click", async e => {
  const b = e.target.closest("[data-k]"); if (!b) return;
  const k = b.dataset.k, v = b.dataset.v;
  if (k === "pandu-open"){ go("pandu", { panduId: v }); setTimeout(scrollPandu, 0); }
  else if (k === "pandu-start"){ const ta = $("#pandu-extra"); const extra = ta ? ta.value : ""; if (b.dataset.need && !extra.trim()){ toast("Tempel instruksi tugasnya dulu."); return; } panduMulai(v, extra); }
  else if (k === "pandu-send"){ const q = $("#panduq"); const t = q ? q.value : ""; if (q) q.value = ""; panduKirim(v, t); }
  else if (k === "pandu-chip"){ panduKirim(UI.panduId, v); }
  else if (k === "pandu-step"){ const id = UI.panduId; const r = await api.panduStep(id, Number(v)); if (!r.ok){ toast(r.error); return; } if (r.pindah) panduKirim(id, "", true); }
  else if (k === "pandu-retry"){ const r = await api.panduRetry(v); if (!r.ok){ toast(r.error); return; } panduKirim(v, r.q || "", !r.q); }
  else if (k === "pandu-reset"){ if (UI.panduConfirm !== v){ UI.panduConfirm = v; render(); return; } UI.panduConfirm = null; await api.panduDel(v); }
  else if (k === "pandu-reset-no"){ UI.panduConfirm = null; render(); }
  else if (k === "chat-open"){ UI.chatKey = v; if (UI.view !== "tanya") go("tanya"); else render(); scrollChat(); setTimeout(() => { const q = $("#chatq"); if (q) q.focus(); }, 0); }
  else if (k === "chat-send"){ const q = $("#chatq"); const t = q ? q.value : ""; if (q) q.value = ""; sendChat(t); }
  else if (k === "chat-suggest"){ sendChat(v); }
  else if (k === "chat-retry"){ if (UI.chatLive) return; UI.chatLive = { key: v, text: "" }; render(); scrollChat(); const r = await api.chatRetry(v); UI.chatLive = null; render(); scrollChat(); if (!r.ok) toast(r.error); }
  else if (k === "side-send"){ const q = $("#sideq"); const t = q ? q.value : ""; if (q) q.value = ""; sendChat(t, v); }
  else if (k === "side-suggest"){ sendChat(v, b.dataset.ck); }
  else if (k === "chat-clear"){ await api.chatClear(UI.chatKey || "umum"); }
  else if (k === "ask-open"){ const q = ($("#askq") || {}).value || ""; UI.chatKey = "m:" + v; go("tanya"); scrollChat(); if (q.trim()) sendChat(q); }
  else if (k === "utab"){ UI.uTab = v; if (b.dataset.scope) (UI.latForm || (UI.latForm = { cid: (sorted()[0] || {}).id, pg: 20, essay: 3 })).scope = b.dataset.scope; UI.latId = null; render(); window.scrollTo(0, 0); }
  else if (k === "ujenis"){ UI.uJenis = v; render(); }
  else if (k === "u-prepare"){ b.disabled = true; toast("Menyusun materi yang belum diringkas. Progresnya ada di pojok kanan bawah."); const r = await api.prepareUjian(v || null, UI.uJenis || ujianNow().jenis); toast(r.ok ? (r.n ? r.n + " materi selesai diringkas." : "Tidak ada file baru yang bisa diringkas.") : r.error); render(); }
  else if (k === "rangkum-make"){ b.disabled = true; const j = UI.uJenis || ujianNow().jenis; const r = await api.rangkumanUjian(v, j); if (r.ok){ UI.rangkum = `${S.current}_${v}_${j}`; render(); window.scrollTo(0, 0); } else { toast(r.error); render(); } }
  else if (k === "rangkum-open"){ UI.rangkum = `${S.current}_${v}_${UI.uJenis || ujianNow().jenis}`; render(); window.scrollTo(0, 0); }
  else if (k === "rangkum-close"){ UI.rangkum = null; render(); }
  else if (k === "lat-quick"){ UI.uTab = "latihan"; UI.latId = null; UI.latForm = { ...(UI.latForm || { pg: 20, essay: 3 }), cid: v, scope: b.dataset.scope || "semua" }; render(); window.scrollTo(0, 0); }
  else if (k === "latf"){ const F = UI.latForm; F[b.dataset.f] = /^\d+$/.test(v) ? Number(v) : v; render(); }
  else if (k === "lat-make"){ const F = UI.latForm, [fa, fb] = F.scope === "uts" ? UJI.uts : F.scope === "uas" ? UJI.uas : F.scope === "semua" ? [1, 16] : [Math.min(F.from, F.to), Math.max(F.from, F.to)];
    b.disabled = true; b.textContent = "Membuat soal…";
    const r = await api.makeLatihan({ cid: F.cid, from: fa, to: fb, pg: F.pg, essay: F.essay, label: F.scope === "uts" ? "Latihan UTS" : F.scope === "uas" ? "Latihan UAS" : F.scope === "semua" ? "Semua pertemuan" : `Pertemuan ${fa} sampai ${fb}` });
    if (r.ok){ UI.latId = r.id; UI.latAns = null; render(); window.scrollTo(0, 0); } else { toast(r.error); render(); } }
  else if (k === "lat-open"){ UI.latId = v; UI.latAns = null; render(); window.scrollTo(0, 0); }
  else if (k === "lat-back"){ UI.latId = null; render(); }
  else if (k === "lat-del"){ await api.delLatihan(v); toast("Latihan dihapus."); }
  else if (k === "lat-pick"){ const [i, o] = v.split("|").map(Number); UI.latAns.pg[i] = o; const y = window.scrollY; render(); window.scrollTo(0, y); api.saveLatihan(UI.latId, { pg: UI.latAns.pg, essay: UI.latAns.essay }); }
  else if (k === "lat-submit"){ const L = S.latihan[UI.latId], A = UI.latAns, miss = L.soal.pg.length - Object.keys(A.pg).length + L.soal.essay.filter((q, i) => !String(A.essay[i] || "").trim()).length;
    if (miss && !b.dataset.sure){ b.dataset.sure = "1"; b.textContent = `${miss} soal belum dijawab. Klik lagi untuk tetap kumpulkan`; return; }
    b.disabled = true; b.textContent = L.soal.essay.length ? "Menilai essay…" : "Menilai…";
    const r = await api.submitLatihan(UI.latId, { pg: A.pg, essay: A.essay }); if (!r.ok){ toast(r.error); render(); } else { render(); window.scrollTo(0, 0); } }
  else if (k === "lat-again"){ const L = S.latihan[v]; UI.latId = null; UI.latForm = { cid: L.cid, scope: "pilih", from: L.from, to: L.to, pg: L.soal.pg.length, essay: L.soal.essay.length }; render(); window.scrollTo(0, 0); }
  else if (k === "chat-from-lat"){ const L = S.latihan[v], c = findCourse(L.cid); const wrong = L.soal.pg.filter((q, i) => !L.hasil.pg[i].benar).slice(0, 8).map(q => `- ${q.q} (jawaban benar: ${q.o[q.a]})`).join("\n");
    UI.chatKey = "c:" + L.cid; go("tanya"); sendChat(`Aku baru latihan soal ${c ? c.nama : ""} dan salah di soal-soal ini:\n${wrong || "- (tidak ada yang salah di pilihan ganda)"}\nJelaskan konsep di balik soal-soal itu supaya aku paham, lalu beri 3 soal mirip untuk kucoba.`); }
  else if (k === "saran-make"){ b.disabled = true; b.textContent = "AI sedang membaca hasilmu…"; const r = await api.makeSaran(saranStats()); if (!r.ok){ toast(r.error); render(); } }
  else if (k === "theme"){ const cur = S.settings.theme || "auto", dark = cur === "dark" || (cur === "auto" && matchMedia("(prefers-color-scheme: dark)").matches); await api.saveSettings({ theme: v || (dark ? "light" : "dark") }); }
});
document.addEventListener("keydown", e => {
  if (e.target.id === "chatq" && e.key === "Enter" && !e.shiftKey){ e.preventDefault(); const t = e.target.value; e.target.value = ""; sendChat(t); }
  if (e.target.id === "panduq" && e.key === "Enter" && !e.shiftKey){ e.preventDefault(); const t = e.target.value; e.target.value = ""; panduKirim(UI.panduId, t); }
  if (e.target.id === "sideq" && e.key === "Enter" && !e.shiftKey){ e.preventDefault(); const t = e.target.value; e.target.value = ""; sendChat(t, e.target.dataset.ck); }
});
document.addEventListener("input", e => {
  if (e.target.id === "chatq" || e.target.id === "sideq" || e.target.id === "panduq"){ e.target.style.height = "auto"; e.target.style.height = Math.min(180, e.target.scrollHeight) + "px"; }
  if (e.target.dataset && e.target.dataset.essay !== undefined && UI.latAns){ UI.latAns.essay[e.target.dataset.essay] = e.target.value; clearTimeout(UI._essT); UI._essT = setTimeout(() => api.saveLatihan(UI.latId, { pg: UI.latAns.pg, essay: UI.latAns.essay }), 800);
    const bar = $(".lb-prog span"); if (bar){ const L = S.latihan[UI.latId]; const nA = Object.keys(UI.latAns.pg).length + Object.values(UI.latAns.essay).filter(x => String(x || "").trim()).length; bar.textContent = `Terjawab ${nA} dari ${L.soal.pg.length + L.soal.essay.length}`; } }
});
document.addEventListener("change", e => {
  if (!UI.latForm) return;
  if (e.target.id === "lf-cid"){ UI.latForm.cid = e.target.value; render(); }
  if (e.target.id === "lf-from"){ UI.latForm.from = Number(e.target.value); render(); }
  if (e.target.id === "lf-to"){ UI.latForm.to = Number(e.target.value); render(); }
});
function applyTheme(){ const t = S && S.settings.theme || "auto"; if (t === "auto") delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = t; }

/* ---------- render ---------- */
function go(v, opts={}){ UI.view = v; Object.assign(UI, opts); UI.confirmDel = null; render(); window.scrollTo(0,0); }
function render(){
  if(!S) return;
  renderNav();
  const v = UI.view;
  const html = v==="jadwal" ? viewJadwal() : v==="materi" ? viewMateri() : v==="ujian" ? viewUjian() : v==="tanya" ? viewTanya() : v==="todo" ? viewTodo() : v==="pandu" ? viewPandu() : v==="pengaturan" ? viewPengaturan() : viewBeranda();
  // Isian yang sedang diketik tidak boleh hilang saat data baru masuk dari sinkron
  const ae = document.activeElement, focus = ae && ae.id && /^(INPUT|TEXTAREA)$/.test(ae.tagName) ? { id: ae.id, v: ae.value, a: ae.selectionStart, b: ae.selectionEnd } : null;
  $("#view").innerHTML = html;
  if(focus){ const el = document.getElementById(focus.id); if(el){ if(el.type !== "checkbox") el.value = focus.v; el.focus(); try { el.setSelectionRange(focus.a, focus.b); } catch(e){} } }
}
document.addEventListener("input", e => { if(e.target.id === "paste" && UI.plan) UI.plan.paste = e.target.value; });

/* ---------- events ---------- */
document.addEventListener("click", async e => {
  const b = e.target.closest("[data-paksa],[data-ulang],[data-ulangya],[data-ulangno],[data-komalt],[data-kompick],[data-komcopy],[data-lamp],[data-go],[data-open],[data-course],[data-back],[data-week],[data-sem],[data-tab],[data-flip],[data-q],[data-qreset],[data-copy],[data-filter],[data-delask],[data-del],[data-delno],[data-delmateri],[data-exam],[data-ask],[data-act],[data-open-url],[data-provider],[data-modal],[data-rmgroup]");
  if(!b) return;
  const d = b.dataset;
  if(d.openUrl){ e.preventDefault(); api.open(d.openUrl); }
  else if(d.go){ go(d.go, d.go==="materi"?{course:null, meet:null}:{}); }
  else if(d.open){ const [cid,n] = d.open.split("|"); go("materi", {course:cid, meet:Number(n), tab:"ringkasan"}); }
  else if(d.course){ UI.course = d.course; UI.meet = null; UI.exam = null; render(); scrollTo(0,0); }
  else if(d.back){ if(d.back==="materi"){ UI.course=null; UI.meet=null; } else UI.meet=null; render(); scrollTo(0,0); }
  else if(d.week){ UI.week = d.week==="now" ? weekOf(today()) : Math.min(16, Math.max(1, UI.week + Number(d.week))); render(); }
  else if(d.sem){ S.current = d.sem; render(); api.setSemester(d.sem); }
  else if(d.tab){ UI.tab = d.tab; render(); }
  else if(d.flip){ UI.flip[d.flip] = !UI.flip[d.flip]; b.classList.toggle("flip"); }
  else if(d.q){ const [qid,i,j] = d.q.split("|"); (UI.quiz[qid] ||= {})[i] = Number(j); onQuiz(qid); render(); }
  else if(d.qreset){ UI.quiz[d.qreset] = {}; render(); }
  else if(d.copy){ const m = sem().materi[d.copy]; try{ await navigator.clipboard.writeText(m.komentar); toast("Tersalin. Tinggal tempel di kolom komentar LMS."); }catch(err){ toast("Gagal menyalin."); } }
  else if(d.filter){ UI.todoFilter = d.filter; render(); }
  else if(d.delask){ UI.confirmDel = d.delask; render(); }
  else if(d.delno){ UI.confirmDel = null; render(); }
  else if(d.del){ UI.confirmDel = null; await api.delTodo(d.del); toast("To-do dihapus."); }
  else if(d.delmateri){ UI.confirmDel = null; await api.deleteMateri(d.delmateri); UI.meet = null; toast("Materi dihapus."); }
  else if(d.exam !== undefined){ UI.exam = d.exam || null; if(d.exam) UI.quiz["exam_"+d.exam] = {}; render(); }
  else if(d.paksa){ const r = await api.forceLampiran(d.paksa); toast(r.ok ? "File ini akan ikut diringkas. Klik tombol Ringkas di pertemuannya." : r.error); }
  else if(d.ulang){ UI.confirmUlang = d.ulang.replace("|", "_"); render(); }
  else if(d.ulangno){ UI.confirmUlang = null; render(); }
  else if(d.ulangya){ const [cid, n] = d.ulangya.split("|"); UI.confirmUlang = null; UI.lampBusy = cid + "_" + n; render(); const r = await api.resummarize(cid, Number(n)); UI.lampBusy = null; render(); toast(r.ok ? (r.warnings && r.warnings.length ? "Materi diringkas ulang. Catatan: " + r.warnings[0] : "Materi diringkas ulang.") : r.error); }
  else if(d.komalt){ UI.komBusy = d.komalt; render(); const r = await api.komentarAlt(d.komalt); UI.komBusy = null; render(); if(!r.ok) toast(r.error); }
  else if(d.kompick){ const [key, i] = d.kompick.split("|"), m = sem().materi[key], t = m && (m.komentarAlt || [])[Number(i)]; if(!t) return; const r = await api.komentarPick(key, t); toast(r.ok ? "Komentar diganti." : r.error); }
  else if(d.komcopy){ const [key, i] = d.komcopy.split("|"), m = sem().materi[key], t = m && (m.komentarAlt || [])[Number(i)]; if(!t) return; try{ await navigator.clipboard.writeText(t); toast("Tersalin. Tinggal tempel di kolom komentar LMS."); }catch(err){ toast("Gagal menyalin."); } }
  else if(d.lamp){ const [cid, n] = d.lamp.split("|"); UI.lampBusy = cid + "_" + n; render(); const r = await api.summarizeLMS(cid, Number(n)); UI.lampBusy = null; if(r.ok){ toast(r.warnings && r.warnings.length ? "Materi tersusun. Catatan: " + r.warnings[0] : "Materi tersusun."); go("materi", { course: cid, meet: Number(n), tab: "ringkasan" }); } else { render(); toast(r.error); } }
  else if(d.ask){ const q = ($("#askq").value||"").trim(); if(!q) return; UI.ask[d.ask] = { q, busy: true }; render(); const r = await api.ask(q, d.ask); UI.ask[d.ask] = { q, a: r.ok ? r.text : r.error }; render(); }
  else if(d.provider){ UI.aiTest = null; await api.saveSettings({ ai: { provider: d.provider } }); }
  else if(d.modal === "close"){ if(!UI.plan || !UI.plan.running){ UI.plan = null; renderModal(); } }
  else if(d.rmgroup){ UI.plan.groups.splice(Number(d.rmgroup),1); renderModal(); }
  else if(d.act){
    const a = d.act;
    if(a === "hello"){ await api.saveSettings({ welcomed: true }); }
    else if(a === "finish"){ if(!(S.lms.connected && aiReady())){ toast("Selesaikan langkah 1 dan 2 dulu."); return; } if(!absMode()){ toast("Pilih cara absensi kampusmu di langkah 3."); return; } await api.saveSettings({ setupDone: true }); go("beranda"); }
    else if(a === "lms-custom"){ UI.customLms = true; render(); setTimeout(()=>{ const i = $("#kampus-url"); if(i) i.focus(); }, 0); }
    else if(a === "lms-default"){ UI.customLms = false; await api.saveSettings({ kampus: { nama: "", url: "https://edlink.id" } }); }
    else if(a === "login"){ const inp = $("#kampus-url"); if(!inp && !(S.settings.kampus && S.settings.kampus.url)) await api.saveSettings({ kampus: { nama: "", url: "https://edlink.id" } }); if(inp){ const u = (inp.value||"").trim(); if(!u){ toast("Isi alamat LMS kampusmu, atau pilih Pakai Edlink biasa."); inp.focus(); return; } const sv = await api.saveSettings({ kampus: { nama: "", url: u } }); if(!sv.ok){ toast(sv.error); return; } } toast("Jendela login LMS dibuka."); const r = await api.lmsLogin(); toast(r.ok ? "LMS terhubung dan tersinkron." : r.error); }
    else if(a === "sync"){ const r = await api.lmsSync(); toast(r.ok ? (r.baru ? r.baru+" post baru dari LMS." : "Sudah tersinkron.") : r.error); }
    else if(a === "logout"){ await api.lmsLogout(); toast("Keluar dari LMS."); }
    else if(a === "quota-reload"){ UI.qErr = null; loadQuota(true); }
    else if(a === "srv-save"){ const inp = $("#srv-url"); UI.open_adv = true; const r = await api.saveSettings({ ai: { serverUrl: inp ? inp.value : "", provider: "server" } }); if (r && r.ok === false){ toast(r.error); return; } UI.quota = null; UI.qErr = null; UI.qAt = 0; toast("Alamat server disimpan."); }
    else if(a === "auto-save"){ const x = d.for, inp = $("#ak-" + x), k = inp && inp.value.trim(); if(!k){ toast("Tempel API key " + x + " dulu."); return; } await api.saveSettings({ ai: { provider: S.settings.ai.provider === "server" ? "server" : "auto", key: k, keyFor: x } }); UI.akMsg = { ok: true, t: "Menghubungkan…", for: x }; render(); const r = await api.testAI(x); UI.akMsg = r.ok ? { ok: true, t: ({cerebras:"Cerebras",groq:"Groq",gemini:"Gemini"})[x] + " tersambung, model " + r.pick + ".", for: x } : { ok: false, t: r.error, for: x }; render(); }
    else if(a === "backup-save"){ const x = d.for, inp = $("#bk-" + x), k = inp && inp.value.trim(); if(!k){ toast("Tempel API key " + AI_INFO[x].nama + " dulu."); return; } UI.backupOpen = true; await api.saveSettings({ ai: { key: k, keyFor: x } }); UI.bkMsg = { ok: true, t: "Menghubungkan " + AI_INFO[x].nama + "…" }; render(); const r = await api.testAI(x); UI.bkMsg = r.ok ? { ok: true, t: AI_INFO[x].nama + " tersambung sebagai cadangan, model " + r.pick + "." } : { ok: false, t: r.error }; render(); }
    else if(a === "test-ai"){
      const patch = { ai: {} };
      const k = $("#ai-key"); if(k && k.value.trim()) patch.ai.key = k.value.trim();
      const u = $("#ollama-url"); if(u) patch.ai.ollamaUrl = u.value.trim();
      await api.saveSettings(patch);
      UI.aiTest = { ok: true, pick: "menguji…" }; render();
      UI.aiTest = await api.testAI(); render();
    }
    else if(a === "guide"){ const r = await api.openGuide(); if(!r.ok) toast(r.error); }
    else if(a === "guide-file"){ const r = await api.openGuideFile(); if(!r.ok) toast(r.error); }
    else if(a === "add"){ openAdd(d.cid ? { cid: d.cid, meet: d.meet } : null); }
    else if(a === "pick"){ const r = await api.pickFiles(!!d.folder); if(r.paths && r.paths.length){ if(!UI.plan) openAdd(UI.plan && UI.plan.prefill); planItems(r.paths.map(p=>({path:p})), UI.plan && UI.plan.prefill); } }
    else if(a === "paste"){ const t = ($("#paste").value||"").trim(); if(!t) return; UI.plan.paste = ""; const items = /^https?:\/\/\S+$/.test(t) ? [{ url: t }] : [{ text: t }]; planItems(items, UI.plan.prefill); }
    else if(a === "run"){ runPlan(); }
  }
});
// Ingat daftar file dosen yang sedang dibuka supaya tidak tertutup saat data diperbarui
document.addEventListener("toggle", e => { const k = e.target && e.target.dataset && e.target.dataset.ud; if (k) (UI.udOpen ||= {})[k] = e.target.open; }, true);
document.addEventListener("change", async e => {
  const t = e.target;
  if(t.dataset.p){ const [cid,n,f] = t.dataset.p.split("|"); await api.setProgress(pKey(cid, Number(n)), f, t.checked); }
  else if(t.dataset.todo){ const id = t.dataset.todo, td = S.todos[id]; if(td) await api.putTodo(id, { ...td, done: t.checked }); }
  else if(t.id === "geser"){ await api.saveSettings({ geserHari: Number(t.value) }); toast("Hari kuliah disesuaikan."); }
  else if(t.id === "autosync"){ await api.saveSettings({ autoSync: t.checked }); }
  else if(t.id === "background"){ await api.saveSettings({ background: t.checked }); }
  else if(t.id === "uj-auto"){ await api.saveSettings({ ujianOtomatis: t.checked }); }
  else if(t.name === "abs-mode"){ await api.saveSettings({ absensiMode: t.value }); toast(t.value === "komentar" ? "Template, ceklis, to-do, dan pengingat komentar dinyalakan." : t.value === "keaktifan" ? "Aktivitasmu di LMS ditampilkan per pertemuan." : "Template dan ceklis komentar disembunyikan."); }
  else if(t.dataset && t.dataset.peng){ await api.saveSettings({ pengingat: { [t.dataset.peng]: t.checked } }); toast(t.checked ? "Pengingat dinyalakan." : "Pengingat dimatikan."); }
  else if(t.id === "automateri"){ await api.saveSettings({ autoMateri: t.checked }); if(t.checked) toast("Materi dari LMS akan disusun otomatis."); }
  else if(t.id === "ai-model"){ await api.saveSettings({ ai: { model: t.value } }); toast("Model diganti ke " + t.value); }
  else if(t.dataset.g !== undefined){ const g = UI.plan.groups[Number(t.dataset.g)]; const k = t.dataset.k; g[k] = k === "merge" ? t.checked : k === "meet" ? Number(t.value) || null : t.value || null; renderModal(); }
});
document.addEventListener("submit", async e => {
  if(e.target.id !== "addform") return;
  e.preventDefault();
  const text = $("#td-text").value.trim(); if(!text) return;
  const id = "m" + Date.now().toString(36) + Math.random().toString(36).slice(2,6);
  await api.putTodo(id, { text, course: $("#td-course").value, due: $("#td-due").value, time: "", done: false, source: "manual", createdAt: new Date().toISOString() });
  toast("To-do ditambahkan."); const el = $("#td-text"); if(el){ el.value = ""; el.focus(); }
});
function onQuiz(qid){
  if(qid.startsWith("exam_")) return;
  const m = sem().materi[qid]; if(!m) return;
  const st = UI.quiz[qid];
  if(Object.keys(st).length === m.kuis.length){ const r = Object.entries(st).filter(([i,a]) => m.kuis[i].a === a).length; const [cid, n] = qid.split(/_(?=\d+$)/); api.setProgress(pKey(cid, Number(n)), "kuis", r); toast("Skor kuis: "+r+"/"+m.kuis.length); }
}

/* drag & drop dari mana saja */
let dragDepth = 0;
window.addEventListener("dragenter", e => { e.preventDefault(); dragDepth++; if(linked()) $("#drop").hidden = false; });
window.addEventListener("dragleave", e => { dragDepth = Math.max(0, dragDepth-1); if(!dragDepth) $("#drop").hidden = true; });
window.addEventListener("dragover", e => e.preventDefault());
window.addEventListener("drop", e => {
  e.preventDefault(); dragDepth = 0; $("#drop").hidden = true;
  if(!linked()){ toast("Hubungkan akun LMS dulu supaya daftar mata kuliah muncul."); return; }
  const items = [];
  for(const f of e.dataTransfer.files){ const p = api.pathOf(f); if(p) items.push({ path: p }); }
  if(!items.length){ const t = (e.dataTransfer.getData("text/uri-list") || e.dataTransfer.getData("text/plain") || "").trim(); if(t) items.push(/^https?:\/\/\S+$/.test(t.split("\n")[0]) ? { url: t.split("\n")[0] } : { text: t }); }
  if(!items.length) return;
  const pre = UI.plan ? UI.plan.prefill : (UI.view === "materi" && UI.course ? { cid: UI.course, meet: UI.meet || weekOf(today()) } : null);
  if(!UI.plan) UI.plan = { groups: [], skipped: [], prefill: pre, running: false, paste: "" };
  planItems(items, pre);
});

/* ---------- boot ---------- */
api.onState(s => { S = s; applyTheme(); if(!ready() && UI.view !== "pengaturan") UI.view = "beranda"; render(); if(UI.plan) renderModal(); });
function renderJob(){
  const el = $("#job"), msg = UI.status.auto || (!UI.plan && UI.status.ingestOn ? UI.status.ingest : null);
  if (!msg){ el.hidden = true; return; }
  const i = msg.indexOf(": "), head = i > 0 && i < 40 ? msg.slice(0, i) : "Menyusun materi", body = i > 0 && i < 40 ? msg.slice(i + 2) : msg;
  el.innerHTML = `<b>${esc(head)}</b><span>${esc(body)}</span><div class="bar"><i></i></div>`; el.hidden = false;
}
api.onStatus(st => { Object.assign(UI.status, st); if(st.ingest && UI.plan) renderModal(); if("sync" in st) renderNav(); if("auto" in st || "ingest" in st) renderJob(); if(st.update) showUpdate(st.update); });
function showUpdate(v){ if($("#updbtn")) return; const b = document.createElement("button"); b.id = "updbtn"; b.className = "btn dark update"; b.textContent = "Versi " + v + " siap. Mulai ulang untuk update"; b.onclick = () => api.installUpdate(); document.body.appendChild(b); }
$("#syncbtn").addEventListener("click", async () => { const r = await api.lmsSync(); toast(r.ok ? (r.baru ? r.baru+" post baru dari LMS." : "Sudah tersinkron.") : r.error); });
api.getState().then(s => { S = s; applyTheme(); if(!ready()) UI.view = "beranda"; render(); });
})();

// Ingat bagian lipat (details) yang dibuka, supaya tidak tertutup lagi saat layar diperbarui
document.addEventListener("toggle", e => { const d = e.target; if (d && d.dataset && d.dataset.fold) UI["open_" + d.dataset.fold] = d.open; }, true);
