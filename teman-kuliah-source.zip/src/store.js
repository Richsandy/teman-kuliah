// Penyimpanan lokal: satu file JSON di folder data aplikasi (AppData\Roaming\Teman Kuliah).
const fs = require("fs");
const path = require("path");

const DEFAULT = {
  version: 1,
  settings: {
    nama: "",
    welcomed: false,           // sudah melewati halaman selamat datang
    setupDone: false,          // sudah menyelesaikan 3 langkah persiapan (LMS + AI)
    kampus: { nama: "", url: "" }, // LMS Edlink kampus, misal https://kuliah.unsia.ac.id
    geserHari: 0,
    absensiMode: null,         // "komentar" | "keaktifan" | "tidak" | null (belum dipilih)
    absensiKomentar: null,     // null = tebak otomatis dari kampus; true = absensi lewat komentar di setiap post dosen              // 0 = sesuai KRS; 2 = Senin di KRS jadi Rabu, dst.
    ai: { provider: "server", serverUrl: "", keys: { gemini: "", openai: "", anthropic: "", cerebras: "", groq: "" }, model: { gemini: "", openai: "", anthropic: "", ollama: "", cerebras: "", groq: "" }, models: {}, ollamaUrl: "http://127.0.0.1:11434" },
    autoSync: true,
    autoMateri: false,         // opsional: susun ringkasan otomatis dari lampiran dosen (default manual)
    background: true,          // jalan di system tray + menyala saat Windows dinyalakan
    pengingat: { materi: true, tenggat: true, kelas: true, komentar: true },
    theme: "auto",             // auto | light | dark
    ujianOtomatis: true        // ringkas otomatis materi yang belum ada saat ujian tinggal 14 hari // notifikasi materi baru, alarm tenggat, pengingat vicon/kuliah
  },
  lms: { connected: false, me: null, lastSync: null, lastError: null },
  semesters: {},               // periode -> { label, mulai, courses: {id: course}, materi: {"cid_meet": materi} }
  current: null,               // periode aktif
  progress: {},                // "<periode>_<cid>_p<n>" -> { belajar, komentar, tugas, kuis }
  chats: {},                   // "m:<cid>_<n>" | "c:<cid>" | "umum" -> [{ role, text, at }]
  latihan: {},                 // id -> { cid, from, to, soal:{pg,essay}, jawaban, hasil }
  ujian: {},                   // "<periode>_<cid>_<uts|uas>" -> { teks, dibuat }
  saran: {},                   // periode -> { teks, dibuat }
  todos: {}                    // id -> { text, course, due, time, done, source, link, note, createdAt }
};

class Store {
  constructor(dir){
    this.file = path.join(dir, "ruang-kuliah-data.json");
    this.data = JSON.parse(JSON.stringify(DEFAULT));
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, "utf8"));
      this.data = Object.assign({}, this.data, raw);
      this.data.settings = Object.assign({}, DEFAULT.settings, raw.settings || {});
      const ra = (raw.settings || {}).ai || {};
      const a = this.data.settings.ai = Object.assign({}, DEFAULT.settings.ai, ra);
      a.keys = Object.assign({}, DEFAULT.settings.ai.keys, ra.keys || {});
      a.model = Object.assign({}, DEFAULT.settings.ai.model, ra.model || {});
      if (ra.geminiKey && !a.keys.gemini) a.keys.gemini = ra.geminiKey;     // migrasi versi lama
      if (!ra.autoMigrated){ if (!ra.provider || ra.provider === "gemini") a.provider = "auto"; a.autoMigrated = true; } // mode otomatis jadi utama
      if (!ra.serverMigrated){ if (!ra.provider || ra.provider === "auto" || ra.provider === "gemini") a.provider = "server"; a.serverMigrated = true; } // v1.0.9: AI Teman Kuliah jadi utama, key milik pengguna jadi cadangan
      if (ra.geminiModel && !a.model.gemini) a.model.gemini = ra.geminiModel;
      if (ra.ollamaModel && !a.model.ollama) a.model.ollama = ra.ollamaModel;
      delete a.geminiKey; delete a.geminiModel; delete a.ollamaModel;
      this.data.settings.pengingat = Object.assign({}, DEFAULT.settings.pengingat, (raw.settings || {}).pengingat || {});
      this.data.lms = Object.assign({}, DEFAULT.lms, raw.lms || {});
      if (!raw.abaikanReset1013){ this.data.lampiranAbaikan = []; this.data.abaikanReset1013 = true; } // 1.0.13: daftar lama terlalu luas (menyembunyikan semua file di pertemuan)
      if (!raw.settings || raw.settings.welcomed === undefined) this.data.settings.welcomed = !!this.data.lms.connected;
      if (!raw.settings || raw.settings.setupDone === undefined){ const a = this.data.settings.ai; this.data.settings.setupDone = !!this.data.lms.connected && !!(a.model && a.model[a.provider]); } // pengguna lama yang sudah siap langsung ke Beranda // pengguna versi lama tidak perlu lihat sambutan lagi
    } catch (e) {
      // File rusak: simpan cadangannya dulu supaya data lama tidak tertimpa
      if (fs.existsSync(this.file)) { try { fs.copyFileSync(this.file, this.file + ".rusak-" + Date.now()); } catch (x) {} }
    }
    this._t = null;
  }
  save(){
    clearTimeout(this._t);
    this._t = setTimeout(() => this.flush(), 150);
  }
  flush(){
    clearTimeout(this._t);
    const tmp = this.file + ".tmp";
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const txt = JSON.stringify(this.data);
    try { fs.writeFileSync(tmp, txt); fs.renameSync(tmp, this.file); }
    catch (e) {
      // Windows kadang mengunci file sesaat (antivirus/indeks): tulis langsung sebagai cadangan
      try { fs.writeFileSync(this.file, txt); } catch (x) { console.error("Gagal menyimpan data:", x.message); }
    }
  }
  sem(periode = this.data.current){
    if (!periode) return null;
    if (!this.data.semesters[periode]) this.data.semesters[periode] = { label: periodeLabel(periode), mulai: null, courses: {}, materi: {} };
    return this.data.semesters[periode];
  }
  // Untuk renderer: data tanpa API key mentah
  publicState(){
    const d = JSON.parse(JSON.stringify(this.data));
    const a = d.settings.ai; a.hasKey = {};
    for (const k of Object.keys(a.keys || {})){ a.hasKey[k] = !!a.keys[k]; a.keys[k] = a.keys[k] ? "••••" + a.keys[k].slice(-4) : ""; }
    return d;
  }
}

function periodeLabel(p){
  const m = String(p).match(/^(\d{4})(\d)$/);
  if (!m) return String(p);
  const y = Number(m[1]);
  return (m[2] === "1" ? "Ganjil " : m[2] === "2" ? "Genap " : "Pendek ") + y + "/" + (y + 1);
}

module.exports = { Store, periodeLabel };
