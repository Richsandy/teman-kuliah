// Desktop: menjalankan viscore.js di jendela tersembunyi (punya canvas, pdf.js, dan pemutar video Chromium).
// Versi HP ada di mobile-src/visr.js dengan fungsi yang sama.
const { app, BrowserWindow } = require("electron");
const fs = require("fs");
const path = require("path");
const { pathToFileURL } = require("url");

let win = null, ready = null, idle = null, busy = 0;
function dirSiap(){
  const dir = path.join(app.getPath("temp"), "teman-kuliah-gambar");
  fs.mkdirSync(dir, { recursive: true });
  const pdfDir = path.dirname(require.resolve("pdf-parse/lib/pdf.js/v1.10.100/build/pdf.js"));
  // Disalin keluar dari app.asar supaya pasti bisa dimuat sebagai file biasa
  for (const [from, to] of [[path.join(pdfDir, "pdf.js"), "pdf.js"], [path.join(pdfDir, "pdf.worker.js"), "pdf.worker.js"], [path.join(__dirname, "viscore.js"), "viscore.js"]]){
    const dst = path.join(dir, to);
    try { const a = fs.statSync(from), b = fs.existsSync(dst) && fs.statSync(dst); if (!b || b.size !== a.size) fs.writeFileSync(dst, fs.readFileSync(from)); } catch (e) { fs.writeFileSync(dst, fs.readFileSync(from)); }
  }
  const html = path.join(dir, "vis.html");
  fs.writeFileSync(html, `<!doctype html><meta charset="utf-8"><body><script src="pdf.js"></script><script>PDFJS.workerSrc = "pdf.worker.js"; PDFJS.disableWorker = true;</script><script src="viscore.js"></script><script>TKVis.setPdf(PDFJS);</script></body>`);
  return html;
}
function buka(){
  if (win && !win.isDestroyed() && ready) return ready;
  win = new BrowserWindow({ show: false, width: 1000, height: 800, webPreferences: { webSecurity: false, nodeIntegration: false, contextIsolation: true, backgroundThrottling: false, offscreen: false } });
  win.webContents.setAudioMuted(true);
  win.on("closed", () => { win = null; ready = null; });
  ready = win.loadFile(dirSiap()).then(() => win, e => { ready = null; try { win.destroy(); } catch (x) {} throw e; });
  return ready;
}
function tutupNanti(){ clearTimeout(idle); idle = setTimeout(() => { if (!busy && win && !win.isDestroyed()) win.destroy(); }, 60000); }
async function call(fn, arg){
  busy++;
  try {
    const w = await buka();
    return await w.webContents.executeJavaScript(`TKVis.${fn}(${JSON.stringify(arg)})`, true);
  } finally { busy--; tutupNanti(); }
}
const fileUrl = p => pathToFileURL(p).href;

module.exports = {
  pdf: (file, opts) => call("pdf", { ...(opts || {}), url: fileUrl(file) }),
  frames: (file, opts) => call("frames", { ...(opts || {}), url: fileUrl(file) }),
  image: (buf, mime) => call("image", `data:${mime};base64,${Buffer.from(buf).toString("base64")}`),
  close(paksa){ if (busy && !paksa) return; clearTimeout(idle); if (win && !win.isDestroyed()) win.destroy(); }
};
