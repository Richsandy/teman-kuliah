// Alamat server AI Teman Kuliah (Cloudflare Worker milik pembuat aplikasi).
// Ganti dengan alamat Worker setelah dipasang, misalnya https://teman-kuliah-ai.namakamu.workers.dev
// Selama masih berisi GANTI, aplikasi memakai API key yang diisi pengguna sendiri.
module.exports = { SERVER: "https://teman-kuliah-ai.nickpram1.workers.dev" };
