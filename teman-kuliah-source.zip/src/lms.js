// Koneksi ke LMS kampus berbasis Edlink (misalnya kuliah.unsia.ac.id atau edlink.id).
// Login lewat halaman resmi di jendela aplikasi; aplikasi tidak pernah melihat password.
// Sinkron dijalankan di dalam halaman LMS (jendela tersembunyi) memakai sesi login pengguna sendiri.
const { BrowserWindow } = require("electron");

function normBase(u){
  let s = String(u || "").trim(); if (!s) throw new Error("Isi alamat web LMS dulu, misalnya kuliah.unsia.ac.id.");
  if (!/^https?:\/\//i.test(s)) s = "https://" + s;
  const url = new URL(s); return "https://" + url.host;
}
const PARTITION = "persist:lms";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";

const WHO = `(function(){ try{ var a = window.$nuxt && $nuxt.$store && $nuxt.$store.state.auth; return a && a.id ? JSON.stringify({ id: a.id, name: a.name }) : null; }catch(e){ return null; } })()`;

function makeWin(opts, allowPopups){
  const wp = { partition: PARTITION, contextIsolation: true, nodeIntegration: false, sandbox: true };
  const w = new BrowserWindow(Object.assign({ webPreferences: wp }, opts));
  w.webContents.setUserAgent(UA);
  // Jendela login (misalnya "Masuk dengan Google") dibuka di sesi yang sama supaya hasil loginnya terbawa ke LMS.
  w.webContents.setWindowOpenHandler(({ url }) => {
    if (!allowPopups || !/^https:\/\//i.test(url)) return { action: "deny" };
    return { action: "allow", overrideBrowserWindowOptions: { parent: w, width: 520, height: 700, autoHideMenuBar: true, title: "Masuk", webPreferences: wp } };
  });
  return w;
}

function login(parent, baseUrl){
  const LMS = normBase(baseUrl), host = new URL(LMS).host;
  return new Promise((resolve, reject) => {
    const w = makeWin({ parent, modal: !!parent, width: 1100, height: 820, title: "Masuk ke LMS", autoHideMenuBar: true, show: true }, true);
    let done = false;
    const timer = setInterval(async () => {
      if (w.isDestroyed()) return;
      try {
        const r = await w.webContents.executeJavaScript(WHO);
        const u = w.webContents.getURL();
        if (r && u.includes(host) && !/\/(login|auth|sso|register)/i.test(u)){ done = true; clearInterval(timer); w.close(); resolve(JSON.parse(r)); }
      } catch (e) { /* halaman masih memuat */ }
    }, 1500);
    w.on("closed", () => { clearInterval(timer); if (!done) reject(new Error("Login dibatalkan.")); });
    w.loadURL(LMS + "/");
  });
}

async function logout(){
  const { session } = require("electron");
  await session.fromPartition(PARTITION).clearStorageData();
}

const SYNC = `(async function(){
  const ax = $nuxt.$axios, B = "https://api.edlink.id/api/v1.4/", me = $nuxt.$store.state.auth;
  const ytId = u => { const m = String(u || "").match(/(?:youtu\\.be\\/|[?&]v=|shorts\\/|embed\\/|live\\/)([A-Za-z0-9_-]{11})/); return m ? m[1] : (/^[A-Za-z0-9_-]{11}$/.test(String(u || "")) ? String(u) : null); };
  const acc = me.activeAccount || me.active_pt || {};
  const nim = String(acc.username || acc.userUniversityId || "").trim();
  const norm = x => String(x || "").toLowerCase().replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\\s+/g, " ").trim();
  const myName = norm(me.name);
  // Komentar/jawaban dianggap milikmu kalau akunnya kamu, atau isinya menyebut NIM atau nama lengkapmu (misalnya ditulis lewat akun lain atau format "Nama - NIM").
  const isMine = x => x.userId === me.id || (x.user && x.user.id === me.id) || (x.universityUser && acc.id && x.universityUser.id === acc.id)
    || (nim.length >= 6 && norm(x.content || x.contentTaggables).includes(nim))
    || (myName.split(" ").length >= 2 && norm(x.content || x.contentTaggables).includes(myName));
  const g = (await ax.post(B + "group/academic-lists", {})).data.data;
  const list = Array.isArray(g) ? g : (g.data || []);
  const dp = JSON.stringify({ criterion: [], page: { current: 1, limit: 400 }, sort: [{ criteria: "id", order: "DESC" }] });
  // Tanda "sudah dikerjakan" dari LMS. Bentuk datanya beda-beda per jenis tugas, jadi dicek beberapa nama field yang umum.
  const DONE = /submit|finish|done|complet|grad|selesai|kumpul/i;
  const sig = (o, d) => {
    if (!o || typeof o !== "object" || d > 2) return false;
    for (const [k, v] of Object.entries(o)){
      if (v === null || v === undefined || v === "") continue;
      if (/^(submittedAt|submitted_at|lastFinishedTest|answeredAt|collectedAt|doneAt|completedAt)$/i.test(k)) return true;
      if (/^(isSubmitted|hasSubmitted|isAnsweredAll|isAnswered|submitted|isDone|isFinished|isCollected|isCompleted)$/i.test(k) && v === true) return true;
      if (/(taken|submission|answer|task|work|member|progress)Status$/i.test(k) && typeof v === "string" && DONE.test(v)) return true;
      if (typeof v === "object" && /quiz|exam|survey|question|task|submission|assignment|answer|member|work/i.test(k) && sig(v, d + 1)) return true;
    }
    return false;
  };
  const doneOf = p => { const o = { quiz: p.quiz, exam: p.exam, survey: p.survey, teacherQuestion: p.teacherQuestion }; Object.keys(p).filter(k => /task|submission|assignment|answer/i.test(k)).forEach(k => o[k] = p[k]); return sig(o, 0); };
  // Student Engagement Score (SES): aktivitas per pertemuan yang langsung tercatat (komentar, materi dibuka, video ditonton),
  // plus status presensi resmi (H/I/S/A) yang baru terisi setelah dosen menutup sesi.
  const sesDp = encodeURIComponent(JSON.stringify({ page: { current: 1, limit: 50 }, criterion: [{ criteria: "keyword", operator: "LK", value: "" }], sort: [{ criteria: "started_at", order: "asc", no_table: true }] }));
  const num = v => v === null || v === undefined || v === "" || isNaN(Number(v)) ? null : Math.round(Number(v));
  // Kelompok: bentuk datanya belum pasti sama di semua kampus, jadi nama anggota dicari di beberapa field yang umum.
  const arr = v => Array.isArray(v) ? v : (v && Array.isArray(v.data) ? v.data : []);
  const pName = m => !m || typeof m !== "object" ? "" : (m.name || (m.user && m.user.name) || (m.universityUser && (m.universityUser.name || (m.universityUser.user && m.universityUser.user.name))) || (m.student && m.student.name) || pName(m.member) || pName(m.groupMember) || "");
  const memList = t => { for (const k of Object.keys(t || {})){ if (/member|anggota|user|student|participant/i.test(k) && Array.isArray(t[k]) && t[k].length && typeof t[k][0] === "object") return t[k]; } return []; };
  // Edlink membagi daftar post per halaman (bawaan cuma 10). Semua halaman dibaca, kalau tidak kuis/tugas/materi yang lebih lama hilang.
  const allPosts = async id => {
    const seen = new Map();
    for (let cur = 1; cur <= 20; cur++){
      let d;
      try { d = (await ax.post(B + "post/group/" + id + "?comment=true", { dataProvider: JSON.stringify({ criterion: [], page: { current: cur, limit: 50 }, sort: [{ criteria: "id", order: "DESC" }] }) })).data.data; }
      catch (e) { if (cur === 1) throw e; break; }
      const arr = (d && d.data) || []; let baru = 0;
      arr.forEach(p => { if (!seen.has(p.id)){ seen.set(p.id, p); baru++; } });
      if (!arr.length || !baru) break;
    }
    return [...seen.values()];
  };
  const courses = await Promise.all(list.map(async c => {
    const isMeMember = m => !!m && typeof m === "object" && (m.userId === me.id || (m.user && m.user.id === me.id) || (acc.id && (m.universityUserId === acc.id || (m.universityUser && m.universityUser.id === acc.id))) || (c.memberId && m.groupMemberId === c.memberId) || isMeMember(m.member) || isMeMember(m.groupMember) || (myName.split(" ").length >= 2 && norm(pName(m)) === myName));
    const [secs, posts, ses, pres, teams] = await Promise.all([
      ax.post(B + "sections/all/" + c.id, {}).then(r => r.data.data || []).catch(() => []),
      allPosts(c.id).catch(() => []),
      ax.get(B + "group/" + c.id + "/ses-by-sections?dataProvider=" + sesDp + "&clear_cache=false").then(r => r.data.data || null).catch(() => null),
      c.memberId ? ax.post(B + "group/member-presence-data", { group_member_id: c.memberId, group_id: c.id }).then(r => r.data.data || null).catch(() => null) : null,
      c.accessGroupTeam === false ? null : ax.post(B + "group-teams", { dataProvider: JSON.stringify({ criterion: [], page: { count: 0, current: 1, limit: 100, next: 1, previous: 1, total: 0 } }), group_id: c.id }).then(r => r.data.data || null).catch(() => null)
    ]);
    const hadir = {};
    ((pres && pres.sections) || []).forEach(s => { if (s && s.meet) hadir[s.meet] = { st: s.presence_status || null, prog: s.progress || null }; });
    ((ses && ses.result) || []).forEach(x => {
      if (!x || !x.meet) return;
      const h = hadir[x.meet] || (hadir[x.meet] = { st: null, prog: x.progress || null });
      if (!h.prog) h.prog = x.progress || null;
      h.ses = { skor: num(x.score), hadir: num(x.presence), interaksi: num(x.interaction), komentar: num(x.feedbackCommentsPercentage), nKomentar: Number(x.feedbackTotalComments) || 0,
        lihat: num(x.viewPostsPercentage), unduh: num(x.downloadedPostsPercentage), video: num(x.videoProgressPercentage), tugas: num(x.assignmentsPercentage), posts: Number(x.totalPosts) || 0 };
    });
    const tims = arr(teams).map(t => { const ms = memList(t); return { id: String(t.id || ""), nama: String(t.name || t.title || t.teamName || ("Kelompok " + (t.id || ""))), anggota: ms.map(m => ({ nama: String(pName(m)), me: isMeMember(m) })).filter(m => m.nama), me: ms.some(isMeMember) || t.isMember === true || t.isMyTeam === true }; });
    const mine = {};
    await Promise.all(posts.filter(p => p.userId !== me.id && String(p.commentStatus) !== "0").map(async p => {
      try { const r = (await ax.post(B + "comment/post/" + p.id, { dataProvider: dp })).data.data; mine[p.id] = (r.data || []).some(isMine); }
      catch (e) { mine[p.id] = "?"; }
    }));
    return {
      id: String(c.id), name: c.name, kelas: c.className, periode: String(c.periode || ""), meets: Number(c.sectionsCount) || 16,
      sections: secs.map(s => ({ id: s.id, meet: s.meet, start: s.startedAt, end: s.endedAt })),
      hadir, sesUpd: (ses && ses.lastUpdatedAt) || null, rekap: (pres && pres.presenceReport) || null, sesOk: !!(ses || pres), tims, timsOk: teams !== null,
      posts: posts.map(p => ({
        id: p.id, sec: p.classScheduleId, meet: p.section ? p.section.meet : null, type: p.type, title: p.title,
        author: p.user ? p.user.name : "", fromMe: p.userId === me.id, created: p.createdAt,
        text: String(p.cleanDescription || p.excerpt || "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").slice(0, 600),
        // Instruksi lengkap untuk post tugas (dipakai fitur Pandu Tugas)
        desc: (p.quiz || p.exam || !["M", "V", "I"].includes(p.type)) ? String(p.description || p.cleanDescription || "").replace(/<\\/(p|div|li|h\\d)>|<br\\s*\\/?>/gi, "\\n").replace(/<li[^>]*>/gi, "- ").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/[ \\t]+/g, " ").replace(/\\n\\s*\\n\\s*\\n+/g, "\\n\\n").trim().slice(0, 12000) : "",
        quiz: p.quiz ? { title: p.quiz.title, start: p.quiz.startedAt, end: p.quiz.finishedAt, status: p.quiz.takenStatus || null } : null,
        exam: !!p.exam, done: doneOf(p), commented: p.id in mine ? mine[p.id] : null,
        team: !!(p.teamType || p.groupTeamId || p.differentTaskForEachTeam),
        files: (p.medias || []).filter(m => m.type === "document" || /\\.(pdf|pptx|docx)$/i.test(m.name || "")).map(m => ({ id: m.id, name: m.name, ext: String(m.extension || "").toLowerCase(), size: Number(m.size) || 0, link: (m.file && m.file.link) || m.link || "" })).filter(f => f.link),
        // Video dari dosen: YouTube biasanya tersimpan sebagai lampiran bertipe "youtube", kadang juga link di deskripsi
        youtube: [...new Set([...((p.youtube && p.youtube.ids) || []), ...((p.youtube && p.youtube.urls) || []).map(ytId),
          ...(p.medias || []).filter(m => m.type === "youtube" || /youtu\\.?be/i.test(m.link || "")).map(m => ytId(m.link || (m.file && m.file.link))),
          ...(String(p.description || "").match(/https?:\\/\\/(?:www\\.)?(?:youtube\\.com|youtu\\.be)\\/[^\\s"'<>]+/gi) || []).map(ytId)].filter(Boolean))].slice(0, 6),
        lain: (p.medias || []).filter(m => !["document", "youtube", "video"].includes(m.type) && !/^(mp4|mov|webm|mkv|m4v)$/i.test(m.extension || "")).map(m => ({ id: m.id, name: m.name || m.title || m.type || "Lampiran", type: String(m.type || ""), ext: String(m.extension || "").toLowerCase(), link: (m.file && m.file.link) || m.link || "" })).slice(0, 10),
        ytNames: Object.fromEntries((p.medias || []).filter(m => m.type === "youtube").map(m => [ytId(m.link || ""), m.name || ""]).filter(x => x[0])),
        videos: (p.medias || []).filter(m => m.type === "video" || /^(mp4|mov|webm|mkv|m4v)$/i.test(m.extension || "")).map(m => ({ id: m.id, name: m.name || "Video", ext: String(m.extension || "mp4").toLowerCase(), size: Number(m.size) || 0, link: (m.file && m.file.link) || m.link || "" })).filter(v => v.link)
      }))
    };
  }));
  const uni = acc.universityName || (me.university && (me.university.name || me.university.shortName)) || "";
  return JSON.stringify({ me: { id: me.id, name: me.name, kampus: uni, nim }, courses });
})()`;

function sync(baseUrl){
  const LMS = normBase(baseUrl);
  return new Promise((resolve, reject) => {
    const w = makeWin({ show: false, width: 1200, height: 900 });
    let finished = false;
    const end = (fn, v) => { if (finished) return; finished = true; clearInterval(t); clearTimeout(to); if (!w.isDestroyed()) w.destroy(); fn(v); };
    const to = setTimeout(() => end(reject, new Error("LMS tidak merespons. Cek koneksi internet lalu coba lagi.")), 150000);
    let tries = 0, running = false;
    const host = new URL(LMS).host;
    // Halaman gagal dimuat (internet mati, DNS, LMS down): ini masalah jaringan, bukan sesi habis
    w.webContents.on("did-fail-load", (e, code, desc, url, isMain) => { if (isMain && code !== -3) end(reject, new Error("Tidak bisa membuka LMS (" + desc + "). Cek koneksi internet lalu coba lagi.")); });
    const t = setInterval(async () => {
      if (w.isDestroyed() || running) return;
      tries++;
      try {
        const url = w.webContents.getURL();
        if (/\/(login|auth|sso)/i.test(url)){ const e = new Error("Sesi LMS habis. Masuk lagi ke LMS."); e.code = "login"; return end(reject, e); }
        const st = await w.webContents.executeJavaScript(`(function(){ var n = window.$nuxt; return !n ? "nonuxt" : (n.$axios && n.$store && n.$store.state.auth && n.$store.state.auth.id) ? "ready" : n.$store ? "noauth" : "loading"; })()`);
        if (st === "noauth" && tries > 8 && url.includes(host)){ const e = new Error("Sesi LMS habis. Masuk lagi ke LMS."); e.code = "login"; return end(reject, e); }
        if (st !== "ready"){ if (tries > 40) end(reject, new Error("LMS terlalu lama dimuat. Coba lagi sebentar lagi.")); return; }
        clearInterval(t); running = true;
        let raw;
        try { raw = await w.webContents.executeJavaScript(SYNC, false); }
        catch (e) {
          const m = String(e && e.message || e);
          if (/401|unauth/i.test(m)){ const x = new Error("Sesi LMS habis. Masuk lagi ke LMS."); x.code = "login"; return end(reject, x); }
          return end(reject, new Error("Gagal membaca data LMS: " + m.slice(0, 200)));
        }
        const data = JSON.parse(raw);
        if (!data.courses || !data.courses.length) return end(reject, new Error("LMS tidak mengirim daftar kelas. Coba sinkron lagi sebentar lagi."));
        data.base = LMS; end(resolve, data);
      } catch (e) { if (tries > 40) end(reject, new Error("Gagal membaca LMS: " + e.message)); }
    }, 1500);
    w.loadURL(LMS + "/classes");
  });
}

module.exports = { login, logout, sync, normBase };
