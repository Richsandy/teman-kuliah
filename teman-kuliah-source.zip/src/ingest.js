// Drag & drop materi: menebak matkul + pertemuan, membaca file, lalu meminta AI membentuk materi.
const fs = require("fs");
const path = require("path");
const { extract, kindOf, youtubeId, youtubeTranscript } = require("./extract");
const ai = require("./ai");

const STOP = new Set(["dan", "dari", "the", "of", "untuk", "pengantar", "dasar", "mku", "mkdu", "sesi", "pertemuan", "materi"]);
const tokens = s => String(s).toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, " ").split(" ").filter(w => w.length >= 2 && !STOP.has(w));

function walk(p, out = [], depth = 0){
  let st; try { st = fs.statSync(p); } catch (e) { return out; }
  if (st.isDirectory()){ if (depth > 6) return out; for (const n of fs.readdirSync(p)) if (!n.startsWith("~$") && !n.startsWith(".")) walk(path.join(p, n), out, depth + 1); }
  else if (kindOf(p) !== "unknown") out.push(p);
  return out;
}

function guessCourse(p, courses){
  const segs = p.split(/[\\/]/).reverse();
  let best = null, bestScore = 0;
  for (const c of courses){
    const ct = new Set(tokens(c.nama));
    if (!ct.size) continue;
    for (const seg of segs){
      const st = tokens(seg); if (!st.length) continue;
      const hit = st.filter(w => ct.has(w)).length;
      const score = hit / ct.size + (hit && hit === st.length ? 0.25 : 0);
      if (score > bestScore){ bestScore = score; best = c; }
    }
  }
  return bestScore >= 0.5 ? best : null;
}

function guessMeet(p){
  const segs = p.split(/[\\/]/);
  const file = segs.pop();
  for (let i = segs.length - 1; i >= Math.max(0, segs.length - 3); i--){ if (/^\d{1,2}$/.test(segs[i].trim())){ const n = +segs[i]; if (n >= 1 && n <= 16) return n; } }
  const m = file.match(/(?:sesi|pertemuan|session|materi|minggu|week|ppt|modul|p)[\s_.-]*0?(\d{1,2})(?!\d)/i) || file.match(/^@?\s*0?(\d{1,2})\b/);
  if (m){ const n = +m[1]; if (n >= 1 && n <= 16) return n; }
  return null;
}

// items: [{path}|{url}|{text}] -> groups: [{courseId, meet, items:[{type, path|url|text, name}]}], skipped: [...]
function plan(items, courses, fallbackMeet){
  const groups = new Map(), skipped = [];
  const add = (cid, meet, it) => { const k = (cid || "?") + "_" + (meet || "?"); if (!groups.has(k)) groups.set(k, { courseId: cid, meet, items: [] }); groups.get(k).items.push(it); };
  for (const it of items){
    if (it.path){
      for (const f of walk(it.path)){
        const name = path.basename(f);
        if (/\b(rps|kontrak)\b/i.test(name)){ skipped.push({ name, reason: "RPS/kontrak kuliah, bukan materi pertemuan" }); continue; }
        if (/^sertifikat|whatsapp image/i.test(name)){ skipped.push({ name, reason: "bukan file materi" }); continue; }
        const c = guessCourse(f, courses);
        add(c ? c.id : null, guessMeet(f) || (c ? null : null), { type: "file", path: f, name });
      }
    } else if (it.url && youtubeId(it.url)){
      add(null, fallbackMeet, { type: "youtube", url: it.url, name: "Video YouTube" });
    } else if (it.text && it.text.trim()){
      add(null, fallbackMeet, { type: "text", text: it.text.trim(), name: "Catatan / ringkasan video" });
    }
  }
  return { groups: [...groups.values()], skipped };
}

async function readSources(items, provider, progress, keys = {}, cfg = {}){
  const out = [], warnings = [], nonMateri = [];
  for (const it of items){
    if (it.type === "file"){
      if (!fs.existsSync(it.path)){ warnings.push(`${it.name}: file tidak ditemukan`); continue; }
      progress && progress(`Membaca ${it.name}`);
      const r = await extract(it.path);
      if (r.warning && !r.text && !r.inline){ warnings.push(`${r.name}: ${r.warning}`); continue; }
      if (provider === "ollama"){ delete r.inline; delete r.images; if (!r.text){ warnings.push(`${r.name}: tidak ada teks (slide bergambar butuh Gemini, ChatGPT, atau Claude)`); continue; } }
      // RPS atau kontrak kuliah: bukan materi pertemuan, tidak diringkas
      const head = String(r.text || "").slice(0, 4000);
      if (!it.paksa && /rencana pembelajaran semester|kontrak (perkuliahan|kuliah)|\bsilabus\b/i.test(head) && /(capaian pembelajaran|\bcpmk\b|\bcpl\b|bobot penilaian|komponen penilaian|metode pembelajaran)/i.test(head)){ nonMateri.push(it.name || r.name); warnings.push(`${r.name}: dilewati karena berisi RPS atau kontrak kuliah, bukan materi`); continue; }
      const db = Object.entries(r.dibuang || {});
      if (db.length) warnings.push(`${r.name}: ${db.map(([k, n]) => n + " halaman " + k).join(", ")} dilewati karena bukan isi materi.`);
      out.push(r);
    } else if (it.type === "youtube"){
      const yt = "https://www.youtube.com/watch?v=" + youtubeId(it.url);
      if (provider === "gemini"){ out.push({ name: "Video YouTube " + it.url, youtube: yt }); continue; }
      // AI pilihan tidak bisa menonton: kalau ada API key Gemini, Gemini menonton dan menulis catatannya dulu
      let gemErr = null;
      if (keys.gemini){
        progress && progress(`Gemini menonton ${it.name || "video YouTube"}`);
        try { const cv = await ai.catatanVideo(cfg, { name: it.name || "Video YouTube", youtube: yt });
          if (!cv.lengkap) warnings.push(`${it.name || "Video YouTube"}: catatan dari Gemini mungkin belum sampai akhir video. Coba Ringkas ulang nanti.`);
          out.push({ name: "Catatan video " + (it.name || "YouTube") + " (ditonton Gemini)", text: cv.text + (cv.lengkap ? "" : "\n\n(Catatan video ini belum sampai akhir video.)") }); continue; }
        catch (e) { gemErr = e; }
      }
      progress && progress("Mengambil transkrip YouTube");
      const t = await youtubeTranscript(it.url).catch(() => "");
      if (!t){ warnings.push(gemErr ? `Video YouTube: Gemini gagal menontonnya (${gemErr.message}) dan transkripnya tidak tersedia.` : "Video YouTube: transkrip tidak tersedia. Isi API key Gemini supaya videonya bisa ditonton, atau tempel ringkasan videonya sebagai teks."); continue; }
      out.push({ name: "Transkrip video YouTube", text: t });
    } else if (it.type === "video"){
      if (provider !== "gemini" || !it.path){
        // AI pilihan tidak bisa menonton video: kalau ada API key Gemini, Gemini menonton dan menulis catatannya dulu
        let gemErr = null;
        if (keys.gemini && it.path && fs.existsSync(it.path)){
          progress && progress(`Gemini menonton ${it.name}`);
          const ext = path.extname(it.path).slice(1).toLowerCase();
          try { const cv = await ai.catatanVideo(cfg, { name: it.name, video: { path: it.path, mime: ext === "mov" ? "video/quicktime" : ext === "webm" ? "video/webm" : ext === "mkv" ? "video/x-matroska" : "video/mp4" } });
            if (!cv.lengkap) warnings.push(`${it.name}: catatan dari Gemini mungkin belum sampai akhir video. Coba Ringkas ulang nanti.`);
            out.push({ name: "Catatan video " + it.name + " (ditonton Gemini)", text: cv.text + (cv.lengkap ? "" : "\n\n(Catatan video ini belum sampai akhir video.)") }); continue; }
          catch (e) { gemErr = e; if (!keys.groq && !(ai.serverOn(cfg) && (cfg.provider === "server" || provider === "server"))){ warnings.push(`${it.name}: Gemini gagal menonton video ini (${e.message}).`); continue; } }
        }
        // Tanpa Gemini: ditranskrip dulu dengan Whisper (Groq, gratis)
        const viaServer = !keys.groq && ai.serverOn(cfg) && (cfg.provider === "server" || provider === "server");
        if (!keys.groq && !viaServer){ warnings.push(`${it.name}: isi API key Gemini supaya videonya bisa ditonton, atau API key Groq supaya videonya ditranskrip Whisper`); continue; }
        progress && progress(`Mentranskrip ${it.name} dengan Whisper`);
        try { const t = await ai.whisper(viaServer ? "" : keys.groq, it.url ? { url: it.url, name: it.name } : { file: it.path, name: it.name }, cfg); out.push({ name: "Transkrip video " + it.name, text: t }); }
        catch (e) { warnings.push(`${it.name}: ${e.message}`); }
        continue;
      }
      if (!it.path || !fs.existsSync(it.path)){ warnings.push(`${it.name}: file video tidak ditemukan`); continue; }
      const ext = path.extname(it.path).slice(1).toLowerCase();
      out.push({ name: it.name, video: { path: it.path, mime: ext === "mov" ? "video/quicktime" : ext === "webm" ? "video/webm" : ext === "mkv" ? "video/x-matroska" : "video/mp4" } });
    } else if (it.type === "text"){
      out.push({ name: it.name || "Catatan", text: it.text });
    }
  }
  return { sources: out, warnings, nonMateri };
}

async function run(store, group, opts, progress){
  const sem = store.sem();
  const course = sem.courses[group.courseId];
  if (!course) throw new Error("Pilih mata kuliah dulu.");
  if (!group.meet) throw new Error("Pilih nomor pertemuan dulu.");
  const key = `${group.courseId}_${group.meet}`;
  const prev = sem.materi[key];
  let items = group.items;
  if (prev && opts.merge){
    const known = new Set(items.map(i => i.path || i.url || i.text));
    items = (prev.sources || []).filter(s => !known.has(s.path || s.url || s.text)).concat(items);
  }
  const cfg = store.data.settings.ai;
  const nama0 = p => ({ server: "AI Teman Kuliah", "server-direct": "AI Teman Kuliah", gemini: "Gemini", openai: "ChatGPT", anthropic: "Claude", ollama: "Ollama", cerebras: "Cerebras", groq: "Groq", auto: "AI" })[p] || "AI";
  const hasVideo = items.some(i => i.type === "video" || i.type === "youtube");
  // Rencana: mode otomatis memilih urutan AI sesuai isi; mode manual memakai AI pilihan lalu cadangan
  const own = ai.autoList(cfg, hasVideo ? "video" : "materi");
  // Mode AI Teman Kuliah: materi disusun dengan key Gemini milik pengguna; server jadi cadangan
  const plan = cfg.provider === "server" ? [...own, ...(ai.serverOn(cfg) ? [{ provider: "server-direct", model: "auto" }] : [])]
    : cfg.provider === "auto" ? own
    : [{ provider: cfg.provider, model: (cfg.model || {})[cfg.provider] }, ...[ai.backupFor(cfg, "materi")].filter(Boolean)];
  if (!plan.length) throw new Error("AI belum siap. Buka Pengaturan, bagian AI.");
  const info = { course: course.nama, meet: group.meet, dosen: course.dosen, kampus: (store.data.settings.kampus || {}).nama || "" };
  const t0 = Date.now(); let st = { phase: "wait", chars: 0 }, nama = nama0(plan[0].provider);
  const mmss = () => { const d = Math.round((Date.now() - t0) / 1000); return Math.floor(d / 60) + ":" + String(d % 60).padStart(2, "0"); };
  const say = () => progress && progress(st.phase === "retry" ? `Server ${nama} penuh, dicoba lagi dalam ${Math.max(0, Math.round((st.until - Date.now()) / 1000))} detik (putaran ${st.round} dari ${st.of})` : st.phase === "upload" ? `Mengunggah video ke ${nama} (${mmss()})` : st.phase === "switch" ? `Server ${nama} sibuk, mencoba model ${st.model} (${mmss()})` : st.phase === "write"
    ? `${nama} sedang menulis ${st.penutup ? "ringkasan dan kuis" : "materi" + bg()}, ${st.chars.toLocaleString("id-ID")} karakter (${mmss()})`
    : `${nama} sedang membaca ${st.penutup ? "hasil semua bagian" : "materi" + bg()} (${mmss()})`);
  const bg = () => st.bn > 1 ? ` bagian ${st.bk} dari ${st.bn}` : "";
  let m, used = null, sources = [], warnings = [], nonMateri = [], lastErr = null, tick = null;
  try {
    for (let i = 0; i < plan.length; i++){
      const L = plan[i]; nama = nama0(L.provider);
      if (i > 0){ st = { phase: "wait", chars: 0 }; progress && progress(`${nama0(plan[i - 1].provider)} penuh, pindah ke ${nama}`); }
      if (L.provider === "server-direct") nama = nama0("server");
      const re = await readSources(items, L.provider === "server-direct" ? "server" : L.provider, progress, cfg.keys || {}, cfg);
      re.warnings.forEach(w => { if (!warnings.includes(w)) warnings.push(w); }); nonMateri = re.nonMateri;
      if (!re.sources.length){ if (i === plan.length - 1 && !lastErr) break; continue; }
      if (!tick){ say(); tick = setInterval(say, 1000); }
      try {
        m = await ai.makeMateri({ ...cfg, provider: L.provider, model: { ...(cfg.model || {}), [L.provider]: L.model }, quick: i < plan.length - 1 }, info, re.sources, x => { st = x; });
        used = L.provider === "server-direct" ? "server" : L.provider; sources = re.sources;
        if (i > 0 && L.provider === "server-direct") warnings.push("Gemini milikmu sedang penuh atau jatahnya habis, jadi materi ini disusun AI Teman Kuliah.");
        else if (i > 0) warnings.push(plan[0].provider === "server-direct" ? (lastErr && lastErr.quota ? "Jatah harian AI Teman Kuliah sudah habis, jadi materi ini disusun dengan API key milikmu." : "AI Teman Kuliah sedang penuh, jadi materi ini disusun dengan API key milikmu.") : `${nama0(plan[0].provider)} sedang penuh, jadi materi ini disusun ${nama}.`);
        break;
      } catch (e) { lastErr = e; if (!ai.canSwitch(e) || i === plan.length - 1) throw e; }
    }
  } finally { if (tick) clearInterval(tick); }
  if (!m){
    if (lastErr) throw lastErr;
    const e = new Error(nonMateri.length ? "File ini berisi RPS atau kontrak kuliah, bukan materi pertemuan, jadi tidak diringkas." : (warnings[0] || "Tidak ada isi yang bisa dibaca."));
    if (nonMateri.length){ e.code = "nonmateri"; e.nonMateri = nonMateri; } throw e;
  }
  if (m.terpotong) warnings.push(m.perBagian ? "Sebagian kecil jawaban AI terpotong walau materinya sudah dikerjakan per bagian. Cek isinya, atau Ringkas ulang." : "Materinya sangat panjang sehingga jawaban AI terpotong di bagian akhir. Cek bagian terakhir, atau ringkas ulang dengan file yang dibagi dua.");
  if (m.dilewati) warnings.push(`Materinya sangat panjang: ${m.perBagian} bagian pertama sudah diringkas, ${m.dilewati} bagian terakhir belum. Pisahkan file sisanya lalu tambahkan sebagai materi pertemuan ini.`);
  delete m.perBagian; delete m.dilewati;
  sem.materi[key] = { ...m, sumber: sources.map(s => s.name.replace(/^Video YouTube .*/, "Video YouTube")), sources: items, provider: used, dibuat: new Date().toISOString() };
  store.save();
  return { key, warnings };
}

module.exports = { plan, run, guessCourse, guessMeet };
