// Membaca isi file materi secara lokal (tanpa cloud).
const fs = require("fs");
const path = require("path");
const JSZip = require("jszip");

const KIND = {
  ".pdf": "pdf", ".pptx": "pptx", ".docx": "docx", ".txt": "text", ".md": "text",
  ".png": "image", ".jpg": "image", ".jpeg": "image", ".webp": "image",
  ".ppt": "legacy", ".doc": "legacy",
  ".mp4": "video", ".mov": "video", ".mkv": "video", ".mp3": "audio", ".m4a": "audio", ".wav": "audio"
};
const MIME = { ".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp" };

function kindOf(p){ return KIND[path.extname(p).toLowerCase()] || "unknown"; }
function mimeOf(p){ return MIME[path.extname(p).toLowerCase()] || "application/octet-stream"; }

const decode = s => s.replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,"&");

async function pptxText(file){
  const zip = await JSZip.loadAsync(fs.readFileSync(file));
  const slides = Object.keys(zip.files).filter(n => /^ppt\/slides\/slide\d+\.xml$/.test(n))
    .sort((a,b) => Number(a.match(/(\d+)\.xml$/)[1]) - Number(b.match(/(\d+)\.xml$/)[1]));
  const out = [];
  for (const [i, n] of slides.entries()){
    const xml = await zip.file(n).async("string");
    const paras = xml.split(/<\/a:p>/).map(p => decode((p.match(/<a:t>([\s\S]*?)<\/a:t>/g) || []).map(t => t.replace(/<\/?a:t>/g,"")).join(""))).map(s => s.trim()).filter(Boolean);
    const notesName = n.replace("slides/slide", "notesSlides/notesSlide");
    let notes = "";
    if (zip.file(notesName)){
      const nx = await zip.file(notesName).async("string");
      notes = decode((nx.match(/<a:t>([\s\S]*?)<\/a:t>/g) || []).map(t => t.replace(/<\/?a:t>/g,"")).join(" ")).trim();
    }
    if (paras.length || notes) out.push(`[Slide ${i+1}]\n` + paras.join("\n") + (notes && !/^\d+$/.test(notes) ? `\n(Catatan: ${notes})` : ""));
  }
  return out.join("\n\n");
}

// Gambar di dalam slide (banyak dosen menaruh isi materi sebagai gambar). Dipakai oleh Gemini.
async function pptxImages(file, maxCount = 14, maxTotal = 12 * 1024 * 1024){
  const zip = await JSZip.loadAsync(fs.readFileSync(file));
  const media = Object.keys(zip.files).filter(n => /^ppt\/media\/.+\.(png|jpe?g)$/i.test(n));
  const items = [];
  for (const n of media){ const buf = await zip.file(n).async("nodebuffer"); if (buf.length > 25 * 1024 && buf.length < 4 * 1024 * 1024) items.push({ n, buf }); }
  items.sort((a,b) => b.buf.length - a.buf.length);
  const out = []; let total = 0;
  for (const it of items){ if (out.length >= maxCount || total + it.buf.length > maxTotal) continue; total += it.buf.length; out.push({ mime: /\.png$/i.test(it.n) ? "image/png" : "image/jpeg", base64: it.buf.toString("base64") }); }
  return out;
}

async function docxText(file){
  const mammoth = require("mammoth");
  const r = await mammoth.extractRawText({ path: file });
  return r.value.replace(/\n{3,}/g, "\n\n").trim();
}

async function pdfText(file){
  const pdf = require("pdf-parse/lib/pdf-parse.js");
  const r = await pdf(fs.readFileSync(file));
  return r.text.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}

// Hasil: { name, kind, text, inline?: {mime, base64}, warning? }
async function extract(file){
  const name = path.basename(file), kind = kindOf(file);
  const size = fs.statSync(file).size;
  try {
    if (kind === "pptx") return { name, kind, text: await pptxText(file), images: await pptxImages(file).catch(() => []) };
    if (kind === "docx") return { name, kind, text: await docxText(file) };
    if (kind === "text") return { name, kind, text: fs.readFileSync(file, "utf8") };
    if (kind === "pdf"){
      const text = await pdfText(file).catch(() => "");
      // Gemini bisa membaca PDF langsung (termasuk gambar di slide) kalau ukurannya < 15 MB
      const inline = size < 15 * 1024 * 1024 ? { mime: "application/pdf", base64: fs.readFileSync(file).toString("base64") } : null;
      return { name, kind, text, inline, warning: !text && !inline ? "PDF ini tidak punya teks yang bisa dibaca dan terlalu besar untuk dikirim utuh." : undefined };
    }
    if (kind === "image"){
      if (size > 15 * 1024 * 1024) return { name, kind, text: "", warning: "Gambar terlalu besar (maks. 15 MB)." };
      return { name, kind, text: "", inline: { mime: mimeOf(file), base64: fs.readFileSync(file).toString("base64") } };
    }
    if (kind === "legacy") return { name, kind, text: "", warning: "Format lama (.ppt/.doc) belum bisa dibaca. Buka di PowerPoint/Word lalu simpan sebagai .pptx/.docx atau PDF." };
    if (kind === "video" || kind === "audio") return { name, kind, text: "", warning: "File video/audio belum didukung. Tempel link YouTube-nya atau tulis ringkasan videonya sebagai teks." };
    return { name, kind, text: "", warning: "Jenis file ini belum didukung." };
  } catch (e) {
    return { name, kind, text: "", warning: "Gagal membaca file: " + e.message };
  }
}

const YT = /(?:youtube\.com\/(?:watch\?v=|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/;
function youtubeId(s){ const m = String(s).match(YT); return m ? m[1] : null; }

// Ambil transkrip YouTube (untuk Ollama; Gemini bisa membaca link YouTube langsung).
async function youtubeTranscript(url){
  const id = youtubeId(url); if (!id) return "";
  const page = await fetch(`https://www.youtube.com/watch?v=${id}&hl=id`, { headers: { "Accept-Language": "id,en;q=0.8" }, signal: AbortSignal.timeout(20000) }).then(r => r.text());
  const m = page.match(/"captionTracks":(\[.*?\])/);
  if (!m) return "";
  const tracks = JSON.parse(m[1]);
  const pick = tracks.find(t => /^id/.test(t.languageCode)) || tracks.find(t => /^en/.test(t.languageCode)) || tracks[0];
  if (!pick) return "";
  const xml = await fetch(pick.baseUrl, { signal: AbortSignal.timeout(20000) }).then(r => r.text());
  return decode((xml.match(/<text[^>]*>([\s\S]*?)<\/text>/g) || []).map(t => t.replace(/<[^>]+>/g, "")).join(" ")).replace(/\s+/g, " ").trim();
}

module.exports = { extract, kindOf, youtubeId, youtubeTranscript };
