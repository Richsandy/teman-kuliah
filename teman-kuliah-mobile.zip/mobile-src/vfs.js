// Pengganti modul "fs" Node untuk HP.
// Semua file hidup di memori supaya kode desktop (yang memakai readFileSync/writeFileSync) tetap jalan apa adanya.
// File di bawah DATA_DIR yang bukan sementara (data JSON utama) ikut disimpan permanen ke penyimpanan aplikasi
// lewat Capacitor Filesystem, dan dimuat lagi ke memori sebelum aplikasi mulai.
const { Buffer } = require("buffer");
const native = require("./capbridge");

const DATA_DIR = "/data";
const files = new Map();   // path -> { data: Uint8Array, mtime }
const dirs = new Set(["/", DATA_DIR, "/tmp"]);
const pending = new Map(); // path -> konten terakhir yang menunggu disimpan
let flushing = null;

const norm = p => { const s = String(p).replace(/\\/g, "/").replace(/\/+/g, "/"); return s.length > 1 ? s.replace(/\/$/, "") : s; };
const parent = p => { const i = p.lastIndexOf("/"); return i <= 0 ? "/" : p.slice(0, i); };
const persistable = p => p.startsWith(DATA_DIR + "/") && /\.json$/.test(p) && !/\/(lampiran|picked)\//.test(p);
const toU8 = (d, enc) => {
  if (typeof d === "string") return new Uint8Array(Buffer.from(d, enc === "base64" ? "base64" : "utf8"));
  if (d instanceof Uint8Array) return new Uint8Array(d.buffer, d.byteOffset, d.byteLength);
  if (d instanceof ArrayBuffer) return new Uint8Array(d);
  return new Uint8Array(Buffer.from(String(d)));
};
const enoent = (p, op) => { const e = new Error(`ENOENT: no such file or directory, ${op} '${p}'`); e.code = "ENOENT"; return e; };

function mkdirp(p){ p = norm(p); const parts = p.split("/").filter(Boolean); let cur = ""; for (const x of parts){ cur += "/" + x; dirs.add(cur); } }
function stat(p){
  p = norm(p);
  const f = files.get(p);
  if (f) return { size: f.data.byteLength, mtime: new Date(f.mtime), mtimeMs: f.mtime, isDirectory: () => false, isFile: () => true };
  if (dirs.has(p)) return { size: 0, mtime: new Date(0), mtimeMs: 0, isDirectory: () => true, isFile: () => false };
  throw enoent(p, "stat");
}
function persist(p){
  if (!persistable(p)) return;
  pending.set(p, files.has(p) ? files.get(p).data : null);
  schedule();
}
let timer = null;
function schedule(){ clearTimeout(timer); timer = setTimeout(() => flush().catch(e => console.error("Gagal menyimpan:", e)), 400); }
async function flush(){
  clearTimeout(timer);
  if (flushing) { await flushing; if (!pending.size) return; }
  flushing = (async () => {
    while (pending.size){
      const [p, data] = pending.entries().next().value; pending.delete(p);
      if (data === null) await native.fsDelete(p).catch(() => {});
      else await native.fsWrite(p, Buffer.from(data).toString("utf8"));
    }
  })();
  try { await flushing; } finally { flushing = null; }
}

const fs = {
  existsSync: p => { p = norm(p); return files.has(p) || dirs.has(p); },
  statSync: stat,
  lstatSync: stat,
  readFileSync(p, opt){
    p = norm(p); const f = files.get(p); if (!f) throw enoent(p, "open");
    const enc = typeof opt === "string" ? opt : opt && opt.encoding;
    const b = Buffer.from(f.data.buffer, f.data.byteOffset, f.data.byteLength);
    return enc ? b.toString(enc) : b;
  },
  writeFileSync(p, d, opt){
    p = norm(p); mkdirp(parent(p));
    const enc = typeof opt === "string" ? opt : opt && opt.encoding;
    files.set(p, { data: toU8(d, enc), mtime: Date.now() }); persist(p);
  },
  appendFileSync(p, d){ const old = files.has(norm(p)) ? fs.readFileSync(p) : Buffer.alloc(0); fs.writeFileSync(p, Buffer.concat([old, Buffer.from(toU8(d))])); },
  renameSync(a, b){ a = norm(a); b = norm(b); const f = files.get(a); if (!f) throw enoent(a, "rename"); files.delete(a); mkdirp(parent(b)); files.set(b, f); persist(a); persist(b); },
  copyFileSync(a, b){ const f = files.get(norm(a)); if (!f) throw enoent(a, "copyfile"); fs.writeFileSync(b, new Uint8Array(f.data)); },
  unlinkSync(p){ p = norm(p); if (!files.delete(p)) throw enoent(p, "unlink"); persist(p); },
  rmSync(p){ p = norm(p); for (const k of [...files.keys()]) if (k === p || k.startsWith(p + "/")){ files.delete(k); persist(k); } for (const d of [...dirs]) if (d === p || d.startsWith(p + "/")) dirs.delete(d); },
  mkdirSync(p){ mkdirp(p); },
  readdirSync(p){
    p = norm(p); if (!dirs.has(p)) throw enoent(p, "scandir");
    const pre = p === "/" ? "/" : p + "/", out = new Set();
    for (const k of [...files.keys(), ...dirs]) if (k.startsWith(pre) && k !== p){ const rest = k.slice(pre.length); if (rest) out.add(rest.split("/")[0]); }
    return [...out].sort();
  },
  cpSync(){},
  promises: {
    readFile: async (p, o) => fs.readFileSync(p, o),
    writeFile: async (p, d, o) => fs.writeFileSync(p, d, o),
    stat: async p => stat(p),
    unlink: async p => fs.unlinkSync(p)
  }
};

// Dipanggil sekali sebelum kode aplikasi jalan: muat data permanen ke memori.
async function init(){
  const list = await native.fsList().catch(() => []);
  for (const p of list){
    if (!persistable(p)) continue;
    const txt = await native.fsRead(p).catch(() => null);
    if (txt !== null){ mkdirp(parent(p)); files.set(p, { data: toU8(txt), mtime: Date.now() }); }
  }
}
// File pilihan pengguna (input file) dimasukkan ke memori supaya bisa dibaca kode desktop lewat path.
async function putFile(dir, file){
  const name = String(file.name || "file").replace(/[\\/]+/g, "_");
  const p = norm(dir + "/" + name);
  fs.writeFileSync(p, new Uint8Array(await file.arrayBuffer()));
  return p;
}

module.exports = Object.assign(fs, { __init: init, __flush: flush, __putFile: putFile, DATA_DIR });
