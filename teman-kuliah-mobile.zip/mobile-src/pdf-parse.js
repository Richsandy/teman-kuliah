// Pengganti pdf-parse (khusus Node) memakai pdf.js versi browser. Hasil sama: { text, numpages }.
const pdfjs = require("pdfjs-dist/legacy/build/pdf.js");
pdfjs.GlobalWorkerOptions.workerSrc = "pdf.worker.min.js";
module.exports = async function pdfParse(buf){
  const data = buf instanceof Uint8Array ? new Uint8Array(buf) : new Uint8Array(buf);
  const doc = await pdfjs.getDocument({ data, isEvalSupported: false, disableFontFace: true, useSystemFonts: false }).promise;
  const out = [];
  try {
    for (let i = 1; i <= doc.numPages; i++){
      const page = await doc.getPage(i);
      const tc = await page.getTextContent();
      let last = null, line = "";
      const lines = [];
      for (const it of tc.items){
        if (!("str" in it)) continue;
        const y = it.transform ? Math.round(it.transform[5]) : null;
        if (last !== null && y !== null && Math.abs(y - last) > 2){ lines.push(line); line = ""; }
        line += it.str; if (it.hasEOL){ lines.push(line); line = ""; }
        last = y;
      }
      if (line) lines.push(line);
      out.push(lines.join("\n"));
      page.cleanup();
    }
  } finally { doc.destroy(); }
  return { text: out.join("\n\n"), numpages: doc.numPages };
};
module.exports.pdfjs = pdfjs;
