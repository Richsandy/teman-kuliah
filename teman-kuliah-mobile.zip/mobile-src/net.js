// fetch untuk HP. Server AI (Gemini, Groq, Cerebras, OpenAI, Claude, server Teman Kuliah) mengizinkan akses
// dari aplikasi web, jadi dipakai fetch biasa (jawaban tetap mengalir sedikit demi sedikit).
// Tujuan lain (file lampiran dosen, YouTube) diambil lewat HTTP native Capacitor supaya tidak terhalang CORS.
const { Capacitor, CapacitorHttp } = require("@capacitor/core");
const { Buffer } = require("buffer");

const webFetch = globalThis.fetch.bind(globalThis);
const CORS_OK = /(^|\.)(googleapis\.com|groq\.com|cerebras\.ai|openai\.com|anthropic\.com|workers\.dev|github\.com|githubusercontent\.com)$/i;

function abortErr(){ const e = new Error("The operation was aborted."); e.name = "AbortError"; return e; }

async function nativeFetch(url, opts = {}){
  const headers = {};
  if (opts.headers) new Headers(opts.headers).forEach((v, k) => { headers[k] = v; });
  let data;
  if (opts.body != null){
    if (typeof opts.body === "string") data = opts.body;
    else return webFetch(url, opts); // FormData/Blob: hanya dipakai ke server AI
  }
  const req = CapacitorHttp.request({ url, method: (opts.method || "GET").toUpperCase(), headers, data, responseType: "arraybuffer", connectTimeout: 30000, readTimeout: 600000 });
  const sig = opts.signal;
  const r = await new Promise((resolve, reject) => {
    if (sig){ if (sig.aborted) return reject(abortErr()); sig.addEventListener("abort", () => reject(abortErr()), { once: true }); }
    req.then(resolve, e => { const x = new TypeError("Failed to fetch: " + (e && e.message || e)); reject(x); });
  });
  let bytes;
  if (typeof r.data === "string"){ try { bytes = Buffer.from(r.data, "base64"); } catch (e) { bytes = Buffer.from(r.data); } }
  else if (r.data && typeof r.data === "object") bytes = Buffer.from(JSON.stringify(r.data));
  else bytes = Buffer.alloc(0);
  const status = r.status >= 200 && r.status <= 599 ? r.status : 500;
  const h = new Headers(); Object.entries(r.headers || {}).forEach(([k, v]) => { try { h.set(k, String(v)); } catch (e) {} });
  const res = new Response([204, 205, 304].includes(status) ? null : bytes, { status, headers: h });
  Object.defineProperty(res, "url", { value: r.url || url });
  return res;
}

function install(){
  globalThis.fetch = async (input, opts = {}) => {
    const url = typeof input === "string" ? input : input.url;
    let host = ""; try { host = new URL(url, location.href).hostname; } catch (e) {}
    if (/anthropic\.com$/i.test(host)){ const h = new Headers(opts.headers || {}); h.set("anthropic-dangerous-direct-browser-access", "true"); opts = { ...opts, headers: h }; }
    if (!Capacitor.isNativePlatform() || CORS_OK.test(host) || !/^https?:/i.test(url) || host === location.hostname) return webFetch(input, opts);
    return nativeFetch(url, opts);
  };
  if (!AbortSignal.timeout) AbortSignal.timeout = ms => { const c = new AbortController(); setTimeout(() => { const e = new Error("signal timed out"); e.name = "TimeoutError"; c.abort(e); }, ms); return c.signal; };
}
module.exports = { install };
