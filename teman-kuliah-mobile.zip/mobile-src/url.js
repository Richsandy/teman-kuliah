module.exports = { pathToFileURL: p => ({ href: String(p) }), URL: globalThis.URL };
