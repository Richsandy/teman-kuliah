// Fitur yang caranya beda di HP: pengingat terjadwal, pilih file, panduan PDF.
const cap = require("./capbridge");
const fs = require("./vfs");

/* ---------- pengingat ----------
   Desktop memeriksa tiap menit selama aplikasi menyala. Di HP aplikasi bisa ditutup kapan saja,
   jadi semua pengingat yang akan datang langsung dijadwalkan ke sistem HP (aturan dan teksnya sama). */
const HARI = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const hm = s => { const m = String(s || "").match(/(\d{1,2})[.:](\d{2})/); return m ? [+m[1], +m[2]] : null; };
const at = (ymdStr, t) => { const [y, mo, d] = String(ymdStr).slice(0, 10).split("-").map(Number); if (!y) return null; return new Date(y, mo - 1, d, t ? t[0] : 23, t ? t[1] : 59); };
const ymd = d => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
const idOf = key => { let h = 5381; for (const c of key) h = ((h * 33) ^ c.charCodeAt(0)) >>> 0; return (h % 1900000000) + 1000; };

function reminderList(store, absensiMode){
  const out = [], now = Date.now(), done = store.data.reminded || {};
  const peng = store.data.settings.pengingat || {};
  const sem = store.sem(), courses = sem ? sem.courses : {};
  const nm = id => (courses[id] && courses[id].singkat) || "Teman Kuliah";
  const add = (key, when, title, body, urgent) => { if (done[key] || !when || when <= now) return; out.push({ key, id: idOf(key), at: +when, title, body, urgent: !!urgent }); };
  for (const [id, t] of Object.entries(store.data.todos || {})){
    if (t.done || !t.due) continue;
    const when = at(t.due, hm(t.time)); if (!when || when <= now) continue;
    if (/^Vicon:/i.test(t.text || "")){
      if (peng.kelas !== false && hm(t.time)) add(id + "_30m", +when - 30 * 60000, nm(t.course) + ": vicon 30 menit lagi", `${t.text.replace(/^Vicon:\s*/i, "")}, jam ${t.time}.`, true);
      continue;
    }
    if (peng.tenggat === false) continue;
    add(id + "_24h", +when - 24 * 3600000, "Tenggat besok", `${nm(t.course)}: ${t.text}. Tutup ${t.time ? "jam " + t.time : "besok"}.`, false);
    add(id + "_3h", +when - 3 * 3600000, "Tenggat 3 jam lagi", `${nm(t.course)}: ${t.text}. Tutup ${t.time ? "jam " + t.time : "hari ini"}.`, true);
  }
  if (sem){
    const g = Number(store.data.settings.geserHari) || 0;
    for (let k = 0; k < 8; k++){
      const d = new Date(); d.setDate(d.getDate() + k); const day = HARI[d.getDay()], dStr = ymd(d);
      const week = sem.mulai ? Math.floor((new Date(dStr + "T00:00:00") - new Date(sem.mulai + "T00:00:00")) / 864e5 / 7) + 1 : null;
      for (const c of Object.values(courses)){
        const i = HARI.indexOf(c.hariKRS); if (i < 0 || HARI[(i + g) % 7] !== day) continue;
        const t = hm(String(c.jam || "").split(/[-–]/)[0]);
        if (peng.kelas !== false && t) add(`kelas_${c.id}_${dStr}`, +at(dStr, t) - 15 * 60000, c.singkat + " mulai 15 menit lagi", `${c.nama}${c.dosen ? ", " + c.dosen : ""}.${absensiMode(store.data) === "komentar" ? " Jangan lupa komentar absensi." : ""}`, false);
        if (peng.komentar !== false && week && absensiMode(store.data) === "komentar"){
          const a = c.absen && c.absen[week]; if (!a || !a.belum || !a.belum.length) continue;
          const key = `komentar_${c.id}_${dStr}`, t19 = at(dStr, [19, 0]);
          const body = `${a.belum.length} post dosen pertemuan ${week} belum kamu komentari: ${a.belum.slice(0, 2).map(b => b.judul).join(", ")}${a.belum.length > 2 ? ", dan lainnya" : ""}.`;
          // Sudah lewat jam 19.00 hari ini dan masih belum: kabari sekarang (sekali), seperti versi desktop.
          if (k === 0 && +t19 <= now){ if (!done[key]){ (store.data.reminded || (store.data.reminded = {}))[key] = now; store.save(); cap.notifyNow(c.singkat + ": komentar absensi belum lengkap", body, false); } }
          else add(key, t19, c.singkat + ": komentar absensi belum lengkap", body, false);
        }
      }
    }
  }
  // Kartu hafalan: jam 19.30 setiap hari selama masih ada kartu yang perlu diulang (dihitung ulang setiap data berubah)
  if (peng.hafalan !== false){
    try {
      const B = require("__belajar__");
      for (let k = 0; k < 7; k++){
        const d = new Date(); d.setDate(d.getDate() + k); const dStr = ymd(d);
        const n = k === 0 ? B.jumlahHariIni(store.data) : (a => a.tempo.length + a.baru.length)(B.antrean(store.data, dStr));
        if (n <= 0) continue;
        const key = `hafalan_${dStr}`, t1930 = +at(dStr, [19, 30]), body = `${n} kartu menunggu hari ini, sekitar ${Math.max(2, Math.round(n * 0.25))} menit. Sedikit tiap hari bikin materi nempel sampai ujian.`;
        // Aplikasi baru dibuka setelah jam 19.30 dan masih ada kartu: kabari sekarang (sekali), seperti versi desktop
        if (k === 0 && t1930 <= now){ if (!done[key]){ (store.data.reminded || (store.data.reminded = {}))[key] = now; store.save(); cap.notifyNow("Waktunya kartu hafalan", body, false); } }
        else add(key, t1930, "Waktunya kartu hafalan", body, false);
      }
    } catch (e) { console.warn("Pengingat hafalan:", e); }
  }
  return out;
}
let planT = null, lastSig = "";
function planReminders(store, absensiMode){
  clearTimeout(planT);
  planT = setTimeout(() => {
    try {
      const list = reminderList(store, absensiMode);
      const sig = JSON.stringify(list.map(x => [x.id, x.at, x.body]));
      if (sig === lastSig) return; lastSig = sig;
      cap.planNotifs(list);
    } catch (e) { console.warn("Gagal menjadwalkan pengingat:", e); }
  }, 2500);
}

/* ---------- pilih file materi dari HP ---------- */
function pickFiles(){
  return new Promise(resolve => {
    const inp = document.createElement("input");
    inp.type = "file"; inp.multiple = true;
    inp.accept = ".pdf,.pptx,.docx,.txt,.md,.png,.jpg,.jpeg,application/pdf,image/*,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain";
    inp.style.display = "none";
    let settled = false;
    const finish = async () => {
      if (settled) return; settled = true;
      const dir = "/data/picked/" + Date.now().toString(36);
      const paths = [];
      for (const f of inp.files || []) paths.push(await fs.__putFile(dir, f));
      inp.remove(); resolve(paths);
    };
    inp.addEventListener("change", finish);
    inp.addEventListener("cancel", () => { settled = true; inp.remove(); resolve([]); });
    document.body.appendChild(inp); inp.click();
  });
}

/* ---------- panduan PDF di dalam aplikasi ---------- */
async function openGuide(){
  const { pdfjs } = require("./pdf-parse");
  let ov = document.getElementById("tk-guide");
  if (ov){ ov.hidden = false; return; }
  ov = document.createElement("div"); ov.id = "tk-guide"; ov.className = "tk-guide";
  ov.innerHTML = `<div class="tk-guide-bar"><b>Panduan Teman Kuliah</b><button class="btn sm" id="tk-guide-x">Tutup</button></div><div class="tk-guide-pages" id="tk-guide-pages"><p class="sub" style="padding:24px;text-align:center">Membuka panduan…</p></div>`;
  document.body.appendChild(ov);
  ov.querySelector("#tk-guide-x").onclick = () => { ov.hidden = true; };
  const box = ov.querySelector("#tk-guide-pages");
  const doc = await pdfjs.getDocument({ url: "Panduan Teman Kuliah.pdf", isEvalSupported: false }).promise;
  box.innerHTML = "";
  const w = Math.min(box.clientWidth || window.innerWidth, 900) - 16, dpr = Math.min(2, window.devicePixelRatio || 1);
  const io = new IntersectionObserver(es => es.forEach(async e => {
    if (!e.isIntersecting || e.target.dataset.done) return; e.target.dataset.done = 1;
    const page = await doc.getPage(+e.target.dataset.n), vp0 = page.getViewport({ scale: 1 }), vp = page.getViewport({ scale: w / vp0.width * dpr });
    const cv = document.createElement("canvas"); cv.width = vp.width; cv.height = vp.height; cv.style.width = "100%";
    await page.render({ canvasContext: cv.getContext("2d"), viewport: vp }).promise; e.target.replaceChildren(cv);
  }), { root: box, rootMargin: "800px 0px" });
  const p1 = (await doc.getPage(1)).getViewport({ scale: 1 });
  for (let n = 1; n <= doc.numPages; n++){ const d = document.createElement("div"); d.className = "tk-guide-page"; d.dataset.n = n; d.style.aspectRatio = p1.width + "/" + p1.height; box.appendChild(d); io.observe(d); }
}

module.exports = { planReminders, pickFiles, openGuide };
