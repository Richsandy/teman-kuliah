// Titik mulai versi HP: siapkan pengganti Node/Electron, muat data, lalu jalankan main.js desktop apa adanya.
const { Buffer } = require("buffer");
globalThis.Buffer = globalThis.Buffer || Buffer;
globalThis.global = globalThis;
globalThis.__dirname = "/src"; globalThis.__filename = "/src/main.js";
globalThis.process = Object.assign(globalThis.process || {}, { argv: [], env: {}, platform: "linux", versions: {}, resourcesPath: "/res", cwd: () => "/", nextTick: (f, ...a) => Promise.resolve().then(() => f(...a)) });

require("./net").install();
const electron = require("electron");
const { invoke, on, markReady } = electron.__bridge;
const fs = require("./vfs");
const cap = require("./capbridge");
const mobile = require("./mobile");

// window.api: dibaca otomatis dari preload.js desktop saat build (build.mjs), jadi fungsi baru di desktop ikut ke HP.
const P = require("__channels__"); // { invoke: {nama: channel}, events: {nama: channel} }
const api = {};
for (const [k, c] of Object.entries(P.invoke)) api[k] = (...a) => invoke(c, ...a);
for (const [k, c] of Object.entries(P.events)) api[k] = fn => on(c, fn);
// Yang caranya beda di HP:
Object.assign(api, {
  pickFiles: async () => { try { return { ok: true, paths: await mobile.pickFiles() }; } catch (e) { return { ok: false, error: e.message, paths: [] }; } },
  openGuide: async () => { try { await mobile.openGuide(); return { ok: true }; } catch (e) { return { ok: false, error: "Panduan gagal dibuka: " + e.message }; } },
  openGuideFile: async () => api.openGuide(),
  pathOf: () => "",
  platform: cap.platform()
});
window.api = api;

// Tautan https di tampilan dibuka di browser HP, bukan menggantikan aplikasi.
document.addEventListener("click", e => {
  const a = e.target.closest && e.target.closest("a[href]"); if (!a) return;
  const href = a.getAttribute("href"); if (!/^https?:\/\//i.test(href)) return;
  e.preventDefault(); cap.openUrl(href);
}, true);

async function start(){
  await fs.__init();
  require("__desktop_main__");           // main.js desktop: mendaftarkan semua fitur (ipcMain.handle) dan menyiapkan data
  await new Promise(r => setTimeout(r, 0));
  markReady();
  const store = () => globalThis.__tkStore;
  let lastAuto = Date.now();
  cap.App.addListener("pause", () => { try { store() && store().flush(); } catch (e) {} fs.__flush(); });
  let lastUpd = Date.now();
  cap.App.addListener("resume", () => {
    // Cek update lagi saat aplikasi dibuka kembali dari latar belakang (paling sering tiap 30 menit)
    if (Date.now() - lastUpd > 30 * 60000){ lastUpd = Date.now(); Promise.resolve(invoke("update:check")).catch(() => {}); }
    const s = store(); if (!s) return;
    if (s.data.lms.connected && s.data.settings.autoSync && Date.now() - lastAuto > 10 * 60000){ lastAuto = Date.now(); invoke("lms:sync"); }
  });
  cap.App.addListener("backButton", () => {
    const g = document.getElementById("tk-guide"); if (g && !g.hidden){ g.hidden = true; return; }
    const m = document.getElementById("modal");
    if (m && !m.hidden){ const x = m.querySelector('[data-modal="close"]'); if (x) x.click(); return; }
    const nav = window.__tkNav;
    if (nav && nav.view() !== "beranda"){ nav.go("beranda"); return; }
    cap.App.minimizeApp().catch(() => {});
  });
  if (cap.isNative()) setTimeout(() => cap.ensureNotif(), 4000);
}
start().catch(e => { console.error(e); document.body.insertAdjacentHTML("afterbegin", `<p style="padding:24px;color:#c00">Teman Kuliah gagal dimulai: ${String(e.message || e)}</p>`); });
