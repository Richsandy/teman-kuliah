// Versi HP dari src/visr.js desktop: viscore.js (pengolah gambar ringkasan) dijalankan langsung di WebView aplikasi.
const fs = require("./vfs");
const Vis = require("__viscore__");
let siap = false;
function init(){ if (!siap){ Vis.setPdf(require("./pdf-parse").pdfjs); siap = true; } }
const bytes = p => { const b = fs.readFileSync(p); return new Uint8Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength)); };
const MIME = { mp4: "video/mp4", m4v: "video/mp4", webm: "video/webm", mov: "video/quicktime", mkv: "video/x-matroska" };

module.exports = {
  async pdf(file, opts){ init(); return Vis.pdf({ ...(opts || {}), data: bytes(file) }); },
  async frames(file, opts){
    init();
    const ext = String(file).split(".").pop().toLowerCase();
    const url = URL.createObjectURL(new Blob([bytes(file)], { type: MIME[ext] || "video/mp4" }));
    try { return await Vis.frames({ ...(opts || {}), url }); } finally { URL.revokeObjectURL(url); }
  },
  async image(buf, mime){
    init();
    const b = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    const url = URL.createObjectURL(new Blob([b], { type: mime }));
    try { return await Vis.image(url); } finally { URL.revokeObjectURL(url); }
  },
  close(){}
};
