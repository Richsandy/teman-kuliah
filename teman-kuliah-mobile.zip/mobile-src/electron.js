// Pengganti modul "electron" untuk HP. Kode main.js desktop memakai ipcMain, BrowserWindow, Notification, dll.
// Di HP semuanya berjalan di satu WebView: ipcMain.handle mendaftarkan fungsi yang dipanggil langsung oleh window.api.
const cap = require("./capbridge");

const handlers = new Map();
const listeners = {};          // channel -> [fn] (event dari "main" ke tampilan)
let readyResolve; const ready = new Promise(r => readyResolve = r);
const clone = v => v === undefined ? v : JSON.parse(JSON.stringify(v));

const ipcMain = {
  handle(ch, fn){ handlers.set(ch, fn); },
  on(){}, removeHandler(ch){ handlers.delete(ch); }
};
async function invoke(ch, ...args){
  await ready;
  const fn = handlers.get(ch);
  if (!fn) return { ok: false, error: "Fitur ini belum tersedia di HP." };
  return clone(await fn({ sender: null }, ...clone(args)));
}
function emit(ch, payload){
  const p = clone(payload);
  setTimeout(() => (listeners[ch] || []).forEach(f => { try { f(p); } catch (e) { console.error(e); } }), 0);
}
function on(ch, fn){ (listeners[ch] = listeners[ch] || []).push(fn); }

// Jendela utama: tampilan aplikasi sudah ada di WebView ini, jadi BrowserWindow cukup tiruan.
class BrowserWindow {
  constructor(){ this._once = {}; this.webContents = { send: (ch, d) => emit(ch, d), once: (ev, fn) => { if (ev === "did-finish-load") ready.then(() => setTimeout(fn, 300)); }, on(){}, setWindowOpenHandler(){}, setUserAgent(){} }; }
  loadFile(){} loadURL(){} once(ev, fn){ if (ev === "ready-to-show") setTimeout(fn, 0); } on(){}
  show(){} hide(){} focus(){} restore(){} close(){} isMinimized(){ return false; } isDestroyed(){ return false; }
}

class Notification {
  static isSupported(){ return true; }
  constructor(o){ this.o = o || {}; }
  on(){ return this; }
  show(){ cap.notifyNow(this.o.title, this.o.body, this.o.urgency === "critical"); }
}

const nativeTheme = {
  _src: "system",
  get shouldUseDarkColors(){ return this._src === "dark" || (this._src === "system" && matchMedia("(prefers-color-scheme: dark)").matches); },
  get themeSource(){ return this._src; },
  set themeSource(v){
    this._src = v;
    const root = document.documentElement;
    if (v === "light" || v === "dark") root.dataset.theme = v; else delete root.dataset.theme;
    cap.setStatusBar(this.shouldUseDarkColors);
  }
};
matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => cap.setStatusBar(nativeTheme.shouldUseDarkColors));

const app = {
  isPackaged: true,
  getVersion: () => __APP_VERSION__,
  requestSingleInstanceLock: () => true,
  setAppUserModelId(){}, setLoginItemSettings(){}, quit(){},
  on(){},
  whenReady: () => Promise.resolve(),
  getPath: n => n === "temp" ? "/tmp" : n === "appData" ? "/appdata" : "/data"
};
const shell = { openExternal: url => cap.openUrl(url), openPath: async () => "" };
const dialog = { showOpenDialog: async () => ({ canceled: true, filePaths: [] }) };
class Tray { constructor(){} setToolTip(){} setContextMenu(){} on(){} destroy(){} }
const Menu = { buildFromTemplate: () => ({}) };
const nativeImage = { createFromPath: () => ({ resize: () => ({}) }) };
const session = { fromPartition: () => ({ clearStorageData: async () => {} }) };

module.exports = { app, BrowserWindow, ipcMain, shell, Notification, dialog, Tray, Menu, nativeImage, nativeTheme, session,
  __bridge: { invoke, on, markReady: () => readyResolve(), handlers } };
