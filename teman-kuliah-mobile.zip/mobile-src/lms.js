// Versi HP dari src/lms.js desktop. Cara kerjanya sama: login lewat halaman resmi Edlink, lalu skrip sinkron
// (SYNC, diambil utuh dari versi desktop) dijalankan di dalam halaman LMS memakai sesi login pengguna sendiri.
// Bedanya: di HP halamannya dibuka dengan InAppBrowser, bukan BrowserWindow Electron.
const desktop = require("__desktop_lms__"); // berisi normBase dan SYNC dari versi desktop
const { normBase, SYNC } = desktop;
const cap = require("./capbridge");

const WHO = `(function(){ var d = { href: location.href, host: location.host, path: location.pathname, nuxt: !!window.$nuxt, store: false, tok: /(^|;\\s*)token=/.test(document.cookie), me: null };
  try { var a = window.$nuxt && $nuxt.$store && $nuxt.$store.state.auth; d.store = !!(window.$nuxt && $nuxt.$store); if (a && a.id) d.me = { id: a.id, name: a.name }; } catch (e) {}
  return JSON.stringify(d); })()`;
// Di HP, Edlink menyelipkan halaman "Akses Edlink dengan Lebih Nyaman" (WebApp / Aplikasi Edlink / Tetap di Browser).
// WebApp (pwa.edlink.id) adalah aplikasi lain yang tidak bisa dibaca, jadi Teman Kuliah memilih "Tetap di Browser" otomatis.
const STAY = `(function(){ try { if (location.host === "pwa.edlink.id") return "pwa";
  var re = /^(tetap di browser|lanjutkan di browser|stay (in|on) browser)$/i, els = document.querySelectorAll("a,button,[role=button],div,span,p");
  var hit = null; for (var i = 0; i < els.length; i++){ var t = (els[i].innerText || "").trim(); if (t.length < 40 && re.test(t)) hit = els[i]; }
  if (hit){ hit.click(); return "klik"; } // elemen terdalam: kliknya ikut naik ke tombol/tautan pembungkusnya
} catch (e) {} return ""; })()`;
const STATE = `(function(){ var n = window.$nuxt; return JSON.stringify({ href: location.href, st: !n ? "nonuxt" : (n.$axios && n.$store && n.$store.state.auth && n.$store.state.auth.id) ? "ready" : n.$store ? "noauth" : "loading" }); })()`;

function iabApi(){
  return new Promise((resolve, reject) => {
    const ok = () => window.cordova && window.cordova.InAppBrowser;
    if (ok()) return resolve(window.cordova.InAppBrowser);
    if (window.__tkMockIAB) return resolve(window.__tkMockIAB); // untuk uji coba di browser
    const t = setTimeout(() => reject(new Error("Login LMS hanya bisa dari aplikasi Teman Kuliah di HP.")), 6000);
    document.addEventListener("deviceready", () => { clearTimeout(t); ok() ? resolve(window.cordova.InAppBrowser) : reject(new Error("Komponen browser LMS tidak tersedia.")); }, { once: true });
  });
}
const OPT_SHOW = () => cap.platform() === "ios"
  ? "location=no,toolbar=yes,toolbarposition=top,closebuttoncaption=Tutup,doneButtonCaption=Tutup,presentationstyle=fullscreen,hidenavigationbuttons=no,toolbarcolor=#15171C,toolbartranslucent=no,closebuttoncolor=#FFD60A,enableViewportScale=no,allowInlineMediaPlayback=yes"
  : "location=yes,zoom=no,hardwareback=yes,toolbarcolor=#15171C,closebuttoncaption=Tutup,closebuttoncolor=#FFD60A,navigationbuttoncolor=#FFFFFF,hidenavigationbuttons=no,hideurlbar=no,footer=no,useWideViewPort=no";
const OPT_HIDDEN = "hidden=yes,location=no,toolbar=no,zoom=no";

// Di Android, balasan executeScript bisa hilang kalau halaman sedang pindah alamat (misalnya edlink.id -> domain kampus).
// Karena itu setiap pembacaan diberi batas waktu, supaya pengecekan berikutnya tetap jalan.
const run = (ref, code, ms = 5000) => new Promise(res => { let fin = false; const t = setTimeout(() => { if (!fin){ fin = true; res(null); } }, ms); try { ref.executeScript({ code }, r => { if (fin) return; fin = true; clearTimeout(t); res(Array.isArray(r) ? r[0] : r); }); } catch (e) { fin = true; clearTimeout(t); res(null); } });
const diag = r => !r ? "halaman belum terbaca" : `halaman ${r.host || "?"}${r.path || ""}, Edlink ${r.nuxt ? "termuat" : "belum termuat"}, tanda login ${r.tok ? "ada" : "tidak ada"}, akun ${r.me ? "terbaca" : "belum terbaca"}`;
// Lewati halaman pilihan Edlink dan kembalikan dari pwa.edlink.id ke web Edlink biasa. true = halaman sedang dipindah.
async function lewatiPilihan(ref, LMS, st){
  const r = await run(ref, STAY, 3000);
  if (r === "pwa" && (st.pwa = (st.pwa || 0) + 1) <= 3){ run(ref, "location.replace(" + JSON.stringify(LMS + "/classes") + ")", 1500); return true; }
  return r === "klik";
}
const parse = s => { try { return typeof s === "string" ? JSON.parse(s) : s; } catch (e) { return null; } };

// Edlink sering pindah ke domain kampus setelah login (misalnya edlink.id -> kuliah.unsia.ac.id),
// jadi login dianggap selesai di alamat mana pun selama halaman Edlink sudah punya akun yang masuk.
// Dicek pada path saja (bukan query), supaya alamat seperti "/classes?from=login" tidak dikira halaman login.
const LOGIN_PAGE = /^\/(login|auth|sso|register|forgot)(\/|$)/i;

// Cek diam-diam apakah sesi Edlink di aplikasi ini sudah masuk (dipakai kalau jendela login ditutup sendiri).
async function checkSession(LMS){
  const IAB = await iabApi();
  return new Promise(resolve => {
    const ref = IAB.open(LMS + "/classes", "_blank", OPT_HIDDEN);
    let fin = false, tries = 0, busy = false; const pil = {};
    const end = v => { if (fin) return; fin = true; clearInterval(t); try { ref.close(); } catch (e) {} setTimeout(() => resolve(v), 900); };
    const t = setInterval(async () => {
      if (fin || busy) return; busy = true; tries++;
      try {
        if (await lewatiPilihan(ref, LMS, pil)) return;
        const r = parse(await run(ref, WHO, 4000)); if (r) checkSession.last = r;
        if (r && r.me && !LOGIN_PAGE.test(r.path || "")) return end(r.me);
        if ((r && LOGIN_PAGE.test(r.path || "") && tries > 4) || tries > 16) end(null);
      } finally { busy = false; }
    }, 1000);
    ref.addEventListener("loaderror", () => setTimeout(() => end(null), 3000));
  });
}

async function login(parent, baseUrl){
  const LMS = normBase(baseUrl);
  const IAB = await iabApi();
  return new Promise((resolve, reject) => {
    // Langsung ke halaman kelas: kalau belum masuk Edlink membuka halaman login, jadi halaman promosi edlink.id terlewati.
    const ref = IAB.open(LMS + "/classes", "_blank", OPT_SHOW());
    let done = false, busy = false, last = null; const pil = {};
    // Android hanya punya satu jendela browser: beri jeda setelah menutup, supaya jendela sinkron berikutnya tidak ikut menerima sinyal "ditutup".
    const ok = me => { if (done) return; done = true; clearInterval(timer); try { ref.close(); } catch (e) {} setTimeout(() => resolve(me), 900); };
    const check = async () => {
      if (done || busy) return; busy = true;
      try {
        if (await lewatiPilihan(ref, LMS, pil)) return;
        const r = parse(await run(ref, WHO, 4000)); if (r) last = r;
        if (r && r.me && !LOGIN_PAGE.test(r.path || "")) ok(r.me);
      } finally { busy = false; }
    };
    const timer = setInterval(check, 1000);
    ref.addEventListener("loadstop", () => setTimeout(check, 600));
    ref.addEventListener("exit", async () => {
      clearInterval(timer);
      if (done) return;
      // Pengguna menutup jendela sendiri: mungkin sudah login tapi belum sempat terdeteksi.
      checkSession.last = null;
      await new Promise(r => setTimeout(r, 400));
      const me = await checkSession(LMS).catch(() => null);
      if (done) return; done = true;
      if (me) return resolve(me);
      const seen = checkSession.last || last;
      // Kalau halaman Edlink sudah terbuka tapi akunnya tidak terbaca, tampilkan apa yang terbaca supaya mudah dicek.
      reject(new Error(seen && !LOGIN_PAGE.test(seen.path || "") && (seen.tok || seen.nuxt)
        ? "Login Edlink belum terbaca oleh Teman Kuliah (" + diag(seen) + "). Coba Masuk lagi, lalu tunggu sampai jendela tertutup sendiri."
        : seen ? "Login dibatalkan."
        : "Login dibatalkan. Catatan untuk pengecekan: halaman Edlink sama sekali tidak bisa dibaca oleh Teman Kuliah."));
    });
  });
}

async function logout(){
  const IAB = await iabApi().catch(() => null); if (!IAB) return;
  await new Promise(resolve => {
    const ref = IAB.open("https://edlink.id/", "_blank", OPT_HIDDEN + ",clearcache=yes,clearsessioncache=yes,cleardata=yes");
    let fin = false; const end = () => { if (fin) return; fin = true; try { ref.close(); } catch (e) {} resolve(); };
    ref.addEventListener("loadstop", async () => { await run(ref, "try{localStorage.clear();sessionStorage.clear();document.cookie.split(';').forEach(function(c){document.cookie=c.split('=')[0].trim()+'=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/'})}catch(e){};1"); end(); });
    ref.addEventListener("loaderror", end);
    setTimeout(end, 15000);
  });
}

// Balasan executeScript yang panjang tidak sampai di sebagian HP Android (batasnya tidak pasti), jadi teks besar
// diambil per potongan yang ukurannya mengecil sendiri kalau gagal. Isi window[nama] harus teks ASCII (hasil encodeURIComponent).
const UKURAN = [16000, 4000, 1000];
async function bacaBesar(ref, nama, len, st){
  const parts = []; let p = 0;
  while (p < len){
    const n = UKURAN[st.u || 0];
    const part = await run(ref, `window.${nama}.slice(${p}, ${p + n})`, 10000);
    if (typeof part === "string" && part.length === Math.min(n, len - p)){ parts.push(part); p += part.length; continue; }
    if ((st.u || 0) < UKURAN.length - 1){ st.u = (st.u || 0) + 1; continue; }
    if (!st.ulangi){ st.ulangi = true; continue; }
    const e = new Error(`Gagal mengambil data LMS (posisi ${p} dari ${len}). Coba sinkron lagi.`); e.potongan = true; throw e;
  }
  return parts.join("");
}

// Ambil header login yang dipakai Edlink sendiri (dibaca dari satu permintaan kecil di halaman LMS), plus data akun singkat.
const CRED = `(function(){ try { var n = window.$nuxt, ax = n.$axios, a = (n.$store && n.$store.state.auth) || {};
  window.__tkCred = { st: "run" }; window.__tkCredH = null;
  var datar = function(h){ var f = {}; var hh = h && h.toJSON ? h.toJSON() : h; var add = function(o){ if (!o || typeof o !== "object") return; Object.keys(o).forEach(function(k){ var v = o[k]; if (v != null && typeof v !== "object" && typeof v !== "function") f[k] = String(v); }); };
    if (hh){ add(hh.common); add(hh.post); add(hh); } return f; };
  ax.post("https://api.edlink.id/api/v1.4/group/academic-lists", {}, { transformRequest: [function(d, h){ try { window.__tkCredH = datar(h); } catch (e) {} try { h["Content-Type"] = "application/json;charset=UTF-8"; } catch (e) {} return JSON.stringify(d || {}); }] }).then(function(){
    var m = document.cookie.match(/(^|;\\s*)token=([^;]+)/);
    window.__tkCred = { st: "ok" };
    window.__tkCredOut = encodeURIComponent(JSON.stringify({ h: window.__tkCredH || datar(ax.defaults && ax.defaults.headers), tok: m ? decodeURIComponent(m[2]) : "",
      auth: { id: a.id, name: a.name, activeAccount: a.activeAccount || null, active_pt: a.active_pt || null, university: a.university || null } }));
    window.__tkCred.len = window.__tkCredOut.length;
  }, function(e){ window.__tkCred = { st: "err", code: e && e.response && e.response.status, msg: String((e && e.message) || e) }; });
} catch (e) { window.__tkCred = { st: "err", msg: String((e && e.message) || e) }; } return 1; })()`;

async function ambilKredensial(ref, st){
  await run(ref, CRED);
  for (let i = 0; i < 20; i++){
    await new Promise(r => setTimeout(r, 1000));
    const s = parse(await run(ref, `JSON.stringify(window.__tkCred || { st: "hilang" })`, 4000));
    if (!s || s.st === "run") continue;
    if (s.st === "hilang") return null;
    if (s.st === "err"){ if (s.code === 401) { const e = new Error("401"); e.code = 401; throw e; } return null; }
    if (s.st === "ok" && s.len) return parse(decodeURIComponent(await bacaBesar(ref, "__tkCredOut", s.len, st)));
  }
  return null;
}

// Sinkron langsung dari aplikasi: skrip sinkron desktop yang sama, tapi permintaannya lewat HTTP native (tanpa CORS).
async function syncNative(cred, LMS){
  const H = {};
  Object.entries(cred.h || {}).forEach(([k, v]) => { if (!/^(content-type|content-length|host|cookie|accept-encoding)$/i.test(k)) H[k] = v; });
  if (!Object.keys(H).some(k => /^authorization$/i.test(k))){
    if (!cred.tok) throw new Error("tanpa token");
    H.Authorization = /^bearer /i.test(cred.tok) ? cred.tok : "Bearer " + cred.tok;
  }
  H.Accept = H.Accept || "application/json, text/plain, */*"; H.Origin = LMS; H.Referer = LMS + "/";
  let aktif = 0; const antre = [];
  const slot = () => new Promise(r => { if (aktif < 6){ aktif++; r(); } else antre.push(r); });
  const lepas = () => { const n = antre.shift(); if (n) n(); else aktif--; };
  const req = async (method, url, body) => {
    await slot();
    try {
      const r = await fetch(url, { method, headers: body === undefined ? H : { ...H, "Content-Type": "application/json;charset=UTF-8" }, body: body === undefined ? undefined : JSON.stringify(body || {}), signal: AbortSignal.timeout(45000) });
      const t = await r.text(); let data; try { data = JSON.parse(t); } catch (e) { data = t; }
      if (!r.ok){ const e = new Error("Request failed with status code " + r.status); e.response = { status: r.status, data }; throw e; }
      return { data };
    } finally { lepas(); }
  };
  const $nuxt = { $axios: { get: u => req("GET", u), post: (u, b) => req("POST", u, b) }, $store: { state: { auth: cred.auth } } };
  const raw = await require("__sync_native__")($nuxt);
  return JSON.parse(raw);
}

async function sync(baseUrl){
  const LMS = normBase(baseUrl);
  const IAB = await iabApi();
  return new Promise((resolve, reject) => {
    const ref = IAB.open(LMS + "/classes", "_blank", OPT_HIDDEN);
    let finished = false, shown = false, tries = 0, running = false, busy = false, stabil = 0, alamat = "", ulang = 0, nativeDicoba = false, catatan = ""; const pil = {}, pot = {};
    const end = (fn, v) => { if (finished) return; finished = true; clearInterval(t); clearTimeout(to); try { ref.close(); } catch (e) {} fn(v); };
    const to = setTimeout(() => end(reject, new Error("LMS tidak merespons. Cek koneksi internet lalu coba lagi.")), 300000);
    ref.addEventListener("loaderror", e => { if (!running) end(reject, new Error("Tidak bisa membuka LMS (" + ((e && e.message) || "jaringan") + "). Cek koneksi internet lalu coba lagi.")); });
    const dibuka = Date.now();
    ref.addEventListener("exit", () => { if (Date.now() - dibuka < 3000) return; end(reject, new Error("Sinkron dibatalkan.")); });
    const loginErr = () => { const e = new Error("Sesi LMS habis. Masuk lagi ke LMS."); e.code = "login"; return e; };
    const selesai = data => {
      if (!data || !data.courses || !data.courses.length) return end(reject, new Error("LMS tidak mengirim daftar kelas. Coba sinkron lagi sebentar lagi."));
      data.base = LMS; end(resolve, data);
    };
    const t = setInterval(async () => {
      if (finished || running || busy) return;
      busy = true; tries++;
      try {
        if (await lewatiPilihan(ref, LMS, pil)) return;
        const s = parse(await run(ref, STATE, 4000)) || { st: "loading", href: "" };
        if (LOGIN_PAGE.test(String(s.href || "").replace(/^https?:\/\/[^/]+/, "").split("?")[0])) return end(reject, loginErr());
        if (s.st === "noauth" && tries > 8) return end(reject, loginErr());
        if (s.st !== "ready"){
          // Beberapa HP menunda halaman yang tersembunyi: tampilkan sebentar supaya tetap jalan.
          if (tries === 20 && !shown){ shown = true; try { ref.show(); } catch (e) {} }
          if (tries > 60) end(reject, new Error("LMS terlalu lama dimuat. Coba lagi sebentar lagi."));
          return;
        }
        // Tunggu halaman tenang dulu (alamat sama 2 kali berturut-turut): Edlink kadang masih pindah halaman sesaat setelah termuat,
        // dan pindah halaman menghapus proses yang sedang berjalan di dalamnya.
        if (s.href !== alamat){ alamat = s.href; stabil = 0; }
        if (++stabil < 2) return;
        running = true;

        // Cara utama: ambil header login dari halaman, lalu sinkron langsung dari aplikasi.
        if (!nativeDicoba){
          nativeDicoba = true;
          let cred = null;
          try { cred = await ambilKredensial(ref, pot); }
          catch (e) { if (e.code === 401) return end(reject, loginErr()); catatan = e.message; }
          if (finished) return;
          if (cred){
            try { return selesai(await syncNative(cred, LMS)); }
            catch (e) {
              if (finished) return;
              const code = e.response && e.response.status;
              if (code === 401) return end(reject, loginErr());
              catatan = (code ? "HTTP " + code : e.message) || "";
            }
          }
        }

        // Cadangan: jalankan sinkron di dalam halaman LMS seperti versi desktop, hasilnya diambil per potongan.
        await run(ref, `(function(){ window.__tkSync = { st: "run" }; try { (${SYNC}).then(function(r){ window.__tkSync = { st: "ok", data: r }; }, function(e){ window.__tkSync = { st: "err", msg: String((e && e.message) || e), code: e && e.response && e.response.status }; }); } catch (e) { window.__tkSync = { st: "err", msg: String(e && e.message || e) }; } return 1; })()`);
        let raw = null;
        for (let i = 0; i < 180 && !finished; i++){
          await new Promise(r => setTimeout(r, 1500));
          const st = parse(await run(ref, `(function(){ var j = window.__tkSync; if (!j) return JSON.stringify({ hilang: true });
            if (j.st === "ok" && j.data && !j.enc){ var d = String(j.data); try { j.enc = encodeURIComponent(d); } catch (e) { j.enc = encodeURIComponent(d.toWellFormed ? d.toWellFormed() : d.replace(/[\\ud800-\\udfff]/g, "?")); } }
            if (j.enc) window.__tkSyncEnc = j.enc;
            return JSON.stringify({ st: j.st, msg: j.msg, code: j.code, len: j.enc ? j.enc.length : 0 }); })()`));
          if (st && st.hilang){
            // Halaman LMS dimuat ulang di tengah sinkron: ulangi dari awal (maksimal 3 kali).
            if (++ulang > 3) return end(reject, new Error("Halaman LMS terus dimuat ulang saat sinkron. Coba sinkron lagi sebentar lagi."));
            running = false; stabil = 0; alamat = ""; return;
          }
          if (!st || st.st === "run") continue;
          if (st.st === "err"){
            if (st.code === 401 || /401|unauth/i.test(st.msg || "")) return end(reject, loginErr());
            return end(reject, new Error("Gagal membaca data LMS: " + String(st.msg || "").slice(0, 200)));
          }
          if (!st.len) return end(reject, new Error("LMS tidak mengirim data. Coba sinkron lagi sebentar lagi."));
          try { raw = decodeURIComponent(await bacaBesar(ref, "__tkSyncEnc", st.len, pot)); }
          catch (e) { return end(reject, new Error(e.potongan ? e.message + (catatan ? " (" + catatan + ")" : "") : "Data LMS yang diterima rusak. Coba sinkron lagi.")); }
          break;
        }
        if (finished) return;
        if (raw === null) return end(reject, new Error("LMS terlalu lama mengirim data. Coba lagi."));
        selesai(JSON.parse(raw));
      } catch (e) { if (!running && tries > 60) end(reject, new Error("Gagal membaca LMS: " + e.message)); else if (running) end(reject, new Error("Gagal membaca LMS: " + e.message)); }
      finally { busy = false; }
    }, 1500);
  });
}

module.exports = { login, logout, sync, normBase };
