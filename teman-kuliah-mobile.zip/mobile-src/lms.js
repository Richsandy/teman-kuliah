// Versi HP dari src/lms.js desktop. Cara kerjanya sama: login lewat halaman resmi Edlink, lalu skrip sinkron
// (SYNC, diambil utuh dari versi desktop) dijalankan di dalam halaman LMS memakai sesi login pengguna sendiri.
// Bedanya: di HP halamannya dibuka dengan InAppBrowser, bukan BrowserWindow Electron.
const desktop = require("__desktop_lms__"); // berisi normBase dan SYNC dari versi desktop
const { normBase, SYNC } = desktop;
const cap = require("./capbridge");

const WHO = `(function(){ try{ var a = window.$nuxt && $nuxt.$store && $nuxt.$store.state.auth; return JSON.stringify({ href: location.href, me: a && a.id ? { id: a.id, name: a.name } : null }); }catch(e){ return JSON.stringify({ href: location.href, me: null }); } })()`;
const STATE = `(function(){ var n = window.$nuxt; return JSON.stringify({ href: location.href, st: !n ? "nonuxt" : (n.$axios && n.$store && n.$store.state.auth && n.$store.state.auth.id) ? "ready" : n.$store ? "noauth" : "loading" }); })()`;

function iabApi(){
  return new Promise((resolve, reject) => {
    const ok = () => window.cordova && window.cordova.InAppBrowser;
    if (ok()) return resolve(window.cordova.InAppBrowser);
    if (window.__tkMockIAB) return resolve(window.__tkMockIAB); // untuk uji coba di browser
    const t = setTimeout(() => reject(new Error("Login LMS hanya bisa dari aplikasi Teman Kuliah di HP.")), 6000);
    document.addEventListener("deviceready", () => { clearTimeout(t); ok() ? resolve(window.cordova.InAppBrowser) : reject(new Error("Komponen browser LMS tidak tersedia.")); }, { once: true });
  });
}
const OPT_SHOW = () => cap.platform() === "ios"
  ? "location=no,toolbar=yes,toolbarposition=top,closebuttoncaption=Tutup,doneButtonCaption=Tutup,presentationstyle=fullscreen,hidenavigationbuttons=no,toolbarcolor=#15171C,toolbartranslucent=no,closebuttoncolor=#FFD60A,enableViewportScale=no,allowInlineMediaPlayback=yes"
  : "location=yes,zoom=no,hardwareback=yes,toolbarcolor=#15171C,closebuttoncaption=Tutup,closebuttoncolor=#FFD60A,navigationbuttoncolor=#FFFFFF,hidenavigationbuttons=no,hideurlbar=no,footer=no,useWideViewPort=yes";
const OPT_HIDDEN = "hidden=yes,location=no,toolbar=no,zoom=no";

const run = (ref, code) => new Promise(res => { try { ref.executeScript({ code }, r => res(Array.isArray(r) ? r[0] : r)); } catch (e) { res(null); } });
const parse = s => { try { return typeof s === "string" ? JSON.parse(s) : s; } catch (e) { return null; } };

// Edlink sering pindah ke domain kampus setelah login (misalnya edlink.id -> kuliah.unsia.ac.id),
// jadi login dianggap selesai di alamat mana pun selama halaman Edlink sudah punya akun yang masuk.
const LOGIN_PAGE = /\/(login|auth|sso|register|forgot)/i;

// Cek diam-diam apakah sesi Edlink di aplikasi ini sudah masuk (dipakai kalau jendela login ditutup sendiri).
async function checkSession(LMS){
  const IAB = await iabApi();
  return new Promise(resolve => {
    const ref = IAB.open(LMS + "/classes", "_blank", OPT_HIDDEN);
    let fin = false, tries = 0, busy = false;
    const end = v => { if (fin) return; fin = true; clearInterval(t); try { ref.close(); } catch (e) {} resolve(v); };
    const t = setInterval(async () => {
      if (fin || busy) return; busy = true; tries++;
      try {
        const r = parse(await run(ref, WHO));
        if (r && r.me && !LOGIN_PAGE.test(r.href || "")) return end(r.me);
        if ((r && LOGIN_PAGE.test(r.href || "") && tries > 4) || tries > 16) end(null);
      } finally { busy = false; }
    }, 1000);
    ref.addEventListener("loaderror", () => setTimeout(() => end(null), 3000));
  });
}

async function login(parent, baseUrl){
  const LMS = normBase(baseUrl);
  const IAB = await iabApi();
  return new Promise((resolve, reject) => {
    const ref = IAB.open(LMS + "/", "_blank", OPT_SHOW());
    let done = false, busy = false;
    const ok = me => { if (done) return; done = true; clearInterval(timer); try { ref.close(); } catch (e) {} resolve(me); };
    const check = async () => {
      if (done || busy) return; busy = true;
      try {
        const r = parse(await run(ref, WHO));
        if (r && r.me && !LOGIN_PAGE.test(r.href || "")) ok(r.me);
      } finally { busy = false; }
    };
    const timer = setInterval(check, 1000);
    ref.addEventListener("loadstop", () => setTimeout(check, 600));
    ref.addEventListener("exit", async () => {
      clearInterval(timer);
      if (done) return;
      // Pengguna menutup jendela sendiri: mungkin sudah login tapi belum sempat terdeteksi.
      const me = await checkSession(LMS).catch(() => null);
      if (done) return; done = true;
      me ? resolve(me) : reject(new Error("Login dibatalkan."));
    });
  });
}

async function logout(){
  const IAB = await iabApi().catch(() => null); if (!IAB) return;
  await new Promise(resolve => {
    const ref = IAB.open("https://edlink.id/", "_blank", OPT_HIDDEN + ",clearcache=yes,clearsessioncache=yes,cleardata=yes");
    let fin = false; const end = () => { if (fin) return; fin = true; try { ref.close(); } catch (e) {} resolve(); };
    ref.addEventListener("loadstop", async () => { await run(ref, "try{localStorage.clear();sessionStorage.clear();document.cookie.split(';').forEach(function(c){document.cookie=c.split('=')[0].trim()+'=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/'})}catch(e){};1"); end(); });
    ref.addEventListener("loaderror", end);
    setTimeout(end, 15000);
  });
}

async function sync(baseUrl){
  const LMS = normBase(baseUrl);
  const IAB = await iabApi();
  return new Promise((resolve, reject) => {
    const ref = IAB.open(LMS + "/classes", "_blank", OPT_HIDDEN);
    let finished = false, shown = false, tries = 0, running = false, busy = false;
    const end = (fn, v) => { if (finished) return; finished = true; clearInterval(t); clearTimeout(to); try { ref.close(); } catch (e) {} fn(v); };
    const to = setTimeout(() => end(reject, new Error("LMS tidak merespons. Cek koneksi internet lalu coba lagi.")), 180000);
    ref.addEventListener("loaderror", e => { if (!running) end(reject, new Error("Tidak bisa membuka LMS (" + ((e && e.message) || "jaringan") + "). Cek koneksi internet lalu coba lagi.")); });
    ref.addEventListener("exit", () => end(reject, new Error("Sinkron dibatalkan.")));
    const loginErr = () => { const e = new Error("Sesi LMS habis. Masuk lagi ke LMS."); e.code = "login"; return e; };
    const t = setInterval(async () => {
      if (finished || running || busy) return;
      busy = true; tries++;
      try {
        const s = parse(await run(ref, STATE)) || { st: "loading", href: "" };
        if (LOGIN_PAGE.test(s.href || "")) return end(reject, loginErr());
        if (s.st === "noauth" && tries > 8) return end(reject, loginErr());
        if (s.st !== "ready"){
          // Beberapa HP menunda halaman yang tersembunyi: tampilkan sebentar supaya tetap jalan.
          if (tries === 20 && !shown){ shown = true; try { ref.show(); } catch (e) {} }
          if (tries > 60) end(reject, new Error("LMS terlalu lama dimuat. Coba lagi sebentar lagi."));
          return;
        }
        running = true;
        await run(ref, `(function(){ window.__tkSync = { st: "run" }; try { (${SYNC}).then(function(r){ window.__tkSync = { st: "ok", data: r }; }, function(e){ window.__tkSync = { st: "err", msg: String((e && e.message) || e), code: e && e.response && e.response.status }; }); } catch (e) { window.__tkSync = { st: "err", msg: String(e && e.message || e) }; } return 1; })()`);
        let raw = null;
        for (let i = 0; i < 110 && !finished; i++){
          await new Promise(r => setTimeout(r, 1500));
          const st = parse(await run(ref, `JSON.stringify({ st: window.__tkSync && window.__tkSync.st, msg: window.__tkSync && window.__tkSync.msg, code: window.__tkSync && window.__tkSync.code, len: window.__tkSync && window.__tkSync.data ? window.__tkSync.data.length : 0 })`));
          if (!st || st.st === "run") continue;
          if (st.st === "err"){
            if (st.code === 401 || /401|unauth/i.test(st.msg || "")) return end(reject, loginErr());
            return end(reject, new Error("Gagal membaca data LMS: " + String(st.msg || "").slice(0, 200)));
          }
          // Data bisa besar: ambil per potongan supaya tidak tersendat di jembatan native.
          const parts = [];
          for (let p = 0; p < st.len; p += 400000) parts.push(await run(ref, `window.__tkSync.data.slice(${p}, ${p + 400000})`));
          raw = parts.join(""); break;
        }
        if (finished) return;
        if (raw === null) return end(reject, new Error("LMS terlalu lama mengirim data. Coba lagi."));
        const data = JSON.parse(raw);
        if (!data.courses || !data.courses.length) return end(reject, new Error("LMS tidak mengirim daftar kelas. Coba sinkron lagi sebentar lagi."));
        data.base = LMS; end(resolve, data);
      } catch (e) { if (!running && tries > 60) end(reject, new Error("Gagal membaca LMS: " + e.message)); else if (running) end(reject, new Error("Gagal membaca LMS: " + e.message)); }
      finally { busy = false; }
    }, 1500);
  });
}

module.exports = { login, logout, sync, normBase };
