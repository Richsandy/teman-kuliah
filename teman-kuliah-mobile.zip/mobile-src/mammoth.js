// mammoth versi browser; versi desktop memanggil extractRawText({ path }), di sini path dibaca dari memori.
const mammoth = require("mammoth/mammoth.browser.js");
const fs = require("./vfs");
module.exports = {
  extractRawText(o){
    if (o && o.path){ const b = fs.readFileSync(o.path); return mammoth.extractRawText({ arrayBuffer: b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength) }); }
    return mammoth.extractRawText(o);
  }
};
