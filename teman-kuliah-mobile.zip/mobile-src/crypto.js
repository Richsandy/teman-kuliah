// Pengganti modul "crypto" Node: hanya yang dipakai aplikasi (randomUUID dan sha256 hex).
const { sha256 } = require("js-sha256");
function randomUUID(){
  if (globalThis.crypto && globalThis.crypto.randomUUID) return globalThis.crypto.randomUUID();
  const b = new Uint8Array(16); globalThis.crypto.getRandomValues(b); b[6] = (b[6] & 15) | 64; b[8] = (b[8] & 63) | 128;
  const h = [...b].map(x => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
function createHash(alg){
  if (alg !== "sha256") throw new Error("Hash " + alg + " tidak didukung.");
  const h = sha256.create();
  const api = { update(s){ h.update(s); return api; }, digest(enc){ return enc === "hex" ? h.hex() : new Uint8Array(h.arrayBuffer()); } };
  return api;
}
module.exports = { randomUUID, createHash };
