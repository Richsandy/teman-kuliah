// Jembatan tipis ke plugin native Capacitor. Di browser biasa (untuk uji coba) plugin memakai versi web-nya.
const { Capacitor } = require("@capacitor/core");
const { Filesystem, Directory, Encoding } = require("@capacitor/filesystem");
const { LocalNotifications } = require("@capacitor/local-notifications");
const { Browser } = require("@capacitor/browser");
const { App } = require("@capacitor/app");
const { StatusBar, Style } = require("@capacitor/status-bar");

const ROOT = "tk";
const isNative = () => Capacitor.isNativePlatform();
const platform = () => Capacitor.getPlatform(); // "android" | "ios" | "web"

async function fsWrite(p, text){
  await Filesystem.writeFile({ path: ROOT + p, data: text, directory: Directory.Data, encoding: Encoding.UTF8, recursive: true });
}
async function fsRead(p){
  const r = await Filesystem.readFile({ path: ROOT + p, directory: Directory.Data, encoding: Encoding.UTF8 });
  return typeof r.data === "string" ? r.data : await r.data.text();
}
async function fsDelete(p){ await Filesystem.deleteFile({ path: ROOT + p, directory: Directory.Data }); }
async function fsList(){
  const r = await Filesystem.readdir({ path: ROOT + "/data", directory: Directory.Data }).catch(() => ({ files: [] }));
  return (r.files || []).filter(f => (f.type || "file") === "file").map(f => "/data/" + (f.name || f));
}

async function openUrl(url){
  if (!/^https:\/\//i.test(url)) return;
  try { await Browser.open({ url, presentationStyle: "popover" }); } catch (e) { window.open(url, "_blank"); }
}

let notifReady = null;
function ensureNotif(){
  if (!notifReady) notifReady = (async () => {
    try {
      let p = await LocalNotifications.checkPermissions();
      if (p.display !== "granted") p = await LocalNotifications.requestPermissions();
      if (platform() === "android"){
        await LocalNotifications.createChannel({ id: "tk", name: "Teman Kuliah", description: "Materi baru, tenggat, vicon, dan jam kuliah", importance: 4, visibility: 1, vibration: true }).catch(() => {});
        await LocalNotifications.createChannel({ id: "tk-alarm", name: "Alarm tenggat", description: "Alarm 3 jam sebelum tenggat dan vicon", importance: 5, visibility: 1, vibration: true }).catch(() => {});
      }
      return p.display === "granted";
    } catch (e) { return false; }
  })();
  return notifReady;
}
const base = (urgent) => platform() === "android" ? { channelId: urgent ? "tk-alarm" : "tk", smallIcon: "ic_stat_tk", iconColor: "#15171C" } : {};
let seq = 1;
async function notifyNow(title, body, urgent){
  if (!(await ensureNotif())) return;
  const id = 2000000000 + ((Date.now() / 1000 | 0) % 100000000) + (seq++ % 1000);
  await LocalNotifications.schedule({ notifications: [{ id, title, body, ...base(urgent), schedule: { at: new Date(Date.now() + 800), allowWhileIdle: true }, extra: { tk: "now" } }] }).catch(e => console.warn("notif", e));
}
// Jadwalkan ulang semua pengingat ke sistem HP, jadi tetap muncul walau aplikasi ditutup.
async function planNotifs(list){
  if (!(await ensureNotif())) return;
  try {
    const pend = await LocalNotifications.getPending();
    const ours = (pend.notifications || []).filter(n => n.extra && n.extra.tk === "plan");
    if (ours.length) await LocalNotifications.cancel({ notifications: ours.map(n => ({ id: n.id })) });
    const now = Date.now();
    const items = list.filter(x => x.at > now + 5000).sort((a, b) => a.at - b.at).slice(0, 55); // iOS: maks 64 notifikasi terjadwal
    if (!items.length) return;
    await LocalNotifications.schedule({ notifications: items.map(x => ({ id: x.id, title: x.title, body: x.body, ...base(x.urgent), schedule: { at: new Date(x.at), allowWhileIdle: true }, extra: { tk: "plan", key: x.key } })) });
  } catch (e) { console.warn("plan notif", e); }
}

function setStatusBar(dark){
  if (!isNative()) return;
  StatusBar.setStyle({ style: dark ? Style.Dark : Style.Light }).catch(() => {});
  if (platform() === "android") StatusBar.setBackgroundColor({ color: dark ? "#000000" : "#F3F4F6" }).catch(() => {});
}

module.exports = { isNative, platform, fsWrite, fsRead, fsDelete, fsList, openUrl, notifyNow, planNotifs, ensureNotif, setStatusBar, App, Browser };
