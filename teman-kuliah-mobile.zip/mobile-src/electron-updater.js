// Pengganti electron-updater: cek rilis terbaru di GitHub, lalu tombol update membuka unduhan APK (Android)
// atau halaman rilis (iPhone). Update tidak bisa dipasang diam-diam di HP.
const cap = require("./capbridge");
const pkg = { version: __APP_VERSION__ };
const REPO = "Richsandy/teman-kuliah";
const newer = (a, b) => { const x = String(a).replace(/^v/, "").split(".").map(Number), y = String(b).split(".").map(Number); for (let i = 0; i < 3; i++){ if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
const listeners = {};
let target = null;
const autoUpdater = {
  autoDownload: true,
  on(ev, fn){ (listeners[ev] = listeners[ev] || []).push(fn); return autoUpdater; },
  async checkForUpdates(){
    if (!cap.isNative()) return;
    const emit = (ev, v) => (listeners[ev] || []).forEach(f => f(v));
    emit("checking-for-update");
    let r;
    try { r = await fetch("https://api.github.com/repos/" + REPO + "/releases/latest", { headers: { Accept: "application/vnd.github+json" }, signal: AbortSignal.timeout(20000) }); }
    catch (e) { emit("error", e); return; }
    if (!r.ok){ emit("error", new Error("HTTP " + r.status + (r.status === 403 ? " rate limit" : ""))); return; }
    const j = await r.json();
    if (!newer(j.tag_name, pkg.version)){ emit("update-not-available", { version: pkg.version }); return; }
    const apk = (j.assets || []).find(a => /\.apk$/i.test(a.name));
    target = cap.platform() === "android" && apk ? apk.browser_download_url : j.html_url;
    const v = String(j.tag_name).replace(/^v/, "");
    // Di HP tidak ada unduhan di latar belakang: langsung siap, tombolnya membuka unduhan APK
    emit("update-available", { version: v });
    emit("update-downloaded", { version: v });
  },
  quitAndInstall(){ if (target) cap.openUrl(target); }
};
module.exports = { autoUpdater };
