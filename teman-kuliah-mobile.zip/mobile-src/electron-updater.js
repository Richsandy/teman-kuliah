// Pengganti electron-updater: cek rilis terbaru di GitHub, lalu tombol update membuka unduhan APK (Android)
// atau halaman rilis (iPhone). Update tidak bisa dipasang diam-diam di HP.
const cap = require("./capbridge");
const pkg = { version: __APP_VERSION__ };
const REPO = "Richsandy/teman-kuliah";
const newer = (a, b) => { const x = String(a).replace(/^v/, "").split(".").map(Number), y = String(b).split(".").map(Number); for (let i = 0; i < 3; i++){ if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
const listeners = {};
let target = null;
const autoUpdater = {
  autoDownload: true,
  on(ev, fn){ (listeners[ev] = listeners[ev] || []).push(fn); return autoUpdater; },
  async checkForUpdates(){
    if (!cap.isNative()) return;
    const r = await fetch("https://api.github.com/repos/" + REPO + "/releases/latest", { headers: { Accept: "application/vnd.github+json" } });
    if (!r.ok) return;
    const j = await r.json();
    if (!newer(j.tag_name, pkg.version)) return;
    const apk = (j.assets || []).find(a => /\.apk$/i.test(a.name));
    target = cap.platform() === "android" && apk ? apk.browser_download_url : j.html_url;
    (listeners["update-downloaded"] || []).forEach(f => f({ version: String(j.tag_name).replace(/^v/, "") }));
  },
  quitAndInstall(){ if (target) cap.openUrl(target); }
};
module.exports = { autoUpdater };
