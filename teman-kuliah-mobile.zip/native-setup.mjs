// Dijalankan setelah "npx cap add android/ios": atur versi, izin notifikasi, dan ikon notifikasi.
// Pakai: node native-setup.mjs android|ios
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const plat = process.argv[2];
const ver = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8")).version;
const [a, b, c] = ver.split(".").map(Number);
const code = a * 10000 + b * 100 + c;
const edit = (f, fn) => { const s = fs.readFileSync(f, "utf8"), t = fn(s); if (t === s) console.warn("Tidak ada perubahan: " + f); fs.writeFileSync(f, t); };

if (plat === "android"){
  const app = path.join(ROOT, "android", "app");
  edit(path.join(app, "build.gradle"), s => s.replace(/versionCode \d+/, "versionCode " + code).replace(/versionName "[^"]*"/, `versionName "${ver}"`));
  edit(path.join(app, "src", "main", "AndroidManifest.xml"), s => {
    const perms = ["android.permission.POST_NOTIFICATIONS", "android.permission.SCHEDULE_EXACT_ALARM", "android.permission.RECEIVE_BOOT_COMPLETED", "android.permission.WAKE_LOCK"]
      .filter(p => !s.includes(p)).map(p => `    <uses-permission android:name="${p}" />`).join("\n");
    return perms ? s.replace(/(\s*<uses-permission android:name="android.permission.INTERNET" \/>)/, `$1\n${perms}`) : s;
  });
  const res = path.join(ROOT, "native", "android-res");
  for (const d of fs.readdirSync(res)){ const to = path.join(app, "src", "main", "res", d); fs.mkdirSync(to, { recursive: true }); fs.copyFileSync(path.join(res, d, "ic_stat_tk.png"), path.join(to, "ic_stat_tk.png")); }
  console.log("Android siap: versi " + ver + " (" + code + ")");
} else if (plat === "ios"){
  const appDir = path.join(ROOT, "ios", "App");
  edit(path.join(appDir, "App.xcodeproj", "project.pbxproj"), s => s.replace(/MARKETING_VERSION = [^;]+;/g, `MARKETING_VERSION = ${ver};`).replace(/CURRENT_PROJECT_VERSION = [^;]+;/g, `CURRENT_PROJECT_VERSION = ${code};`));
  edit(path.join(appDir, "App", "Info.plist"), s => {
    const add = [];
    if (!s.includes("ITSAppUsesNonExemptEncryption")) add.push("\t<key>ITSAppUsesNonExemptEncryption</key>\n\t<false/>");
    if (!s.includes("UIViewControllerBasedStatusBarAppearance")) add.push("\t<key>UIViewControllerBasedStatusBarAppearance</key>\n\t<true/>");
    return add.length ? s.replace(/<\/dict>\s*<\/plist>\s*$/, add.join("\n") + "\n</dict>\n</plist>\n") : s;
  });
  console.log("iOS siap: versi " + ver + " (" + code + ")");
} else { console.error("Pakai: node native-setup.mjs android|ios"); process.exit(1); }
