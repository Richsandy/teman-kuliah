// Dijalankan setelah "npx cap add android/ios": atur versi, izin notifikasi, dan ikon notifikasi.
// Pakai: node native-setup.mjs android|ios
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const plat = process.argv[2];
const ver = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8")).version;
const [a, b, c] = ver.split(".").map(Number);
const code = a * 10000 + b * 100 + c;
const edit = (f, fn) => { const s = fs.readFileSync(f, "utf8"), t = fn(s); if (t === s) console.warn("Tidak ada perubahan: " + f); fs.writeFileSync(f, t); };

if (plat === "android"){
  const app = path.join(ROOT, "android", "app");
  edit(path.join(app, "build.gradle"), s => s.replace(/versionCode \d+/, "versionCode " + code).replace(/versionName "[^"]*"/, `versionName "${ver}"`));
  edit(path.join(app, "src", "main", "AndroidManifest.xml"), s => {
    const perms = ["android.permission.POST_NOTIFICATIONS", "android.permission.SCHEDULE_EXACT_ALARM", "android.permission.RECEIVE_BOOT_COMPLETED", "android.permission.WAKE_LOCK"]
      .filter(p => !s.includes(p)).map(p => `    <uses-permission android:name="${p}" />`).join("\n");
    return perms ? s.replace(/(\s*<uses-permission android:name="android.permission.INTERNET" \/>)/, `$1\n${perms}`) : s;
  });
  // Ukuran huruf sistem Android tidak ikut memperbesar tampilan (desain HP Teman Kuliah sudah diatur sendiri).
  const mains = [];
  const walk = d => { for (const f of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, f.name); if (f.isDirectory()) walk(p); else if (f.name === "MainActivity.java") mains.push(p); } };
  walk(path.join(app, "src", "main", "java"));
  if (mains.length !== 1) throw new Error("MainActivity.java tidak ditemukan (" + mains.length + ")");
  // Fitur "Dengarkan ringkasan": WebView Android tidak punya speechSynthesis, jadi suara HP (TextToSpeech bawaan Android)
  // disambungkan ke tampilan lewat window.TKSuara (bicara/stop). Selesai tiap kalimat dikabarkan lewat window.__tkSuara.
  // Proyek baru (cap add) berisi kelas kosong. Kalau MainActivity sudah pernah ditambal versi lama (setTextZoom tanpa TKSuara), ditambal ulang dari awal.
  edit(mains[0], s => s.includes("TKSuara") ? s : s
    .replace(/public class MainActivity extends BridgeActivity \{[\s\S]*\}\s*$/, "public class MainActivity extends BridgeActivity {}\n")
    .replace("import com.getcapacitor.BridgeActivity;", `import com.getcapacitor.BridgeActivity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.util.Locale;`)
    .replace(/public class MainActivity extends BridgeActivity \{\s*\}/, `public class MainActivity extends BridgeActivity {
    private TextToSpeech tts;
    private boolean ttsSiap = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            WebView wv = getBridge().getWebView();
            wv.addJavascriptInterface(new Suara(), "TKSuara"); // dipasang sebelum halaman selesai dimuat, jadi langsung terlihat oleh tampilan
        } catch (Exception e) { }
    }

    // Teman Kuliah memakai ukuran hurufnya sendiri: ukuran huruf sistem tidak memperbesar tampilan aplikasi.
    @Override
    public void onResume() {
        super.onResume();
        if (getBridge() != null && getBridge().getWebView() != null) getBridge().getWebView().getSettings().setTextZoom(100);
    }

    @Override
    public void onDestroy() {
        if (tts != null) { try { tts.stop(); tts.shutdown(); } catch (Exception e) { } }
        super.onDestroy();
    }

    private void kabari(final String ev, final String id) {
        runOnUiThread(new Runnable() { public void run() {
            try { getBridge().getWebView().evaluateJavascript("window.__tkSuara && window.__tkSuara('" + ev + "','" + id.replaceAll("[^0-9a-zA-Z.]", "") + "')", null); } catch (Exception e) { }
        }});
    }

    private Runnable tunda = null;
    private String idTunda = "";
    private boolean ttsGagal = false;
    private boolean tanpaIndonesia = false;

    // Mesin suara Android disiapkan saat pertama dipakai. Permintaan selama persiapan disimpan (yang terakhir), lalu dijalankan.
    private void siapkan(final Runnable lalu, final String id) {
        if (tts != null && ttsSiap) { lalu.run(); return; }
        if (ttsGagal) { kabari("error", id); return; }
        tunda = lalu; idTunda = id;
        if (tts != null) return;
        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            public void onInit(int status) {
                ttsSiap = status == TextToSpeech.SUCCESS;
                if (!ttsSiap) { ttsGagal = true; kabari("error", idTunda); tunda = null; return; }
                // HP tanpa suara bahasa Indonesia: tampilan diberi tahu ("nolang") lalu memakai suara Google online
                try { int r = tts.setLanguage(new Locale("id", "ID")); if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tanpaIndonesia = true; } catch (Exception e) { tanpaIndonesia = true; }
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    public void onStart(String id) { }
                    public void onDone(String id) { kabari("done", id); }
                    public void onError(String id) { kabari("error", id); }
                });
                Runnable r = tunda; tunda = null; if (r != null) r.run();
            }
        });
    }

    public class Suara {
        @JavascriptInterface
        public void bicara(final String teks, final float laju, final String id) {
            runOnUiThread(new Runnable() { public void run() {
                siapkan(new Runnable() { public void run() {
                    if (tanpaIndonesia) { kabari("nolang", id); return; }
                    try { tts.setSpeechRate(laju); tts.speak(teks, TextToSpeech.QUEUE_FLUSH, null, id); } catch (Exception e) { kabari("error", id); }
                }}, id);
            }});
        }
        @JavascriptInterface
        public void stop() {
            runOnUiThread(new Runnable() { public void run() { tunda = null; if (tts != null) { try { tts.stop(); } catch (Exception e) { } } } });
        }
    }
}`));
  if (!fs.readFileSync(mains[0], "utf8").includes("setTextZoom(100)") || !fs.readFileSync(mains[0], "utf8").includes("TKSuara")) throw new Error("Patch MainActivity gagal");
  // Jendela login Edlink (InAppBrowser) juga: dengan huruf sistem besar, halaman login jadi terlalu besar dan harus digeser.
  // File plugin di node_modules disalin ke proyek Android oleh "cap sync", jadi yang diubah keduanya.
  const iabFiles = [path.join(ROOT, "node_modules", "cordova-plugin-inappbrowser", "src", "android", "InAppBrowser.java")];
  const walkIab = d => { if (!fs.existsSync(d)) return; for (const f of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, f.name); if (f.isDirectory()) walkIab(p); else if (f.name === "InAppBrowser.java") iabFiles.push(p); } };
  walkIab(path.join(ROOT, "android", "capacitor-cordova-android-plugins"));
  for (const f of iabFiles){
    if (!fs.existsSync(f)) continue;
    edit(f, s => s.includes("setTextZoom(100)") ? s : s.replace("inAppWebView.getSettings().setUseWideViewPort(useWideViewPort);", "inAppWebView.getSettings().setUseWideViewPort(useWideViewPort);\n                inAppWebView.getSettings().setTextZoom(100);"));
    if (!fs.readFileSync(f, "utf8").includes("setTextZoom(100)")) throw new Error("Patch InAppBrowser gagal: " + f);
  }
  const res = path.join(ROOT, "native", "android-res");
  for (const d of fs.readdirSync(res)){ const to = path.join(app, "src", "main", "res", d); fs.mkdirSync(to, { recursive: true }); fs.copyFileSync(path.join(res, d, "ic_stat_tk.png"), path.join(to, "ic_stat_tk.png")); }
  console.log("Android siap: versi " + ver + " (" + code + ")");
} else if (plat === "ios"){
  const appDir = path.join(ROOT, "ios", "App");
  edit(path.join(appDir, "App.xcodeproj", "project.pbxproj"), s => s.replace(/MARKETING_VERSION = [^;]+;/g, `MARKETING_VERSION = ${ver};`).replace(/CURRENT_PROJECT_VERSION = [^;]+;/g, `CURRENT_PROJECT_VERSION = ${code};`));
  edit(path.join(appDir, "App", "Info.plist"), s => {
    const add = [];
    if (!s.includes("ITSAppUsesNonExemptEncryption")) add.push("\t<key>ITSAppUsesNonExemptEncryption</key>\n\t<false/>");
    if (!s.includes("UIViewControllerBasedStatusBarAppearance")) add.push("\t<key>UIViewControllerBasedStatusBarAppearance</key>\n\t<true/>");
    return add.length ? s.replace(/<\/dict>\s*<\/plist>\s*$/, add.join("\n") + "\n</dict>\n</plist>\n") : s;
  });
  console.log("iOS siap: versi " + ver + " (" + code + ")");
} else { console.error("Pakai: node native-setup.mjs android|ios"); process.exit(1); }
