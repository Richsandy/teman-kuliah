// Merakit versi HP dari source desktop Teman Kuliah.
// Pakai: node build.mjs [folder-source-desktop]   (default: ../app, yaitu isi teman-kuliah-source.zip)
// Hasil: folder www/ (tampilan + core.js) yang dibungkus Capacitor jadi aplikasi Android dan iPhone.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import * as esbuild from "esbuild";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const DESK = path.resolve(process.argv[2] || process.env.DESKTOP_SRC || path.join(ROOT, "..", "app"));
const GEN = path.join(ROOT, ".gen"), WWW = path.join(ROOT, "www"), MS = path.join(ROOT, "mobile-src");
if (!fs.existsSync(path.join(DESK, "src", "main.js"))) { console.error("Source desktop tidak ditemukan di " + DESK); process.exit(1); }

const read = p => fs.readFileSync(p, "utf8");
// Ganti teks persis; berhenti kalau teks aslinya tidak ketemu (artinya source desktop berubah dan patch perlu dicek).
function patch(src, from, to, label, { all = false, optional = false } = {}){
  const hit = typeof from === "string" ? src.includes(from) : from.test(src);
  if (!hit){ if (optional) return src; throw new Error("Patch gagal (" + label + "): teks tidak ditemukan."); }
  if (typeof from === "string") return all ? src.split(from).join(to) : src.replace(from, () => to);
  return src.replace(from, to);
}

fs.rmSync(GEN, { recursive: true, force: true }); fs.rmSync(WWW, { recursive: true, force: true });
fs.mkdirSync(path.join(GEN, "src"), { recursive: true }); fs.mkdirSync(WWW, { recursive: true });
const deskPkg = JSON.parse(read(path.join(DESK, "package.json")));
fs.writeFileSync(path.join(GEN, "package.json"), JSON.stringify(deskPkg));

/* ---------- kode "main" desktop ---------- */
for (const f of fs.readdirSync(path.join(DESK, "src"))) if (f.endsWith(".js")) fs.copyFileSync(path.join(DESK, "src", f), path.join(GEN, "src", f));
let main = read(path.join(GEN, "src", "main.js"));
main = patch(main, `store = new Store(app.getPath("userData"));`, `store = new Store(app.getPath("userData")); globalThis.__tkStore = store;`, "store global");
main = patch(main, `function push(){ identity();`, `function push(){ identity(); require("__mobile__").planReminders(store, absensiMode);`, "pengingat terjadwal");
main = patch(main, `setInterval(checkReminders, 60000); setTimeout(checkReminders, 8000);`, `setTimeout(() => require("__mobile__").planReminders(store, absensiMode), 3000);`, "pengingat");
// Video besar tidak diunduh ke HP: dibaca lewat link (transkrip Whisper) kalau tersedia
main = patch(main, `if (f.video && !geminiOn){`, `if (f.video && (!geminiOn || f.size > 80 * 1024 * 1024)){`, "video besar");
main = patch(main, `const r = await ingest.run(store, { courseId: j.c.id, meet: j.meet, items }, { merge: true }, msg => status({ auto: \`\${lbl}: \${msg}\` }));`,
  `let r; try { r = await ingest.run(store, { courseId: j.c.id, meet: j.meet, items }, { merge: true }, msg => status({ auto: \`\${lbl}: \${msg}\` })); } finally { items.forEach(it => { if (it.path) try { fs.unlinkSync(it.path); } catch (e) {} }); }`, "bersihkan lampiran");
main = patch(main, `const r = await ingest.run(store, group, opts || {}, msg => status({ ingest: msg }));`,
  `const r = await ingest.run(store, group, opts || {}, msg => status({ ingest: msg })); (group.items || []).forEach(it => { if (it.path && it.path.startsWith("/data/picked/")) try { fs.unlinkSync(it.path); } catch (e) {} });`, "bersihkan file pilihan");
fs.writeFileSync(path.join(GEN, "src", "main.js"), main);
// Teks alasan file dari dosen (1.0.13 ke atas) yang menyebut "seret ke aplikasi"
for (const f of ["process.js"]){
  const p = path.join(GEN, "src", f); let s = read(p);
  s = s.split("lalu seret ke aplikasi.").join("lalu tambahkan lewat Tambah materi.");
  fs.writeFileSync(p, s);
}
let lms = read(path.join(GEN, "src", "lms.js"));
lms = patch(lms, `module.exports = { login, logout, sync, normBase };`, `module.exports = { login, logout, sync, normBase, SYNC };`, "SYNC");
fs.writeFileSync(path.join(GEN, "src", "lms.js"), lms);
// Skrip sinkron desktop (SYNC) juga dijadikan fungsi biasa, supaya di HP bisa dijalankan langsung di aplikasi:
// permintaan ke api.edlink.id lewat HTTP native (mobile-src/net.js), bukan di jendela web Edlink yang tersembunyi.
{
  const m = lms.match(/const SYNC = `([\s\S]*?)`;\n/);
  if (!m) throw new Error("Patch gagal (SYNC native): const SYNC tidak ditemukan.");
  if (m[1].includes("${")) throw new Error("Patch gagal (SYNC native): SYNC berisi ${...}.");
  const code = new Function("return `" + m[1] + "`;")();
  fs.writeFileSync(path.join(GEN, "sync-native.js"), "// Dibuat otomatis dari SYNC di src/lms.js desktop\nmodule.exports = function($nuxt){ return " + code.trim() + "; };\n");
}

const alias = {
  electron: path.join(MS, "electron.js"),
  "electron-updater": path.join(MS, "electron-updater.js"),
  fs: path.join(MS, "vfs.js"),
  crypto: path.join(MS, "crypto.js"),
  path: path.join(ROOT, "node_modules", "path-browserify", "index.js"),
  url: path.join(MS, "url.js"),
  "pdf-parse/lib/pdf-parse.js": path.join(MS, "pdf-parse.js"),
  mammoth: path.join(MS, "mammoth.js"),
  __desktop_main__: path.join(GEN, "src", "main.js"),
  __desktop_lms__: path.join(GEN, "src", "lms.js"),
  __sync_native__: path.join(GEN, "sync-native.js"),
  __mobile__: path.join(MS, "mobile.js"),
  __viscore__: path.join(GEN, "src", "viscore.js"),
  __belajar__: path.join(GEN, "src", "belajar.js")
};
// window.api versi HP diambil dari preload.js desktop: invoke ke channel yang sama, event ke channel yang sama.
{
  const pre = read(path.join(DESK, "src", "preload.js"));
  const body = pre.slice(pre.indexOf("exposeInMainWorld"));
  const names = [...body.matchAll(/^\s*(\w+)\s*:/gm)].map(m => m[1]);
  const inv = Object.fromEntries([...body.matchAll(/^\s*(\w+)\s*:[^\n]*?ipcRenderer\.invoke\("([^"]+)"/gm)].map(m => [m[1], m[2]]));
  const ev = Object.fromEntries([...body.matchAll(/^\s*(\w+)\s*:[^\n]*?ipcRenderer\.on\("([^"]+)"/gm)].map(m => [m[1], m[2]]));
  const HP = ["pickFiles", "openGuide", "openGuideFile", "pathOf"]; // dibuat khusus di mobile-src/boot.js
  HP.forEach(k => delete inv[k]);
  const lupa = names.filter(k => !(k in inv) && !(k in ev) && !HP.includes(k));
  if (lupa.length) throw new Error("Fungsi preload.js desktop belum ada versi HP-nya: " + lupa.join(", ") + ". Tambahkan di mobile-src/boot.js.");
  const mainSrc = read(path.join(GEN, "src", "main.js"));
  const tanpaHandler = Object.entries(inv).filter(([, c]) => !mainSrc.includes(`"${c}"`) && c !== "update:install").map(([k]) => k);
  if (tanpaHandler.length) console.warn("Peringatan: channel tanpa handler di main.js: " + tanpaHandler.join(", "));
  fs.writeFileSync(path.join(GEN, "channels.json"), JSON.stringify({ invoke: inv, events: ev }));
  alias.__channels__ = path.join(GEN, "channels.json");
  console.log("window.api: " + Object.keys(inv).length + " fungsi, " + Object.keys(ev).length + " event dari preload.js");
}
fs.writeFileSync(path.join(MS, "url.js"), "module.exports = { pathToFileURL: p => ({ href: String(p) }), URL: globalThis.URL };\n");
const shimPlugin = {
  name: "tk-shim",
  setup(b){
    b.onResolve({ filter: /.*/ }, a => {
      if (alias[a.path] && !(a.path === "mammoth" && a.importer === alias.mammoth)) return { path: alias[a.path] };
      if (a.path === "./lms" && a.importer === alias.__desktop_main__) return { path: path.join(MS, "lms.js") }; // LMS versi HP
      if (a.path === "./visr" && a.importer.startsWith(GEN)) return { path: path.join(MS, "visr.js") }; // pengolah gambar ringkasan versi HP (tanpa jendela tersembunyi)
      if (a.path === "../package.json" && a.importer.startsWith(GEN)) return { path: path.join(GEN, "package.json") };
      return null;
    });
  }
};
await esbuild.build({
  entryPoints: [path.join(MS, "boot.js")], bundle: true, format: "iife", platform: "browser", target: ["chrome90", "safari15"],
  outfile: path.join(WWW, "core.js"), plugins: [shimPlugin], minify: true, legalComments: "none", logLevel: "warning",
  define: { __APP_VERSION__: JSON.stringify(deskPkg.version), "process.env.NODE_ENV": '"production"' },
  nodePaths: [path.join(ROOT, "node_modules")]
});

/* ---------- tampilan desktop (renderer) ---------- */
const R = path.join(DESK, "src", "renderer");
for (const f of fs.readdirSync(R, { recursive: true })){
  const s = path.join(R, f), d = path.join(WWW, f);
  if (fs.statSync(s).isDirectory()) fs.mkdirSync(d, { recursive: true }); else fs.copyFileSync(s, d);
}
let js = read(path.join(WWW, "app.js"));
const T = (from, to, label, o) => { js = patch(js, from, to, label, o); };
T(`["auto","Ikuti Windows"]`, `["auto","Ikuti HP"]`, "tema");
T(/<div class="field"><div class="inline" style="justify-content:space-between"><label for="background">[\s\S]*?Notifikasi muncul setiap dosen posting\.<\/p><\/div>/,
  `<div class="field"><label>Di HP</label><p class="cap">Sinkron berjalan setiap aplikasi dibuka dan tiap 30 menit selama terbuka. Pengingat tenggat, vicon, jam kuliah, dan komentar absensi tetap muncul walau aplikasi ditutup.</p></div>`, "latar belakang");
T(`Muncul sebagai notifikasi Windows selama aplikasi menyala`, `Muncul sebagai notifikasi HP, walau aplikasi ditutup`, "pengingat");
T(`\${!S.settings.background ? `, `\${false ? `, "peringatan latar");
T(`tersimpan di laptop ini, di folder AppData aplikasi`, `tersimpan di HP ini, di penyimpanan aplikasi`, "data");
T(`Seret file atau folder ke jendela ini, atau tempel link YouTube / ringkasan video.`, `Pilih file dari HP, atau tempel link YouTube / ringkasan video.`, "tambah materi");
T(` Seret file dari folder kuliahmu ke jendela ini untuk menambah.`, ` Ketuk Tambah materi untuk menambah dari file di HP.`, "materi kosong");
T(`Belum ada file. Seret file/folder ke sini, atau`, `Belum ada file. Pilih PDF, PPTX, DOCX, atau foto materi.`, "kosong");
T(`<button class="btn" data-act="pick" data-folder="1">Pilih folder</button>`, ``, "folder", { all: true });
T(`<button class="btn sm" data-act="pick" data-folder="1">Pilih folder</button>`, ``, "folder kecil", { all: true });
T(`Mulai ulang untuk update`, `Ketuk untuk mengunduh`, "update");
T(`placeholder="Tulis pertanyaanmu. Enter untuk kirim, Shift+Enter untuk baris baru."`, `placeholder="Tulis pertanyaanmu..."`, "placeholder chat", { optional: true });
T(`placeholder="Tulis jawaban atau pertanyaanmu. Enter untuk kirim."`, `placeholder="Tulis jawaban atau pertanyaanmu..."`, "placeholder pandu", { optional: true });
T(`<button class="btn" data-act="guide-file">Buka file PDF</button>`, ``, "panduan file");
T(`Login lewat halaman resmi Edlink di jendela aplikasi.`, `Login lewat halaman resmi Edlink di dalam aplikasi.`, "login", { optional: true });
js = js.replace(/\bKlik\b/g, "Ketuk").replace(/\bklik\b/g, "ketuk");
// Tombol Kembali Android butuh akses ke navigasi app.js (go() ada di dalam closure)
js = js.replace(/(\nfunction go\(v, opts=\{\}\)\{[^\n]*\n)/, (m) => m + "window.__tkNav = { view: () => UI.view, go: v => go(v) };\n");
if (!js.includes("window.__tkNav")) throw new Error("Patch gagal (navigasi): function go() tidak ditemukan.");
fs.writeFileSync(path.join(WWW, "app.js"), js);

// Tema gelap paksa: desktop memakai tema sistem Electron; di HP tema dipaksa lewat atribut data-theme.
function forceDark(css){
  let out = css, extra = "";
  const re = /@media \(prefers-color-scheme: dark\)\{/g; let m;
  while ((m = re.exec(css))){
    let i = m.index + m[0].length, depth = 1;
    while (depth && i < css.length){ if (css[i] === "{") depth++; else if (css[i] === "}") depth--; i++; }
    const inner = css.slice(m.index + m[0].length, i - 1);
    if (inner.includes(':root:not([data-theme="light"])')) extra += inner.split(':root:not([data-theme="light"])').join(':root[data-theme="dark"]') + "\n";
  }
  return out + "\n/* tema gelap paksa (HP) */\n" + extra;
}
// Ukuran HP: desain desktop dipadatkan seragam (huruf sedikit lebih kecil, jarak/kotak/sudut lebih rapat).
// Tampilan dan susunannya tetap sama; batas @media tidak diubah. Nilai <= 2px (garis) dibiarkan.
const HURUF = 0.93, JARAK = 0.86;
const RUANG = /^(--[\w-]+|padding(-[a-z-]+)?|margin(-[a-z-]+)?|gap|row-gap|column-gap|width|height|min-width|min-height|max-width|max-height|top|right|bottom|left|inset(-[a-z-]+)?|border-radius|border(-[a-z]+)+-radius|flex|flex-basis|grid-template-columns|grid-template-rows|grid-auto-rows|transform|translate|scroll-margin-top|scroll-padding-top|text-indent|background-size)$/i;
function padatkan(css){
  return css.replace(/(@(?:media|supports|container)[^{]*\{)|([\w-]+)(\s*:\s*)([^;{}]+)/g, (m, at, prop, sep, val) => {
    if (at) return at;
    const p = prop.toLowerCase();
    const f = /^(font-size|line-height|font)$/.test(p) ? HURUF : RUANG.test(p) ? JARAK : null;
    if (!f) return m;
    return prop + sep + val.replace(/(-?\d*\.?\d+)px/g, (x, n) => { const v = parseFloat(n); return Math.abs(v) <= 2 ? x : (Math.round(v * f * 10) / 10) + "px"; });
  });
}
fs.writeFileSync(path.join(WWW, "base.css"), padatkan(read(path.join(WWW, "base.css"))));
fs.writeFileSync(path.join(WWW, "app.css"), forceDark(padatkan(read(path.join(WWW, "app.css")))));
fs.copyFileSync(path.join(MS, "mobile.css"), path.join(WWW, "mobile.css"));

let html = read(path.join(WWW, "index.html"));
html = patch(html, `<meta name="viewport" content="width=device-width, initial-scale=1">`, `<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1">\n<meta name="color-scheme" content="light dark">`, "viewport");
html = patch(html, /<meta http-equiv="Content-Security-Policy"[^>]*>/, `<meta http-equiv="Content-Security-Policy" content="default-src 'self' capacitor: https://localhost; connect-src 'self' https: http://127.0.0.1:* http://localhost:* capacitor:; img-src 'self' data: blob: https://i.ytimg.com; media-src 'self' blob: capacitor:; style-src 'self' 'unsafe-inline'; font-src 'self' data:; script-src 'self'; worker-src 'self' blob:">`, "CSP");
html = patch(html, `<link rel="stylesheet" href="app.css">`, `<link rel="stylesheet" href="app.css">\n<link rel="stylesheet" href="mobile.css">`, "mobile css");
html = patch(html, `<script src="app.js"></script>`, `<script src="core.js"></script>\n<script src="app.js"></script>`, "core");
html = html.replace(`<body>`, `<body class="tk-mobile">`);
fs.writeFileSync(path.join(WWW, "index.html"), html);

fs.copyFileSync(path.join(ROOT, "node_modules", "pdfjs-dist", "legacy", "build", "pdf.worker.min.js"), path.join(WWW, "pdf.worker.min.js"));
const guide = path.join(DESK, "docs", "Panduan Teman Kuliah.pdf");
if (fs.existsSync(guide)) fs.copyFileSync(guide, path.join(WWW, "Panduan Teman Kuliah.pdf"));

// Versi aplikasi HP mengikuti versi desktop
const mp = JSON.parse(read(path.join(ROOT, "package.json"))); if (mp.version !== deskPkg.version){ mp.version = deskPkg.version; fs.writeFileSync(path.join(ROOT, "package.json"), JSON.stringify(mp, null, 2) + "\n"); }
console.log("Teman Kuliah HP " + deskPkg.version + " siap di www/ (" + Math.round(fs.statSync(path.join(WWW, "core.js")).size / 1024) + " KB core.js)");
